#!/usr/bin/env python3
"""Rebuild selected Lean theorem modules from source in an isolated directory.

Requires the pinned Lean 4.33.1 toolchain. No Z3, CVC5, Python theorem checker,
or pre-existing .olean file is used to prove any theorem.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, re, shutil, subprocess, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'lean'
PINNED = '4.33.1'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def closure(targets):
    modules = {}
    def visit(name, stack=()):
        if name in stack:
            raise ValueError(f'Import cycle: {stack + (name,)}')
        if name in modules:
            return
        path = SOURCE / (name.replace('.', '/') + '.lean')
        if not path.is_file():
            raise FileNotFoundError(path)
        imports = []
        for line in path.read_text().splitlines():
            found = re.match(r'^import\s+([A-Za-z0-9_. ]+)', line)
            if found:
                for dep in found.group(1).split():
                    if (SOURCE / (dep.replace('.', '/') + '.lean')).is_file():
                        imports.append(dep)
        for dep in imports:
            visit(dep, stack + (name,))
        modules[name] = {'path': path, 'imports': imports}
    for target in targets:
        visit(target)
    return modules

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('targets', nargs='+', help='For example GunFamilyClassification or TClassification')
    p.add_argument('--lean', help='Path to Lean 4.33.1 executable')
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--output', type=Path, default=ROOT / '.build' / 'lean')
    p.add_argument('--list', action='store_true', help='Only list the source dependency order')
    args = p.parse_args()
    modules = closure(args.targets)
    if args.list:
        print(json.dumps({'targets': args.targets, 'modules': list(modules), 'count': len(modules)}, indent=2))
        return
    executable = args.lean or shutil.which('lean')
    if not executable:
        bundled = ROOT / '.tools' / 'lean-4.33.1-darwin_aarch64' / 'bin' / 'lean'
        if bundled.is_file():
            executable = str(bundled)
    if not executable:
        p.error('Install Lean 4.33.1, or pass --lean /absolute/path/to/lean')
    version = subprocess.check_output([executable, '--version'], text=True).strip()
    if not re.search(r'\b4\.33\.1\b', version):
        p.error(f'Expected Lean {PINNED}; found {version}')
    out = args.output.resolve()
    if out == SOURCE.resolve():
        p.error('Use an isolated output directory, not the source directory')
    out.mkdir(parents=True, exist_ok=True)
    logs = out / 'logs'
    logs.mkdir(exist_ok=True)
    receipts_path = out / 'receipts.json'
    old = json.loads(receipts_path.read_text()) if receipts_path.exists() else {}
    receipts = {}
    env = dict(os.environ, LEAN_PATH=str(out))
    start = time.monotonic()
    def compile_one(name):
        module = modules[name]
        artifact = out / (name.replace('.', '/') + '.olean')
        artifact.parent.mkdir(parents=True, exist_ok=True)
        evidence = {'source_sha256': digest(module['path']),
                    'imports': {dep: receipts[dep]['compiled_sha256'] for dep in module['imports']},
                    'lean_version': version}
        previous = old.get('modules', {}).get(name, {})
        if artifact.exists() and all(previous.get(k) == v for k, v in evidence.items()) and previous.get('compiled_sha256') == digest(artifact):
            return name, dict(previous, cached=True)
        begun = time.monotonic()
        result = subprocess.run([executable, '-o', str(artifact), str(module['path'])], cwd=ROOT,
                                env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log = logs / (name + '.log')
        log.write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(f'{name} failed; inspect {log}\n{result.stdout[-4000:]}')
        if digest(module['path']) != evidence['source_sha256']:
            raise RuntimeError(f'{name} source changed during compilation; run again')
        # An admitted term cannot enter the accepted dependency closure.
        if 'sorryAx' in result.stdout or 'declaration uses `sorry`' in result.stdout:
            raise RuntimeError(f'{name} used an admitted term; inspect {log}')
        return name, dict(evidence, compiled_sha256=digest(artifact),
                          elapsed_seconds=time.monotonic()-begun, cached=False,
                          log=str(log.relative_to(out)))
    pending = set(modules)
    running = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        while pending or running:
            ready = [n for n in modules if n in pending and all(d in receipts for d in modules[n]['imports'])]
            for name in ready[:max(1, args.jobs)-len(running)]:
                pending.remove(name)
                running[pool.submit(compile_one, name)] = name
            if not running:
                raise RuntimeError('No buildable source modules remain')
            done, _ = concurrent.futures.wait(running, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                running.pop(future)
                name, receipt = future.result()
                receipts[name] = receipt
                print(f'{len(receipts)}/{len(modules)} {name}: '+('cached' if receipt['cached'] else 'compiled'), flush=True)
                receipts_path.write_text(json.dumps({'targets': args.targets, 'modules': receipts,
                    'elapsed_seconds': time.monotonic()-start}, indent=2)+'\n')
    print(f'All {len(modules)} modules verified. Receipts: {receipts_path}', flush=True)

if __name__ == '__main__':
    main()

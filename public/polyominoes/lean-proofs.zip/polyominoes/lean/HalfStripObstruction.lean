import TilingCore
import CornerCertificateCore

namespace PolyominoFormal
namespace HalfStripObstruction

open CrossUnits CornerCertificate

/-- This is a proof obligation, not an axiom: the finite certificate replay
    supplies it separately for each parameter family. -/
def LocalTheorem (a : Int) : Prop :=
  ∀ (world : Cross → Prop) (h : Int) (k : Kind) (B : Region),
    (∀ t, world t → Copy a 1 1 0 t) → DisjointWorld world →
    CoversWindow world h → SelectedBelow world h →
    TileClosed world B → Below h B → Clean k 0 0 B →
    Transition world h k B

def localWorld (world : Cross → Prop) (X Y : Int) : Cross → Prop :=
  fun t => world (shift X Y t)

theorem shifted_contains (X Y x y : Int) (t : Cross) :
    Contains (shift X Y t) (X+x) (Y+y) ↔ Contains t x y := by
  rw [contains_shift]
  have hx : X+x-X=x := by omega
  have hy : Y+y-Y=y := by omega
  rw [hx,hy]

theorem unshift_contains (X Y x y : Int) (t : Cross) :
    Contains (shift (-X) (-Y) t) x y ↔ Contains t (X+x) (Y+y) := by
  rw [contains_shift]
  have hx : x - -X=X+x := by omega
  have hy : y - -Y=Y+y := by omega
  rw [hx,hy]

theorem inverse_shift (X Y : Int) (t : Cross) :
    shift X Y (shift (-X) (-Y) t)=t := by
  rw [shift_add]
  have hx : -X+X=0 := by omega
  have hy : -Y+Y=0 := by omega
  rw [hx,hy,shift_zero]

theorem propagate {a H : Int} (stepProof : LocalTheorem a)
    (T : Tiling a 1 1 0 (HalfStrip H))
    (X Y : Int) (k : Kind) (B : Region)
    (hX : 0 ≤ X) (hY : 0 ≤ Y)
    (closed : TileClosed T.world B) (bounded : Below H B)
    (clean : Clean k X Y B) :
    ∃ (B' : Region) (new : Kind) (dx dy : Int),
      TileClosed T.world B' ∧ Below H B' ∧
      Clean new (X+dx) (Y+dy) B' ∧ Progress k new dx dy := by
  let W := localWorld T.world X Y
  let C : Region := fun x y => B (X+x) (Y+y)
  have wc : ∀ t, W t → Copy a 1 1 0 t := by
    intro t ht
    exact (copy_shift a 1 1 0 X Y t).1 (T.copies _ ht)
  have wd : DisjointWorld W := by
    intro t u x y ht hu hc hd
    apply shift_injective X Y
    exact T.disjoint _ _ (X+x) (Y+y) ht hu
      ((shifted_contains X Y x y t).2 hc)
      ((shifted_contains X Y x y u).2 hd)
  have cover : CoversWindow W (H-Y) := by
    intro x y ⟨hx, hx7, hy, hyH⟩
    obtain ⟨t, ht, hc⟩ := T.cover (X+x) (Y+y) (by
      unfold HalfStrip; exact ⟨by omega, by omega, by omega⟩)
    refine ⟨shift (-X) (-Y) t, ?_, (unshift_contains X Y x y t).2 hc⟩
    show T.world (shift X Y (shift (-X) (-Y) t))
    simpa only [inverse_shift] using ht
  have selected : SelectedBelow W (H-Y) := by
    intro t ht _ x y hc
    have hb := T.inside _ ht (X+x) (Y+y) ((shifted_contains X Y x y t).2 hc)
    unfold HalfStrip at hb
    omega
  have cc : TileClosed W C := by
    intro t ht x y hc hb u v hd
    exact closed _ ht (X+x) (Y+y) ((shifted_contains X Y x y t).2 hc) hb
      (X+u) (Y+v) ((shifted_contains X Y u v t).2 hd)
  have cb : Below (H-Y) C := by
    intro x y hb
    have := bounded (X+x) (Y+y) hb
    omega
  have ck : Clean k 0 0 C := by
    simpa only [Clean, C, Int.zero_add] using clean
  obtain ⟨D, new, dx, dy, added, dc, db, dk, dp⟩ :=
    stepProof W (H-Y) k C wc wd cover selected cc cb ck
  let B' : Region := fun x y => D (x-X) (y-Y)
  refine ⟨B', new, dx, dy, ?_, ?_, ?_, dp⟩
  · intro t ht x y hc hb u v hd
    have tw : W (shift (-X) (-Y) t) := by
      show T.world (shift X Y (shift (-X) (-Y) t))
      simpa only [inverse_shift] using ht
    have hc' : Contains (shift (-X) (-Y) t) (x-X) (y-Y) := by
      rw [contains_shift]
      have hx : x-X - -X=x := by omega
      have hy : y-Y - -Y=y := by omega
      simpa only [hx,hy] using hc
    have hd' : Contains (shift (-X) (-Y) t) (u-X) (v-Y) := by
      rw [contains_shift]
      have hx : u-X - -X=u := by omega
      have hy : v-Y - -Y=v := by omega
      simpa only [hx,hy] using hd
    exact dc _ tw _ _ hc' hb _ _ hd'
  · intro x y hb
    have := db (x-X) (y-Y) hb
    omega
  · constructor
    · intro x y hw
      have := dk.1 x y hw
      show D (X+dx+x-X) (Y+dy+y-Y)
      have hx : X+dx+x-X=dx+x := by omega
      have hy : Y+dy+y-Y=dy+y := by omega
      simpa only [hx,hy] using this
    · intro x y hx hy
      have := dk.2 x y hx hy
      show D (X+dx+x-X) (Y+dy+y-Y) ↔ Extra new x y
      have hx' : X+dx+x-X=dx+x := by omega
      have hy' : Y+dy+y-Y=dy+y := by omega
      simpa only [hx',hy'] using this

theorem no_clean_corner {a H : Int} (stepProof : LocalTheorem a)
    (T : Tiling a 1 1 0 (HalfStrip H)) :
    ∀ (X Y : Int) (k : Kind) (B : Region),
      0 ≤ X → 0 ≤ Y → TileClosed T.world B → Below H B →
      Clean k X Y B → False := by
  have descent : ∀ n : Nat, ∀ (X Y : Int) (k : Kind) (B : Region),
      (3*(H-Y)+zeroRank k).toNat=n →
      0 ≤ X → 0 ≤ Y → TileClosed T.world B → Below H B →
      Clean k X Y B → False := by
    intro n
    induction n using Nat.strongRecOn with
    | ind n ih =>
      intro X Y k B hn hX hY closed bounded clean
      obtain ⟨B', new, dx, dy, closed', bounded', clean', progress⟩ :=
        propagate stepProof T X Y k B hX hY closed bounded clean
      have below := clean_origin_below clean bounded
      have below' := clean_origin_below clean' bounded'
      have ranks := kind_bounds k
      have ranks' := kind_bounds new
      have decrease := progress_rank_decreases progress
      have lt : (3*(H-(Y+dy))+zeroRank new).toNat < n := by omega
      exact ih _ lt (X+dx) (Y+dy) new B' rfl
        (by have := progress.1; omega)
        (by have := progress.2.1; omega) closed' bounded' clean'
  intro X Y k B hX hY closed bounded clean
  exact descent _ X Y k B rfl hX hY closed bounded clean

theorem no_tall_half_strip {a H : Int} (stepProof : LocalTheorem a)
    (height : 4 ≤ H) : ¬ Tiles a 1 1 0 (HalfStrip H) := by
  rintro ⟨T⟩
  let B : Region := Wall .alpha
  have closed : TileClosed T.world B := by
    intro t ht x y hc hb
    have inside := T.inside t ht x y hc
    simp only [HalfStrip] at inside
    rcases hb with hb | hb <;> omega
  have bounded : Below H B := by
    intro x y hb
    change Wall .alpha x y at hb
    simp only [Wall, wallHeight, wallWidth] at hb
    omega
  have clean : Clean .alpha 0 0 B := by
    constructor
    · intro x y hw
      simpa only [Int.zero_add] using hw
    · intro x y hx hy
      simp only [Int.zero_add, B, Wall, Extra]
      constructor
      · intro hw
        rcases hw with hw | hw <;> omega
      · intro h
        exact False.elim h
  exact no_clean_corner stepProof T 0 0 .alpha B (by omega) (by omega) closed bounded clean

theorem no_half_strip {a : Int} (stepProof : LocalTheorem a) :
    ¬ HalfStripTileable a 1 1 0 := by
  rintro ⟨H, hH, ⟨T⟩⟩
  have doubled := T.doubleHalfStrip hH
  have quadrupled := doubled.doubleHalfStrip (by omega)
  exact no_tall_half_strip stepProof (by omega : 4 ≤ (H+H)+(H+H)) ⟨quadrupled⟩

#print axioms no_half_strip

end HalfStripObstruction
end PolyominoFormal

import THalfPlaneStarters
import THalfPlaneGaps
set_option maxHeartbeats 100000
set_option maxRecDepth 10000
namespace PolyominoFormal.LHalfPlaneLocal
open CrossUnits TBoundary THalfPlaneStarters THalfPlaneGaps

def Tip (horizontal vertical p h : Int) (t : Cross) : Prop :=
  t=⟨p,h+vertical,horizontal,0,0,vertical⟩ ∨ t=⟨p,h+vertical,0,0,horizontal,vertical⟩
def Starter (a b p h : Int) (t : Cross) : Prop := Tip b a p h t ∨ Tip a b p h t

theorem tip_base {u v p h : Int} (hu : 1≤u) (hv : 1≤v) {t : Cross}
    (st : Tip u v p h t) : Contains t p h := by
  rcases st with rfl | rfl <;> right <;> dsimp <;> omega

theorem tip_base_only {u v p h x : Int} (hu : 1≤u) (hv : 1≤v) {t : Cross}
    (st : Tip u v p h t) (hit : Contains t x h) : x=p := by
  rcases st with rfl | rfl <;> dsimp [Contains] at hit <;> omega

theorem adjacent_same_height {u v p h : Int} (hu : 1≤u) {t z : Cross}
    (st : Tip u v p h t) (sz : Tip u v (p+1) h z) (apart : Apart t z) :
    t=⟨p,h+v,0,0,u,v⟩ ∧ z=⟨p+1,h+v,u,0,0,v⟩ := by
  rcases st with rfl | rfl
  all_goals rcases sz with rfl | rfl
  all_goals first | exact ⟨rfl,rfl⟩ | skip
  all_goals dsimp [Apart] at apart; omega

theorem no_three_same_height {u v p h : Int} (hu : 1≤u) {t z w : Cross}
    (st : Tip u v p h t) (sz : Tip u v (p+1) h z) (sw : Tip u v (p+2) h w)
    (ap : Apart t z) (ap2 : Apart z w) : False := by
  have h1 := (adjacent_same_height hu st sz ap).2
  have h2 := (adjacent_same_height hu sz (by simpa only [show p+1+1=p+2 by omega] using sw) ap2).1
  have eq := congrArg Cross.east (h1.symm.trans h2); dsimp at eq; omega

theorem run_forms {a b L R p h : Int} (ha : 1≤a) (hb : 1≤b) (hp0 : L≤p) (hp1 : p≤R)
    {t : Cross} (copy : Copy a b 0 0 t) (hit : Contains t p h)
    (left : ¬Contains t (L-1) h) (right : ¬Contains t (R+1) h)
    (floor : ¬Contains t p (h-1))
    (center : L≤t.x → t.x≤R → ¬Contains t t.x (h-1)) :
    (∃q l r,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧ t=⟨q+r,h,l-r,a+b-l,r,0⟩ ∧
      L≤q ∧ q≤p ∧ p≤q+l ∧ q+l≤R) ∨ Starter a b p h t := by
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) copy
  rcases nn with ⟨he,hn,hw,hs⟩
  by_cases row : t.y=h
  · have span : t.x-t.west≤p ∧ p≤t.x+t.east := by rcases hit with hit | hit <;> omega
    have noLeft : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact left (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have noRight : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact right (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have bounds : L≤t.x-t.west ∧ t.x+t.east≤R := by omega
    have south : t.south=0 := by
      apply Classical.byContradiction; intro neq
      exact center (by omega) (by omega) (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs row south bounds span
    all_goals subst e; subst n; subst w; subst s
    · left; refine ⟨x,a,0,Or.inl rfl,Or.inl rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
    · left; refine ⟨x-b,b,b,Or.inr rfl,Or.inr rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · left; refine ⟨x-a,a,a,Or.inl rfl,Or.inr rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · left; refine ⟨x,b,0,Or.inr rfl,Or.inl rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
  · have vertical : t.x=p ∧ t.y-t.south≤h ∧ h≤t.y+t.north := by
      rcases hit with hit | hit <;> omega
    have bottom : t.y-t.south=h := by
      apply Classical.byContradiction; intro different
      exact floor (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    right
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs bottom vertical row
    all_goals subst e; subst n; subst w; subst s
    · exfalso; omega
    · left; left; apply same_eq; dsimp [Same]; omega
    · right; right; apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · left; right; apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
    · right; left; apply same_eq; dsimp [Same]; omega

theorem blocked_short_tall_run {a b L R h : Int} {region : Region} (ha : b≤a) (hb : 1≤b)
    (three : L+2≤R) (short : R-L<b) (T : Tiling a b 0 0 region) (B : Region)
    (closed : CornerCertificate.TileClosed T.world B)
    (inside : ∀x,L≤x → x≤R → region x h)
    (empty : ∀x,L≤x → x≤R → ¬B x h)
    (floor : ∀x,L≤x → x≤R → B x (h-1))
    (left : B (L-1) h) (right : B (R+1) h)
    (leftTall : B (L-1) (h+b)) (rightTall : B (R+1) (h+b)) : False := by
  have choose : ∀p,L≤p → p≤R → ∃t,T.world t ∧ Tip b a p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀{x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    have form := run_forms (by omega) hb hp0 hp1 (T.copies t ht) hit
      (avoid left) (avoid right) (avoid (floor p hp0 hp1))
      (fun h0 h1 => avoid (floor t.x h0 h1))
    rcases form with ⟨q,l,r,hl,hr,eq,hq0,hq1,hq2,hq3⟩ | st | st
    · omega
    · exact ⟨t,ht,st⟩
    · rcases st with eq | eq
      · have blocked := avoid rightTall
        rw [eq] at blocked
        exact False.elim (blocked (by left; dsimp; omega))
      · have blocked := avoid leftTall
        rw [eq] at blocked
        exact False.elim (blocked (by left; dsimp; omega))
  obtain ⟨t,ht,st⟩ := choose L (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := choose (L+1) (by omega) (by omega)
  obtain ⟨v,hv,sv⟩ := choose (L+2) (by omega) (by omega)
  have ap : Apart t u := separate (by omega) (by omega) (by omega) T ht hu
    (tip_base (by omega) (by omega) st) (by intro hit; have := tip_base_only (by omega) (by omega) su hit; omega)
  have ap2 : Apart u v := separate (by omega) (by omega) (by omega) T hu hv
    (tip_base (by omega) (by omega) su) (by intro hit; have := tip_base_only (by omega) (by omega) sv hit; omega)
  exact no_three_same_height (by omega) st su sv ap ap2

/-- A completely enclosed rectangle narrower than either L leg cannot
contain even its bottom-left cell of a tiling. -/
theorem enclosed_thin_rectangle {a b L R lo hi : Int} {region : Region}
    (ha : b≤a) (hb : 1≤b) (width : R-L<b) (hx : L≤R) (hy : lo≤hi)
    (T : Tiling a b 0 0 region) (B : Region)
    (closed : CornerCertificate.TileClosed T.world B) (inside : region L lo)
    (empty : ¬B L lo)
    (left : ∀y,lo≤y → y≤hi → B (L-1) y)
    (right : ∀y,lo≤y → y≤hi → B (R+1) y)
    (bottom : ∀x,L≤x → x≤R → B x (lo-1))
    (top : ∀x,L≤x → x≤R → B x (hi+1)) : False := by
  obtain ⟨t,ht,hit⟩ := T.cover L lo inside
  have avoid : ∀{x y},B x y → ¬Contains t x y :=
    fun blocked => avoid_closed closed ht hit empty blocked
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
  rcases nn with ⟨he,hn,hw,hs⟩
  have hitLeft := avoid (left lo (by omega) (by omega))
  have hitRight := avoid (right lo (by omega) (by omega))
  have hitBelow := avoid (bottom L (by omega) (by omega))
  have hitAbove := avoid (top L (by omega) (by omega))
  have center : L≤t.x ∧ t.x≤R ∧ lo≤t.y ∧ t.y≤hi := by
    rcases hit with hor | ver
    · have nl : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
        rintro ⟨h0,h1⟩; exact hitLeft (Or.inl ⟨h0,h1,by omega,by omega⟩)
      have nr : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
        rintro ⟨h0,h1⟩; exact hitRight (Or.inl ⟨h0,h1,by omega,by omega⟩)
      omega
    · have nb : ¬(t.y-t.south≤lo-1 ∧ lo-1≤t.y+t.north) := by
        rintro ⟨h0,h1⟩; exact hitBelow (Or.inr ⟨by omega,by omega,h0,h1⟩)
      have nt : ¬(t.y-t.south≤hi+1 ∧ hi+1≤t.y+t.north) := by
        rintro ⟨h0,h1⟩; exact hitAbove (Or.inr ⟨by omega,by omega,h0,h1⟩)
      omega
  have leftCenter := avoid (left t.y center.2.2.1 center.2.2.2)
  have rightCenter := avoid (right t.y center.2.2.1 center.2.2.2)
  have span : b≤t.east+t.west := by
    have cp := T.copies t ht
    rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨e,n,w,s⟩
    all_goals omega
  have nl : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
    rintro ⟨h0,h1⟩; exact leftCenter (Or.inl ⟨h0,h1,by omega,by omega⟩)
  have nr : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
    rintro ⟨h0,h1⟩; exact rightCenter (Or.inl ⟨h0,h1,by omega,by omega⟩)
  omega

#print axioms enclosed_thin_rectangle
#print axioms run_forms
#print axioms blocked_short_tall_run
end PolyominoFormal.LHalfPlaneLocal

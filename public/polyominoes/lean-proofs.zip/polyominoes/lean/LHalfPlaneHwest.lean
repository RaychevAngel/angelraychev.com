import LHalfPlaneHwestNear
import LQuadrantHpBoundaryallSeparatedHwestAwayPrunedGeometry

namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits LRegion

/-- The left-pointing long bar above a short boundary bar is impossible for
every unequal pair in the remaining half-plane domain. -/
theorem upright_long_left {a b : Int} (ha : 5≤a) (hb : 3≤b)
    (hab : b<a) : PairObstruction a b ⟨a+1,1,0,b,a,0⟩ := by
  by_cases hnear : a≤b+2
  · exact upright_long_left_near ha hb hab hnear
  intro T hO hU
  apply HP_boundaryall_separated_hwest_away_pruned_anchored_obstruction a b
    (by omega) hb hab ha (by omega) (by omega) (by omega) T hO
  simpa only [Int.add_comm] using hU

#print axioms upright_long_left
end PolyominoFormal.LHalfPlaneShortbarAssembly

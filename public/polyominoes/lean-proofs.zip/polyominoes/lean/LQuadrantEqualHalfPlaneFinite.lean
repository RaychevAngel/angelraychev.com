import LQuadrantHpEqualBarLongFixed3PrunedGeometry
import LQuadrantHpEqualBarLongFixed4PrunedGeometry
import LQuadrantHpEqualBarLongFixed5PrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

theorem equal_bottom_forms (a : Int) (ha : 3≤a)
    (T : Tiling a a 0 0 HalfPlane) (t : Cross) (ht : T.world t)
    (hit : Contains t 0 0) :
    t.y=0 ∧ ((t.east=a ∧ t.north=a ∧ t.west=0 ∧ t.south=0) ∨
             (t.east=0 ∧ t.north=a ∧ t.west=a ∧ t.south=0)) := by
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
  have inside : 0≤t.y-t.south := T.inside t ht t.x (t.y-t.south) (by
    unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  have allowed := equal_avoid_tips a ha T t ht
  unfold Contains at hit
  unfold ForbiddenShortTip at allowed
  rcases T.copies t ht with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals omega

theorem equal_finite_right_bar (a p : Int) (ha : 3≤a) (hb : a≤5)
    (T : Tiling a a 0 0 HalfPlane) (anchor : T.world ⟨p,0,a,a,0,0⟩) : False := by
  have cases : a=3 ∨ a=4 ∨ a=5 := by omega
  rcases cases with rfl | rfl | rfl
  · apply HP_equal_bar_long_fixed_3_pruned_no_shifted_anchor 3 3 p
      (by omega) (by omega) rfl rfl T
    simpa only [shift,Int.zero_add,Int.add_zero] using anchor
  · apply HP_equal_bar_long_fixed_4_pruned_no_shifted_anchor 4 4 p
      (by omega) (by omega) rfl rfl T
    simpa only [shift,Int.zero_add,Int.add_zero] using anchor
  · apply HP_equal_bar_long_fixed_5_pruned_no_shifted_anchor 5 5 p
      (by omega) (by omega) rfl rfl T
    simpa only [shift,Int.zero_add,Int.add_zero] using anchor

theorem equal_finite_no_half_plane (a : Int) (ha : 3≤a) (hb : a≤5) :
    ¬Tiles a a 0 0 HalfPlane := by
  rintro ⟨T⟩
  obtain ⟨t,ht,hit⟩ := T.cover 0 0 (by unfold HalfPlane; omega)
  obtain ⟨hy,arms⟩ := equal_bottom_forms a ha T t ht hit
  rcases t with ⟨p,y,e,n,w,s⟩
  dsimp only at hy arms
  subst y
  rcases arms with ⟨he,hn,hw,hs⟩ | ⟨he,hn,hw,hs⟩
  · subst e; subst n; subst w; subst s
    exact equal_finite_right_bar a p ha hb T ht
  · subst e; subst n; subst w; subst s
    apply equal_finite_right_bar a (-p) ha hb T.mirrorX
    exact ⟨_,ht,rfl⟩

#print axioms equal_finite_no_half_plane
end PolyominoFormal.LRegion

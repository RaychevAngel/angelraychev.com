import LQuadrantHpBoundaryallUnequalCornerLongPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

theorem long_corner_right_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,a,b,0,0⟩)
    (tip : T.world ⟨p+1,b+1,0,0,a,b⟩) : False := by
  apply HP_boundaryall_unequal_corner_long_pruned_no_shifted_anchor a b p
    (by omega) hb hab ha T
  · simpa only [shift,Int.zero_add,Int.add_zero] using bar
  · simpa only [shift,Int.zero_add,Int.add_zero,Int.add_comm] using tip

theorem long_corner_left_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,0,b,a,0⟩)
    (tip : T.world ⟨p-1,b+1,a,0,0,b⟩) : False := by
  apply long_corner_right_impossible a b (-p) ha hb hab T.mirrorX
  · exact ⟨_,bar,rfl⟩
  · refine ⟨_,tip,?_⟩
    apply same_eq
    dsimp [Same,mirrorX]
    omega

def LongBoundaryCorner (a b : Int) (t u : Cross) : Prop :=
  t.y=0 ∧ t.north=b ∧ t.south=0 ∧
  u.y=b+1 ∧ u.north=0 ∧ u.south=b ∧
  ((t.east=a ∧ t.west=0 ∧ u.x=t.x+1 ∧ u.east=0 ∧ u.west=a) ∨
   (t.east=0 ∧ t.west=a ∧ u.x=t.x-1 ∧ u.east=a ∧ u.west=0))

def ForbiddenLongBoundaryCorner (a b : Int) (t u : Cross) : Prop :=
  LongBoundaryCorner a b t u ∨ LongBoundaryCorner a b u t

theorem avoid_long_boundary_corner_ordered (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬LongBoundaryCorner a b t u := by
  rintro ⟨p,y,e,n,w,s⟩ ⟨q,z,f,m,v,r⟩ ht hu
    ⟨hy,hn,hs,hz,hm,hr,arms⟩
  dsimp only at hy hn hs hz hm hr arms
  subst y; subst n; subst s; subst z; subst m; subst r
  rcases arms with ⟨he,hw,hq,hf,hv⟩ | ⟨he,hw,hq,hf,hv⟩
  · subst e; subst w; subst q; subst f; subst v
    exact long_corner_right_impossible a b p ha hb hab T ht hu
  · subst e; subst w; subst q; subst f; subst v
    exact long_corner_left_impossible a b p ha hb hab T ht hu

theorem avoid_long_boundary_corner (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenLongBoundaryCorner a b t u := by
  intro t u ht hu bad
  rcases bad with bad | bad
  · exact avoid_long_boundary_corner_ordered a b ha hb hab T t u ht hu bad
  · exact avoid_long_boundary_corner_ordered a b ha hb hab T u t hu ht bad

#print axioms long_corner_right_impossible
#print axioms avoid_long_boundary_corner
end PolyominoFormal.LRegion

import LHalfPlaneShortbarAssembly
import LQuadrantHpAdjacentBarShortBranchPrunedGeometry
import LQuadrantHpSeparatedBarShortBranchPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

/-- The two explicit parameter domains exhaust every strictly unequal pair. -/
theorem upright_long_shortbar_obstruction (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    LHalfPlaneShortbarAssembly.PairObstruction a b ⟨1,1,a,b,0,0⟩ := by
  intro T hO hU
  by_cases adjacent : a=b+1
  · exact HP_adjacent_bar_short_branch_pruned_anchored_obstruction a b
      (by omega) hb hab ha adjacent T hO hU
  · exact HP_separated_bar_short_branch_pruned_anchored_obstruction a b
      (by omega) hb hab ha (by omega) T hO hU

theorem short_upright_long_right_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,b,a,0,0⟩)
    (inner : T.world ⟨p+1,1,a,b,0,0⟩) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply upright_long_shortbar_obstruction a b ha hb hab U
  · refine ⟨_,bar,?_⟩
    apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,inner,?_⟩
    apply same_eq; dsimp [Same,shift]; omega

theorem short_upright_long_left_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,0,a,b,0⟩)
    (inner : T.world ⟨p-1,1,0,b,a,0⟩) : False := by
  apply short_upright_long_right_impossible a b (-p) ha hb hab T.mirrorX
  · exact ⟨_,bar,rfl⟩
  · refine ⟨_,inner,?_⟩
    apply same_eq; dsimp [Same,mirrorX]; omega

def ShortUprightLong (a b : Int) (t u : Cross) : Prop :=
  t.y=0 ∧ t.north=a ∧ t.south=0 ∧
  u.y=1 ∧ u.north=b ∧ u.south=0 ∧
  ((t.east=b ∧ t.west=0 ∧ u.x=t.x+1 ∧ u.east=a ∧ u.west=0) ∨
   (t.east=0 ∧ t.west=b ∧ u.x=t.x-1 ∧ u.east=0 ∧ u.west=a))

def ForbiddenShortUprightLong (a b : Int) (t u : Cross) : Prop :=
  ShortUprightLong a b t u ∨ ShortUprightLong a b u t

theorem avoid_short_upright_long_ordered (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ShortUprightLong a b t u := by
  rintro ⟨p,y,e,n,w,s⟩ ⟨q,z,f,m,v,r⟩ ht hu
    ⟨hy,hn,hs,hz,hm,hr,arms⟩
  dsimp only at hy hn hs hz hm hr arms
  subst y; subst n; subst s; subst z; subst m; subst r
  rcases arms with ⟨he,hw,hq,hf,hv⟩ | ⟨he,hw,hq,hf,hv⟩
  · subst e; subst w; subst q; subst f; subst v
    exact short_upright_long_right_impossible a b p ha hb hab T ht hu
  · subst e; subst w; subst q; subst f; subst v
    exact short_upright_long_left_impossible a b p ha hb hab T ht hu

theorem avoid_short_upright_long (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenShortUprightLong a b t u := by
  intro t u ht hu bad
  rcases bad with bad | bad
  · exact avoid_short_upright_long_ordered a b ha hb hab T t u ht hu bad
  · exact avoid_short_upright_long_ordered a b ha hb hab T u t hu ht bad

#print axioms upright_long_shortbar_obstruction
#print axioms avoid_short_upright_long
end PolyominoFormal.LRegion

import LRunCertificates
import LQuadrantHpBoundaryallUnequalVleftLongneighborPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
import LHalfPlaneShortbarPairs
import LHalfPlaneOutwardLongCorner
import LHalfPlaneShortbarBranch
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_vleft_longneighbor_pruned_M (a b : Int) : Int := 4*(a+b+1)
def HP_boundaryall_unequal_vleft_longneighbor_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_vleft_longneighbor_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_vleft_longneighbor_pruned_M a b ∧ y≤HP_boundaryall_unequal_vleft_longneighbor_pruned_M a b
def HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south
def HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair (a b : Int) (t u : Cross) : Prop := ((((ForbiddenSameBoundaryBars a b t u) ∨ ForbiddenLongBoundaryCorner a b t u) ∨ ForbiddenSameShortBars a b t u) ∨ ForbiddenOutwardLongBoundaryCorner a b t u) ∨ ForbiddenShortUprightLong a b t u

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht4
  apply avoidRunRight [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b)] (2 : Int) ((1 : Int) + b) ((-1 : Int) + ((-1 : Int) * a))
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_empty a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hx0) (ha) (hx1)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_tall a b (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_point a b ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o0 a b jx jy (hlong) (insideT) (sep3).2.2.2 (hb) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o1 a b jx jy (insideT) (hit) (sep1).2.2.1 (allowed) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o2 a b jx jy (allowed) (hit) (sep1).2.2.1 (hlong) (sep4).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o3 a b jx jy (hb) (sep3).2.2.1 (sep4).2.1 (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o4 a b jx jy (insideT) (hit) (sep1).2.2.1 (allowed) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o5 a b jx jy (sep3).2.1 (hit) (sep2).2.1 (sep4).2.2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o6 a b jx jy (hb) (sep4).2.2.2 (hit) (sep2).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o7 a b jx jy (sep1).2.2.1 (insideT) (allowed) (hb) (hit) (sep0).2.1 (hlong)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o0 a b jx jy (insideT) (hlong) (hit) (hb) (sep2).2.1 (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o1 a b jx jy (insideT) (hit) (hlong) (sep1).2.2.1 (hb) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit) (hb) (insideT) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node002 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o3 a b jx jy (sep1).2.2.1 (sep0).2.1 (hit) (sep3).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o4 a b jx jy (hlong) (insideT) (allowed) (sep1).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o5 a b jx jy (hlong) (sep2).2.1 (hit) (hb) (sep3).2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o6 a b jx jy (sep2).2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node003 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o7 a b jx jy (insideT) (sep0).2.1 (hit) (sep1).2.2.1 (hlong) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  apply avoidRunLeft [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b)] (1 : Int) b (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_empty a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hx1)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hx1)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node008 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ht5 : world (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_5 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have in5 := inside (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have allowed5 := avoid (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  apply avoidRunRight [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b), (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b)] (3 : Int) ((2 : Int) + b) ((-2 : Int) + ((-1 : Int) * a))
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_empty a b run_x (ha) (hx1) (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_floor a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ht5 : world (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_5 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have in5 := inside (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have allowed5 := avoid (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht5
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_point a b ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent)) (hb) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o0 a b jx jy (sep5).2.2.1 (sep3).2.1 (sep5).2.2.2 (hb) (hit) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o1 a b jx jy (sep4).2.2.1 (insideT) (ap1_4).2.1 (hit) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o2 a b jx jy (insideT) (sep5).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (allowed) (hb) (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node008 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o3 a b jx jy (ap1_4).2.1 (sep0).2.1 (hit) (sep4).2.2.1 (sep5).2.2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o4 a b jx jy (ha) (hb) (sep4).2.2.1 (ap1_4).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o5 a b jx jy (sep5).2.2.1 (sep3).2.1 (sep5).2.1 (hit) (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o6 a b jx jy (insideT) (hb) (sep4).2.2.1 (ha) (hit) (ap1_4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o7 a b jx jy (ha) (sep0).2.1 (allowed) (ap1_4).2.1 (hit) (insideT) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node009 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ht5 : world (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_5 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have in5 := inside (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have allowed5 := avoid (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht5
  apply avoidRunLeft [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b), (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b)] (2 : Int) ((1 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_empty a b run_x (hx1) (ap1_4).2.1 (ha) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node010 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ht5 : world (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_5 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have in5 := inside (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have allowed5 := avoid (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-2 : Int) ((2 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_point a b ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent)) (hb) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (-2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) ((2 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ap1_5).2.1 (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) ((2 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o0 a b jx jy (ap1_4).2.1 (sep5).2.1 (sep1).2.1 (ha) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o1 a b jx jy (ha) (hit) (insideT) (sep1).2.2.1 (hb) (ap1_4).2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o2 a b jx jy (ap1_4).2.1 (hit) (sep3).2.2.2 (sep5).2.1 (hb) (sep4).2.2.1 (sep0).2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o3 a b jx jy (sep4).2.1 (sep5).2.1 (sep3).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o4 a b jx jy (ap1_4).2.1 (sep1).2.2.1 (hit) (allowed) (insideT) (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o5 a b jx jy (sep5).2.1 (hb) (sep1).2.1 (hit) (ap1_4).2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o6 a b jx jy (sep1).2.1 (sep5).2.1 (hb) (ap1_4).2.1 (hit) (sep3).2.2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o7 a b jx jy (ap1_4).2.1 (hit) (ha) (sep5).2.1 (sep1).2.1 (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht3 ht4
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_point a b (hb) (ha) ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o0 a b jx jy (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (ha) (hit) (insideT) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node007 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o1 a b jx jy (ap1_4).2.1 (insideT) (hit) (ha) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-3 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o2 a b jx jy (hit) (sep3).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node009 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o3 a b jx jy (hb) (hit) (sep4).2.2.1 (sep0).2.1 (ap1_4).2.1 (insideT) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o4 a b jx jy (ap1_4).2.1 (hit) (insideT) (sep4).2.2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-3 : Int) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o5 a b jx jy (sep3).2.2.1 (hb) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep3).2.1 (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node010 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o6 a b jx jy (hit) (ha) (insideT) (hb) (sep4).2.2.1 (ap1_4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o7 a b jx jy (insideT) (allowed) (ha) (sep4).2.1 (hit) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-1 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_point a b ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (-1 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_empty a b (hstrict) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o0 a b jx jy (sep3).2.1 (sep1).2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o1 a b jx jy (hit) (allowed) (hb) (insideT) (sep1).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o2 a b jx jy (hit) (sep2).2.2.2 (sep1).2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (hstrict) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node006 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o3 a b jx jy (hstrict) (hit) (sep2).2.2.1 (sep3).2.1 (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o4 a b jx jy (sep1).2.2.1 (allowed) (hstrict) (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o5 a b jx jy (hit) (hstrict) (insideT) (sep2).1 (sep0).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o6 a b jx jy (hit) (sep3).2.1 (hstrict) (sep2).2.2.2 (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o7 a b jx jy (sep1).2.2.1 (hstrict) (sep3).2.1 (hit) (hb) (sep0).2.1

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node011 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o0 a b jx jy (hb) (sep3).2.1 (insideT) (hit) (hstrict) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o1 a b jx jy (sep1).2.2.1 (hit) (hlong) (insideT) (hb) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o2 a b jx jy (insideT) (sep3).2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o3 a b jx jy (hlong) (sep2).2.1 (sep3).2.2.1 (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o4 a b jx jy (hit) (sep1).2.2.1 (insideT) (allowed) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o5 a b jx jy (sep3).2.2.1 (sep3).2.1 (hit) (sep2).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o6 a b jx jy (hit) (sep3).2.2.2 (insideT) (hb) (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o7 a b jx jy (hit) (sep1).2.2.1 (sep0).2.1 (hlong) (insideT) (hb)

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_point a b ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_Box,HP_boundaryall_unequal_vleft_longneighbor_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_empty a b (allowed0) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o0 a b jx jy (sep2).2.1 (hb) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node001 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o1 a b jx jy (hlong) (hb) (insideT) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o2 a b jx jy (insideT) (hit) (allowed) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node004 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o3 a b jx jy (hit) (sep1).2.2.1 (sep2).2.2.1 (hlong) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o4 a b jx jy (allowed) (sep1).2.2.1 (hit) (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o5 a b jx jy (sep2).2.1 (hit) (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node005 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o6 a b jx jy (sep2).2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node011 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o7 a b jx jy (insideT) (hit) (allowed) (hb) ((by simpa only [HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair, ForbiddenSameBoundaryBars, ForbiddenLongBoundaryCorner, LongBoundaryCorner, ForbiddenSameShortBars, ForbiddenOutwardLongBoundaryCorner, OutwardLongBoundaryCorner, ForbiddenShortUprightLong, ShortUprightLong, eq_comm] using pairAllowed2))

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_longneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_longneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (anchor2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) anchor0 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) anchor1 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_vleft_longneighbor_pruned_node000 a b ha hb hstrict hlong hexception world copies inside cover sep avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair anchor0 anchor1 anchor2 rootap0_1 rootap0_2 rootap1_2

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (anchor2 : T.world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair : ∀t u,T.world t → T.world u → ¬HP_boundaryall_unequal_vleft_longneighbor_pruned_ForbiddenPair a b t u := by
    intro t u ht hu bad
    rcases bad with bad | bad
    ·
      rcases bad with bad | bad
      ·
        rcases bad with bad | bad
        ·
          rcases bad with bad | bad
          ·
            exact avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T t u ht hu bad
          ·
            exact avoid_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
        ·
          exact avoid_same_short_bars a b (by omega) (by omega) T t u ht hu bad
      ·
        exact avoid_outward_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
    ·
      exact avoid_short_upright_long a b (by omega) (by omega) (by omega) T t u ht hu bad
  apply HP_boundaryall_unequal_vleft_longneighbor_pruned_bounded_obstruction a b ha hb hstrict hlong hexception T.world T.copies ?_ ?_ T.disjoint (LRunCertificates.tiling_extended_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_down_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_right_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_left_run_obstruction (by omega) (by omega) T) avoid avoidPair anchor0 anchor1 anchor2
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a)))
    (anchor2 : T.world (shift p 0 (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_vleft_longneighbor_pruned_anchored_obstruction a b ha hb hstrict hlong hexception U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor2,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_vleft_longneighbor_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_vleft_longneighbor_pruned_bounded_obstruction
end PolyominoFormal.LRegion

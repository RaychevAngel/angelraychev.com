import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2965 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3545 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3466 a b) ∨ (fact_366edf150095_5793 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_4118 a b) ∨ (fact_366edf150095_3713 a b) ∨ (fact_366edf150095_5864 a b) ∨ (fact_366edf150095_5947 a b) ∨ (fact_366edf150095_3794 a b) ∨ (fact_366edf150095_4227 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7517 a b) ∨ (fact_366edf150095_7585 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7517 a b) ∧ (fact_366edf150095_7585 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7517 a b) ∧ (fact_366edf150095_7585 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (fact_366edf150095_4799 a b) ∨ (fact_366edf150095_4885 a b)) ∨ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (fact_366edf150095_5518 a b) ∨ (fact_366edf150095_5571 a b)))) ∨ ((fact_366edf150095_7517 a b) ∧ (fact_366edf150095_7585 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (fact_366edf150095_4799 a b) ∨ (fact_366edf150095_4885 a b)) ∧ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (fact_366edf150095_5518 a b) ∨ (fact_366edf150095_5571 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2320 a b run_x) ∨ (fact_366edf150095_3538 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h5 : (run_x ≤ ((2 : Int) + a)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n226_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3316 a b run_x) ∨ (fact_366edf150095_5231 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_empty (a b : Int)
    (h0 : (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o1 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ (jy = ((5 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_2953 a b jy))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o2 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h9 : (fact_366edf150095_2954 a b jy))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((4 : Int) + b)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2952 a b jy))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((4 : Int) = jx) ∧ (jy = ((5 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ ((((4 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n227_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h4 : (¬ ((((4 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2906 a b) ∨ (fact_366edf150095_2578 a b) ∨ (fact_366edf150095_4067 a b) ∨ (fact_366edf150095_4072 a b) ∨ (fact_366edf150095_2581 a b) ∨ (fact_366edf150095_3181 a b) ∨ (fact_366edf150095_2583 a b) ∨ (fact_366edf150095_4074 a b) ∨ ((((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o0 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o1 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (fact_366edf150095_2953 a b jy))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((jx + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) + a)) ∨ (((5 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_366edf150095_2952 a b jy))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h5 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((jx + (0 : Int)) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n228_o7 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_four (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((5 : Int) + b)) ∨ (((5 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h3 : (¬ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  apply h3
  clear h3
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((4 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7665 a b) ∨ (fact_366edf150095_7769 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7665 a b) ∧ (fact_366edf150095_7769 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7665 a b) ∧ (fact_366edf150095_7769 a b) ∧ (((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5665 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (fact_366edf150095_1534 a b)) ∨ (fact_366edf150095_6612 a b)))) ∨ ((fact_366edf150095_7665 a b) ∧ (fact_366edf150095_7769 a b) ∧ ((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5665 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (fact_366edf150095_1534 a b)) ∨ (fact_366edf150095_6612 a b))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  by_cases split0 : ((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))
  · left
    refine ⟨?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · left
      right
      right
      right
      right
      right
      right
      right
      right
      left
      right
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · by_cases split1 : ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a))
    · right
      right
      right
      right
      refine ⟨?_,?_,?_,?_⟩
      · right
        right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · by_cases split2 : ((((4 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))
      · right
        left
        refine ⟨?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · left
          right
          right
          right
          right
          right
          right
          right
          right
          right
          right
          right
          left
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_empty (a b run_x : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : (((4 : Int) + a) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n229_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((4 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7498 a b) ∨ (fact_366edf150095_7828 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7498 a b) ∧ (fact_366edf150095_7828 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7498 a b) ∧ (fact_366edf150095_7828 a b) ∧ (((((((-1 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∨ ((((((-1 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((4 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7498 a b) ∧ (fact_366edf150095_7828 a b) ∧ ((((((-1 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∧ ((((((-1 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((4 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n230_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_empty (a b : Int)
    (h0 : ((fact_366edf150095_2906 a b) ∨ (fact_366edf150095_2578 a b) ∨ (fact_366edf150095_4067 a b) ∨ (fact_366edf150095_4072 a b) ∨ (fact_366edf150095_2581 a b) ∨ (fact_366edf150095_3181 a b) ∨ (fact_366edf150095_2583 a b) ∨ (fact_366edf150095_4074 a b) ∨ ((((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))) ∨ ((((5 : Int) ≥ ((4 : Int) - b)) ∧ ((5 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2953 a b jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o2 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o3 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_366edf150095_2952 a b jy))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (((jx + (0 : Int)) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h7 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n231_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_empty (a b : Int)
    (h0 : ((fact_366edf150095_2909 a b) ∨ (fact_366edf150095_2589 a b) ∨ (fact_366edf150095_4082 a b) ∨ (fact_366edf150095_4087 a b) ∨ (fact_366edf150095_2592 a b) ∨ (fact_366edf150095_3194 a b) ∨ (fact_366edf150095_2594 a b) ∨ (fact_366edf150095_4089 a b) ∨ ((((6 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≥ ((3 : Int) + a)) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))) ∨ ((((6 : Int) ≥ ((4 : Int) - b)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o0 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - a))))
    (h5 : (fact_366edf150095_2953 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o3 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_2952 a b jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n232_o7 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (¬ ((((6 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_four (a b : Int)
    (h0 : (¬ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((5 : Int) + b)) ∨ (((5 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((4 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((5 : Int) + b)) ∨ (((5 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7719 a b) ∨ (fact_366edf150095_7825 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7719 a b) ∧ (fact_366edf150095_7825 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7719 a b) ∧ (fact_366edf150095_7825 a b) ∧ (((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (fact_366edf150095_5634 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (fact_366edf150095_6608 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7719 a b) ∧ (fact_366edf150095_7825 a b) ∧ ((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (fact_366edf150095_5634 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (fact_366edf150095_6608 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + b) + (0 : Int))))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  by_cases split0 : ((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))
  · left
    refine ⟨?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · left
      right
      right
      right
      right
      right
      right
      right
      right
      left
      right
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · by_cases split1 : ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a))
    · right
      right
      right
      right
      refine ⟨?_,?_,?_,?_⟩
      · right
        right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · right
      left
      refine ⟨?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h5 : (((4 : Int) + a) ≤ run_x))
    (h6 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n233_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((5 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_four (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (¬ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((5 : Int) + b)) ∨ (((5 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((4 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7666 a b) ∨ (fact_366edf150095_7770 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7666 a b) ∧ (fact_366edf150095_7770 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7666 a b) ∧ (fact_366edf150095_7770 a b) ∧ (((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (fact_366edf150095_5634 a b) ∨ (fact_366edf150095_5665 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (fact_366edf150095_6608 a b) ∨ (fact_366edf150095_6612 a b)))) ∨ ((fact_366edf150095_7666 a b) ∧ (fact_366edf150095_7770 a b) ∧ ((fact_366edf150095_5140 a b) ∨ (fact_366edf150095_4434 a b) ∨ (fact_366edf150095_6359 a b) ∨ (fact_366edf150095_6447 a b) ∨ (fact_366edf150095_4518 a b) ∨ (fact_366edf150095_5268 a b) ∨ (fact_366edf150095_4598 a b) ∨ (fact_366edf150095_6523 a b) ∨ (fact_366edf150095_5357 a b) ∨ (fact_366edf150095_4711 a b) ∨ (fact_366edf150095_5634 a b) ∨ (fact_366edf150095_5665 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6550 a b) ∨ (fact_366edf150095_6086 a b) ∨ (fact_366edf150095_6608 a b) ∨ (fact_366edf150095_6612 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  by_cases split0 : ((((4 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))
  · left
    refine ⟨?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · left
      right
      right
      right
      right
      right
      right
      right
      right
      left
      right
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · by_cases split1 : ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a))
    · right
      right
      right
      right
      refine ⟨?_,?_,?_,?_⟩
      · right
        right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · by_cases split2 : ((((4 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))
      · right
        left
        refine ⟨?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · right
          right
          right
          right
          right
          right
          right
          left
          right
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · left
          right
          right
          right
          right
          right
          right
          right
          right
          right
          right
          right
          left
          refine ⟨?_,?_,?_,?_⟩
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
          · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_empty (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((5 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n234_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((5 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((5 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((-1 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7488 a b) ∨ (fact_366edf150095_7558 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7488 a b) ∧ (fact_366edf150095_7558 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7488 a b) ∧ (fact_366edf150095_7558 a b) ∧ (((fact_366edf150095_4162 a b) ∨ (fact_366edf150095_3757 a b) ∨ (fact_366edf150095_5908 a b) ∨ (fact_366edf150095_5991 a b) ∨ (fact_366edf150095_3838 a b) ∨ (fact_366edf150095_4271 a b) ∨ (fact_366edf150095_3895 a b) ∨ (fact_366edf150095_6047 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∨ ((fact_366edf150095_5124 a b) ∨ (fact_366edf150095_4418 a b) ∨ (fact_366edf150095_6343 a b) ∨ (fact_366edf150095_6431 a b) ∨ (fact_366edf150095_4502 a b) ∨ (fact_366edf150095_5252 a b) ∨ (fact_366edf150095_4584 a b) ∨ (fact_366edf150095_6513 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7488 a b) ∧ (fact_366edf150095_7558 a b) ∧ ((fact_366edf150095_4162 a b) ∨ (fact_366edf150095_3757 a b) ∨ (fact_366edf150095_5908 a b) ∨ (fact_366edf150095_5991 a b) ∨ (fact_366edf150095_3838 a b) ∨ (fact_366edf150095_4271 a b) ∨ (fact_366edf150095_3895 a b) ∨ (fact_366edf150095_6047 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∧ ((fact_366edf150095_5124 a b) ∨ (fact_366edf150095_4418 a b) ∨ (fact_366edf150095_6343 a b) ∨ (fact_366edf150095_6431 a b) ∨ (fact_366edf150095_4502 a b) ∨ (fact_366edf150095_5252 a b) ∨ (fact_366edf150095_4584 a b) ∨ (fact_366edf150095_6513 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a > b))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n235_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7499 a b) ∨ (fact_366edf150095_7580 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7499 a b) ∧ (fact_366edf150095_7580 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7499 a b) ∧ (fact_366edf150095_7580 a b) ∧ (((((((-1 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((5 : Int) + a)) ∧ ((-1 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int)))))) ∨ ((((((-1 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((5 : Int) + a)) ∧ ((-1 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7499 a b) ∧ (fact_366edf150095_7580 a b) ∧ ((((((-1 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((5 : Int) + a)) ∧ ((-1 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int)))))) ∧ ((((((-1 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((5 : Int) + a)) ∧ ((-1 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ (fact_366edf150095_2346 a b run_x) ∨ (fact_366edf150095_3621 a b run_x) ∨ ((((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h1 : (run_x ≤ ((4 : Int) + b)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n236_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (fact_366edf150095_3312 a b run_x) ∨ (fact_366edf150095_5227 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((4 : Int) + b)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_left (a b : Int)
    (h0 : (¬ (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7424 a b) ∨ (fact_366edf150095_7460 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7424 a b) ∧ (fact_366edf150095_7460 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7424 a b) ∧ (fact_366edf150095_7460 a b) ∧ (((((((-1 : Int) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((4 : Int) + a)) ∧ ((-1 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int)))))) ∨ ((((((-1 : Int) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((4 : Int) + a)) ∧ ((-1 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7424 a b) ∧ (fact_366edf150095_7460 a b) ∧ ((((((-1 : Int) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((4 : Int) + a)) ∧ ((-1 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int)))))) ∧ ((((((-1 : Int) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((4 : Int) + a)) ∧ ((-1 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((1 : Int) + a)))
    (h5 : ((fact_366edf150095_2379 a b run_x) ∨ (fact_366edf150095_2342 a b run_x) ∨ (fact_366edf150095_3617 a b run_x) ∨ (fact_366edf150095_3618 a b run_x) ∨ (fact_366edf150095_2343 a b run_x) ∨ (fact_366edf150095_3038 a b run_x) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n237_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3343 a b run_x) ∨ (fact_366edf150095_3292 a b run_x) ∨ (fact_366edf150095_5207 a b run_x) ∨ (fact_366edf150095_5217 a b run_x) ∨ (fact_366edf150095_3302 a b run_x) ∨ (fact_366edf150095_3522 a b run_x) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2903 a b) ∨ (fact_366edf150095_2572 a b) ∨ (fact_366edf150095_4059 a b) ∨ (fact_366edf150095_4062 a b) ∨ (fact_366edf150095_2574 a b) ∨ (fact_366edf150095_3173 a b) ∨ (fact_366edf150095_2575 a b) ∨ (fact_366edf150095_4063 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ ((((4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o1 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((jx = ((4 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((4 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o6 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (¬ ((((4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n238_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_366edf150095_1 a b))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_empty (a b : Int)
    (h0 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((fact_366edf150095_3223 a b) ∨ (fact_366edf150095_3129 a b) ∨ (fact_366edf150095_4219 a b) ∨ (fact_366edf150095_4308 a b) ∨ (fact_366edf150095_3137 a b) ∨ (fact_366edf150095_3354 a b) ∨ (fact_366edf150095_3144 a b) ∨ (fact_366edf150095_4316 a b) ∨ (fact_366edf150095_3148 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + ((2 : Int) * a)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (fact_366edf150095_1818 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1821 a b jx jy))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1849 a b jx jy))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_366edf150095_1864 a b jx jy))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (fact_366edf150095_1865 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : (fact_366edf150095_1848 a b jx jy))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_366edf150095_1820 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n239_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1819 a b jx jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2905 a b) ∨ (fact_366edf150095_2577 a b) ∨ (fact_366edf150095_4066 a b) ∨ (fact_366edf150095_4071 a b) ∨ (fact_366edf150095_2580 a b) ∨ (fact_366edf150095_3180 a b) ∨ (fact_366edf150095_2582 a b) ∨ (fact_366edf150095_4073 a b) ∨ (fact_366edf150095_2585 a b) ∨ (fact_366edf150095_3190 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o2 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((5 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o5 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (¬ (((jx = ((5 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o6 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n240_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6096 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7560 a b) ∨ (fact_366edf150095_7699 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7560 a b) ∧ (fact_366edf150095_7699 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7560 a b) ∧ (fact_366edf150095_7699 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_4966 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6100 a b)))) ∨ ((fact_366edf150095_7560 a b) ∧ (fact_366edf150095_7699 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_4966 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6100 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3005 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (((2 : Int) + a) ≤ run_x))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n241_run_floor (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (((2 : Int) + a) ≤ run_x))
    (h5 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3587 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3504 a b) ∨ (fact_366edf150095_3453 a b) ∨ (fact_366edf150095_5780 a b) ∨ (fact_366edf150095_5788 a b) ∨ (fact_366edf150095_3461 a b) ∨ (fact_366edf150095_3699 a b) ∨ (fact_366edf150095_3467 a b) ∨ (fact_366edf150095_5794 a b) ∨ (fact_366edf150095_3469 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3708 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4126 a b) ∨ (fact_366edf150095_3721 a b) ∨ (fact_366edf150095_5872 a b) ∨ (fact_366edf150095_5955 a b) ∨ (fact_366edf150095_3802 a b) ∨ (fact_366edf150095_4235 a b) ∨ (fact_366edf150095_3875 a b) ∨ (fact_366edf150095_6028 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4387 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7503 a b) ∨ (fact_366edf150095_7576 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7503 a b) ∧ (fact_366edf150095_7576 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7503 a b) ∧ (fact_366edf150095_7576 a b) ∧ (((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_3940 a b) ∨ (fact_366edf150095_4894 a b) ∨ (fact_366edf150095_4390 a b)) ∨ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_4713 a b) ∨ (fact_366edf150095_5592 a b) ∨ (fact_366edf150095_5401 a b)))) ∨ ((fact_366edf150095_7503 a b) ∧ (fact_366edf150095_7576 a b) ∧ ((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_3940 a b) ∨ (fact_366edf150095_4894 a b) ∨ (fact_366edf150095_4390 a b)) ∧ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_4713 a b) ∨ (fact_366edf150095_5592 a b) ∨ (fact_366edf150095_5401 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2328 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2973 a b run_x)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((5 : Int) ≤ run_x))
    (h5 : (run_x ≤ ((4 : Int) + b)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n242_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3327 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3553 a b run_x))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_four (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6096 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7571 a b) ∨ (fact_366edf150095_7703 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7571 a b) ∧ (fact_366edf150095_7703 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7571 a b) ∧ (fact_366edf150095_7703 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_5388 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6555 a b)))) ∨ ((fact_366edf150095_7571 a b) ∧ (fact_366edf150095_7703 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_5388 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6555 a b))))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a > b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + a) ≤ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3005 a b run_x) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n243_run_floor (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3587 a b run_x) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : (((2 : Int) + a) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_four (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6096 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7572 a b) ∨ (fact_366edf150095_7704 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7572 a b) ∧ (fact_366edf150095_7704 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7572 a b) ∧ (fact_366edf150095_7704 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_5651 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6610 a b)))) ∨ ((fact_366edf150095_7572 a b) ∧ (fact_366edf150095_7704 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5577 a b) ∨ (fact_366edf150095_5651 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6610 a b))))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3005 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((2 : Int) + a) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n244_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3587 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) + a) ≤ run_x))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3501 a b) ∨ (fact_366edf150095_3450 a b) ∨ (fact_366edf150095_5777 a b) ∨ (fact_366edf150095_5785 a b) ∨ (fact_366edf150095_3458 a b) ∨ (fact_366edf150095_3696 a b) ∨ (fact_366edf150095_3465 a b) ∨ (fact_366edf150095_5792 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3706 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6963 a b) ∨ (fact_366edf150095_6951 a b) ∨ (fact_366edf150095_7268 a b) ∨ (fact_366edf150095_7270 a b) ∨ (fact_366edf150095_6953 a b) ∨ (fact_366edf150095_7009 a b) ∨ (fact_366edf150095_6954 a b) ∨ (fact_366edf150095_7275 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_7020 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7419 a b) ∨ (fact_366edf150095_7759 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7419 a b) ∧ (fact_366edf150095_7759 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7419 a b) ∧ (fact_366edf150095_7759 a b) ∧ (((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_3930 a b) ∨ (fact_366edf150095_4378 a b)) ∨ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7043 a b) ∨ (fact_366edf150095_7202 a b)))) ∨ ((fact_366edf150095_7419 a b) ∧ (fact_366edf150095_7759 a b) ∧ ((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_3930 a b) ∨ (fact_366edf150095_4378 a b)) ∧ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7043 a b) ∨ (fact_366edf150095_7202 a b))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2328 a b run_x) ∨ (fact_366edf150095_2970 a b run_x)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n245_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3327 a b run_x) ∨ (fact_366edf150095_3550 a b run_x))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_empty (a b : Int)
    (h0 : ((fact_366edf150095_2905 a b) ∨ (fact_366edf150095_2577 a b) ∨ (fact_366edf150095_4066 a b) ∨ (fact_366edf150095_4071 a b) ∨ (fact_366edf150095_2580 a b) ∨ (fact_366edf150095_3180 a b) ∨ (fact_366edf150095_2582 a b) ∨ (fact_366edf150095_4073 a b) ∨ (fact_366edf150095_2585 a b) ∨ (fact_366edf150095_3191 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o0 (a b jx jy : Int)
    (h0 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (¬ (((jx = ((5 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o5 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((5 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n246_o7 (a b jx jy : Int)
    (h0 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_four (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (fact_366edf150095_4940 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6099 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7561 a b) ∨ (fact_366edf150095_7700 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7561 a b) ∧ (fact_366edf150095_7700 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7561 a b) ∧ (fact_366edf150095_7700 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_4966 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6100 a b)))) ∨ ((fact_366edf150095_7561 a b) ∧ (fact_366edf150095_7700 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_4966 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6100 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + a) ≤ run_x))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3010 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n247_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3593 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (((2 : Int) + a) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_empty (a b : Int)
    (h0 : ((fact_366edf150095_2908 a b) ∨ (fact_366edf150095_2588 a b) ∨ (fact_366edf150095_4081 a b) ∨ (fact_366edf150095_4086 a b) ∨ (fact_366edf150095_2591 a b) ∨ (fact_366edf150095_3193 a b) ∨ (fact_366edf150095_2593 a b) ∨ (fact_366edf150095_4088 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((6 : Int) ≥ ((4 : Int) - b)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3203 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o0 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h9 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((6 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o6 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n248_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (fact_366edf150095_4940 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6099 a b) ∨ (fact_366edf150095_6102 a b) ∨ (fact_366edf150095_5808 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7655 a b) ∨ (fact_366edf150095_7762 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7655 a b) ∧ (fact_366edf150095_7762 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7655 a b) ∧ (fact_366edf150095_7762 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6109 a b)))) ∨ ((fact_366edf150095_7655 a b) ∧ (fact_366edf150095_7762 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6109 a b))))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) + a) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3010 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (fact_366edf150095_2340 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n249_run_floor (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3593 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (fact_366edf150095_3341 a b run_x))))
    (h3 : (((2 : Int) + a) ≤ run_x))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3468 a b) ∨ (fact_366edf150095_5795 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4040 a b) ∨ (fact_366edf150095_3710 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_3877 a b) ∨ (fact_366edf150095_6030 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4983 a b) ∨ (fact_366edf150095_4395 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7603 a b) ∨ (fact_366edf150095_7668 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7603 a b) ∧ (fact_366edf150095_7668 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7603 a b) ∧ (fact_366edf150095_7668 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4955 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7603 a b) ∧ (fact_366edf150095_7668 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4955 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2328 a b run_x) ∨ (fact_366edf150095_3012 a b run_x) ∨ (fact_366edf150095_3016 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (run_x ≤ ((5 : Int) + b)))
    (h6 : ((6 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n250_run_floor (a b run_x : Int)
    (h0 : ((6 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((5 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3327 a b run_x) ∨ (fact_366edf150095_3594 a b run_x) ∨ (fact_366edf150095_3600 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (fact_366edf150095_4940 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6099 a b) ∨ (fact_366edf150095_6102 a b) ∨ (fact_366edf150095_6067 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7661 a b) ∨ (fact_366edf150095_7771 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7661 a b) ∧ (fact_366edf150095_7771 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7661 a b) ∧ (fact_366edf150095_7771 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6558 a b)))) ∨ ((fact_366edf150095_7661 a b) ∧ (fact_366edf150095_7771 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6558 a b))))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3010 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (fact_366edf150095_2974 a b run_x)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((2 : Int) + a) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n251_run_floor (a b run_x : Int)
    (h0 : (((2 : Int) + a) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3593 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (fact_366edf150095_3554 a b run_x))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (fact_366edf150095_4940 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6099 a b) ∨ (fact_366edf150095_6102 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7662 a b) ∨ (fact_366edf150095_7772 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7662 a b) ∧ (fact_366edf150095_7772 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7662 a b) ∧ (fact_366edf150095_7772 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6621 a b)))) ∨ ((fact_366edf150095_7662 a b) ∧ (fact_366edf150095_7772 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5653 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6621 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + a) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2327 a b run_x) ∨ (fact_366edf150095_3010 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n252_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3326 a b run_x) ∨ (fact_366edf150095_3593 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (((2 : Int) + a) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3504 a b) ∨ (fact_366edf150095_3453 a b) ∨ (fact_366edf150095_5780 a b) ∨ (fact_366edf150095_5788 a b) ∨ (fact_366edf150095_3461 a b) ∨ (fact_366edf150095_3699 a b) ∨ (fact_366edf150095_3467 a b) ∨ (fact_366edf150095_5794 a b) ∨ (fact_366edf150095_3469 a b) ∨ (((((4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3708 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4126 a b) ∨ (fact_366edf150095_3721 a b) ∨ (fact_366edf150095_5872 a b) ∨ (fact_366edf150095_5955 a b) ∨ (fact_366edf150095_3802 a b) ∨ (fact_366edf150095_4235 a b) ∨ (fact_366edf150095_3875 a b) ∨ (fact_366edf150095_6028 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((4 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4387 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7504 a b) ∨ (fact_366edf150095_7577 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7504 a b) ∧ (fact_366edf150095_7577 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7504 a b) ∧ (fact_366edf150095_7577 a b) ∧ (((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_3940 a b) ∨ (fact_366edf150095_4945 a b) ∨ (fact_366edf150095_4390 a b)) ∨ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_4713 a b) ∨ (fact_366edf150095_5637 a b) ∨ (fact_366edf150095_5401 a b)))) ∨ ((fact_366edf150095_7504 a b) ∧ (fact_366edf150095_7577 a b) ∧ ((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_3940 a b) ∨ (fact_366edf150095_4945 a b) ∨ (fact_366edf150095_4390 a b)) ∧ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_4713 a b) ∨ (fact_366edf150095_5637 a b) ∨ (fact_366edf150095_5401 a b))))))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2328 a b run_x) ∨ (fact_366edf150095_3012 a b run_x) ∨ (fact_366edf150095_2973 a b run_x)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n253_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3327 a b run_x) ∨ (fact_366edf150095_3594 a b run_x) ∨ (fact_366edf150095_3553 a b run_x))))
    (h1 : (run_x ≤ ((4 : Int) + b)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4121 a b) ∨ (fact_366edf150095_3716 a b) ∨ (fact_366edf150095_5867 a b) ∨ (fact_366edf150095_5950 a b) ∨ (fact_366edf150095_3797 a b) ∨ (fact_366edf150095_4230 a b) ∨ (fact_366edf150095_3874 a b) ∨ (fact_366edf150095_6027 a b) ∨ (fact_366edf150095_3922 a b) ∨ (fact_366edf150095_4940 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_5802 a b) ∨ (fact_366edf150095_6099 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n254_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7573 a b) ∨ (fact_366edf150095_7705 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7573 a b) ∧ (fact_366edf150095_7705 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7573 a b) ∧ (fact_366edf150095_7705 a b) ∧ (((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5388 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6555 a b)))) ∨ ((fact_366edf150095_7573 a b) ∧ (fact_366edf150095_7705 a b) ∧ ((fact_366edf150095_5128 a b) ∨ (fact_366edf150095_4422 a b) ∨ (fact_366edf150095_6347 a b) ∨ (fact_366edf150095_6435 a b) ∨ (fact_366edf150095_4506 a b) ∨ (fact_366edf150095_5256 a b) ∨ (fact_366edf150095_4588 a b) ∨ (fact_366edf150095_6515 a b) ∨ (fact_366edf150095_4705 a b) ∨ (fact_366edf150095_5622 a b) ∨ (fact_366edf150095_5388 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6084 a b) ∨ (fact_366edf150095_6606 a b) ∨ (fact_366edf150095_6555 a b))))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

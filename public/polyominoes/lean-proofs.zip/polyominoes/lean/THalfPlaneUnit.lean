import THalfPlane
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
namespace PolyominoFormal.THalfPlaneUnit
open CrossUnits TBoundary THalfPlane THalfPlaneStarters THalfPlaneGaps

def V (a b : Int) : Cross := ⟨0,1,b,a,0,1⟩
def H (a b : Int) : Cross := ⟨a+1,0,1,b,a,0⟩
def Base (a b : Int) : Region := fun x y => Contains (V a b) x y ∨ Contains (H a b) x y

theorem base_closed {a b : Int} (T : Tiling a b 1 0 HalfPlane)
    (hv : T.world (V a b)) (hh : T.world (H a b)) :
    CornerCertificate.TileClosed T.world (Base a b) := pair_closed T hv hh

theorem base_gap {a b : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (gap : b+3≤a) (T : Tiling a b 1 0 HalfPlane)
    (hv : T.world (V a b)) (hh : T.world (H a b)) : False := by
  apply blocked_short_run (L:=b+1) (R:=a) (h:=1) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) T (Base a b) (base_closed T hv hh)
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [Base,V,H,Contains]; omega
  · intro x h0 h1; right; left; dsimp [H]; omega
  · left; left; dsimp [V]; omega
  · right; right; dsimp [H]; omega

theorem equal_gap {a b : Int} (ha : 7≤a) (eq : a=b)
    (T : Tiling a b 1 0 HalfPlane)
    (hv : T.world (V a b)) (hh : T.world (H a b)) : False := by
  apply blocked_short_run (L:=1) (R:=b) (h:=2) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) T (Base a b) (base_closed T hv hh)
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [Base,V,H,Contains]; omega
  · intro x h0 h1; left; left; dsimp [V]; omega
  · left; right; dsimp [V]; omega
  · right; right; dsimp [H]; omega

theorem choose_gap {a b p : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (hp0 : b+1≤p) (hp1 : p≤a) (T : Tiling a b 1 0 HalfPlane)
    (hv : T.world (V a b)) (hh : T.world (H a b)) :
    ∃ t, T.world t ∧ Starter a b 1 p 1 t := by
  obtain ⟨t,ht,hit⟩ := T.cover p 1 (by unfold HalfPlane; omega)
  have empty : ¬Base a b p 1 := by dsimp [Base,V,H,Contains]; omega
  have avoid : ∀{x y}, Base a b x y → ¬Contains t x y :=
    fun blocked => avoid_closed (base_closed T hv hh) ht hit empty blocked
  refine ⟨t,ht,short_run_forms (L:=b+1) (R:=a) (by omega) (by omega) (by omega)
    (by omega) hp0 hp1 (T.copies t ht) hit ?_ ?_ ?_ ?_⟩
  · apply avoid; left; left; dsimp [V]; omega
  · apply avoid; right; right; dsimp [H]; omega
  · apply avoid; right; left; dsimp [H]; omega
  · intro h0 h1; apply avoid; right; left; dsimp [H]; omega

def Tall (a b : Int) (t : Cross) : Prop :=
  t=⟨b+1,1+a,b,1,0,a⟩ ∨ t=⟨b+1,1+a,0,1,b,a⟩ ∨
  t=⟨b+1,1+b,a,0,1,b⟩ ∨ t=⟨b+1,1+b,1,0,a,b⟩

theorem tall_gap {a b : Int} (ha : 7≤a) (hb : 3≤b) (short : b+1≤a)
    (T : Tiling a b 1 0 HalfPlane) (hv : T.world (V a b))
    (hh : T.world (H a b)) {t : Cross} (ht : T.world t) (tall : Tall a b t) : False := by
  apply blocked_short_run (L:=1) (R:=b) (h:=2) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) T (fun x y => Base a b x y ∨ Contains t x y)
    (union_closed (base_closed T hv hh) (single_closed T ht))
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; rcases tall with rfl | rfl | rfl | rfl
    all_goals dsimp [Base,V,H,Contains]; omega
  · intro x h0 h1; left; left; left; dsimp [V]; omega
  · left; left; right; dsimp [V]; omega
  · right; rcases tall with rfl | rfl | rfl | rfl
    all_goals right; dsimp; omega

theorem left_short_gap {a b : Int} (ha : 7≤a) (hb : 3≤b) (short : b+1≤a)
    (T : Tiling a b 1 0 HalfPlane) (hv : T.world (V a b))
    (hh : T.world (H a b)) (ht : T.world ⟨b+1,2,0,a,b,1⟩) : False := by
  apply blocked_short_run (L:=1) (R:=b) (h:=3) (by omega) (by omega) (by omega)
    (by omega) (by omega) (by omega) T (fun x y => Base a b x y ∨ Contains ⟨b+1,2,0,a,b,1⟩ x y)
    (union_closed (base_closed T hv hh) (single_closed T ht))
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [Base,V,H,Contains]; omega
  · intro x h0 h1; right; left; dsimp; omega
  · left; left; right; dsimp [V]; omega
  · right; right; dsimp; omega

theorem no_short_v_origin {a b : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (T : Tiling a b 1 0 HalfPlane) (hv : T.world (V a b)) : False := by
  obtain ⟨s,hs,hh⟩ := right_v_neighbor_horizontal (p:=0) (r:=1)
    (by omega) (by omega) hb (Or.inr rfl) T (by simpa [V] using hv)
  have hH : T.world (H a b) := by
    rcases hs with hs | hs
    · subst s; simpa only [H, show 0+1+a=a+1 by omega, show a+1-a=1 by omega] using hh
    · subst s
      have eq := T.disjoint _ _ 2 1 hh hv
        (by right; dsimp; omega) (by left; dsimp [V]; omega)
      have h := congrArg Cross.y eq; dsimp [V] at h; omega
  by_cases large : b+3≤a
  · exact base_gap ha hb short large T hv hH
  by_cases equal : a=b
  · exact equal_gap ha equal T hv hH
  have b3 : 3≤b := by omega
  obtain ⟨t,ht,st⟩ := choose_gap (p:=b+1) ha hb short (by omega) (by omega) T hv hH
  by_cases one : a=b+1
  · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    · exact tall_gap ha b3 (by omega) T hv hH ht (Or.inl rfl)
    · have eq := T.disjoint _ _ (b+2) 2 ht hH
        (by left; dsimp; omega) (by right; dsimp [H]; omega)
      have h := congrArg Cross.y eq; dsimp [H] at h; omega
    · exact tall_gap ha b3 (by omega) T hv hH ht (Or.inr (Or.inl rfl))
    · exact left_short_gap ha b3 (by omega) T hv hH ht
    · exact tall_gap ha b3 (by omega) T hv hH ht (Or.inr (Or.inr (Or.inl rfl)))
    · exact tall_gap ha b3 (by omega) T hv hH ht (Or.inr (Or.inr (Or.inr rfl)))
  · have two : a=b+2 := by omega
    obtain ⟨u,hu,su⟩ := choose_gap (p:=b+2) ha hb short (by omega) (by omega) T hv hH
    have ap : Apart t u := separate (by omega) (by omega) (by omega) T ht hu
      (starter_contains_base (by omega) (by omega) (by omega) st) (by
        intro hit
        have := starter_base_only (by omega) (by omega) (by omega) su hit
        omega)
    have left := (adjacent_starters (by omega) (by omega) (by omega) (by omega) st
      (by simpa only [show b+1+1=b+2 by omega] using su) ap).1
    rcases left with htall | hshort
    · exact tall_gap ha b3 (by omega) T hv hH ht (Or.inr (Or.inl htall))
    · rw [hshort] at ht
      exact left_short_gap ha b3 (by omega) T hv hH ht

theorem no_right_v_unit {a b p r : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (hr : r=a ∨ r=1) (T : Tiling a b 1 0 HalfPlane)
    (anchor : T.world ⟨p,r,b,a+1-r,0,r⟩) : False := by
  rcases hr with hr | hr
  · subst r
    exact no_right_v_short_lower (by omega) (by omega) hb short (Or.inl rfl) T anchor
  · subst r
    let U : Tiling a b 1 0 HalfPlane := (T.translate (-p) 0).congr (by
      intro x y; simp only [HalfPlane,Int.sub_zero])
    have hu : U.world (V a b) := by
      refine ⟨_,anchor,?_⟩
      apply same_eq; dsimp [Same,shift,V]; omega
    exact no_short_v_origin ha hb short U hu

theorem no_left_v_unit {a b p r : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (hr : r=a ∨ r=1) (T : Tiling a b 1 0 HalfPlane)
    (anchor : T.world ⟨p,r,0,a+1-r,b,r⟩) : False := by
  let U : Tiling a b 1 0 HalfPlane := T.mirrorX.congr (by intro x y; rfl)
  have hu : U.world ⟨-p,r,b,a+1-r,0,r⟩ := ⟨_,anchor,rfl⟩
  exact no_right_v_unit ha hb short hr U hu

theorem horizontal_cover_unit {a b : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (T : Tiling a b 1 0 HalfPlane) : HorizontalCover T := by
  intro z
  obtain ⟨t,ht,hit⟩ := T.cover z 0 (by unfold HalfPlane; omega)
  have forms := boundary_forms (by omega) (by omega) (by omega)
    (T.copies t ht) (hp_bound (by omega) (by omega) (by omega) T ht) hit
  rcases forms with ⟨x,rfl,h0,h1⟩ | ⟨x,rfl,h0,h1⟩ | st
  · refine ⟨x-1,1,Or.inr rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+1-1=a by omega] using ht
  · refine ⟨x-a,a,Or.inl rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+1-a=1 by omega] using ht
  · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals exfalso
    · exact no_right_v_unit ha hb short (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+1-a=1 by omega] using ht)
    · exact no_right_v_unit ha hb short (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+1-1=a by omega] using ht)
    · exact no_left_v_unit ha hb short (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+1-a=1 by omega] using ht)
    · exact no_left_v_unit ha hb short (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+1-1=a by omega] using ht)
    · exact no_s_right (by omega) (by omega) hb T (by simpa only [Int.zero_add] using ht)
    · exact no_s_left (by omega) (by omega) hb T (by simpa only [Int.zero_add] using ht)

/-- A full floor and blocked ends force either a horizontal crossbar within
this row or a starter, without any restriction on the length of the row. -/
theorem run_forms {a b c L R p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    (hp0 : L≤p) (hp1 : p≤R) {t : Cross} (copy : Copy a b c 0 t)
    (hit : Contains t p h) (left : ¬Contains t (L-1) h) (right : ¬Contains t (R+1) h)
    (floor : ¬Contains t p (h-1))
    (center : L≤t.x → t.x≤R → ¬Contains t t.x (h-1)) :
    (∃ q r, (r=a ∨ r=c) ∧ t=⟨q+r,h,a+c-r,b,r,0⟩ ∧
      L≤q ∧ q≤p ∧ p≤q+a+c ∧ q+a+c≤R) ∨ Starter a b c p h t := by
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) copy
  rcases nn with ⟨he,hn,hw,hs⟩
  by_cases row : t.y=h
  · have span : t.x-t.west≤p ∧ p≤t.x+t.east := by
      rcases hit with hit | hit <;> omega
    have noLeft : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact left (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have noRight : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact right (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have bounds : L≤t.x-t.west ∧ t.x+t.east≤R := by omega
    have south : t.south=0 := by
      apply Classical.byContradiction; intro neq
      exact center (by omega) (by omega) (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with copy | copy | copy | copy | copy | copy | copy | copy
    all_goals rcases copy with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs row south bounds span
    all_goals subst e; subst n; subst w; subst s
    · left; refine ⟨x-c,c,Or.inr rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
    · exfalso; omega
    · exfalso; omega
    · left; refine ⟨x-a,a,Or.inl rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
  · have vertical : t.x=p ∧ t.y-t.south≤h ∧ h≤t.y+t.north := by
      rcases hit with hit | hit <;> omega
    have bottom : t.y-t.south=h := by
      apply Classical.byContradiction; intro different
      exact floor (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    right
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with copy | copy | copy | copy | copy | copy | copy | copy
    all_goals rcases copy with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs bottom vertical row
    all_goals subst e; subst n; subst w; subst s
    · exfalso; omega
    · left; apply same_eq; dsimp [Same]; simp only [and_true]; omega
    · right; right; right; right; right
      apply same_eq; dsimp [Same]; simp only [and_true]; omega
    · right; right; right; left
      apply same_eq; dsimp [Same]; simp only [and_true]; omega
    · right; right; left
      apply same_eq; dsimp [Same]; simp only [and_true]; omega
    · exfalso; omega
    · right; left; apply same_eq; dsimp [Same]; simp only [and_true]; omega
    · right; right; right; right; left
      apply same_eq; dsimp [Same]; simp only [and_true]; omega

def WideBase (a b p : Int) : Region := fun x y =>
  Contains ⟨p+1,0,a,b,1,0⟩ x y ∨ Contains ⟨p+2*a+2,0,1,b,a,0⟩ x y

theorem early_horizontal_gap {a b p q r : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (hr : r=a ∨ r=1) (hq0 : p+2≤q) (hq1 : q≤p+4)
    (T : Tiling a b 1 0 HalfPlane)
    (h0 : T.world ⟨p+1,0,a,b,1,0⟩) (h1 : T.world ⟨p+2*a+2,0,1,b,a,0⟩)
    (hh : T.world ⟨q+r,1,a+1-r,b,r,0⟩) : False := by
  apply blocked_short_run (L:=q+a+2) (R:=p+2*a+1) (h:=1)
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) T
    (fun x y => WideBase a b p x y ∨ Contains ⟨q+r,1,a+1-r,b,r,0⟩ x y)
    (union_closed (pair_closed T h0 h1) (single_closed T hh))
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [WideBase,Contains]; omega
  · intro x h0 h1; left; dsimp [WideBase,Contains]; omega
  · right; left; dsimp; omega
  · left; right; right; dsimp; omega

theorem no_wide_pair {a b p : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (T : Tiling a b 1 0 HalfPlane)
    (h0 : T.world ⟨p+1,0,a,b,1,0⟩) (h1 : T.world ⟨p+2*a+2,0,1,b,a,0⟩) : False := by
  have closed : CornerCertificate.TileClosed T.world (WideBase a b p) := pair_closed T h0 h1
  have choose : ∀ z, p+2≤z → z≤p+4 → ∃t,T.world t ∧ Starter a b 1 z 1 t := by
    intro z hz0 hz1
    obtain ⟨t,ht,hit⟩ := T.cover z 1 (by unfold HalfPlane; omega)
    have empty : ¬WideBase a b p z 1 := by dsimp [WideBase,Contains]; omega
    have avoid : ∀{x y}, WideBase a b p x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit empty blocked
    have forms := run_forms (L:=p+2) (R:=p+2*a+1) (by omega) (by omega) (by omega)
      hz0 (by omega) (T.copies t ht) hit
      (avoid (by left; right; dsimp; omega))
      (avoid (by right; right; dsimp; omega))
      (avoid (by dsimp [WideBase,Contains]; omega))
      (by intro hx0 hx1; apply avoid; dsimp [WideBase,Contains]; omega)
    rcases forms with ⟨q,r,hr,eq,hq0,hq1,hq2,hq3⟩ | st
    · subst t
      exact False.elim (early_horizontal_gap ha hb short hr hq0 (by omega) T h0 h1 ht)
    · exact ⟨t,ht,st⟩
  obtain ⟨t,ht,st⟩ := choose (p+2) (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := choose (p+3) (by omega) (by omega)
  obtain ⟨v,hv,sv⟩ := choose (p+4) (by omega) (by omega)
  have ap : Apart t u := separate (by omega) (by omega) (by omega) T ht hu
    (starter_contains_base (by omega) (by omega) (by omega) st) (by
      intro hit; have := starter_base_only (by omega) (by omega) (by omega) su hit; omega)
  have ap2 : Apart u v := separate (by omega) (by omega) (by omega) T hu hv
    (starter_contains_base (by omega) (by omega) (by omega) su) (by
      intro hit; have := starter_base_only (by omega) (by omega) (by omega) sv hit; omega)
  exact no_three_starters (by omega) (by omega) (by omega) (by omega) st
    (by simpa only [show p+2+1=p+3 by omega] using su)
    (by simpa only [show p+2+2=p+4 by omega] using sv) ap ap2

theorem all_horizontal_unit_impossible {a b : Int} (ha : 7≤a) (hb : 2≤b) (short : b≤a)
    (T : Tiling a b 1 0 HalfPlane) (cover : HorizontalCover T) : False := by
  obtain ⟨p,r,hr,first,_,_⟩ := cover 0
  obtain ⟨s,hs,second⟩ := next_horizontal (by omega) (by omega) (by omega) hr T cover first
  have distinct : s≠r := by
    intro eq
    exact no_short_horizontal_pair (by omega) (by omega) (by omega) (by omega) hr hs
      (by omega) (by omega) T first second
  by_cases inc : r<s
  · have er : r=1 := by omega
    have es : s=a := by omega
    subst r; subst s
    exact no_wide_pair ha hb short T
      (by simpa only [show a+1-1=a by omega] using first)
      (by simpa only [show p+(a+1+1)+a=p+2*a+2 by omega,show a+1-a=1 by omega] using second)
  · obtain ⟨q,hq,third⟩ := next_horizontal (by omega) (by omega) (by omega) hs T cover second
    have distinct2 : q≠s := by
      intro eq
      exact no_short_horizontal_pair (by omega) (by omega) (by omega) (by omega) hs hq
        (by omega) (by omega) T second third
    have es : s=1 := by omega
    have eq : q=a := by omega
    subst s; subst q
    exact no_wide_pair (p:=p+(a+1+1)) ha hb short T
      (by simpa only [show a+1-1=a by omega] using second)
      (by simpa only [show p+(a+1+1)+(a+1+1)+a=p+(a+1+1)+2*a+2 by omega,
        show a+1-a=1 by omega] using third)

theorem no_halfplane_unit_large {a b : Int} (ha : 7≤a) (hb : 2≤b) :
    ¬Tiles a b 1 0 HalfPlane := by
  by_cases short : b≤a
  · rintro ⟨T⟩
    exact all_horizontal_unit_impossible ha hb short T (horizontal_cover_unit ha hb short T)
  · exact no_halfplane_unit_long (by omega) (by omega)

#print axioms no_short_v_origin
#print axioms horizontal_cover_unit
#print axioms run_forms
#print axioms no_wide_pair
#print axioms no_halfplane_unit_large
end PolyominoFormal.THalfPlaneUnit

import PositiveHierarchy

set_option maxRecDepth 10000
set_option maxHeartbeats 500000

namespace PositivePlaneTwo
open CrossUnits PolyominoFormal

def period (a c : Int) : Int := a+c+3
def upTile (a c k l : Int) : Cross :=
  ⟨k*period a c+l*(c+1),2*l,a,2,c,0⟩
def downTile (a c k l : Int) : Cross :=
  ⟨k*period a c+l*(c+1)+a+1,2*l+1,c,0,a,2⟩
def World (a c : Int) (t : Cross) : Prop :=
  ∃ k l, t=upTile a c k l ∨ t=downTile a c k l

/-- Three residue pieces on each row of a two-row slanted period cell. -/
def Info (a c k l : Int) (t : Cross) (x y : Int) : Prop :=
  (t=upTile a c k l ∧ y=2*l ∧
    k*period a c+1≤x-l*(c+1)+c+1 ∧ x-l*(c+1)+c+1≤k*period a c+period a c-2) ∨
  (t=upTile a c k (l-1) ∧ y=2*l ∧ x-l*(c+1)+c+1=k*period a c) ∨
  (t=downTile a c k l ∧ y=2*l ∧ x-l*(c+1)+c+1=k*period a c+period a c-1) ∨
  (t=downTile a c k l ∧ y=2*l+1 ∧
    k*period a c+1≤x-l*(c+1) ∧ x-l*(c+1)≤k*period a c+period a c-2) ∨
  (t=upTile a c k l ∧ y=2*l+1 ∧ x-l*(c+1)=k*period a c) ∨
  (t=downTile a c k (l+1) ∧ y=2*l+1 ∧ x-l*(c+1)=k*period a c+period a c-1)

theorem up_contains (a c k l x y : Int) (ha : 1≤a) (hc : 1≤c) :
    Contains (upTile a c k l) x y ↔
    (y=2*l ∧ k*period a c+l*(c+1)-c≤x ∧ x≤k*period a c+l*(c+1)+a) ∨
    (y=2*l+1 ∧ x=k*period a c+l*(c+1)) ∨
    (y=2*l+2 ∧ x=k*period a c+l*(c+1)) := by
  unfold Contains upTile
  dsimp
  omega

theorem down_contains (a c k l x y : Int) (ha : 1≤a) (hc : 1≤c) :
    Contains (downTile a c k l) x y ↔
    (y=2*l+1 ∧ k*period a c+l*(c+1)+1≤x ∧ x≤k*period a c+l*(c+1)+a+c+1) ∨
    (y=2*l ∧ x=k*period a c+l*(c+1)+a+1) ∨
    (y=2*l-1 ∧ x=k*period a c+l*(c+1)+a+1) := by
  unfold Contains downTile
  dsimp
  omega

theorem info_ybounds (a c k l : Int) (t : Cross) (x y : Int) (hi : Info a c k l t x y) :
    l*2≤y ∧ y<l*2+2 := by
  unfold Info at hi
  omega

theorem info_xbounds (a c k l : Int) (ha : 1≤a) (hc : 1≤c)
    (t : Cross) (x y : Int) (hi : Info a c k l t x y) :
    (y=2*l ∧ k*period a c≤x-l*(c+1)+c+1 ∧ x-l*(c+1)+c+1<k*period a c+period a c) ∨
    (y=2*l+1 ∧ k*period a c≤x-l*(c+1) ∧ x-l*(c+1)<k*period a c+period a c) := by
  unfold Info period at *
  omega

theorem info_contains (a c k l : Int) (ha : 1≤a) (hc : 1≤c)
    (t : Cross) (x y : Int) (hi : Info a c k l t x y) : Contains t x y := by
  rcases hi with ⟨rfl,hy,h0,h1⟩ | ⟨rfl,hy,he⟩ | ⟨rfl,hy,he⟩ |
    ⟨rfl,hy,h0,h1⟩ | ⟨rfl,hy,he⟩ | ⟨rfl,hy,he⟩
  · rw [up_contains a c k l x y ha hc]; left; unfold period at *; omega
  · rw [up_contains a c k (l-1) x y ha hc]; right; right
    simp only [Int.sub_mul,Int.one_mul]; omega
  · rw [down_contains a c k l x y ha hc]; right; left; unfold period at *; omega
  · rw [down_contains a c k l x y ha hc]; left; unfold period at *; omega
  · rw [up_contains a c k l x y ha hc]; right; left; omega
  · rw [down_contains a c k (l+1) x y ha hc]; right; right
    simp only [Int.add_mul,Int.one_mul]; unfold period at *; omega

theorem contains_info (a c : Int) (ha : 1≤a) (hc : 1≤c)
    (t : Cross) (x y : Int) (ht : World a c t) (hit : Contains t x y) :
    ∃ k l, Info a c k l t x y := by
  rcases ht with ⟨k,l,rfl | rfl⟩
  · rw [up_contains a c k l x y ha hc] at hit
    rcases hit with ⟨hy,h0,h1⟩ | ⟨hy,he⟩ | ⟨hy,he⟩
    · refine ⟨k,l,Or.inl ⟨rfl,hy,?_,?_⟩⟩ <;> unfold period at * <;> omega
    · exact ⟨k,l,Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,hy,by omega⟩))))⟩
    · refine ⟨k,l+1,Or.inr (Or.inl ⟨?_,?_,?_⟩)⟩
      · have heq : l+1-1=l := by omega
        rw [heq]
      · omega
      · simp only [Int.add_mul,Int.one_mul]; omega
  · rw [down_contains a c k l x y ha hc] at hit
    rcases hit with ⟨hy,h0,h1⟩ | ⟨hy,he⟩ | ⟨hy,he⟩
    · refine ⟨k,l,Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,hy,?_,?_⟩)))⟩
      all_goals unfold period at *
      all_goals omega
    · refine ⟨k,l,Or.inr (Or.inr (Or.inl ⟨rfl,hy,?_⟩))⟩
      unfold period at *; omega
    · refine ⟨k,l-1,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨?_,?_,?_⟩))))⟩
      · have heq : l-1+1=l := by omega
        rw [heq]
      · omega
      · simp only [Int.sub_mul,Int.one_mul]; unfold period at *; omega

theorem info_world (a c k l : Int) (t : Cross) (x y : Int) (hi : Info a c k l t x y) :
    World a c t := by
  rcases hi with ⟨rfl,_,_,_⟩ | ⟨rfl,_,_⟩ | ⟨rfl,_,_⟩ |
    ⟨rfl,_,_,_⟩ | ⟨rfl,_,_⟩ | ⟨rfl,_,_⟩
  · exact ⟨k,l,Or.inl rfl⟩
  · exact ⟨k,l-1,Or.inl rfl⟩
  · exact ⟨k,l,Or.inr rfl⟩
  · exact ⟨k,l,Or.inr rfl⟩
  · exact ⟨k,l,Or.inl rfl⟩
  · exact ⟨k,l+1,Or.inr rfl⟩

theorem info_unique (a c k l : Int) (ha : 1≤a) (hc : 1≤c) (t u : Cross) (x y : Int)
    (ht : Info a c k l t x y) (hu : Info a c k l u x y) : t=u := by
  rcases ht with ⟨rfl,hy,h0,h1⟩ | ⟨rfl,hy,he⟩ | ⟨rfl,hy,he⟩ |
    ⟨rfl,hy,h0,h1⟩ | ⟨rfl,hy,he⟩ | ⟨rfl,hy,he⟩
  all_goals rcases hu with ⟨rfl,hy',h0',h1'⟩ | ⟨rfl,hy',he'⟩ | ⟨rfl,hy',he'⟩ |
    ⟨rfl,hy',h0',h1'⟩ | ⟨rfl,hy',he'⟩ | ⟨rfl,hy',he'⟩
  all_goals unfold period at *
  all_goals first | rfl | omega

theorem cover_info (a c x y : Int) (ha : 1≤a) (hc : 1≤c) :
    ∃ k l t, Info a c k l t x y := by
  let n := period a c
  let l := y/2
  have hn : 0<n := by dsimp [n,period]; omega
  have hyb := PositiveHierarchy.div_bounds 2 y (by omega)
  have hy : y=2*l ∨ y=2*l+1 := by dsimp [l]; omega
  rcases hy with hy | hy
  · let z := x-l*(c+1)+c+1
    let k := z/n
    let r := z%n
    have hr0 : 0≤r := Int.emod_nonneg _ (by omega)
    have hr1 : r<n := Int.emod_lt_of_pos _ hn
    have he : r+k*n=z := Int.emod_add_ediv_mul _ _
    by_cases hzero : r=0
    · refine ⟨k,l,upTile a c k (l-1),Or.inr (Or.inl ⟨rfl,hy,?_⟩)⟩
      change z=k*n; omega
    · by_cases hend : r=n-1
      · refine ⟨k,l,downTile a c k l,Or.inr (Or.inr (Or.inl ⟨rfl,hy,?_⟩))⟩
        change z=k*n+n-1; omega
      · refine ⟨k,l,upTile a c k l,Or.inl ⟨rfl,hy,?_,?_⟩⟩
        · change k*n+1≤z; omega
        · change z≤k*n+n-2; omega
  · let z := x-l*(c+1)
    let k := z/n
    let r := z%n
    have hr0 : 0≤r := Int.emod_nonneg _ (by omega)
    have hr1 : r<n := Int.emod_lt_of_pos _ hn
    have he : r+k*n=z := Int.emod_add_ediv_mul _ _
    by_cases hzero : r=0
    · refine ⟨k,l,upTile a c k l,Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,hy,?_⟩))))⟩
      change z=k*n; omega
    · by_cases hend : r=n-1
      · refine ⟨k,l,downTile a c k (l+1),Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨rfl,hy,?_⟩))))⟩
        change z=k*n+n-1; omega
      · refine ⟨k,l,downTile a c k l,Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl,hy,?_,?_⟩)))⟩
        · change k*n+1≤z; omega
        · change z≤k*n+n-2; omega

def planeTiling (a c : Int) (ha : 1≤a) (hc : 1≤c) : Tiling a 2 c 0 Plane where
  world := World a c
  copies := by
    rintro t ⟨k,l,rfl | rfl⟩
    all_goals simp [Copy,Arms,upTile,downTile]
  inside := by intros; trivial
  cover := by
    intro x y _
    obtain ⟨k,l,t,hi⟩ := cover_info a c x y ha hc
    exact ⟨t,info_world a c k l t x y hi,info_contains a c k l ha hc t x y hi⟩
  disjoint := by
    intro t u x y ht hu hit hiu
    obtain ⟨k,l,hk⟩ := contains_info a c ha hc t x y ht hit
    obtain ⟨q,m,hq⟩ := contains_info a c ha hc u x y hu hiu
    have hlb := info_ybounds a c k l t x y hk
    have hmb := info_ybounds a c q m u x y hq
    have hlm := PositiveConstructions.block_unique 2 l m y (by omega) hlb.1 hlb.2 hmb.1 hmb.2
    subst m
    have hkb := info_xbounds a c k l ha hc t x y hk
    have hqb := info_xbounds a c q l ha hc u x y hq
    have hn : 0<period a c := by unfold period; omega
    have hkq : k=q := by
      rcases hkb with ⟨hy,h0,h1⟩ | ⟨hy,h0,h1⟩
      all_goals rcases hqb with ⟨hy',h0',h1'⟩ | ⟨hy',h0',h1'⟩
      · exact PositiveConstructions.block_unique (period a c) k q _ hn h0 h1 h0' h1'
      · omega
      · omega
      · exact PositiveConstructions.block_unique (period a c) k q _ hn h0 h1 h0' h1'
    subst q
    exact info_unique a c k l ha hc t u x y hk hq

theorem tiles_plane (a c : Int) (ha : 1≤a) (hc : 1≤c) : Tiles a 2 c 0 Plane :=
  ⟨planeTiling a c ha hc⟩

#print axioms tiles_plane
end PositivePlaneTwo

import LHalfPlaneEqualStarters
import LQuadrantEqualHalfPlaneFinite
import THalfPlane
set_option maxHeartbeats 100000
set_option maxRecDepth 10000
namespace PolyominoFormal.LHalfPlaneEqual
open CrossUnits TBoundary THalfPlaneGaps

def HorizontalCover {a : Int} (T : Tiling a a 0 0 HalfPlane) : Prop :=
  ∀z,∃p r,(r=0 ∨ r=a) ∧ T.world ⟨p+r,0,a-r,a,r,0⟩ ∧ p≤z ∧ z≤p+a

theorem horizontal_cover {a : Int} (ha : 3≤a) (T : Tiling a a 0 0 HalfPlane) : HorizontalCover T := by
  intro z
  obtain ⟨⟨x,y,e,n,w,s⟩,ht,hit⟩ := T.cover z 0 (by unfold HalfPlane; omega)
  have bound := THalfPlane.hp_bound (by omega) (by omega) (by omega) T ht
  have cp := T.copies _ ht
  rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
  all_goals rcases cp with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp [Contains] at hit
  · have hy : y=0 := by omega
    subst y; refine ⟨x,0,Or.inl rfl,?_,by omega,by omega⟩
    simpa only [Int.add_zero,Int.sub_zero] using ht
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.equal_no_right_tip a x ha T ht)
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.equal_no_left_tip a x ha T ht)
  · have hy : y=0 := by omega
    subst y; refine ⟨x-a,a,Or.inr rfl,?_,by omega,by omega⟩
    simpa only [Int.sub_add_cancel,Int.sub_self] using ht
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.equal_no_left_tip a x ha T ht)
  · have hy : y=0 := by omega
    subst y; refine ⟨x-a,a,Or.inr rfl,?_,by omega,by omega⟩
    simpa only [Int.sub_add_cancel,Int.sub_self] using ht
  · have hy : y=0 := by omega
    subst y; refine ⟨x,0,Or.inl rfl,?_,by omega,by omega⟩
    simpa only [Int.add_zero,Int.sub_zero] using ht
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.equal_no_right_tip a x ha T ht)

theorem next_horizontal {a p r : Int} (ha : 1≤a) (hr : r=0 ∨ r=a)
    (T : Tiling a a 0 0 HalfPlane) (cover : HorizontalCover T)
    (ht : T.world ⟨p+r,0,a-r,a,r,0⟩) :
    ∃s,(s=0 ∨ s=a) ∧ T.world ⟨p+(a+1)+s,0,a-s,a,s,0⟩ := by
  obtain ⟨q,s,hs,hu,hq0,hq1⟩ := cover (p+(a+1))
  have hit : Contains ⟨q+s,0,a-s,a,s,0⟩ (p+(a+1)) 0 := by left; dsimp; omega
  have ap := separate (by omega) (by omega) (by omega) T hu ht hit
    (by dsimp [Contains]; omega)
  have hq : q=p+(a+1) := by dsimp [Apart] at ap; omega
  subst q; exact ⟨s,hs,hu⟩

theorem no_equal_pair {a p r : Int} (ha : 3≤a) (hr : r=0 ∨ r=a)
    (T : Tiling a a 0 0 HalfPlane)
    (ht : T.world ⟨p+r,0,a-r,a,r,0⟩)
    (hu : T.world ⟨p+(a+1)+r,0,a-r,a,r,0⟩) : False := by
  apply blocked_short_run (L:=p+r+1) (R:=p+a+r) (h:=1) (by omega)
    (by omega) (by omega) T _ (pair_closed T ht hu)
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [Contains]; omega
  · intro x h0 h1; dsimp [Contains]; omega
  · left; right; dsimp; omega
  · right; right; dsimp; omega

def WideBase (a p : Int) : Region := fun x y =>
  Contains ⟨p,0,a,a,0,0⟩ x y ∨ Contains ⟨p+2*a+1,0,0,a,a,0⟩ x y

theorem early_horizontal_gap {a p q r : Int} (ha : 6≤a) (hr : r=0 ∨ r=a)
    (hq0 : p+1≤q) (hq1 : q≤p+3) (T : Tiling a a 0 0 HalfPlane)
    (h0 : T.world ⟨p,0,a,a,0,0⟩) (h1 : T.world ⟨p+2*a+1,0,0,a,a,0⟩)
    (ht : T.world ⟨q+r,1,a-r,a,r,0⟩) : False := by
  apply blocked_short_run (L:=q+a+1) (R:=p+2*a) (h:=1) (by omega)
    (by omega) (by omega) T (fun x y => WideBase a p x y ∨ Contains ⟨q+r,1,a-r,a,r,0⟩ x y)
    (union_closed (pair_closed T h0 h1) (single_closed T ht))
  · intro x h0 h1; unfold HalfPlane; omega
  · intro x h0 h1; dsimp [WideBase,Contains]; omega
  · intro x h0 h1; left; dsimp [WideBase,Contains]; omega
  · right; left; dsimp; omega
  · left; right; right; dsimp; omega

theorem no_wide_pair {a p : Int} (ha : 6≤a) (T : Tiling a a 0 0 HalfPlane)
    (h0 : T.world ⟨p,0,a,a,0,0⟩) (h1 : T.world ⟨p+2*a+1,0,0,a,a,0⟩) : False := by
  have closed : CornerCertificate.TileClosed T.world (WideBase a p) := pair_closed T h0 h1
  have choose : ∀z,p+1≤z → z≤p+3 → ∃t,T.world t ∧ Starter a z 1 t := by
    intro z hz0 hz1
    obtain ⟨t,ht,hit⟩ := T.cover z 1 (by unfold HalfPlane; omega)
    have empty : ¬WideBase a p z 1 := by dsimp [WideBase,Contains]; omega
    have avoid : ∀{x y},WideBase a p x y → ¬Contains t x y :=
      fun blocked => THalfPlaneStarters.avoid_closed closed ht hit empty blocked
    have forms := run_forms (L:=p+1) (R:=p+2*a) (by omega) hz0 (by omega)
      (T.copies t ht) hit
      (avoid (by left; right; dsimp; omega)) (avoid (by right; right; dsimp; omega))
      (avoid (by dsimp [WideBase,Contains]; omega))
      (by intro h0 h1; apply avoid; dsimp [WideBase,Contains]; omega)
    rcases forms with ⟨q,r,hr,eq,hq0,hq1,hq2,hq3⟩ | st
    · subst t; exact False.elim (early_horizontal_gap ha hr hq0 (by omega) T h0 h1 ht)
    · exact ⟨t,ht,st⟩
  obtain ⟨t,ht,st⟩ := choose (p+1) (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := choose (p+2) (by omega) (by omega)
  obtain ⟨v,hv,sv⟩ := choose (p+3) (by omega) (by omega)
  have ap : Apart t u := separate (by omega) (by omega) (by omega) T ht hu
    (starter_base (by omega) st) (by intro hit; have := starter_base_only (by omega) su hit; omega)
  have ap2 : Apart u v := separate (by omega) (by omega) (by omega) T hu hv
    (starter_base (by omega) su) (by intro hit; have := starter_base_only (by omega) sv hit; omega)
  exact no_three (by omega) st
    (by simpa only [show p+1+1=p+2 by omega] using su)
    (by simpa only [show p+1+2=p+3 by omega] using sv) ap ap2

theorem no_halfplane_large {a : Int} (ha : 6≤a) : ¬Tiles a a 0 0 HalfPlane := by
  rintro ⟨T⟩
  have cover := horizontal_cover (by omega) T
  obtain ⟨p,r,hr,h0,_,_⟩ := cover 0
  obtain ⟨s,hs,h1⟩ := next_horizontal (by omega) hr T cover h0
  have distinct : s≠r := by intro eq; subst s; exact no_equal_pair (by omega) hr T h0 h1
  by_cases inc : r<s
  · have er : r=0 := by omega
    have es : s=a := by omega
    subst r; subst s
    exact no_wide_pair ha T
      (by simpa only [Int.add_zero,Int.sub_zero] using h0)
      (by simpa only [show p+(a+1)+a=p+2*a+1 by omega,Int.sub_self] using h1)
  · obtain ⟨q,hq,h2⟩ := next_horizontal (by omega) hs T cover h1
    have distinct2 : q≠s := by intro eq; subst q; exact no_equal_pair (by omega) hs T h1 h2
    have es : s=0 := by omega
    have eq : q=a := by omega
    subst s; subst q
    exact no_wide_pair (p:=p+(a+1)) ha T
      (by simpa only [Int.add_zero,Int.sub_zero] using h1)
      (by simpa only [show p+(a+1)+(a+1)+a=p+(a+1)+2*a+1 by omega,Int.sub_self] using h2)

theorem no_halfplane {a : Int} (ha : 3≤a) : ¬Tiles a a 0 0 HalfPlane := by
  by_cases large : 6≤a
  · exact no_halfplane_large large
  · exact LRegion.equal_finite_no_half_plane a ha (by omega)

#print axioms no_halfplane_large
#print axioms no_halfplane
end PolyominoFormal.LHalfPlaneEqual

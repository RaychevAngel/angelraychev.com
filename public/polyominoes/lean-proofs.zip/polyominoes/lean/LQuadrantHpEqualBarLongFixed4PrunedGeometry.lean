import LQuadrantHpEqualBarLongFixed4PrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LQuadrantBoundaryTips
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_equal_bar_long_fixed_4_pruned_M (a b : Int) : Int := 12*(a+b+1)
def HP_equal_bar_long_fixed_4_pruned_Box (a b x y : Int) : Prop := -HP_equal_bar_long_fixed_4_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_equal_bar_long_fixed_4_pruned_M a b ∧ y≤HP_equal_bar_long_fixed_4_pruned_M a b
def HP_equal_bar_long_fixed_4_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_equal_bar_long_fixed_4_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ht3 : world (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_3 : Apart (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht2
  have in3 := inside (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht2
  have allowed3 := avoid (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o0 a b jx jy (hfixed_a) (heq) (hit) (sep0).2.1 (sep2).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o1 a b jx jy (insideT) (sep2).2.2.1 (hfixed_a) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o2 a b jx jy (hit) (heq) (sep2).2.2.1 (hfixed_a) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o3 a b jx jy (heq) (hit) (sep0).2.1 (insideT) (hfixed_a) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o4 a b jx jy (hit) (hfixed_a) (insideT) (sep2).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o5 a b jx jy (hfixed_a) (sep3).2.1 (hit) (sep3).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o6 a b jx jy (heq) (sep3).2.2.1 (hit) (sep3).2.1 (hfixed_a) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n003_o7 a b jx jy (sep3).2.2.1 (heq) (sep2).2.2.1 (insideT) (hfixed_a) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht2
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o0 a b jx jy (heq) (hfixed_a) (hit) (sep0).2.1 (sep0).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o1 a b jx jy (insideT) (sep2).2.2.1 (hfixed_a) (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o2 a b jx jy (hfixed_a) (heq) (insideT) (allowed) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o3 a b jx jy (hfixed_a) (sep0).2.2.1 (hit) (heq) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node003 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o4 a b jx jy (hit) (sep0).2.2.1 (insideT) (sep2).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o5 a b jx jy (sep0).2.1 (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.2.1 (heq) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node003 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o6 a b jx jy (hfixed_a) (sep0).2.2.1 (sep2).2.2.1 (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n002_o7 a b jx jy (hfixed_a) (heq) (insideT) (hit) (allowed) (sep2).2.2.1

theorem HP_equal_bar_long_fixed_4_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht2
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o0 a b jx jy (hfixed_a) (sep1).2.2.1 (sep1).2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o1 a b jx jy (sep2).2.2.1 (hfixed_a) (hit) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o2 a b jx jy (allowed) (hfixed_a) (hit) (sep2).2.2.1 (insideT) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o3 a b jx jy (heq) (hit) (sep2).2.1 (hfixed_a) (sep1).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o4 a b jx jy (sep2).2.2.1 (hfixed_a) (hit) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o5 a b jx jy (sep1).2.1 (hfixed_a) (hit) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o6 a b jx jy (hfixed_a) (hit) (sep1).2.2.1 (sep1).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n004_o7 a b jx jy (hfixed_a) (heq) (sep2).2.2.1 (hit) (allowed) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht1
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o0 a b jx jy (hfixed_a) (sep0).2.1 (hit) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o1 a b jx jy (hfixed_a) (heq) (hit) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node002 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o2 a b jx jy (hfixed_a) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (heq) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node004 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o3 a b jx jy (sep0).2.1 (hfixed_a) (sep1).2.1 (heq) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o4 a b jx jy (hit) (hfixed_a) (sep1).2.2.1 (heq) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node004 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o5 a b jx jy (sep0).2.1 (hit) (hfixed_a) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o6 a b jx jy (insideT) (hit) (sep0).2.1 (heq) (sep1).2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (-1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n001_o7 a b jx jy (hfixed_a) (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (allowed) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node002 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)

theorem HP_equal_bar_long_fixed_4_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht3
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o0 a b jx jy (hfixed_a) (insideT) (hit) (sep0).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o1 a b jx jy (hit) (insideT) (hfixed_a) (sep0).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o2 a b jx jy (hit) (insideT) (hfixed_a) (heq) (allowed) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o3 a b jx jy (sep2).2.1 (sep0).2.2.1 (heq) (hit) (hfixed_a) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o4 a b jx jy (sep0).2.2.1 (sep3).2.2.1 (hit) (insideT) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o5 a b jx jy (sep3).2.1 (hit) (hfixed_a) (sep0).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o6 a b jx jy (hit) (heq) (hfixed_a) (sep3).2.1 (sep0).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n007_o7 a b jx jy (hit) (heq) (allowed) (sep3).2.2.1 (hfixed_a) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node009 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ht4 : world (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_4 : Apart (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht3
  have in4 := inside (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o0 a b jx jy (hfixed_a) (hit) (sep1).2.1 (sep4).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o1 a b jx jy (hit) (sep4).2.2.1 (insideT) (hfixed_a) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o2 a b jx jy (heq) (hfixed_a) (insideT) (sep3).2.2.1 (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o3 a b jx jy (sep4).2.2.1 (hit) (sep1).2.1 (hfixed_a) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o4 a b jx jy (insideT) (sep4).2.2.1 (hit) (sep3).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o5 a b jx jy (heq) (sep1).2.1 (hit) (sep3).2.2.1 (sep4).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o6 a b jx jy (sep1).2.1 (hit) (sep4).2.1 (hfixed_a) (heq) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n009_o7 a b jx jy (hfixed_a) (sep4).2.2.1 (heq) (hit) (sep3).2.2.1

theorem HP_equal_bar_long_fixed_4_pruned_node008 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht3
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o0 a b jx jy (heq) (hfixed_a) (sep1).2.1 (hit) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node009 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o1 a b jx jy (insideT) (hit) (hfixed_a) (sep3).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o2 a b jx jy (heq) (hit) (insideT) (sep3).2.2.1 (hfixed_a) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o3 a b jx jy (hit) (sep3).2.2.1 (sep1).2.2.1 (hfixed_a) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o4 a b jx jy (hit) (hfixed_a) (insideT) (sep3).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o5 a b jx jy (sep3).2.2.1 (heq) (hfixed_a) (sep1).2.1 (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o6 a b jx jy (hfixed_a) (heq) (sep1).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node009 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n008_o7 a b jx jy (insideT) (hfixed_a) (sep3).2.2.1 (allowed) (hit) (heq)

theorem HP_equal_bar_long_fixed_4_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht2
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o0 a b jx jy (hfixed_a) (hit) (sep0).2.1 (sep0).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o1 a b jx jy (heq) (sep0).2.2.1 (hfixed_a) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node007 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o2 a b jx jy (hit) (hfixed_a) (insideT) (heq) (allowed) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node008 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o3 a b jx jy (hit) (hfixed_a) (insideT) (sep2).2.1 (sep0).2.1 (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o4 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hfixed_a) (sep0).2.2.1 (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node008 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o5 a b jx jy (sep2).2.1 (sep0).2.1 (hit) (insideT) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o6 a b jx jy (heq) (sep0).2.1 (hit) (sep2).2.1 (hfixed_a) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n006_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (allowed) (hit) (hfixed_a) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node007 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_equal_bar_long_fixed_4_pruned_node015 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ht7 : world (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_7 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have in7 := inside (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-7 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (-7 : Int) (2 : Int) ∨ Contains (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-7 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-7 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o0 a b jx jy (heq) (hfixed_a) (hit) (sep6).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o1 a b jx jy (hit) (sep7).2.2.1 (insideT) (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o2 a b jx jy (sep6).2.2.1 (hit) (insideT) (hfixed_a) (heq) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o3 a b jx jy (hit) (sep3).2.1 (hfixed_a) (heq) (sep7).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o4 a b jx jy (hfixed_a) (sep6).2.2.1 (insideT) (hit) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o5 a b jx jy (hfixed_a) (insideT) (sep7).2.1 (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o6 a b jx jy (sep7).2.2.1 (hit) (sep3).2.1 (sep6).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n015_o7 a b jx jy (insideT) (sep6).2.2.1 (hit) (sep7).2.2.1 (heq) (hfixed_a)

theorem HP_equal_bar_long_fixed_4_pruned_node014 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-9 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-9 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (-9 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-9 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o0 a b jx jy (heq) (hfixed_a) (hit) (sep3).2.1 (sep3).2.2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o1 a b jx jy (insideT) (hit) (hfixed_a) (sep3).2.2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o2 a b jx jy (insideT) (hit) (hfixed_a) (heq) (allowed) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o3 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (heq) (hfixed_a) (sep3).2.2.1 (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node015 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o4 a b jx jy (sep6).2.2.1 (insideT) (hfixed_a) (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o5 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep3).2.1 (heq) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node015 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o6 a b jx jy (hfixed_a) (sep3).2.1 (sep6).2.2.1 (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n014_o7 a b jx jy (hit) (hfixed_a) (insideT) (sep6).2.2.1 (heq) (allowed)

theorem HP_equal_bar_long_fixed_4_pruned_node016 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-12 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-12 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-12 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-12 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o0 a b jx jy (hfixed_a) (hit) (sep6).2.1 (sep5).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o1 a b jx jy (hit) (sep6).2.2.1 (sep5).2.2.1 (insideT) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o2 a b jx jy (hit) (hfixed_a) (heq) (sep6).2.2.1 (insideT) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o3 a b jx jy (hit) (sep6).2.1 (sep6).2.2.1 (sep5).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o4 a b jx jy (hfixed_a) (hit) (sep6).2.2.1 (insideT) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o5 a b jx jy (hit) (insideT) (sep6).2.1 (hfixed_a) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o6 a b jx jy (heq) (hit) (sep5).2.1 (sep5).2.2.1 (hfixed_a) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n016_o7 a b jx jy (hfixed_a) (allowed) (insideT) (sep6).2.2.1 (heq) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node013 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-11 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-11 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o0 a b jx jy (hfixed_a) (hit) (sep3).2.1 (sep5).2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o1 a b jx jy (hit) (heq) (hfixed_a) (sep5).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node014 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o2 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (hit) (heq) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node016 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o3 a b jx jy (heq) (sep3).2.1 (hfixed_a) (insideT) (hit) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-11 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o4 a b jx jy (insideT) (hit) (heq) (sep5).2.2.1 (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node016 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o5 a b jx jy (insideT) (sep5).2.1 (hit) (sep3).2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o6 a b jx jy (hfixed_a) (heq) (insideT) (sep5).2.1 (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (-11 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n013_o7 a b jx jy (hit) (insideT) (allowed) ((by simpa only [Same,eq_comm] using absent)) (heq) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node014 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_equal_bar_long_fixed_4_pruned_node019 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap6_7 : Apart (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (7 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (7 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (7 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o0 a b jx jy (hfixed_a) (hit) (sep2).2.1 (sep2).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o1 a b jx jy (hit) (sep7).2.2.1 (insideT) (hfixed_a) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o2 a b jx jy (insideT) (hit) (hfixed_a) (heq) (allowed) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o3 a b jx jy (sep7).2.1 (hfixed_a) (hit) (sep2).2.1 (heq) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o4 a b jx jy (insideT) (hit) (hfixed_a) (sep2).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o5 a b jx jy (sep2).2.1 (sep2).2.2.1 (hfixed_a) (hit) (sep7).2.2.1 (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o6 a b jx jy (sep7).2.2.1 (sep7).2.1 (sep2).2.2.1 (hit) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n019_o7 a b jx jy (sep7).2.2.1 (hit) (hfixed_a) (heq) (insideT) (allowed)

theorem HP_equal_bar_long_fixed_4_pruned_node020 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap6_7 : Apart (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o0 a b jx jy (heq) (hit) (hfixed_a) (sep6).2.1 (sep6).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o1 a b jx jy (hit) (sep6).2.2.1 (insideT) (hfixed_a) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o2 a b jx jy (insideT) (hit) (sep7).2.2.1 (hfixed_a) (sep6).2.2.1 (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o3 a b jx jy (sep7).2.1 (hit) (sep7).2.2.1 (sep6).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o4 a b jx jy (hfixed_a) (hit) (sep6).2.2.1 (insideT) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o5 a b jx jy (hit) (sep7).2.1 (sep6).2.2.1 (hfixed_a) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o6 a b jx jy (hfixed_a) (sep6).2.2.1 (heq) (sep7).2.1 (sep6).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n020_o7 a b jx jy (sep7).2.2.1 (hfixed_a) (insideT) (heq) (sep6).2.2.1 (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node018 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (6 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o0 a b jx jy (hfixed_a) (hit) (sep2).2.1 (sep2).2.2.1 (sep6).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o1 a b jx jy (heq) (insideT) (hit) (hfixed_a) (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node019 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o2 a b jx jy (insideT) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (heq) (hit) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node020 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o3 a b jx jy (hit) (sep2).2.2.1 (sep2).2.1 (hfixed_a) (heq) (sep6).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (6 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o4 a b jx jy (hfixed_a) (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node020 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o5 a b jx jy (hit) (hfixed_a) (sep2).2.1 (sep6).1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o6 a b jx jy (sep6).1 (insideT) (heq) (hit) (hfixed_a) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n018_o7 a b jx jy (hfixed_a) (heq) (insideT) (allowed) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node019 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)

theorem HP_equal_bar_long_fixed_4_pruned_node022 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ht7 : world (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have in7 := inside (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed7 := avoid (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o0 a b jx jy (hit) (hfixed_a) (sep6).2.1 (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o1 a b jx jy (sep6).2.2.1 (insideT) (hfixed_a) (hit) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o2 a b jx jy (hit) (sep7).2.2.1 (heq) (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o3 a b jx jy (hit) (hfixed_a) (sep6).2.1 (heq) (sep7).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o4 a b jx jy (sep6).2.2.1 (insideT) (hfixed_a) (sep7).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o5 a b jx jy (sep7).2.1 (sep7).2.2.1 (sep6).2.2.1 (hfixed_a) (hit) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o6 a b jx jy (hfixed_a) (sep6).2.1 (hit) (sep7).2.1 (sep7).2.2.1 (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n022_o7 a b jx jy (sep6).2.2.1 (hit) (heq) (hfixed_a) (sep7).2.2.1 (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node021 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o0 a b jx jy (sep6).2.2.1 (hfixed_a) (hit) (heq) (sep6).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o1 a b jx jy (hit) (sep0).2.2.1 (hfixed_a) (insideT) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o2 a b jx jy (hit) (hfixed_a) (heq) (allowed) (insideT) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o3 a b jx jy (hit) (sep0).2.2.1 (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep6).2.2.1 (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node022 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o4 a b jx jy (hit) (sep6).2.2.1 (insideT) (sep0).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o5 a b jx jy (sep0).2.1 (heq) (hfixed_a) (insideT) (hit) (sep6).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node022 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o6 a b jx jy (sep6).2.1 (hit) (sep6).2.2.1 (sep0).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n021_o7 a b jx jy (sep6).2.2.1 (hit) (insideT) (hfixed_a) (heq) (allowed)

theorem HP_equal_bar_long_fixed_4_pruned_node024 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ht7 : world (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have in7 := inside (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o0 a b jx jy (hit) (hfixed_a) (sep1).2.1 (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o1 a b jx jy (insideT) (hit) (sep6).2.2.1 (hfixed_a) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o2 a b jx jy (hit) (heq) (sep7).2.2.1 (hfixed_a) (insideT) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o3 a b jx jy (hit) (sep6).2.2.1 (sep7).2.2.1 (hfixed_a) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o4 a b jx jy (insideT) (hit) (sep6).2.2.1 (hfixed_a) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o5 a b jx jy (hit) (sep7).2.2.1 (sep7).2.1 (hfixed_a) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o6 a b jx jy (sep1).2.1 (hfixed_a) (heq) (hit) (sep7).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n024_o7 a b jx jy (heq) (sep6).2.2.1 (hit) (hfixed_a) (sep7).2.2.1

theorem HP_equal_bar_long_fixed_4_pruned_node023 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o0 a b jx jy (sep1).2.1 (hfixed_a) (hit) (heq) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node024 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o1 a b jx jy (insideT) (hfixed_a) (sep6).2.2.1 (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o2 a b jx jy (heq) (insideT) (allowed) (sep6).2.2.1 (hfixed_a) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o3 a b jx jy (heq) (insideT) (sep1).1 (hit) (sep6).2.2.1 (sep1).2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o4 a b jx jy (insideT) (sep6).2.2.1 (hit) (sep1).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o5 a b jx jy (hit) (heq) (sep1).2.1 (hfixed_a) (sep6).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o6 a b jx jy (hfixed_a) (sep1).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node024 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n023_o7 a b jx jy (allowed) (hfixed_a) (hit) (sep6).2.2.1 (heq) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node026 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap6_7 : Apart (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (7 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (7 : Int) (1 : Int) ∨ Contains (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (7 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (7 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o0 a b jx jy (hit) (sep2).2.1 (hfixed_a) (sep2).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o1 a b jx jy (hit) (hfixed_a) (insideT) (sep2).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o2 a b jx jy (hfixed_a) (hit) (insideT) (sep7).2.2.1 (heq) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o3 a b jx jy (sep2).2.1 (sep2).2.2.1 (hit) (sep7).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o4 a b jx jy (sep7).2.2.1 (hit) (hfixed_a) (sep2).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o5 a b jx jy (hfixed_a) (hit) (sep2).2.1 (sep7).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o6 a b jx jy (hfixed_a) (heq) (sep2).2.1 (sep7).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n026_o7 a b jx jy (hit) (sep7).2.2.1 (allowed) (heq) (hfixed_a) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node025 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (6 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int) ∨ Contains (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o0 a b jx jy (sep2).2.1 (insideT) (sep6).1 (hit) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o1 a b jx jy (insideT) (hit) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.1 (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node026 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o2 a b jx jy (insideT) (hit) (heq) (hfixed_a) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o3 a b jx jy (sep6).2.1 (heq) (hfixed_a) (sep2).2.2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o4 a b jx jy (heq) (hit) (insideT) (hfixed_a) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o5 a b jx jy (hfixed_a) (sep2).2.1 (hit) (sep2).2.2.1 (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o6 a b jx jy (insideT) (heq) (hfixed_a) (hit) (sep6).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (6 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n025_o7 a b jx jy (allowed) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (heq) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node026 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)

theorem HP_equal_bar_long_fixed_4_pruned_node017 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o0 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (heq) (sep0).2.1 (sep0).2.2.1 (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node018 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (heq) (hfixed_a) (sep0).2.2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node021 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o2 a b jx jy (allowed) ((by simpa only [Same,eq_comm] using absent)) (insideT) (heq) (hfixed_a) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node023 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o3 a b jx jy (heq) (sep0).2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node025 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o4 a b jx jy (insideT) (heq) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (sep0).2.2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node023 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o5 a b jx jy (hit) (sep0).2.1 (heq) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node025 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (heq) (hfixed_a) (sep0).2.2.1 (hit) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node018 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (1 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n017_o7 a b jx jy (insideT) (allowed) (hfixed_a) (heq) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node021 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_equal_bar_long_fixed_4_pruned_node012 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht4
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-11 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-11 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o0 a b jx jy (hfixed_a) (heq) (insideT) (hit) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node013 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o1 a b jx jy (allowed) (insideT) (hit) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o2 a b jx jy (heq) (insideT) (allowed) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o3 a b jx jy (heq) (sep3).2.1 (hit) (insideT) (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node017 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o4 a b jx jy (heq) (allowed) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (heq) (hit) (hfixed_a) (insideT) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node017 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o6 a b jx jy (hfixed_a) (sep3).2.1 (hit) (heq) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node013 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n012_o7 a b jx jy (hit) (insideT) (allowed) (heq)

theorem HP_equal_bar_long_fixed_4_pruned_node029 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (11 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (11 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (11 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o0 a b jx jy (heq) (hit) (hfixed_a) (sep4).2.2.1 (sep6).2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o1 a b jx jy (hit) (insideT) (sep4).2.2.1 (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o2 a b jx jy (insideT) (allowed) (hfixed_a) (hit) (heq) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o3 a b jx jy (sep4).2.1 (sep6).2.2.1 (hit) (hfixed_a) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o4 a b jx jy (sep6).2.2.1 (insideT) (hfixed_a) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o5 a b jx jy (sep4).2.1 (hfixed_a) (hit) (sep6).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o6 a b jx jy (sep6).2.2.1 (sep4).2.2.1 (hfixed_a) (sep6).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n029_o7 a b jx jy (hit) (sep6).2.2.1 (hfixed_a) (allowed) (insideT) (heq)

theorem HP_equal_bar_long_fixed_4_pruned_node031 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ht7 : world (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_7 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_7 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have in7 := inside (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed7 := avoid (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (6 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o0 a b jx jy (hfixed_a) (hit) (sep2).2.1 (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o1 a b jx jy (hit) (insideT) (sep7).2.2.1 (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o2 a b jx jy (hit) (sep6).2.2.1 (insideT) (heq) (hfixed_a) (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o3 a b jx jy (sep2).2.1 (heq) (hit) (hfixed_a) (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o4 a b jx jy (insideT) (sep7).2.2.1 (hit) (sep6).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o5 a b jx jy (sep2).2.1 (hit) (sep7).2.1 (sep7).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o6 a b jx jy (hfixed_a) (sep2).2.1 (heq) (sep7).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n031_o7 a b jx jy (heq) (insideT) (sep6).2.2.1 (hfixed_a) (hit) (sep7).2.2.1

theorem HP_equal_bar_long_fixed_4_pruned_node030 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (8 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (8 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (8 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o0 a b jx jy (heq) (hfixed_a) (hit) (sep2).2.1 (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node031 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o1 a b jx jy (insideT) (hfixed_a) (hit) (sep6).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o2 a b jx jy (heq) (hit) (insideT) (allowed) (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o3 a b jx jy (sep2).2.1 (hit) (sep2).2.2.1 (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o4 a b jx jy (insideT) (sep6).2.2.1 (hfixed_a) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o5 a b jx jy (hit) (sep2).2.1 (heq) (sep6).2.2.1 (sep2).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hfixed_a) (heq) (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node031 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n030_o7 a b jx jy (hit) (sep6).2.2.1 (heq) (insideT) (hfixed_a) (allowed)

theorem HP_equal_bar_long_fixed_4_pruned_node028 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht5
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (10 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (10 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o0 a b jx jy (insideT) (hfixed_a) (sep2).2.1 (sep4).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (hfixed_a) (heq) (sep4).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node029 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o2 a b jx jy (hfixed_a) (insideT) (heq) (hit) ((by simpa only [Same,eq_comm] using absent)) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node030 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o3 a b jx jy (insideT) (hit) (hfixed_a) (heq) (sep2).2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o4 a b jx jy (sep4).2.2.1 (heq) (hit) (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node030 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o5 a b jx jy (hit) (insideT) (sep4).2.1 (sep2).2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o6 a b jx jy (hit) (hfixed_a) (heq) (insideT) (sep4).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n028_o7 a b jx jy (hit) (heq) (hfixed_a) (allowed) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node029 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_equal_bar_long_fixed_4_pruned_node033 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (11 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (11 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (11 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (11 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o0 a b jx jy (sep4).2.2.1 (hfixed_a) (hit) (heq) (sep6).2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o1 a b jx jy (hit) (sep6).2.2.1 (insideT) (hfixed_a) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o2 a b jx jy (allowed) (heq) (insideT) (hfixed_a) (hit) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o3 a b jx jy (sep6).2.2.1 (sep4).2.2.1 (hfixed_a) (hit) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o4 a b jx jy (hfixed_a) (insideT) (hit) (sep4).2.2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o5 a b jx jy (sep4).2.1 (sep6).2.1 (sep4).2.2.1 (hfixed_a) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o6 a b jx jy (sep4).2.1 (hfixed_a) (hit) (heq) (sep6).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n033_o7 a b jx jy (sep6).2.2.1 (insideT) (hfixed_a) (allowed) (heq) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node035 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ht7 : world (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_7 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_7 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_7 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_7 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have in7 := inside (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed7 := avoid (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht7
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (6 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_point a b (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (6 : Int) (2 : Int) ∨ Contains (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (6 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o0 a b jx jy (hit) (sep2).2.1 (hfixed_a) (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o1 a b jx jy (hit) (hfixed_a) (insideT) (sep6).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o2 a b jx jy (sep7).2.2.1 (hit) (heq) (insideT) (hfixed_a) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o3 a b jx jy (hfixed_a) (sep7).2.2.1 (sep6).2.2.1 (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o4 a b jx jy (hit) (hfixed_a) (sep7).2.2.1 (insideT) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o5 a b jx jy (heq) (hit) (sep6).2.2.1 (sep7).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o6 a b jx jy (insideT) (hit) (sep7).2.1 (hfixed_a) (sep2).2.1 (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n035_o7 a b jx jy (sep7).2.2.1 (hit) (sep6).2.2.1 (heq) (insideT) (hfixed_a)

theorem HP_equal_bar_long_fixed_4_pruned_node034 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap5_6 : Apart (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht6
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (8 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (8 : Int) (1 : Int) ∨ Contains (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (8 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (8 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o0 a b jx jy (hit) (hfixed_a) (heq) (insideT) (sep2).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node035 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o1 a b jx jy (sep2).2.2.1 (insideT) (hfixed_a) (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o2 a b jx jy (sep6).2.2.1 (allowed) (hfixed_a) (hit) (insideT) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o3 a b jx jy (sep2).2.2.1 (sep6).2.2.1 (hfixed_a) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o4 a b jx jy (hit) (sep2).2.2.1 (insideT) (sep6).2.2.1 (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o5 a b jx jy (sep2).2.2.1 (sep6).2.2.1 (sep2).2.1 (hit) (hfixed_a) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o6 a b jx jy (sep2).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (heq) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_equal_bar_long_fixed_4_pruned_node035 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n034_o7 a b jx jy (allowed) (sep6).2.2.1 (heq) (hfixed_a) (hit) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node032 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (10 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int) ∨ Contains (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (10 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o0 a b jx jy (sep2).2.1 (sep4).2.1 (hfixed_a) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (heq) (insideT) (hit) (hfixed_a) (sep4).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node033 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hfixed_a) (heq) (insideT) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node034 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o3 a b jx jy (hfixed_a) (hit) (insideT) (sep2).2.1 (heq) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (10 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o4 a b jx jy (heq) (hfixed_a) (hit) (sep4).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node034 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o5 a b jx jy (insideT) (sep4).2.1 (sep2).2.1 (hfixed_a) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o6 a b jx jy (hit) (hfixed_a) (sep2).2.1 (sep4).2.1 (insideT) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (10 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n032_o7 a b jx jy (hit) (insideT) (allowed) (heq) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_equal_bar_long_fixed_4_pruned_node033 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_equal_bar_long_fixed_4_pruned_node027 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht4
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-11 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-11 : Int) (0 : Int) ∨ Contains (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-11 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-11 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o0 a b jx jy (hit) (hfixed_a) (sep3).2.1 (heq) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node028 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o1 a b jx jy (insideT) (hit) (allowed) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o2 a b jx jy (heq) (hit) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o3 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (heq) (hfixed_a) (sep3).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node032 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o4 a b jx jy (hit) (allowed) (heq) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-11 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o5 a b jx jy (hit) (sep3).2.1 (heq) (insideT) (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node032 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-15 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o6 a b jx jy (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (sep3).1 (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node028 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n027_o7 a b jx jy (heq) (allowed) (hit) (insideT)

theorem HP_equal_bar_long_fixed_4_pruned_node011 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht3
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (10 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (0 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (0 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (10 : Int) (0 : Int) ∨ Contains (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (10 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (10 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o0 a b jx jy (heq) (insideT) (hfixed_a) (hit) (sep2).1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node012 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o1 a b jx jy (allowed) (hit) (insideT) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o2 a b jx jy (hit) (insideT) (allowed) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o3 a b jx jy (hfixed_a) (insideT) (heq) (hit) (sep2).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node027 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o4 a b jx jy (heq) (allowed) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (14 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o5 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hfixed_a) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node027 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o6 a b jx jy (hfixed_a) (heq) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node012 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n011_o7 a b jx jy (heq) (insideT) (hit) (allowed)

theorem HP_equal_bar_long_fixed_4_pruned_node038 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ht5 : world (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_5 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_5 : Apart (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht4
  have in5 := inside (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht4
  have allowed5 := avoid (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht5
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o0 a b jx jy (sep0).2.1 (heq) (hfixed_a) (hit) (sep4).2.2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o1 a b jx jy (hfixed_a) (hit) (insideT) (sep5).2.2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o2 a b jx jy (hfixed_a) (sep4).2.2.1 (sep5).2.2.1 (hit) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o3 a b jx jy (hfixed_a) (hit) (sep5).2.1 (sep5).2.2.1 (heq) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o4 a b jx jy (sep4).2.2.1 (sep5).2.2.1 (insideT) (hit) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o5 a b jx jy (hfixed_a) (sep5).2.2.1 (hit) (sep5).2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o6 a b jx jy (sep0).2.1 (sep4).2.2.1 (sep5).2.2.1 (hfixed_a) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n038_o7 a b jx jy (hit) (insideT) (sep5).2.2.1 (heq) (sep4).2.2.1 (hfixed_a)

theorem HP_equal_bar_long_fixed_4_pruned_node037 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht4
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o0 a b jx jy (sep4).2.2.1 (hit) (sep0).2.2.1 (sep0).2.1 (heq) (hfixed_a)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o1 a b jx jy (sep4).2.2.1 (hfixed_a) (sep0).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o2 a b jx jy (hit) (allowed) (hfixed_a) (sep4).2.2.1 (insideT) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o3 a b jx jy (hit) (heq) (sep0).2.2.1 (sep0).2.1 (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node038 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o4 a b jx jy (sep4).2.2.1 (hfixed_a) (sep0).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (1 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o5 a b jx jy (heq) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_equal_bar_long_fixed_4_pruned_node038 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o6 a b jx jy (hit) (hfixed_a) (sep0).2.2.1 (sep1).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n037_o7 a b jx jy (sep4).2.2.1 (insideT) (hfixed_a) (allowed) (heq) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node039 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    (ap3_4 : Apart (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht4
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) (-3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o0 a b jx jy (hit) (hfixed_a) (sep4).2.1 (sep3).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o1 a b jx jy (sep1).2.2.1 (insideT) (hit) (hfixed_a) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o2 a b jx jy (insideT) (allowed) (hfixed_a) (sep4).2.2.1 (hit) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o3 a b jx jy (hit) (hfixed_a) (sep1).2.2.1 (sep4).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o4 a b jx jy (hfixed_a) (sep1).2.2.1 (sep4).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o5 a b jx jy (sep4).2.2.1 (hfixed_a) (heq) (hit) (sep1).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o6 a b jx jy (heq) (sep4).2.1 (sep3).2.1 (hfixed_a) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n039_o7 a b jx jy (allowed) (sep4).2.2.1 (hfixed_a) (insideT) (hit) (heq)

theorem HP_equal_bar_long_fixed_4_pruned_node036 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht3
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_point a b ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (hfixed_a) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o0 a b jx jy (hit) (hfixed_a) (insideT) (sep3).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o1 a b jx jy (sep1).2.2.1 (hit) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (insideT) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node037 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (allowed) (hfixed_a) (hit) (heq)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node039 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o3 a b jx jy (hfixed_a) (sep1).2.1 (sep3).2.1 (insideT) (heq) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (5 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (heq) (insideT) (hfixed_a) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node039 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o5 a b jx jy (hfixed_a) (insideT) (sep1).2.1 (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o6 a b jx jy (hfixed_a) (heq) (sep1).2.1 (sep3).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (-2 : Int) (5 : Int) (4 : Int) (0 : Int) (0 : Int) (4 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n036_o7 a b jx jy (insideT) (allowed) ((by simpa only [Same,eq_comm] using absent)) (hit) (heq) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_equal_bar_long_fixed_4_pruned_node037 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_equal_bar_long_fixed_4_pruned_node010 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht2
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-6 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_point a b (heq) (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-6 : Int) (0 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-6 : Int) (0 : Int) ∨ Contains (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (-6 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-6 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o0 a b jx jy (insideT) (heq) (sep1).1 ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node011 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o1 a b jx jy (heq) (allowed) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o2 a b jx jy (hit) (insideT) (allowed) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o3 a b jx jy (hfixed_a) (insideT) (heq) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node036 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o4 a b jx jy (heq) (allowed) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-6 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o5 a b jx jy (insideT) (hfixed_a) (sep1).1 (heq) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node036 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-10 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o6 a b jx jy (heq) (hit) (hfixed_a) (sep1).1 (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_equal_bar_long_fixed_4_pruned_node011 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n010_o7 a b jx jy (heq) (insideT) (allowed) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht1
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (5 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_point a b (hfixed_a) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent)) (heq)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (5 : Int) (0 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) (5 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o0 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (heq) (sep0).1 (insideT) (hit) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node006 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o1 a b jx jy (insideT) (heq) (allowed) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o2 a b jx jy (insideT) (heq) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o3 a b jx jy (insideT) (sep0).1 (hfixed_a) (heq) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node010 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o4 a b jx jy (hit) (heq) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (9 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (hit) (heq) (sep0).1 (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node010 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o6 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (heq) (sep0).1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_equal_bar_long_fixed_4_pruned_node006 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n005_o7 a b jx jy (allowed) (insideT) (hit) (heq)

theorem HP_equal_bar_long_fixed_4_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht0
  have support : HP_equal_bar_long_fixed_4_pruned_Box a b (-1 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_point a b (hfixed_a) (heq) ((by simpa only [HP_equal_bar_long_fixed_4_pruned_Box,HP_equal_bar_long_fixed_4_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) (-1 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty hit)
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o0 a b jx jy (hfixed_a) (heq) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact HP_equal_bar_long_fixed_4_pruned_node001 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o1 a b jx jy (heq) (insideT) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o2 a b jx jy (heq) (insideT) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o3 a b jx jy (heq) (insideT) (hfixed_a) (sep0).2.1 (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact HP_equal_bar_long_fixed_4_pruned_node005 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o4 a b jx jy (hit) (heq) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o5 a b jx jy (hfixed_a) (sep0).2.1 (insideT) (heq) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact HP_equal_bar_long_fixed_4_pruned_node005 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (heq) (hit) (insideT) (hfixed_a) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact HP_equal_bar_long_fixed_4_pruned_node001 a b ha hb heq hfixed_a world copies inside cover separate avoid ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_bar_long_fixed_4_pruned_n000_o7 a b jx jy (insideT) (allowed) (heq) (hit)

theorem HP_equal_bar_long_fixed_4_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_bar_long_fixed_4_pruned_Inside t)
    (cover : ∀ x y, HP_equal_bar_long_fixed_4_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (anchor : world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  exact HP_equal_bar_long_fixed_4_pruned_node000 a b ha hb heq hfixed_a world copies inside cover sep avoid anchor

theorem HP_equal_bar_long_fixed_4_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int))) : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenShortTip a b t := by
    subst b
    exact equal_avoid_tips a (by omega) T
  apply HP_equal_bar_long_fixed_4_pruned_bounded_obstruction a b ha hb heq hfixed_a T.world T.copies ?_ ?_ T.disjoint avoid anchor
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_equal_bar_long_fixed_4_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (hfixed_a : (a = (4 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) (4 : Int) (4 : Int) (0 : Int) (0 : Int)))) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_equal_bar_long_fixed_4_pruned_anchored_obstruction a b ha hb heq hfixed_a U
  refine ⟨_,anchor,?_⟩
  apply same_eq
  unfold Same shift; dsimp
  exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_equal_bar_long_fixed_4_pruned_no_shifted_anchor
#print axioms HP_equal_bar_long_fixed_4_pruned_bounded_obstruction
end PolyominoFormal.LRegion

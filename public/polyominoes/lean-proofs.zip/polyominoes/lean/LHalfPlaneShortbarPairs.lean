import LHalfPlaneLocal
import TilingSymmetry

set_option maxHeartbeats 1000000
namespace PolyominoFormal.LRegion
open CrossUnits

/-- Two adjacent equally directed short horizontal bars trap a b-cell run
between their longer vertical arms. The common row need not be the boundary. -/
theorem same_short_bars_right_impossible (a b p h : Int)
    (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane)
    (first : T.world ⟨p,h,b,a,0,0⟩)
    (second : T.world ⟨p+b+1,h,b,a,0,0⟩) : False := by
  let O : Cross := ⟨p,h,b,a,0,0⟩
  let U : Cross := ⟨p+b+1,h,b,a,0,0⟩
  let B : Region := fun x y => Contains O x y ∨ Contains U x y
  have hO : T.world O := first
  have hU : T.world U := second
  have hh : 0≤h := T.inside O hO p h (by left; dsimp [O]; omega)
  have closed : CornerCertificate.TileClosed T.world B := by
    intro t ht x y hit blocked u v hu
    rcases blocked with blocked | blocked
    · have eq := T.disjoint t O x y ht hO hit blocked
      subst t
      exact Or.inl hu
    · have eq := T.disjoint t U x y ht hU hit blocked
      subst t
      exact Or.inr hu
  apply LHalfPlaneLocal.blocked_short_tall_run (L:=p+1) (R:=p+b) (h:=h+1)
    (by omega) (by omega) (by omega) (by omega) T B closed
  · intro x hx0 hx1; unfold HalfPlane; omega
  · intro x hx0 hx1
    dsimp [B,O,U,Contains]
    omega
  · intro x hx0 hx1
    left; left; dsimp [O]; omega
  · left; right; dsimp [O]; omega
  · right; right; dsimp [U]; omega
  · left; right; dsimp [O]; omega
  · right; right; dsimp [U]; omega

theorem same_short_bars_left_impossible (a b p h : Int)
    (hb : 3≤b) (hab : b<a) (T : Tiling a b 0 0 HalfPlane)
    (first : T.world ⟨p,h,0,a,b,0⟩)
    (second : T.world ⟨p+b+1,h,0,a,b,0⟩) : False := by
  apply same_short_bars_right_impossible a b (-p-b-1) h hb hab T.mirrorX
  · refine ⟨_,second,?_⟩
    apply same_eq; dsimp [Same,mirrorX]; omega
  · refine ⟨_,first,?_⟩
    apply same_eq; dsimp [Same,mirrorX]; omega

def ForbiddenSameShortBars (a b : Int) (t u : Cross) : Prop :=
  t.y=u.y ∧ t.north=a ∧ u.north=a ∧ t.south=0 ∧ u.south=0 ∧
  (t.x+b+1=u.x ∨ u.x+b+1=t.x) ∧
  ((t.east=b ∧ t.west=0 ∧ u.east=b ∧ u.west=0) ∨
   (t.east=0 ∧ t.west=b ∧ u.east=0 ∧ u.west=b))

theorem avoid_same_short_bars (a b : Int) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenSameShortBars a b t u := by
  rintro ⟨p,y,e,n,w,s⟩ ⟨q,z,f,m,v,r⟩ ht hu
    ⟨hy,hn,hm,hs,hr,near,arms⟩
  dsimp only at hy hn hm hs hr near arms
  subst z; subst n; subst m; subst s; subst r
  rcases arms with ⟨he,hw,hf,hv⟩ | ⟨he,hw,hf,hv⟩
  · subst e; subst w; subst f; subst v
    rcases near with hq | hp
    · subst q; exact same_short_bars_right_impossible a b p y hb hab T ht hu
    · subst p; exact same_short_bars_right_impossible a b q y hb hab T hu ht
  · subst e; subst w; subst f; subst v
    rcases near with hq | hp
    · subst q; exact same_short_bars_left_impossible a b p y hb hab T ht hu
    · subst p; exact same_short_bars_left_impossible a b q y hb hab T hu ht

#print axioms same_short_bars_right_impossible
#print axioms avoid_same_short_bars
end PolyominoFormal.LRegion

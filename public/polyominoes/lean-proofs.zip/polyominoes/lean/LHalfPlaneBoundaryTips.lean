import LHalfPlaneBoundaryUnequalTipLongGeometry
namespace PolyominoFormal.LRegion
open CrossUnits

theorem unequal_no_right_long_tip (a b p : Int) (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) : ¬T.world ⟨p,a,b,0,0,a⟩ := by
  intro ht
  exact HP_boundary_unequal_tip_long_pruned_no_shifted_anchor a b p (by omega) hb hab ha T
    (by simpa only [shift,Int.zero_add,Int.add_zero] using ht)

theorem unequal_no_left_long_tip (a b p : Int) (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) : ¬T.world ⟨p,a,0,0,b,a⟩ := by
  intro ht
  apply unequal_no_right_long_tip a b (-p) hb hab ha T.mirrorX
  exact ⟨_,ht,rfl⟩

def ForbiddenBoundaryTip (a b : Int) (t : Cross) : Prop :=
  ForbiddenShortTip a b t ∨ ForbiddenShortTip b a t

theorem unequal_avoid_boundary_tips (a b : Int) (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) : ∀t,T.world t → ¬ForbiddenBoundaryTip a b t := by
  intro t ht forbidden
  rcases forbidden with short | long
  · exact unequal_avoid_short_tips a b hb hab ha T t ht short
  · rcases t with ⟨p,y,e,n,w,s⟩
    rcases long with ⟨hy,hn,hs,arms⟩
    dsimp only at hy hn hs arms
    subst y; subst n; subst s
    rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
    · subst e; subst w; exact unequal_no_right_long_tip a b p hb hab ha T ht
    · subst e; subst w; exact unequal_no_left_long_tip a b p hb hab ha T ht

#print axioms unequal_avoid_boundary_tips
end PolyominoFormal.LRegion

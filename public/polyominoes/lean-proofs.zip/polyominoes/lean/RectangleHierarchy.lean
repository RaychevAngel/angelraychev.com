import TilingCore

namespace PolyominoFormal
open CrossUnits

/-- Repeating a finite rectangle horizontally produces a genuine half-strip
    tiling. The quotient argument proves disjointness between all blocks. -/
def Tiling.rectangleToHalfStrip {a b c d w h : Int}
    (hw : 0 < w) (T : Tiling a b c d (Rectangle w h)) :
    Tiling a b c d (HalfStrip h) := by
  let I := {n : Int // 0 ≤ n} × {t : Cross // T.world t}
  let tile : I → Cross := fun i => shift (i.1.val*w) 0 i.2.val
  apply Tiling.ofIndexed tile
  · intro i
    exact (copy_shift a b c d _ 0 i.2.val).2 (T.copies i.2.val i.2.property)
  · intro i x y hit
    have hcell := T.inside i.2.val i.2.property _ _
      ((contains_shift _ _ _ _ _).1 hit)
    have nonneg := Int.mul_nonneg i.1.property (Int.le_of_lt hw)
    simp only [Rectangle] at hcell
    unfold HalfStrip
    omega
  · intro x y hcell
    obtain ⟨hx,hy,hyh⟩ := hcell
    have hrem0 := Int.emod_nonneg x (by omega : w ≠ 0)
    have hremw := Int.emod_lt_of_pos x hw
    have hdiv := Int.ediv_nonneg hx (Int.le_of_lt hw)
    obtain ⟨t, ht, hit⟩ := T.cover (x%w) y ⟨hrem0,hremw,hy,hyh⟩
    refine ⟨(⟨x/w,hdiv⟩,⟨t,ht⟩), ?_⟩
    show Contains (shift (x/w*w) 0 t) x y
    rw [contains_shift]
    have hx' : x-x/w*w=x%w := by have := Int.emod_add_ediv_mul x w; omega
    simpa only [hx',Int.sub_zero] using hit
  · intro i j x y hi hj
    have ci := T.inside i.2.val i.2.property _ _
      ((contains_shift _ _ _ _ _).1 hi)
    have cj := T.inside j.2.val j.2.property _ _
      ((contains_shift _ _ _ _ _).1 hj)
    have qi : x/w=i.1.val := (Int.ediv_eq_iff_of_pos hw).2 (by
      unfold Rectangle at ci; omega)
    have qj : x/w=j.1.val := (Int.ediv_eq_iff_of_pos hw).2 (by
      unfold Rectangle at cj; omega)
    have qeq : i.1.val=j.1.val := by omega
    have hi' : Contains i.2.val (x-i.1.val*w) y := by
      simpa only [Int.sub_zero] using ((contains_shift _ _ _ _ _).1 hi)
    have hj' : Contains j.2.val (x-i.1.val*w) y := by
      rw [qeq]
      simpa only [Int.sub_zero] using ((contains_shift _ _ _ _ _).1 hj)
    have teq := T.disjoint i.2.val j.2.val _ _ i.2.property j.2.property hi' hj'
    change shift (i.1.val*w) 0 i.2.val = shift (j.1.val*w) 0 j.2.val
    rw [qeq,teq]

theorem rectangle_implies_half_strip {a b c d : Int}
    (h : RectangleTileable a b c d) : HalfStripTileable a b c d := by
  obtain ⟨w,h,hw,hh,⟨T⟩⟩ := h
  exact ⟨h,hh,⟨T.rectangleToHalfStrip hw⟩⟩

#print axioms rectangle_implies_half_strip
end PolyominoFormal

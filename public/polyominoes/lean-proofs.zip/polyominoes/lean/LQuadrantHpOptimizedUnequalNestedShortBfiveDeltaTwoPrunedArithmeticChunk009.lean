import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3368 a b) ∨ (fact_9fdb227ae99d_3375 a b) ∨ (fact_9fdb227ae99d_4410 a b) ∨ (fact_9fdb227ae99d_5549 a b) ∨ (fact_9fdb227ae99d_3737 a b) ∨ (fact_9fdb227ae99d_3399 a b) ∨ (fact_9fdb227ae99d_3409 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3377 a b) ∨ (((((-3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3378 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3749 a b) ∨ (fact_9fdb227ae99d_3781 a b) ∨ (fact_9fdb227ae99d_5159 a b) ∨ (fact_9fdb227ae99d_5837 a b) ∨ (fact_9fdb227ae99d_4532 a b) ∨ (fact_9fdb227ae99d_3918 a b) ∨ (fact_9fdb227ae99d_3965 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3811 a b) ∨ (((((-3 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3829 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7633 a b) ∨ (fact_9fdb227ae99d_7742 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7633 a b) ∧ (fact_9fdb227ae99d_7742 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7633 a b) ∧ (fact_9fdb227ae99d_7742 a b) ∧ (((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3938 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_5980 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_4035 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∨ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4776 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_6544 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4880 a b) ∨ (fact_9fdb227ae99d_4677 a b)))) ∨ ((fact_9fdb227ae99d_7633 a b) ∧ (fact_9fdb227ae99d_7742 a b) ∧ ((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3938 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_5980 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_4035 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∧ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4776 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_6544 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4880 a b) ∨ (fact_9fdb227ae99d_4677 a b))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2467 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_3610 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2487 a b run_x) ∨ (fact_9fdb227ae99d_2402 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n249_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3223 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_5354 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3250 a b run_x) ∨ (fact_9fdb227ae99d_3201 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3383 a b) ∨ (fact_9fdb227ae99d_3384 a b) ∨ (fact_9fdb227ae99d_4498 a b) ∨ (fact_9fdb227ae99d_5585 a b) ∨ (fact_9fdb227ae99d_3854 a b) ∨ (fact_9fdb227ae99d_3471 a b) ∨ (fact_9fdb227ae99d_3473 a b) ∨ ((((4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3385 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3861 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3856 a b) ∨ (fact_9fdb227ae99d_3858 a b) ∨ (fact_9fdb227ae99d_5288 a b) ∨ (fact_9fdb227ae99d_5903 a b) ∨ (fact_9fdb227ae99d_4709 a b) ∨ ((((4 : Int) ≥ ((-1 : Int) - b)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4185 a b) ∨ ((((4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3860 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4711 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7639 a b) ∨ (fact_9fdb227ae99d_7750 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7639 a b) ∧ (fact_9fdb227ae99d_7750 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7639 a b) ∧ (fact_9fdb227ae99d_7750 a b) ∧ (((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3934 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_5976 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4028 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∨ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4788 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_6555 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_4907 a b) ∨ (fact_9fdb227ae99d_5436 a b)))) ∨ ((fact_9fdb227ae99d_7639 a b) ∧ (fact_9fdb227ae99d_7750 a b) ∧ ((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3934 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_5976 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4028 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∧ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4788 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_6555 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_4907 a b) ∨ (fact_9fdb227ae99d_5436 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : ((fact_9fdb227ae99d_2446 a b run_x) ∨ (fact_9fdb227ae99d_2447 a b run_x) ∨ (fact_9fdb227ae99d_3070 a b run_x) ∨ (fact_9fdb227ae99d_3571 a b run_x) ∨ (fact_9fdb227ae99d_2982 a b run_x) ∨ (fact_9fdb227ae99d_2536 a b run_x) ∨ (fact_9fdb227ae99d_2538 a b run_x) ∨ ((((4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2448 a b run_x) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2983 a b run_x)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n250_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3174 a b run_x) ∨ (fact_9fdb227ae99d_3184 a b run_x) ∨ (fact_9fdb227ae99d_3727 a b run_x) ∨ (fact_9fdb227ae99d_5192 a b run_x) ∨ (fact_9fdb227ae99d_3486 a b run_x) ∨ (fact_9fdb227ae99d_3218 a b run_x) ∨ (fact_9fdb227ae99d_3234 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3193 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3556 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2966 a b) ∨ (fact_9fdb227ae99d_2968 a b) ∨ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-4 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_3151 a b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((jx + a) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o1 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o2 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n251_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_four (a b : Int)
    (h0 : (¬ ((-5 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_short (a b : Int)
    (h0 : (¬ (((-5 : Int) - ((-2 : Int) + ((-1 : Int) * a))) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-4 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-4 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7875 a b) ∨ (fact_9fdb227ae99d_7658 a b))) ∨ (((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7875 a b) ∧ (fact_9fdb227ae99d_7658 a b)) ∨ ((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-5 : Int) = (((-2 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7875 a b) ∧ (fact_9fdb227ae99d_7658 a b) ∧ (((fact_9fdb227ae99d_6021 a b) ∨ (fact_9fdb227ae99d_6059 a b) ∨ (fact_9fdb227ae99d_6821 a b) ∨ (fact_9fdb227ae99d_7033 a b) ∨ (fact_9fdb227ae99d_6587 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6266 a b) ∨ (fact_9fdb227ae99d_7081 a b) ∨ (fact_9fdb227ae99d_6086 a b) ∨ (fact_9fdb227ae99d_6720 a b) ∨ (fact_9fdb227ae99d_6732 a b)) ∨ ((fact_9fdb227ae99d_4079 a b) ∨ (fact_9fdb227ae99d_4107 a b) ∨ (fact_9fdb227ae99d_5313 a b) ∨ (fact_9fdb227ae99d_5928 a b) ∨ (fact_9fdb227ae99d_4742 a b) ∨ (((((-1 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4272 a b) ∨ (fact_9fdb227ae99d_6153 a b) ∨ (fact_9fdb227ae99d_4121 a b) ∨ (fact_9fdb227ae99d_5092 a b) ∨ (fact_9fdb227ae99d_5095 a b)))) ∨ ((fact_9fdb227ae99d_7875 a b) ∧ (fact_9fdb227ae99d_7658 a b) ∧ ((fact_9fdb227ae99d_6021 a b) ∨ (fact_9fdb227ae99d_6059 a b) ∨ (fact_9fdb227ae99d_6821 a b) ∨ (fact_9fdb227ae99d_7033 a b) ∨ (fact_9fdb227ae99d_6587 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6266 a b) ∨ (fact_9fdb227ae99d_7081 a b) ∨ (fact_9fdb227ae99d_6086 a b) ∨ (fact_9fdb227ae99d_6720 a b) ∨ (fact_9fdb227ae99d_6732 a b)) ∧ ((fact_9fdb227ae99d_4079 a b) ∨ (fact_9fdb227ae99d_4107 a b) ∨ (fact_9fdb227ae99d_5313 a b) ∨ (fact_9fdb227ae99d_5928 a b) ∨ (fact_9fdb227ae99d_4742 a b) ∨ (((((-1 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4272 a b) ∨ (fact_9fdb227ae99d_6153 a b) ∨ (fact_9fdb227ae99d_4121 a b) ∨ (fact_9fdb227ae99d_5092 a b) ∨ (fact_9fdb227ae99d_5095 a b))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((-5 : Int) ≥ run_x))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (fact_9fdb227ae99d_3608 a b run_x) ∨ (fact_9fdb227ae99d_2397 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n252_run_floor (a b run_x : Int)
    (h0 : (((-2 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (fact_9fdb227ae99d_5352 a b run_x) ∨ (fact_9fdb227ae99d_3196 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : ((-5 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (fact_9fdb227ae99d_5762 a b) ∨ (fact_9fdb227ae99d_5771 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3509 a b) ∨ (fact_9fdb227ae99d_3526 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_4301 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7901 a b) ∨ (fact_9fdb227ae99d_7679 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7901 a b) ∧ (fact_9fdb227ae99d_7679 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7901 a b) ∧ (fact_9fdb227ae99d_7679 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_7085 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6730 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_6151 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5090 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7901 a b) ∧ (fact_9fdb227ae99d_7679 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_7085 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6730 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_6151 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5090 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_3609 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3004 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n253_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_5353 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3578 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3414 a b) ∨ (fact_9fdb227ae99d_3432 a b) ∨ (fact_9fdb227ae99d_4507 a b) ∨ (fact_9fdb227ae99d_5591 a b) ∨ (fact_9fdb227ae99d_3879 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3446 a b) ∨ (fact_9fdb227ae99d_5725 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_tall (a b : Int)
    (h0 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7809 a b) ∨ (fact_9fdb227ae99d_7561 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7809 a b) ∧ (fact_9fdb227ae99d_7561 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7809 a b) ∧ (fact_9fdb227ae99d_7561 a b) ∧ (((fact_9fdb227ae99d_6027 a b) ∨ (fact_9fdb227ae99d_6065 a b) ∨ (fact_9fdb227ae99d_6827 a b) ∨ (fact_9fdb227ae99d_7039 a b) ∨ (fact_9fdb227ae99d_6593 a b) ∨ (fact_9fdb227ae99d_6236 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6089 a b) ∨ (fact_9fdb227ae99d_7090 a b)) ∨ ((fact_9fdb227ae99d_4069 a b) ∨ (fact_9fdb227ae99d_4097 a b) ∨ (fact_9fdb227ae99d_5303 a b) ∨ (fact_9fdb227ae99d_5918 a b) ∨ (fact_9fdb227ae99d_4732 a b) ∨ (fact_9fdb227ae99d_4229 a b) ∨ (fact_9fdb227ae99d_4260 a b) ∨ (fact_9fdb227ae99d_6149 a b) ∨ (fact_9fdb227ae99d_4113 a b) ∨ (fact_9fdb227ae99d_6160 a b)))) ∨ ((fact_9fdb227ae99d_7809 a b) ∧ (fact_9fdb227ae99d_7561 a b) ∧ ((fact_9fdb227ae99d_6027 a b) ∨ (fact_9fdb227ae99d_6065 a b) ∨ (fact_9fdb227ae99d_6827 a b) ∨ (fact_9fdb227ae99d_7039 a b) ∨ (fact_9fdb227ae99d_6593 a b) ∨ (fact_9fdb227ae99d_6236 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6089 a b) ∨ (fact_9fdb227ae99d_7090 a b)) ∧ ((fact_9fdb227ae99d_4069 a b) ∨ (fact_9fdb227ae99d_4097 a b) ∨ (fact_9fdb227ae99d_5303 a b) ∨ (fact_9fdb227ae99d_5918 a b) ∨ (fact_9fdb227ae99d_4732 a b) ∨ (fact_9fdb227ae99d_4229 a b) ∨ (fact_9fdb227ae99d_4260 a b) ∨ (fact_9fdb227ae99d_6149 a b) ∨ (fact_9fdb227ae99d_4113 a b) ∨ (fact_9fdb227ae99d_6160 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_3609 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3612 a b run_x)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h5 : (b = (5 : Int)))
    (h6 : ((-3 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n254_run_floor (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_5353 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_5356 a b run_x))))
    (h2 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3467 a b) ∨ (fact_9fdb227ae99d_3469 a b) ∨ ((((3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3121 a b) ∨ (fact_9fdb227ae99d_3123 a b) ∨ ((((3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7397 a b) ∨ (fact_9fdb227ae99d_7334 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7397 a b) ∧ (fact_9fdb227ae99d_7334 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7397 a b) ∧ (fact_9fdb227ae99d_7334 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_5970 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_5540 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7397 a b) ∧ (fact_9fdb227ae99d_7334 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_5970 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_5540 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2532 a b run_x) ∨ (fact_9fdb227ae99d_2534 a b run_x) ∨ ((((3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h2 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (run_x ≤ a))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n255_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3217 a b run_x) ∨ (fact_9fdb227ae99d_3233 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h2 : (run_x ≤ a))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_0 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3284 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ (fact_9fdb227ae99d_3116 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_2923 a b jy))
    (h9 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o4 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o5 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n256_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h5 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3582 a b) ∨ (fact_9fdb227ae99d_3586 a b) ∨ (fact_9fdb227ae99d_4719 a b) ∨ (fact_9fdb227ae99d_5749 a b) ∨ (fact_9fdb227ae99d_4338 a b) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4476 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4486 a b) ∨ (fact_9fdb227ae99d_4488 a b) ∨ (fact_9fdb227ae99d_5542 a b) ∨ (fact_9fdb227ae99d_6323 a b) ∨ (fact_9fdb227ae99d_5198 a b) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5339 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7311 a b) ∨ (fact_9fdb227ae99d_7355 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7311 a b) ∧ (fact_9fdb227ae99d_7355 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7311 a b) ∧ (fact_9fdb227ae99d_7355 a b) ∧ (((fact_9fdb227ae99d_4345 a b) ∨ (fact_9fdb227ae99d_4362 a b) ∨ (fact_9fdb227ae99d_5455 a b) ∨ (fact_9fdb227ae99d_6178 a b) ∨ (fact_9fdb227ae99d_5113 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4454 a b) ∨ (fact_9fdb227ae99d_5230 a b)) ∨ ((fact_9fdb227ae99d_5265 a b) ∨ (fact_9fdb227ae99d_5274 a b) ∨ (fact_9fdb227ae99d_5832 a b) ∨ (fact_9fdb227ae99d_6765 a b) ∨ (fact_9fdb227ae99d_5666 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5333 a b) ∨ (fact_9fdb227ae99d_5779 a b)))) ∨ ((fact_9fdb227ae99d_7311 a b) ∧ (fact_9fdb227ae99d_7355 a b) ∧ ((fact_9fdb227ae99d_4345 a b) ∨ (fact_9fdb227ae99d_4362 a b) ∨ (fact_9fdb227ae99d_5455 a b) ∨ (fact_9fdb227ae99d_6178 a b) ∨ (fact_9fdb227ae99d_5113 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4454 a b) ∨ (fact_9fdb227ae99d_5230 a b)) ∧ ((fact_9fdb227ae99d_5265 a b) ∨ (fact_9fdb227ae99d_5274 a b) ∨ (fact_9fdb227ae99d_5832 a b) ∨ (fact_9fdb227ae99d_6765 a b) ∨ (fact_9fdb227ae99d_5666 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5333 a b) ∨ (fact_9fdb227ae99d_5779 a b))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + a)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : ((2 : Int) ≤ run_x))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3045 a b run_x)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n257_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3745 a b run_x))))
    (h2 : (run_x ≤ ((-1 : Int) + a)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2895 a b) ∨ (fact_9fdb227ae99d_2897 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - b)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o0 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (b = (5 : Int)))
    (h8 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o6 (a b jx jy : Int)
    (h0 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n258_o7 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2900 a b) ∨ (fact_9fdb227ae99d_2904 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (((jx + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o6 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n259_o7 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3396 a b) ∨ (fact_9fdb227ae99d_3406 a b) ∨ (((((-3 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3920 a b) ∨ (fact_9fdb227ae99d_3967 a b) ∨ (((((-3 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7483 a b) ∨ (fact_9fdb227ae99d_7598 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7483 a b) ∧ (fact_9fdb227ae99d_7598 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7483 a b) ∧ (fact_9fdb227ae99d_7598 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_3977 a b) ∨ (fact_9fdb227ae99d_4021 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_4826 a b) ∨ (fact_9fdb227ae99d_4884 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7483 a b) ∧ (fact_9fdb227ae99d_7598 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_3977 a b) ∨ (fact_9fdb227ae99d_4021 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_4826 a b) ∨ (fact_9fdb227ae99d_4884 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2485 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n260_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3248 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3398 a b) ∨ (fact_9fdb227ae99d_3408 a b) ∨ (((((-3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3917 a b) ∨ (fact_9fdb227ae99d_3964 a b) ∨ (((((-3 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7489 a b) ∨ (fact_9fdb227ae99d_7592 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7489 a b) ∧ (fact_9fdb227ae99d_7592 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7489 a b) ∧ (fact_9fdb227ae99d_7592 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3936 a b) ∨ (fact_9fdb227ae99d_3985 a b) ∨ (fact_9fdb227ae99d_4031 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4774 a b) ∨ (fact_9fdb227ae99d_4816 a b) ∨ (fact_9fdb227ae99d_4876 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7489 a b) ∧ (fact_9fdb227ae99d_7592 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3936 a b) ∨ (fact_9fdb227ae99d_3985 a b) ∨ (fact_9fdb227ae99d_4031 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4774 a b) ∨ (fact_9fdb227ae99d_4816 a b) ∨ (fact_9fdb227ae99d_4876 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b = (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n261_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3395 a b) ∨ (fact_9fdb227ae99d_3405 a b) ∨ (((((-3 : Int) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3919 a b) ∨ (fact_9fdb227ae99d_3966 a b) ∨ (((((-3 : Int) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7361 a b) ∨ (fact_9fdb227ae99d_7432 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7361 a b) ∧ (fact_9fdb227ae99d_7432 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7361 a b) ∧ (fact_9fdb227ae99d_7432 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3923 a b) ∨ (fact_9fdb227ae99d_3969 a b) ∨ (fact_9fdb227ae99d_4017 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4779 a b) ∨ (fact_9fdb227ae99d_4822 a b) ∨ (fact_9fdb227ae99d_4882 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7361 a b) ∧ (fact_9fdb227ae99d_7432 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3923 a b) ∨ (fact_9fdb227ae99d_3969 a b) ∨ (fact_9fdb227ae99d_4017 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4779 a b) ∨ (fact_9fdb227ae99d_4822 a b) ∨ (fact_9fdb227ae99d_4882 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2485 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (run_x ≤ ((1 : Int) + b)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n262_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3248 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_short (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((1 : Int) - (-2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5882 a b) ∨ (fact_9fdb227ae99d_5887 a b) ∨ (fact_9fdb227ae99d_6759 a b) ∨ (fact_9fdb227ae99d_7006 a b) ∨ (fact_9fdb227ae99d_6404 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5942 a b) ∨ (fact_9fdb227ae99d_5949 a b) ∨ (fact_9fdb227ae99d_6475 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5875 a b) ∨ (fact_9fdb227ae99d_5877 a b) ∨ (fact_9fdb227ae99d_5879 a b) ∨ (fact_9fdb227ae99d_6358 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-2 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7705 a b) ∨ (fact_9fdb227ae99d_7688 a b))) ∨ (((1 : Int) ≥ ((-2 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7705 a b) ∧ (fact_9fdb227ae99d_7688 a b)) ∨ ((1 : Int) ≥ ((-2 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7705 a b) ∧ (fact_9fdb227ae99d_7688 a b) ∧ (((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6506 a b) ∨ (fact_9fdb227ae99d_6519 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6871 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6414 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6796 a b)))) ∨ ((fact_9fdb227ae99d_7705 a b) ∧ (fact_9fdb227ae99d_7688 a b) ∧ ((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6506 a b) ∨ (fact_9fdb227ae99d_6519 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6871 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6414 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6796 a b))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_empty (a b run_x : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4245 a b run_x) ∨ (fact_9fdb227ae99d_4280 a b run_x) ∨ (fact_9fdb227ae99d_4305 a b run_x) ∨ (fact_9fdb227ae99d_4997 a b run_x)))
    (h2 : ((1 : Int) ≥ run_x))
    (h3 : (a > b))
    (h4 : ((-2 : Int) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n263_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5671 a b run_x) ∨ (fact_9fdb227ae99d_5673 a b run_x) ∨ (fact_9fdb227ae99d_5677 a b run_x) ∨ (fact_9fdb227ae99d_5956 a b run_x))))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : ((-2 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2820 a b) ∨ (fact_9fdb227ae99d_2822 a b) ∨ (fact_9fdb227ae99d_3204 a b) ∨ (fact_9fdb227ae99d_3850 a b) ∨ (fact_9fdb227ae99d_3066 a b) ∨ (fact_9fdb227ae99d_2901 a b) ∨ (fact_9fdb227ae99d_2905 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2823 a b)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o0 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (¬ (((jx = ((3 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h8 : (¬ ((((3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n264_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2966 a b) ∨ (fact_9fdb227ae99d_2968 a b) ∨ ((((-4 : Int) ≥ ((-3 : Int) - b)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_3108 a b)))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o5 (a b jx jy : Int)
    (h0 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n265_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_point (a b : Int)
    (h0 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h1 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_2969 a b) ∨ ((((-4 : Int) ≥ ((-3 : Int) - b)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o0 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o1 (a b jx jy : Int)
    (h0 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o3 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h7 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n266_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_short (a b : Int)
    (h0 : (¬ (((1 : Int) - (-3 : Int)) < b)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_nonnegative (a b : Int)
    (h0 : (¬ (((-3 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5815 a b) ∨ (fact_9fdb227ae99d_5817 a b) ∨ (fact_9fdb227ae99d_6675 a b) ∨ (fact_9fdb227ae99d_7000 a b) ∨ (fact_9fdb227ae99d_6340 a b) ∨ (((((-1 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5878 a b) ∨ (((((-3 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5819 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (fact_9fdb227ae99d_1116 a)) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-4 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-3 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7938 a b) ∨ (fact_9fdb227ae99d_7936 a b))) ∨ (((1 : Int) ≥ ((-3 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7938 a b) ∧ (fact_9fdb227ae99d_7936 a b)) ∨ ((1 : Int) ≥ ((-3 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7938 a b) ∧ (fact_9fdb227ae99d_7936 a b) ∧ (((fact_9fdb227ae99d_6447 a b) ∨ (fact_9fdb227ae99d_6461 a b) ∨ (fact_9fdb227ae99d_6957 a b) ∨ (fact_9fdb227ae99d_7135 a b) ∨ (fact_9fdb227ae99d_6853 a b) ∨ (fact_9fdb227ae99d_6510 a b) ∨ (fact_9fdb227ae99d_6525 a b) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6470 a b) ∨ (fact_9fdb227ae99d_6877 a b) ∨ (fact_9fdb227ae99d_7147 a b) ∨ (fact_9fdb227ae99d_6895 a b)) ∨ ((fact_9fdb227ae99d_6344 a b) ∨ (fact_9fdb227ae99d_6350 a b) ∨ (fact_9fdb227ae99d_6919 a b) ∨ (fact_9fdb227ae99d_7123 a b) ∨ (fact_9fdb227ae99d_6789 a b) ∨ (fact_9fdb227ae99d_6416 a b) ∨ (fact_9fdb227ae99d_6425 a b) ∨ (((((-3 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-3 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6355 a b) ∨ (fact_9fdb227ae99d_6800 a b) ∨ (fact_9fdb227ae99d_7141 a b) ∨ (fact_9fdb227ae99d_6861 a b)))) ∨ ((fact_9fdb227ae99d_7938 a b) ∧ (fact_9fdb227ae99d_7936 a b) ∧ ((fact_9fdb227ae99d_6447 a b) ∨ (fact_9fdb227ae99d_6461 a b) ∨ (fact_9fdb227ae99d_6957 a b) ∨ (fact_9fdb227ae99d_7135 a b) ∨ (fact_9fdb227ae99d_6853 a b) ∨ (fact_9fdb227ae99d_6510 a b) ∨ (fact_9fdb227ae99d_6525 a b) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6470 a b) ∨ (fact_9fdb227ae99d_6877 a b) ∨ (fact_9fdb227ae99d_7147 a b) ∨ (fact_9fdb227ae99d_6895 a b)) ∧ ((fact_9fdb227ae99d_6344 a b) ∨ (fact_9fdb227ae99d_6350 a b) ∨ (fact_9fdb227ae99d_6919 a b) ∨ (fact_9fdb227ae99d_7123 a b) ∨ (fact_9fdb227ae99d_6789 a b) ∨ (fact_9fdb227ae99d_6416 a b) ∨ (fact_9fdb227ae99d_6425 a b) ∨ (((((-3 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-3 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6355 a b) ∨ (fact_9fdb227ae99d_6800 a b) ∨ (fact_9fdb227ae99d_7141 a b) ∨ (fact_9fdb227ae99d_6861 a b))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_empty (a b run_x : Int)
    (h0 : (a > b))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((-3 : Int) ≤ run_x))
    (h4 : ((fact_9fdb227ae99d_4084 a b run_x) ∨ (fact_9fdb227ae99d_4112 a b run_x) ∨ (fact_9fdb227ae99d_5318 a b run_x) ∨ (fact_9fdb227ae99d_5933 a b run_x) ∨ (fact_9fdb227ae99d_4747 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4281 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4126 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((-4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n267_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5623 a b run_x) ∨ (fact_9fdb227ae99d_5625 a b run_x) ∨ (fact_9fdb227ae99d_6338 a b run_x) ∨ (fact_9fdb227ae99d_6923 a b run_x) ∨ (fact_9fdb227ae99d_5935 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5674 a b run_x) ∨ (((((-3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5627 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + a))) ∨ (fact_9fdb227ae99d_314 a run_x)) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))) ∨ (((((-4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : ((-3 : Int) ≤ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5773 a b) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-4 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((-4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7930 a b) ∨ (fact_9fdb227ae99d_7939 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7930 a b) ∧ (fact_9fdb227ae99d_7939 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7930 a b) ∧ (fact_9fdb227ae99d_7939 a b) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6240 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6304 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6616 a b) ∨ (fact_9fdb227ae99d_6620 a b) ∨ (fact_9fdb227ae99d_6988 a b) ∨ (fact_9fdb227ae99d_7149 a b) ∨ (fact_9fdb227ae99d_6908 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6723 a b) ∨ (fact_9fdb227ae99d_6624 a b) ∨ (fact_9fdb227ae99d_6912 a b) ∨ (fact_9fdb227ae99d_7160 a b) ∨ (fact_9fdb227ae99d_6930 a b)))) ∨ ((fact_9fdb227ae99d_7930 a b) ∧ (fact_9fdb227ae99d_7939 a b) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6240 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6304 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6616 a b) ∨ (fact_9fdb227ae99d_6620 a b) ∨ (fact_9fdb227ae99d_6988 a b) ∨ (fact_9fdb227ae99d_7149 a b) ∨ (fact_9fdb227ae99d_6908 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6723 a b) ∨ (fact_9fdb227ae99d_6624 a b) ∨ (fact_9fdb227ae99d_6912 a b) ∨ (fact_9fdb227ae99d_7160 a b) ∨ (fact_9fdb227ae99d_6930 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_empty (a b run_x : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_3691 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (run_x ≤ ((1 : Int) + a)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b = (5 : Int)))
    (h10 : ((4 : Int) ≤ run_x))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n268_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5485 a b run_x) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ (fact_9fdb227ae99d_2906 a b) ∨ (fact_9fdb227ae99d_2907 a b) ∨ (fact_9fdb227ae99d_2909 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ (fact_9fdb227ae99d_4319 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - b)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (4 : Int))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ ((4 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) + a))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o3 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o6 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n269_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3477 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ (fact_9fdb227ae99d_5715 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_3863 a b) ∨ (fact_9fdb227ae99d_3865 a b) ∨ (fact_9fdb227ae99d_5289 a b) ∨ (fact_9fdb227ae99d_5904 a b) ∨ (fact_9fdb227ae99d_4712 a b) ∨ (fact_9fdb227ae99d_4186 a b) ∨ (fact_9fdb227ae99d_4188 a b) ∨ (fact_9fdb227ae99d_4191 a b) ∨ (fact_9fdb227ae99d_3867 a b) ∨ (fact_9fdb227ae99d_4714 a b) ∨ ((((5 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_4716 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7836 a b) ∨ (fact_9fdb227ae99d_7879 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7836 a b) ∧ (fact_9fdb227ae99d_7879 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7836 a b) ∧ (fact_9fdb227ae99d_7879 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_5984 a b) ∨ (fact_9fdb227ae99d_4052 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_6563 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_5443 a b)))) ∨ ((fact_9fdb227ae99d_7836 a b) ∧ (fact_9fdb227ae99d_7879 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_5984 a b) ∨ (fact_9fdb227ae99d_4052 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_6563 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_5443 a b))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ (fact_9fdb227ae99d_2539 a b run_x) ∨ (fact_9fdb227ae99d_2540 a b run_x) ∨ (fact_9fdb227ae99d_2542 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ (fact_9fdb227ae99d_3669 a b run_x) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (run_x ≤ ((1 : Int) + a)))
    (h7 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n270_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (fact_9fdb227ae99d_3219 a b run_x) ∨ (fact_9fdb227ae99d_3235 a b run_x) ∨ (fact_9fdb227ae99d_3247 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (fact_9fdb227ae99d_5359 a b run_x) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ (fact_9fdb227ae99d_2906 a b) ∨ (fact_9fdb227ae99d_2907 a b) ∨ (fact_9fdb227ae99d_2909 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ (fact_9fdb227ae99d_4319 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - b)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h3 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o0 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o6 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n271_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3477 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ (fact_9fdb227ae99d_5715 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3863 a b) ∨ (fact_9fdb227ae99d_3865 a b) ∨ (fact_9fdb227ae99d_5289 a b) ∨ (fact_9fdb227ae99d_5904 a b) ∨ (fact_9fdb227ae99d_4712 a b) ∨ (fact_9fdb227ae99d_4186 a b) ∨ (fact_9fdb227ae99d_4188 a b) ∨ (fact_9fdb227ae99d_4191 a b) ∨ (fact_9fdb227ae99d_3867 a b) ∨ (fact_9fdb227ae99d_4714 a b) ∨ ((((5 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4716 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7839 a b) ∨ (fact_9fdb227ae99d_7883 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7839 a b) ∧ (fact_9fdb227ae99d_7883 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7839 a b) ∧ (fact_9fdb227ae99d_7883 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_5984 a b) ∨ (fact_9fdb227ae99d_4941 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_6563 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5443 a b)))) ∨ ((fact_9fdb227ae99d_7839 a b) ∧ (fact_9fdb227ae99d_7883 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_5984 a b) ∨ (fact_9fdb227ae99d_4941 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_6563 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5443 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ (fact_9fdb227ae99d_2539 a b run_x) ∨ (fact_9fdb227ae99d_2540 a b run_x) ∨ (fact_9fdb227ae99d_2542 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ (fact_9fdb227ae99d_3669 a b run_x) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h5 : (run_x ≤ ((1 : Int) + a)))
    (h6 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : ((4 : Int) ≤ run_x))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n272_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (fact_9fdb227ae99d_3219 a b run_x) ∨ (fact_9fdb227ae99d_3235 a b run_x) ∨ (fact_9fdb227ae99d_3247 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (fact_9fdb227ae99d_5359 a b run_x) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5688 a b) ∨ (fact_9fdb227ae99d_5701 a b) ∨ (fact_9fdb227ae99d_6369 a b) ∨ (fact_9fdb227ae99d_6965 a b) ∨ (fact_9fdb227ae99d_5995 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5772 a b) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5708 a b) ∨ (fact_9fdb227ae99d_6119 a b) ∨ (fact_9fdb227ae99d_6982 a b) ∨ (fact_9fdb227ae99d_6987 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_3527 a b) ∨ (((((-3 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7934 a b) ∨ (fact_9fdb227ae99d_7776 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7934 a b) ∧ (fact_9fdb227ae99d_7776 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7934 a b) ∧ (fact_9fdb227ae99d_7776 a b) ∧ (((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6247 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4238 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4297 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ ((fact_9fdb227ae99d_7934 a b) ∧ (fact_9fdb227ae99d_7776 a b) ∧ ((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6247 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4238 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4297 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : ((-4 : Int) ≥ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2467 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2486 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n273_run_floor (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3223 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3249 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_short (a b : Int)
    (h0 : (¬ (((1 : Int) - (-2 : Int)) < b)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_nonnegative (a b : Int)
    (h0 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5882 a b) ∨ (fact_9fdb227ae99d_5887 a b) ∨ (fact_9fdb227ae99d_6759 a b) ∨ (fact_9fdb227ae99d_7006 a b) ∨ (fact_9fdb227ae99d_6404 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5942 a b) ∨ (fact_9fdb227ae99d_5949 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5875 a b) ∨ (fact_9fdb227ae99d_5877 a b) ∨ (fact_9fdb227ae99d_5879 a b) ∨ (fact_9fdb227ae99d_5818 a b) ∨ (fact_9fdb227ae99d_6359 a b) ∨ (fact_9fdb227ae99d_6437 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-2 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7905 a b) ∨ (fact_9fdb227ae99d_7892 a b))) ∨ (((1 : Int) ≥ ((-2 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7905 a b) ∧ (fact_9fdb227ae99d_7892 a b)) ∨ ((1 : Int) ≥ ((-2 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7905 a b) ∧ (fact_9fdb227ae99d_7892 a b) ∧ (((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6506 a b) ∨ (fact_9fdb227ae99d_6519 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6464 a b) ∨ (fact_9fdb227ae99d_6873 a b) ∨ (fact_9fdb227ae99d_6891 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6414 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b)))) ∨ ((fact_9fdb227ae99d_7905 a b) ∧ (fact_9fdb227ae99d_7892 a b) ∧ ((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6506 a b) ∨ (fact_9fdb227ae99d_6519 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6464 a b) ∨ (fact_9fdb227ae99d_6873 a b) ∨ (fact_9fdb227ae99d_6891 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6414 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4245 a b run_x) ∨ (fact_9fdb227ae99d_4280 a b run_x) ∨ (fact_9fdb227ae99d_4305 a b run_x) ∨ (fact_9fdb227ae99d_4125 a b run_x) ∨ (fact_9fdb227ae99d_5017 a b run_x) ∨ (fact_9fdb227ae99d_5094 a b run_x)))
    (h1 : (a ≥ b))
    (h2 : ((1 : Int) ≥ run_x))
    (h3 : ((-2 : Int) ≤ run_x))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n274_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5671 a b run_x) ∨ (fact_9fdb227ae99d_5673 a b run_x) ∨ (fact_9fdb227ae99d_5677 a b run_x) ∨ (fact_9fdb227ae99d_5626 a b run_x) ∨ (fact_9fdb227ae99d_5957 a b run_x) ∨ (fact_9fdb227ae99d_6002 a b run_x))))
    (h1 : (b = (5 : Int)))
    (h2 : ((-2 : Int) ≤ run_x))
    (h3 : ((1 : Int) ≥ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3624 a b) ∨ (fact_9fdb227ae99d_3626 a b) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (fact_9fdb227ae99d_4390 a b) ∨ (fact_9fdb227ae99d_4485 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3168 a b) ∨ (fact_9fdb227ae99d_3170 a b) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (fact_9fdb227ae99d_3463 a b) ∨ (fact_9fdb227ae99d_3548 a b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7664 a b) ∨ (fact_9fdb227ae99d_7543 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7664 a b) ∧ (fact_9fdb227ae99d_7543 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7664 a b) ∧ (fact_9fdb227ae99d_7543 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4439 a b) ∨ (fact_9fdb227ae99d_4459 a b) ∨ (fact_9fdb227ae99d_4477 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3515 a b) ∨ (fact_9fdb227ae99d_3530 a b) ∨ (fact_9fdb227ae99d_3543 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b)))) ∨ ((fact_9fdb227ae99d_7664 a b) ∧ (fact_9fdb227ae99d_7543 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4439 a b) ∨ (fact_9fdb227ae99d_4459 a b) ∨ (fact_9fdb227ae99d_4477 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3515 a b) ∨ (fact_9fdb227ae99d_3530 a b) ∨ (fact_9fdb227ae99d_3543 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (run_x ≤ a))
    (h4 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2697 a b run_x) ∨ (fact_9fdb227ae99d_2714 a b run_x) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3036 a b run_x) ∨ (fact_9fdb227ae99d_3047 a b run_x)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n275_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3356 a b run_x) ∨ (fact_9fdb227ae99d_3359 a b run_x) ∨ (((((-3 : Int) - b) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3721 a b run_x) ∨ (fact_9fdb227ae99d_3747 a b run_x))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ (fact_9fdb227ae99d_2906 a b) ∨ (fact_9fdb227ae99d_2907 a b) ∨ (fact_9fdb227ae99d_2909 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - b)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o0 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o6 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n276_o7 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3477 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((fact_9fdb227ae99d_3863 a b) ∨ (fact_9fdb227ae99d_3865 a b) ∨ (fact_9fdb227ae99d_5289 a b) ∨ (fact_9fdb227ae99d_5904 a b) ∨ (fact_9fdb227ae99d_4712 a b) ∨ (fact_9fdb227ae99d_4186 a b) ∨ (fact_9fdb227ae99d_4188 a b) ∨ (fact_9fdb227ae99d_4191 a b) ∨ (fact_9fdb227ae99d_3867 a b) ∨ (fact_9fdb227ae99d_4714 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4716 a b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n277_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7754 a b) ∨ (fact_9fdb227ae99d_7791 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7754 a b) ∧ (fact_9fdb227ae99d_7791 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7754 a b) ∧ (fact_9fdb227ae99d_7791 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4051 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5443 a b)))) ∨ ((fact_9fdb227ae99d_7754 a b) ∧ (fact_9fdb227ae99d_7791 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4051 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4791 a b) ∨ (fact_9fdb227ae99d_4848 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (((((-4 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5443 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

import LQuadrantBoundaryTips
import THalfPlaneStarters
import THalfPlaneGaps
set_option maxHeartbeats 100000
set_option maxRecDepth 10000
namespace PolyominoFormal.LHalfPlaneEqual
open CrossUnits TBoundary THalfPlaneStarters THalfPlaneGaps

def Starter (a p h : Int) (t : Cross) : Prop :=
  t=⟨p,h+a,a,0,0,a⟩ ∨ t=⟨p,h+a,0,0,a,a⟩

theorem starter_base {a p h : Int} (ha : 1≤a) {t : Cross} (st : Starter a p h t) : Contains t p h := by
  rcases st with rfl | rfl <;> right <;> dsimp <;> omega

theorem starter_base_only {a p h x : Int} (ha : 1≤a) {t : Cross}
    (st : Starter a p h t) (hit : Contains t x h) : x=p := by
  rcases st with rfl | rfl <;> dsimp [Contains] at hit <;> omega

theorem adjacent {a p h : Int} (ha : 1≤a) {t u : Cross}
    (st : Starter a p h t) (su : Starter a (p+1) h u) (apart : Apart t u) :
    t=⟨p,h+a,0,0,a,a⟩ ∧ u=⟨p+1,h+a,a,0,0,a⟩ := by
  rcases st with rfl | rfl
  all_goals rcases su with rfl | rfl
  all_goals first | exact ⟨rfl,rfl⟩ | skip
  all_goals dsimp [Apart] at apart; omega

theorem no_three {a p h : Int} (ha : 1≤a) {t u v : Cross}
    (st : Starter a p h t) (su : Starter a (p+1) h u) (sv : Starter a (p+2) h v)
    (ap : Apart t u) (ap2 : Apart u v) : False := by
  have e1 := (adjacent ha st su ap).2
  have e2 := (adjacent ha su (by simpa only [show p+1+1=p+2 by omega] using sv) ap2).1
  have eq := congrArg Cross.east (e1.symm.trans e2); dsimp at eq; omega

theorem run_forms {a L R p h : Int} (ha : 1≤a) (hp0 : L≤p) (hp1 : p≤R)
    {t : Cross} (copy : Copy a a 0 0 t) (hit : Contains t p h)
    (left : ¬Contains t (L-1) h) (right : ¬Contains t (R+1) h)
    (floor : ¬Contains t p (h-1))
    (center : L≤t.x → t.x≤R → ¬Contains t t.x (h-1)) :
    (∃q r,(r=0 ∨ r=a) ∧ t=⟨q+r,h,a-r,a,r,0⟩ ∧ L≤q ∧ q≤p ∧ p≤q+a ∧ q+a≤R) ∨
    Starter a p h t := by
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) copy
  rcases nn with ⟨he,hn,hw,hs⟩
  by_cases row : t.y=h
  · have span : t.x-t.west≤p ∧ p≤t.x+t.east := by rcases hit with hit | hit <;> omega
    have noLeft : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact left (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have noRight : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩; exact right (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have bounds : L≤t.x-t.west ∧ t.x+t.east≤R := by omega
    have south : t.south=0 := by
      apply Classical.byContradiction; intro neq
      exact center (by omega) (by omega) (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs row south bounds span
    all_goals subst e; subst n; subst w; subst s
    · left; refine ⟨x,0,Or.inl rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
    · left; refine ⟨x-a,a,Or.inr rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · left; refine ⟨x-a,a,Or.inr rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · left; refine ⟨x,0,Or.inl rfl,?_,by omega,by omega,by omega,by omega⟩
      apply same_eq; dsimp [Same]; omega
    · exfalso; omega
  · have vertical : t.x=p ∧ t.y-t.south≤h ∧ h≤t.y+t.north := by
      rcases hit with hit | hit <;> omega
    have bottom : t.y-t.south=h := by
      apply Classical.byContradiction; intro different
      exact floor (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
    right
    rcases t with ⟨x,y,e,n,w,s⟩
    rcases copy with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨ce,cn,cw,cs⟩
    all_goals dsimp only at ce cn cw cs bottom vertical row
    all_goals subst e; subst n; subst w; subst s
    · exfalso; omega
    · left; apply same_eq; dsimp [Same]; omega
    · right; apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · right; apply same_eq; dsimp [Same]; omega
    · exfalso; omega
    · exfalso; omega
    · left; apply same_eq; dsimp [Same]; omega

theorem blocked_short_run {a L R h : Int} {region : Region} (ha : 1≤a)
    (three : L+2≤R) (short : R-L<a) (T : Tiling a a 0 0 region) (B : Region)
    (closed : CornerCertificate.TileClosed T.world B)
    (inside : ∀x,L≤x → x≤R → region x h)
    (empty : ∀x,L≤x → x≤R → ¬B x h)
    (floor : ∀x,L≤x → x≤R → B x (h-1))
    (left : B (L-1) h) (right : B (R+1) h) : False := by
  have choose : ∀p,L≤p → p≤R → ∃t,T.world t ∧ Starter a p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀{x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    have form := run_forms ha hp0 hp1 (T.copies t ht) hit
      (avoid left) (avoid right) (avoid (floor p hp0 hp1))
      (fun h0 h1 => avoid (floor t.x h0 h1))
    rcases form with ⟨q,r,hr,eq,hq0,hq1,hq2,hq3⟩ | st
    · omega
    · exact ⟨t,ht,st⟩
  obtain ⟨t,ht,st⟩ := choose L (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := choose (L+1) (by omega) (by omega)
  obtain ⟨v,hv,sv⟩ := choose (L+2) (by omega) (by omega)
  have ap : Apart t u := by
    apply TPlane.apart_of_no_common_nonnegative t u
      (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht))
      (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies u hu))
    intro x y hit hit'
    have eq := T.disjoint t u x y ht hu hit hit'
    have h := starter_base_only ha su (eq ▸ starter_base ha st); omega
  have ap2 : Apart u v := by
    apply TPlane.apart_of_no_common_nonnegative u v
      (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies u hu))
      (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies v hv))
    intro x y hit hit'
    have eq := T.disjoint u v x y hu hv hit hit'
    have h := starter_base_only ha sv (eq ▸ starter_base ha su); omega
  exact no_three ha st su sv ap ap2

#print axioms blocked_short_run
end PolyominoFormal.LHalfPlaneEqual

import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (fact_366edf150095_3920 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3473 a b) ∨ (fact_366edf150095_4054 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_3711 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (fact_366edf150095_4637 a b) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4028 a b) ∨ (fact_366edf150095_5044 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_4403 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_tall (a b : Int)
    (h0 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7695 a b) ∨ (fact_366edf150095_7725 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7695 a b) ∧ (fact_366edf150095_7725 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7695 a b) ∧ (fact_366edf150095_7725 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_4828 a b) ∨ (fact_366edf150095_4018 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_5549 a b) ∨ (fact_366edf150095_4869 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7695 a b) ∧ (fact_366edf150095_7725 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_4828 a b) ∨ (fact_366edf150095_4018 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_5549 a b) ∨ (fact_366edf150095_4869 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5420 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((7 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (run_x ≤ ((6 : Int) + b)))
    (h7 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2998 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3024 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_2978 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n420_run_floor (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((6 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3577 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3611 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_3558 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_point (a b : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_7 a b))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_3229 a b) ∨ (fact_366edf150095_3135 a b) ∨ (fact_366edf150095_4225 a b) ∨ (fact_366edf150095_4314 a b) ∨ (fact_366edf150095_3143 a b) ∨ (fact_366edf150095_3360 a b) ∨ (fact_366edf150095_3394 a b) ∨ (fact_366edf150095_3406 a b) ∨ (fact_366edf150095_3156 a b) ∨ (fact_366edf150095_3159 a b) ∨ (fact_366edf150095_3417 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((7 : Int) + a) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((7 : Int) + a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((-1 : Int) + (0 : Int)) < ((2 : Int) + ((-1 : Int) * a))) ∨ (((2 : Int) + ((-1 : Int) * a)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (((3 : Int) + b) - (0 : Int))) ∨ ((0 : Int) > (((3 : Int) + b) + b))))
    (h6 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_366edf150095_1840 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1845 a b jx jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o2 (a b jx jy : Int)
    (h0 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (fact_366edf150095_1861 a b jx jy))
    (h6 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1876 a b jx jy))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_1877 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o5 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (fact_366edf150095_1860 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h12 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h13 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h14 : (a = (b + (2 : Int))))
    (h15 : (a ≥ (5 : Int)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1844 a b jx jy))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n421_o7 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_366edf150095_1841 a b jx jy))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3516 a b) ∨ (fact_366edf150095_3496 a b) ∨ (fact_366edf150095_5828 a b) ∨ (fact_366edf150095_5829 a b) ∨ (fact_366edf150095_3497 a b) ∨ (fact_366edf150095_4109 a b) ∨ (fact_366edf150095_4112 a b) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3499 a b) ∨ (fact_366edf150095_4115 a b) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_4116 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - a)) ∧ ((8 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7697 a b) ∨ (fact_366edf150095_7728 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7697 a b) ∧ (fact_366edf150095_7728 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7697 a b) ∧ (fact_366edf150095_7728 a b) ∧ (((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_4832 a b) ∨ (fact_366edf150095_4023 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5076 a b)) ∨ ((fact_366edf150095_5193 a b) ∨ (fact_366edf150095_4487 a b) ∨ (fact_366edf150095_6412 a b) ∨ (fact_366edf150095_6500 a b) ∨ (fact_366edf150095_4571 a b) ∨ (fact_366edf150095_5321 a b) ∨ (fact_366edf150095_5478 a b) ∨ (fact_366edf150095_5565 a b) ∨ (fact_366edf150095_4921 a b) ∨ (fact_366edf150095_5022 a b) ∨ (fact_366edf150095_5734 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5764 a b)))) ∨ ((fact_366edf150095_7697 a b) ∧ (fact_366edf150095_7728 a b) ∧ ((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_4832 a b) ∨ (fact_366edf150095_4023 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5076 a b)) ∧ ((fact_366edf150095_5193 a b) ∨ (fact_366edf150095_4487 a b) ∨ (fact_366edf150095_6412 a b) ∨ (fact_366edf150095_6500 a b) ∨ (fact_366edf150095_4571 a b) ∨ (fact_366edf150095_5321 a b) ∨ (fact_366edf150095_5478 a b) ∨ (fact_366edf150095_5565 a b) ∨ (fact_366edf150095_4921 a b) ∨ (fact_366edf150095_5022 a b) ∨ (fact_366edf150095_5734 a b) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_5764 a b))))))
    (h2 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h7 : (a > b))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) + ((-1 : Int) * a)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) + ((-1 : Int) * a))) ∨ ((((3 : Int) + b) + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (((3 : Int) + b) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((1 : Int) + a)))
    (h5 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ (fact_366edf150095_3059 a b run_x) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2359 a b run_x) ∨ (fact_366edf150095_3060 a b run_x) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_3061 a b run_x)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n422_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (fact_366edf150095_3562 a b run_x) ∨ (((((3 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3337 a b run_x) ∨ (fact_366edf150095_3607 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ (fact_366edf150095_3615 a b run_x))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2910 a b) ∨ (fact_366edf150095_2597 a b) ∨ (fact_366edf150095_4096 a b) ∨ (fact_366edf150095_4100 a b) ∨ (fact_366edf150095_2598 a b) ∨ (fact_366edf150095_3204 a b) ∨ (fact_366edf150095_3207 a b) ∨ (fact_366edf150095_3208 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2600 a b) ∨ (fact_366edf150095_3209 a b) ∨ ((((7 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((7 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((3 : Int) + b) + a))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o0 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o1 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((jx + b) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o2 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (fact_366edf150095_2954 a b jy))
    (h7 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o3 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o6 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n423_o7 (a b jx jy : Int)
    (h0 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_point (a b : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_7 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_empty (a b : Int)
    (h0 : ((fact_366edf150095_3229 a b) ∨ (fact_366edf150095_3135 a b) ∨ (fact_366edf150095_4225 a b) ∨ (fact_366edf150095_4314 a b) ∨ (fact_366edf150095_3143 a b) ∨ (fact_366edf150095_3360 a b) ∨ (fact_366edf150095_3394 a b) ∨ (fact_366edf150095_3406 a b) ∨ (fact_366edf150095_3156 a b) ∨ (fact_366edf150095_3159 a b) ∨ (fact_366edf150095_3417 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((7 : Int) ≤ ((6 : Int) + b)) ∧ ((7 : Int) ≥ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a > b))
    (h5 : (fact_366edf150095_711 a b))
    (h6 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_711 a b))
    (h4 : (a > b))
    (h5 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_366edf150095_1840 a b jx jy))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o1 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (fact_366edf150095_1845 a b jx jy))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h6 : (fact_366edf150095_711 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a > b))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (fact_366edf150095_1861 a b jx jy))
    (h6 : (fact_366edf150095_711 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h9 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1876 a b jx jy))
    (h2 : (fact_366edf150095_711 a b))
    (h3 : (a > b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o4 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1877 a b jx jy))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o5 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_711 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (fact_366edf150095_1860 a b jx jy))
    (h4 : (a > b))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_711 a b))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1844 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (a > b))
    (h9 : (¬ ((((((jy = (0 : Int)) ∧ ((3 : Int) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((5 : Int) = ((jx + a) + (1 : Int))) ∨ (jx = (((5 : Int) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((5 : Int) = (jx - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((5 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((5 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((3 : Int) = jy) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((5 : Int) = ((jx + b) + (1 : Int))) ∨ ((((5 : Int) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((5 : Int) = (jx - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((5 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((5 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = (jx + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((5 : Int) = (jx - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((5 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (jx = ((5 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h9
  clear h9
  left
  left
  left
  left
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n424_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (fact_366edf150095_2955 a b jy))
    (h2 : (fact_366edf150095_1841 a b jx jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (fact_366edf150095_711 a b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a > b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (fact_366edf150095_3920 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3473 a b) ∨ (fact_366edf150095_4054 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_3711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (fact_366edf150095_4637 a b) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4028 a b) ∨ (fact_366edf150095_5044 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_4403 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7696 a b) ∨ (fact_366edf150095_7726 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7696 a b) ∧ (fact_366edf150095_7726 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7696 a b) ∧ (fact_366edf150095_7726 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_4828 a b) ∨ (fact_366edf150095_4018 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_5549 a b) ∨ (fact_366edf150095_4869 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7696 a b) ∧ (fact_366edf150095_7726 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_4828 a b) ∨ (fact_366edf150095_4018 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_5549 a b) ∨ (fact_366edf150095_4869 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5420 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2998 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3024 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_2978 a b run_x)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (run_x ≤ ((6 : Int) + b)))
    (h6 : (fact_366edf150095_711 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n425_run_floor (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3577 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3611 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_3558 a b run_x))))
    (h2 : (run_x ≤ ((6 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_point (a b : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_7 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_3229 a b) ∨ (fact_366edf150095_3135 a b) ∨ (fact_366edf150095_4225 a b) ∨ (fact_366edf150095_4314 a b) ∨ (fact_366edf150095_3143 a b) ∨ (fact_366edf150095_3360 a b) ∨ (fact_366edf150095_3394 a b) ∨ (fact_366edf150095_3406 a b) ∨ (fact_366edf150095_3156 a b) ∨ (fact_366edf150095_3159 a b) ∨ (fact_366edf150095_3417 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + a)))) ∨ ((((((7 : Int) + a) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((7 : Int) + a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h2 : (a > b))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_711 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_711 a b))
    (h2 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (((jx + a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_1840 a b jx jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (a > b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_711 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (fact_366edf150095_1845 a b jx jy))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o2 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_711 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_366edf150095_1861 a b jx jy))
    (h7 : (fact_366edf150095_2954 a b jy))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a > b))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h6 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (fact_366edf150095_1876 a b jx jy))
    (h10 : (fact_366edf150095_711 a b))
    (h11 : (a > b))
    (h12 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h14 : (a = (b + (2 : Int))))
    (h15 : (a ≥ (5 : Int)))
    (h16 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h17 : (a ≥ b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o4 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_366edf150095_1877 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_366edf150095_711 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (fact_366edf150095_1860 a b jx jy))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h14 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h15 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h16 : (a > b))
    (h17 : (a ≥ b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o6 (a b jx jy : Int)
    (h0 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1844 a b jx jy))
    (h2 : (fact_366edf150095_711 a b))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a > b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n426_o7 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_711 a b))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_366edf150095_1841 a b jx jy))
    (h6 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (fact_366edf150095_2955 a b jy))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3516 a b) ∨ (fact_366edf150095_3496 a b) ∨ (fact_366edf150095_5828 a b) ∨ (fact_366edf150095_5829 a b) ∨ (fact_366edf150095_3497 a b) ∨ (fact_366edf150095_4109 a b) ∨ (fact_366edf150095_4112 a b) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3499 a b) ∨ (fact_366edf150095_4115 a b) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_4116 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_right (a b : Int)
    (h0 : (¬ (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - a)) ∧ ((8 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_711 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_tall (a b : Int)
    (h0 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_366edf150095_711 a b))
    (h4 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7698 a b) ∨ (fact_366edf150095_7729 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7698 a b) ∧ (fact_366edf150095_7729 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7698 a b) ∧ (fact_366edf150095_7729 a b) ∧ (((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_4832 a b) ∨ (fact_366edf150095_4023 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5076 a b)) ∨ ((fact_366edf150095_5193 a b) ∨ (fact_366edf150095_4487 a b) ∨ (fact_366edf150095_6412 a b) ∨ (fact_366edf150095_6500 a b) ∨ (fact_366edf150095_4571 a b) ∨ (fact_366edf150095_5321 a b) ∨ (fact_366edf150095_5478 a b) ∨ (fact_366edf150095_5565 a b) ∨ (fact_366edf150095_4921 a b) ∨ (fact_366edf150095_5022 a b) ∨ (fact_366edf150095_5734 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5764 a b)))) ∨ ((fact_366edf150095_7698 a b) ∧ (fact_366edf150095_7729 a b) ∧ ((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_4832 a b) ∨ (fact_366edf150095_4023 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5076 a b)) ∧ ((fact_366edf150095_5193 a b) ∨ (fact_366edf150095_4487 a b) ∨ (fact_366edf150095_6412 a b) ∨ (fact_366edf150095_6500 a b) ∨ (fact_366edf150095_4571 a b) ∨ (fact_366edf150095_5321 a b) ∨ (fact_366edf150095_5478 a b) ∨ (fact_366edf150095_5565 a b) ∨ (fact_366edf150095_4921 a b) ∨ (fact_366edf150095_5022 a b) ∨ (fact_366edf150095_5734 a b) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_5764 a b))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h7 : (a > b))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ (fact_366edf150095_3059 a b run_x) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2359 a b run_x) ∨ (fact_366edf150095_3060 a b run_x) ∨ ((((8 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_3061 a b run_x)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n427_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (fact_366edf150095_3562 a b run_x) ∨ (((((3 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3337 a b run_x) ∨ (fact_366edf150095_3607 a b run_x) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + a)))) ∨ (fact_366edf150095_3615 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((3 : Int) + a) - (6 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3919 a b) ∨ (((((3 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3710 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_4123 a b) ∨ (fact_366edf150095_3718 a b) ∨ (fact_366edf150095_5869 a b) ∨ (fact_366edf150095_5952 a b) ∨ (fact_366edf150095_3799 a b) ∨ (fact_366edf150095_4232 a b) ∨ (((((2 : Int) - a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + b)) ∧ ((5 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_366edf150095_7466 a b) ∨ (fact_366edf150095_7532 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_366edf150095_7466 a b) ∧ (fact_366edf150095_7532 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7466 a b) ∧ (fact_366edf150095_7532 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_4814 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5134 a b) ∨ (fact_366edf150095_4428 a b) ∨ (fact_366edf150095_6353 a b) ∨ (fact_366edf150095_6441 a b) ∨ (fact_366edf150095_4512 a b) ∨ (fact_366edf150095_5262 a b) ∨ (fact_366edf150095_5443 a b) ∨ (fact_366edf150095_5525 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5407 a b)))) ∨ ((fact_366edf150095_7466 a b) ∧ (fact_366edf150095_7532 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_4814 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5134 a b) ∨ (fact_366edf150095_4428 a b) ∨ (fact_366edf150095_6353 a b) ∨ (fact_366edf150095_6441 a b) ∨ (fact_366edf150095_4512 a b) ∨ (fact_366edf150095_5262 a b) ∨ (fact_366edf150095_5443 a b) ∨ (fact_366edf150095_5525 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5407 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((3 : Int) + a)))
    (h3 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2998 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n428_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + a)))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3577 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ (((3 : Int) + b) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ (((3 : Int) + b) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_empty (a b : Int)
    (h0 : (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - a)) ∧ ((4 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - b)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((4 : Int) ≥ ((6 : Int) - b)) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + b)))))
    (h2 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h10 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o1 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h2 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h6 : (((jx + (0 : Int)) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o4 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h5 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + b)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + a)))))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h7 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n429_o7 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_point (a b : Int)
    (h0 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_7 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_empty (a b : Int)
    (h0 : ((fact_366edf150095_3229 a b) ∨ (fact_366edf150095_3135 a b) ∨ (fact_366edf150095_4225 a b) ∨ (fact_366edf150095_4314 a b) ∨ (fact_366edf150095_3143 a b) ∨ (fact_366edf150095_3360 a b) ∨ (fact_366edf150095_3394 a b) ∨ (fact_366edf150095_3406 a b) ∨ (fact_366edf150095_3156 a b) ∨ (fact_366edf150095_3159 a b) ∨ ((((((6 : Int) + a) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1840 a b jx jy))
    (h1 : (((jx + a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o1 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1845 a b jx jy))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_366edf150095_1861 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_366edf150095_1876 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h10 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h11 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (a = (b + (2 : Int))))
    (h13 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (a ≥ b))
    (h16 : (b ≥ (3 : Int)))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1877 a b jx jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o5 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1860 a b jx jy))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o6 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1844 a b jx jy))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n430_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1841 a b jx jy))
    (h1 : (fact_366edf150095_2955 a b jy))
    (h2 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_7 a b))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_3229 a b) ∨ (fact_366edf150095_3135 a b) ∨ (fact_366edf150095_4225 a b) ∨ (fact_366edf150095_4314 a b) ∨ (fact_366edf150095_3143 a b) ∨ (fact_366edf150095_3360 a b) ∨ (fact_366edf150095_3394 a b) ∨ (fact_366edf150095_3406 a b) ∨ (fact_366edf150095_3156 a b) ∨ (fact_366edf150095_3159 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o0 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1840 a b jx jy))
    (h3 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_1845 a b jx jy))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1861 a b jx jy))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_1876 a b jx jy))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1877 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h4 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (fact_366edf150095_1860 a b jx jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o6 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1844 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n431_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2955 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (fact_366edf150095_1841 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3514 a b) ∨ (fact_366edf150095_3489 a b) ∨ (fact_366edf150095_5822 a b) ∨ (fact_366edf150095_5825 a b) ∨ (fact_366edf150095_3492 a b) ∨ (fact_366edf150095_4098 a b) ∨ (fact_366edf150095_4104 a b) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4107 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - a)) ∧ ((7 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7472 a b) ∨ (fact_366edf150095_7538 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7472 a b) ∧ (fact_366edf150095_7538 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7472 a b) ∧ (fact_366edf150095_7538 a b) ∧ (((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (fact_366edf150095_4666 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4041 a b) ∨ (fact_366edf150095_5046 a b)) ∨ ((fact_366edf150095_5186 a b) ∨ (fact_366edf150095_4480 a b) ∨ (fact_366edf150095_6405 a b) ∨ (fact_366edf150095_6493 a b) ∨ (fact_366edf150095_4564 a b) ∨ (fact_366edf150095_5314 a b) ∨ (((((2 : Int) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5727 a b)))) ∨ ((fact_366edf150095_7472 a b) ∧ (fact_366edf150095_7538 a b) ∧ ((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (fact_366edf150095_4666 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4041 a b) ∨ (fact_366edf150095_5046 a b)) ∧ ((fact_366edf150095_5186 a b) ∨ (fact_366edf150095_4480 a b) ∨ (fact_366edf150095_6405 a b) ∨ (fact_366edf150095_6493 a b) ∨ (fact_366edf150095_4564 a b) ∨ (fact_366edf150095_5314 a b) ∨ (((((2 : Int) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5727 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ (fact_366edf150095_3053 a b run_x) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3056 a b run_x)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n432_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (fact_366edf150095_3561 a b run_x) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3605 a b run_x))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3511 a b) ∨ (fact_366edf150095_3481 a b) ∨ (fact_366edf150095_5816 a b) ∨ (fact_366edf150095_5818 a b) ∨ (fact_366edf150095_3483 a b) ∨ (fact_366edf150095_4083 a b) ∨ (fact_366edf150095_4093 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4094 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3236 a b) ∨ (fact_366edf150095_3195 a b) ∨ (fact_366edf150095_5102 a b) ∨ (fact_366edf150095_5104 a b) ∨ (fact_366edf150095_3196 a b) ∨ (fact_366edf150095_3432 a b) ∨ (fact_366edf150095_3433 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3434 a b))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7389 a b) ∨ (fact_366edf150095_7350 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7389 a b) ∧ (fact_366edf150095_7350 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7389 a b) ∧ (fact_366edf150095_7350 a b) ∧ (((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4994 a b)) ∨ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3688 a b)))) ∨ ((fact_366edf150095_7389 a b) ∧ (fact_366edf150095_7350 a b) ∧ ((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4994 a b)) ∧ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3688 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_3046 a b run_x) ∨ (fact_366edf150095_3047 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3050 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ a))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n433_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3560 a b run_x) ∨ (fact_366edf150095_3572 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3595 a b run_x))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - a)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (¬ ((((5 : Int) = jx) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o1 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o3 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ (((jx = ((5 : Int) + b)) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o4 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o5 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((5 : Int) + a)) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n434_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((5 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_point (a b : Int)
    (h0 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_empty (a b : Int)
    (h0 : ((fact_366edf150095_2907 a b) ∨ (fact_366edf150095_2587 a b) ∨ (fact_366edf150095_4080 a b) ∨ (fact_366edf150095_4085 a b) ∨ (fact_366edf150095_2590 a b) ∨ (fact_366edf150095_3192 a b) ∨ (fact_366edf150095_3197 a b) ∨ (fact_366edf150095_3200 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o0 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (¬ ((((6 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o2 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (fact_366edf150095_2954 a b jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (¬ (((jx = ((6 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o4 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h4 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o5 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((6 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n435_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((((6 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_366edf150095_2955 a b jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ (5 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_short (a b : Int)
    (h0 : (¬ (((5 : Int) - (5 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-1 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((((5 : Int) ≥ ((5 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7724 a b) ∨ (fact_366edf150095_7723 a b))) ∨ (((5 : Int) ≥ ((5 : Int) + (2 : Int))) ∧ (fact_366edf150095_7724 a b) ∧ (fact_366edf150095_7723 a b)) ∨ ((5 : Int) ≥ ((5 : Int) + (4 : Int))) ∨ (((5 : Int) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7724 a b) ∧ (fact_366edf150095_7723 a b) ∧ (((fact_366edf150095_6589 a b) ∨ (fact_366edf150095_6231 a b) ∨ (fact_366edf150095_7086 a b) ∨ (fact_366edf150095_7120 a b) ∨ (fact_366edf150095_6261 a b) ∨ (fact_366edf150095_6775 a b) ∨ (fact_366edf150095_6806 a b) ∨ (fact_366edf150095_6831 a b) ∨ (fact_366edf150095_6843 a b) ∨ (fact_366edf150095_6325 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))))) ∨ ((fact_366edf150095_6584 a b) ∨ (fact_366edf150095_6226 a b) ∨ (fact_366edf150095_7081 a b) ∨ (fact_366edf150095_7115 a b) ∨ (fact_366edf150095_6256 a b) ∨ (fact_366edf150095_6770 a b) ∨ (fact_366edf150095_6804 a b) ∨ (fact_366edf150095_6827 a b) ∨ (fact_366edf150095_6838 a b) ∨ (fact_366edf150095_6320 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))))))) ∨ ((fact_366edf150095_7724 a b) ∧ (fact_366edf150095_7723 a b) ∧ ((fact_366edf150095_6589 a b) ∨ (fact_366edf150095_6231 a b) ∨ (fact_366edf150095_7086 a b) ∨ (fact_366edf150095_7120 a b) ∨ (fact_366edf150095_6261 a b) ∨ (fact_366edf150095_6775 a b) ∨ (fact_366edf150095_6806 a b) ∨ (fact_366edf150095_6831 a b) ∨ (fact_366edf150095_6843 a b) ∨ (fact_366edf150095_6325 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))))) ∧ ((fact_366edf150095_6584 a b) ∨ (fact_366edf150095_6226 a b) ∨ (fact_366edf150095_7081 a b) ∨ (fact_366edf150095_7115 a b) ∨ (fact_366edf150095_6256 a b) ∨ (fact_366edf150095_6770 a b) ∨ (fact_366edf150095_6804 a b) ∨ (fact_366edf150095_6827 a b) ∨ (fact_366edf150095_6838 a b) ∨ (fact_366edf150095_6320 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b)))))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_4214 a b run_x) ∨ (fact_366edf150095_4199 a b run_x) ∨ (fact_366edf150095_6128 a b run_x) ∨ (fact_366edf150095_6134 a b run_x) ∨ (fact_366edf150095_4202 a b run_x) ∨ (fact_366edf150095_5115 a b run_x) ∨ (fact_366edf150095_5203 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))))))
    (h1 : ((5 : Int) ≥ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((5 : Int) ≤ run_x))
    (h7 : (a > b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n436_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_5848 a b run_x) ∨ (fact_366edf150095_5833 a b run_x) ∨ (fact_366edf150095_6956 a b run_x) ∨ (fact_366edf150095_6959 a b run_x) ∨ (fact_366edf150095_5836 a b run_x) ∨ (fact_366edf150095_6131 a b run_x) ∨ (fact_366edf150095_6161 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_669 a run_x)) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : ((5 : Int) ≥ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3505 a b) ∨ (fact_366edf150095_3454 a b) ∨ (fact_366edf150095_5781 a b) ∨ (fact_366edf150095_5789 a b) ∨ (fact_366edf150095_3462 a b) ∨ (fact_366edf150095_3700 a b) ∨ (fact_366edf150095_3918 a b) ∨ (fact_366edf150095_3972 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3709 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4129 a b) ∨ (fact_366edf150095_3724 a b) ∨ (fact_366edf150095_5875 a b) ∨ (fact_366edf150095_5958 a b) ∨ (fact_366edf150095_3805 a b) ∨ (fact_366edf150095_4238 a b) ∨ (fact_366edf150095_4635 a b) ∨ (((((3 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4394 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7481 a b) ∨ (fact_366edf150095_7554 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7481 a b) ∧ (fact_366edf150095_7554 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7481 a b) ∧ (fact_366edf150095_7554 a b) ∧ (((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_4812 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4396 a b)) ∨ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_5544 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_5410 a b)))) ∨ ((fact_366edf150095_7481 a b) ∧ (fact_366edf150095_7554 a b) ∧ ((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_4812 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4396 a b)) ∧ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_5544 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_5410 a b))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2996 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2975 a b run_x)))
    (h3 : ((6 : Int) ≤ run_x))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (run_x ≤ ((5 : Int) + b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n437_run_floor (a b run_x : Int)
    (h0 : ((6 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3576 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3555 a b run_x))))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((6 : Int) + a) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ (((6 : Int) + a) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_empty (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) + (0 : Int)) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < ((2 : Int) - a)) ∨ (((2 : Int) + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < ((2 : Int) + b))))
    (h4 : ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ ((((((6 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((6 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((1 : Int) + ((2 : Int) * a)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o0 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o2 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((jx - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : ((((jx - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : ((jx < ((6 : Int) + a)) ∨ (((6 : Int) + a) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (a = (b + (2 : Int))))
    (h14 : (a ≥ b))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((jx - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o5 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jx < ((6 : Int) + a)) ∨ (((6 : Int) + a) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h12 : ((((jx - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h13 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n438_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ (5 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_short (a b : Int)
    (h0 : (¬ (((5 : Int) - (5 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-1 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((5 : Int) ≥ ((5 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7731 a b) ∨ (fact_366edf150095_7730 a b))) ∨ (((5 : Int) ≥ ((5 : Int) + (2 : Int))) ∧ (fact_366edf150095_7731 a b) ∧ (fact_366edf150095_7730 a b)) ∨ ((5 : Int) ≥ ((5 : Int) + (4 : Int))) ∨ (((5 : Int) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7731 a b) ∧ (fact_366edf150095_7730 a b) ∧ (((fact_366edf150095_6589 a b) ∨ (fact_366edf150095_6231 a b) ∨ (fact_366edf150095_7086 a b) ∨ (fact_366edf150095_7120 a b) ∨ (fact_366edf150095_6261 a b) ∨ (fact_366edf150095_6775 a b) ∨ (fact_366edf150095_6806 a b) ∨ (fact_366edf150095_6831 a b) ∨ (fact_366edf150095_6843 a b) ∨ (fact_366edf150095_6325 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6584 a b) ∨ (fact_366edf150095_6226 a b) ∨ (fact_366edf150095_7081 a b) ∨ (fact_366edf150095_7115 a b) ∨ (fact_366edf150095_6256 a b) ∨ (fact_366edf150095_6770 a b) ∨ (fact_366edf150095_6804 a b) ∨ (fact_366edf150095_6827 a b) ∨ (fact_366edf150095_6838 a b) ∨ (fact_366edf150095_6320 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7731 a b) ∧ (fact_366edf150095_7730 a b) ∧ ((fact_366edf150095_6589 a b) ∨ (fact_366edf150095_6231 a b) ∨ (fact_366edf150095_7086 a b) ∨ (fact_366edf150095_7120 a b) ∨ (fact_366edf150095_6261 a b) ∨ (fact_366edf150095_6775 a b) ∨ (fact_366edf150095_6806 a b) ∨ (fact_366edf150095_6831 a b) ∨ (fact_366edf150095_6843 a b) ∨ (fact_366edf150095_6325 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6584 a b) ∨ (fact_366edf150095_6226 a b) ∨ (fact_366edf150095_7081 a b) ∨ (fact_366edf150095_7115 a b) ∨ (fact_366edf150095_6256 a b) ∨ (fact_366edf150095_6770 a b) ∨ (fact_366edf150095_6804 a b) ∨ (fact_366edf150095_6827 a b) ∨ (fact_366edf150095_6838 a b) ∨ (fact_366edf150095_6320 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + b) + (0 : Int))))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_4214 a b run_x) ∨ (fact_366edf150095_4199 a b run_x) ∨ (fact_366edf150095_6128 a b run_x) ∨ (fact_366edf150095_6134 a b run_x) ∨ (fact_366edf150095_4202 a b run_x) ∨ (fact_366edf150095_5115 a b run_x) ∨ (fact_366edf150095_5203 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : ((5 : Int) ≥ run_x))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n439_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : ((5 : Int) ≥ run_x))
    (h3 : (¬ ((fact_366edf150095_5848 a b run_x) ∨ (fact_366edf150095_5833 a b run_x) ∨ (fact_366edf150095_6956 a b run_x) ∨ (fact_366edf150095_6959 a b run_x) ∨ (fact_366edf150095_5836 a b run_x) ∨ (fact_366edf150095_6131 a b run_x) ∨ (fact_366edf150095_6161 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_669 a run_x)) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_four (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((6 : Int) + b) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((6 : Int) + b)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((((6 : Int) + b) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7456 a b) ∨ (fact_366edf150095_7627 a b))) ∨ (((((6 : Int) + b) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7456 a b) ∧ (fact_366edf150095_7627 a b)) ∨ ((((6 : Int) + b) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((6 : Int) + b) + (1 : Int))) ∧ (fact_366edf150095_7456 a b) ∧ (fact_366edf150095_7627 a b) ∧ (((((((-1 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))))))) ∨ ((fact_366edf150095_7456 a b) ∧ (fact_366edf150095_7627 a b) ∧ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((6 : Int) + b) - (1 : Int))) ∧ ((((6 : Int) + b) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)))))))))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h2
  clear h2
  by_cases split0 : ((((6 : Int) + b) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a)))
  · left
    refine ⟨?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · left
      right
      right
      right
      right
      right
      right
      right
      right
      right
      right
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · by_cases split1 : ((((6 : Int) + b) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a)))
    · right
      left
      refine ⟨?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · right
      right
      right
      left
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · left
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a))))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((6 : Int) + b) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n440_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (((6 : Int) + b) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2904 a b) ∨ (fact_366edf150095_2576 a b) ∨ (fact_366edf150095_4065 a b) ∨ (fact_366edf150095_4070 a b) ∨ (fact_366edf150095_2579 a b) ∨ (fact_366edf150095_3179 a b) ∨ (fact_366edf150095_3185 a b) ∨ (fact_366edf150095_3187 a b) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_366edf150095_2954 a b jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o3 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (¬ (((jx = ((5 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h7 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n441_o7 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ ((((5 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3917 a b) ∨ (fact_366edf150095_3970 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3707 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4125 a b) ∨ (fact_366edf150095_3720 a b) ∨ (fact_366edf150095_5871 a b) ∨ (fact_366edf150095_5954 a b) ∨ (fact_366edf150095_3801 a b) ∨ (fact_366edf150095_4234 a b) ∨ (fact_366edf150095_4633 a b) ∨ (fact_366edf150095_4775 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4386 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7493 a b) ∨ (fact_366edf150095_7568 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7493 a b) ∧ (fact_366edf150095_7568 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7493 a b) ∧ (fact_366edf150095_7568 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4789 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4388 a b)) ∨ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (fact_366edf150095_5447 a b) ∨ (fact_366edf150095_5533 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_5399 a b)))) ∨ ((fact_366edf150095_7493 a b) ∧ (fact_366edf150095_7568 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4789 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4388 a b)) ∧ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (fact_366edf150095_5447 a b) ∨ (fact_366edf150095_5533 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_5399 a b))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((4 : Int) + b)))
    (h6 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2996 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2972 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n442_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3576 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3552 a b run_x))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3511 a b) ∨ (fact_366edf150095_3481 a b) ∨ (fact_366edf150095_5816 a b) ∨ (fact_366edf150095_5818 a b) ∨ (fact_366edf150095_3483 a b) ∨ (fact_366edf150095_4083 a b) ∨ (fact_366edf150095_4093 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4094 a b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_3236 a b) ∨ (fact_366edf150095_3195 a b) ∨ (fact_366edf150095_5102 a b) ∨ (fact_366edf150095_5104 a b) ∨ (fact_366edf150095_3196 a b) ∨ (fact_366edf150095_3432 a b) ∨ (fact_366edf150095_3433 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3434 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : ((((2 : Int) * a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7494 a b) ∨ (fact_366edf150095_7417 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7494 a b) ∧ (fact_366edf150095_7417 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7494 a b) ∧ (fact_366edf150095_7417 a b) ∧ (((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4994 a b)) ∨ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3688 a b)))) ∨ ((fact_366edf150095_7494 a b) ∧ (fact_366edf150095_7417 a b) ∧ ((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4994 a b)) ∧ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3688 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_empty (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ a))
    (h2 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_3046 a b run_x) ∨ (fact_366edf150095_3047 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3050 a b run_x)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n443_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3560 a b run_x) ∨ (fact_366edf150095_3572 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((5 : Int) + a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3595 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((6 : Int) ≥ ((-1 : Int) - a)) ∧ ((6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((6 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((6 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) * a)) ∧ ((6 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((6 : Int) ≥ ((2 : Int) - a)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_right (a b : Int)
    (h0 : (¬ (((((6 : Int) ≥ ((-1 : Int) - a)) ∧ ((6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((6 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((6 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) * a)) ∧ ((6 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((6 : Int) ≥ ((2 : Int) - a)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_366edf150095_7416 a b) ∨ (fact_366edf150095_7457 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_366edf150095_7416 a b) ∧ (fact_366edf150095_7457 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_366edf150095_7416 a b) ∧ (fact_366edf150095_7457 a b) ∧ (((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∨ ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7416 a b) ∧ (fact_366edf150095_7457 a b) ∧ ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_empty (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_3046 a b run_x) ∨ (fact_366edf150095_3047 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n444_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3560 a b run_x) ∨ (fact_366edf150095_3572 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_left (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ ((((((4 : Int) + b) - b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ ((((((4 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_tall (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a > b))
    (h3 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7685 a b) ∨ (fact_366edf150095_7523 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7685 a b) ∧ (fact_366edf150095_7523 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7685 a b) ∧ (fact_366edf150095_7523 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_7142 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6664 a b)))) ∨ ((fact_366edf150095_7685 a b) ∧ (fact_366edf150095_7523 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_7142 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6664 a b))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  left
  refine ⟨?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n445_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_empty (a b : Int)
    (h0 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3177 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - b)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o3 (a b jx jy : Int)
    (h0 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o4 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o5 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o6 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n446_o7 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (fact_366edf150095_2955 a b jy))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_empty (a b : Int)
    (h0 : ((fact_366edf150095_2904 a b) ∨ (fact_366edf150095_2576 a b) ∨ (fact_366edf150095_4065 a b) ∨ (fact_366edf150095_4070 a b) ∨ (fact_366edf150095_2579 a b) ∨ (fact_366edf150095_3179 a b) ∨ (fact_366edf150095_3185 a b) ∨ (fact_366edf150095_3187 a b) ∨ ((((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3189 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((jx + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o3 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h2 : (¬ (((jx = ((5 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o4 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n447_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((5 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n448_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n448_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

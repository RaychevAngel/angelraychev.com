import FiniteRectangle

namespace PolyominoFormal
namespace FiniteEightStrip
open CrossUnits FiniteRectangle

def offsets : List Int := [-1,0,1]
def nearby (ts : List Cross) : List Cross :=
  ts.flatMap fun t => offsets.map fun d => shift (8*d) 0 t

def separationCheck (ts : List Cross) : Bool :=
  ts.all fun t => ts.all fun u => offsets.all fun d =>
    decide (Same t (shift (8*d) 0 u) ∨ Apart t (shift (8*d) 0 u))

def tilingOfChecks (ts : List Cross)
    (copies : copiesCheck ts 4 3 0 0=true)
    (inside : insideCheck ts 16 8=true)
    (cover : coverCheck (nearby ts) 8 8=true)
    (separate : separationCheck ts=true) : Tiling 4 3 0 0 (Strip 8) where
  world t := ∃ k u, u∈ts ∧ shift (8*k) 0 u=t
  copies := by
    rintro t ⟨k,u,hu,rfl⟩
    exact (copy_shift _ _ _ _ _ _ _).2
      (of_decide_eq_true ((List.all_eq_true.1 copies) u hu))
  inside := by
    rintro t ⟨k,u,hu,rfl⟩ x y hit
    have bound : InsideBounds 16 8 u := of_decide_eq_true ((List.all_eq_true.1 inside) u hu)
    have hit' := (contains_shift _ _ _ _ _).1 hit
    have rect := inside_of_bounds bound _ _ hit'
    unfold Rectangle at rect
    unfold Strip
    omega
  cover := by
    intro x y hy
    have hx0 := Int.emod_nonneg x (by omega : (8:Int)≠0)
    have hx8 := Int.emod_lt_of_pos x (by omega : (0:Int)<8)
    have hx : (x%8).toNat∈List.range 8 := List.mem_range.2 (by omega)
    have hy' : y.toNat∈List.range 8 := List.mem_range.2 (by unfold Strip at hy; omega)
    have found := (List.all_eq_true.1 ((List.all_eq_true.1 cover) (x%8).toNat hx)) y.toNat hy'
    obtain ⟨v,hv,hit⟩ := List.any_eq_true.1 found
    obtain ⟨u,hu,hv⟩ := List.mem_flatMap.1 hv
    obtain ⟨d,hd,eq⟩ := List.mem_map.1 hv
    have hcx : ((x%8).toNat : Int)=x%8 := by omega
    have hcy : (y.toNat : Int)=y := by unfold Strip at hy; omega
    have hit' : Contains (shift (8*d) 0 u) (x%8) y := by
      simpa only [hcx,hcy,eq] using (of_decide_eq_true hit)
    have hc := (contains_shift _ _ _ _ _).1 hit'
    refine ⟨shift (8*(x/8+d)) 0 u,⟨x/8+d,u,hu,rfl⟩,?_⟩
    rw [contains_shift]
    have remainder := Int.emod_add_ediv_mul x 8
    have identity : x-8*(x/8+d)=x%8-8*d := by omega
    simpa only [identity] using hc
  disjoint := by
    rintro t u x y ⟨k,v,hv,rfl⟩ ⟨l,w,hw,rfl⟩ hi hj
    have vi := (contains_shift _ _ _ _ _).1 hi
    have wj := (contains_shift _ _ _ _ _).1 hj
    have bv : InsideBounds 16 8 v := of_decide_eq_true ((List.all_eq_true.1 inside) v hv)
    have bw : InsideBounds 16 8 w := of_decide_eq_true ((List.all_eq_true.1 inside) w hw)
    have rv := inside_of_bounds bv _ _ vi
    have rw' := inside_of_bounds bw _ _ wj
    have delta : l-k∈offsets := by
      unfold Rectangle at rv rw'
      simp only [offsets,List.mem_cons,List.mem_singleton]
      omega
    have pair := (List.all_eq_true.1 ((List.all_eq_true.1
      ((List.all_eq_true.1 separate) v hv)) w hw)) (l-k) delta
    have wHit : Contains (shift (8*(l-k)) 0 w) (x-8*k) (y-0) := by
      rw [contains_shift]
      have hx : x-8*k-8*(l-k)=x-8*l := by omega
      simpa only [hx,Int.sub_zero] using wj
    rcases of_decide_eq_true pair with eq | apart
    · have eq' := same_eq eq
      rw [eq',shift_add]
      have dx : 8*(l-k)+8*k=8*l := by omega
      rw [dx]
      rfl
    · exact False.elim (apart_no_common apart _ _ vi wHit)

end FiniteEightStrip
end PolyominoFormal

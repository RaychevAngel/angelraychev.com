import RectangleRep
import TilingSymmetry

namespace PolyominoFormal
open CrossUnits CoreBoundaryObstructions

/-- Reflections of enlarged cell blocks include the k-1 alignment shift. -/
def Tiling.reflectScaledX {a b c d e n w s k : Int}
    (T : Tiling a b c d (ScaledCross e n w s k)) :
    Tiling a b c d (ScaledCross w n e s k) :=
  (T.mirrorX.translate (k-1) 0).congr (by
    intro x y
    simp only [ScaledCross,Int.add_mul,Int.neg_mul,Int.one_mul]
    omega)

def Tiling.reflectScaledY {a b c d e n w s k : Int}
    (T : Tiling a b c d (ScaledCross e n w s k)) :
    Tiling a b c d (ScaledCross e s w n k) :=
  (T.mirrorY.translate 0 (k-1)).congr (by
    intro x y
    simp only [ScaledCross,Int.add_mul,Int.neg_mul,Int.one_mul]
    omega)

def Tiling.transposeScaled {a b c d e n w s k : Int}
    (T : Tiling a b c d (ScaledCross e n w s k)) :
    Tiling a b c d (ScaledCross n e s w k) :=
  T.transpose.congr (by intro x y; unfold ScaledCross; omega)

theorem scaled_copy_tileable {a b c d k : Int}
    (T : Tiling a b c d (ScaledCross a b c d k))
    (t : Cross) (ht : Copy a b c d t) :
    Tiles a b c d (ScaledCross t.east t.north t.west t.south k) := by
  rcases ht with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals rw [he,hn,hw,hs]
  · exact ⟨T⟩
  · exact ⟨T.transposeScaled.reflectScaledY⟩
  · exact ⟨T.reflectScaledX.reflectScaledY⟩
  · exact ⟨T.transposeScaled.reflectScaledX⟩
  · exact ⟨T.transposeScaled.reflectScaledX.reflectScaledY⟩
  · exact ⟨T.reflectScaledX⟩
  · exact ⟨T.transposeScaled⟩
  · exact ⟨T.reflectScaledY⟩

theorem shifted_scaled_cross (t : Cross) (k : Int) (hk : 0<k) (x y : Int) :
    ScaledCross t.east t.north t.west t.south k (x-t.x*k) (y-t.y*k) ↔
      Dilate (Contains t) k x y := by
  unfold Dilate Contains ScaledCross
  rw [Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk]
  simp only [Int.sub_mul,Int.add_mul,Int.neg_mul,Int.one_mul]
  omega

theorem dilated_copy_tileable {a b c d k : Int} (hk : 0<k)
    (T : Tiling a b c d (ScaledCross a b c d k))
    (t : Cross) (ht : Copy a b c d t) : Tiles a b c d (Dilate (Contains t) k) := by
  obtain ⟨U⟩ := scaled_copy_tileable T t ht
  exact ⟨(U.translate (t.x*k) (t.y*k)).congr (shifted_scaled_cross t k hk)⟩

/-- Replace each enlarged tile by an actual congruent-copy dissection. -/
noncomputable def Tiling.substitute {a b c d k : Int} {R : Region}
    (hk : 0<k) (T : Tiling a b c d R)
    (D : Tiling a b c d (ScaledCross a b c d k)) :
    Tiling a b c d (Dilate R k) := by
  classical
  let pieces (u : Cross) (hu : T.world u) : Tiling a b c d (Dilate (Contains u) k) :=
    Classical.choice (dilated_copy_tileable hk D u (T.copies u hu))
  exact {
    world := fun t => ∃ u, ∃ hu : T.world u, (pieces u hu).world t
    copies := by
      rintro t ⟨u,hu,ht⟩
      exact (pieces u hu).copies t ht
    inside := by
      rintro t ⟨u,hu,ht⟩ x y hit
      exact T.inside u hu _ _ ((pieces u hu).inside t ht x y hit)
    cover := by
      intro x y hit
      obtain ⟨u,hu,contains⟩ := T.cover (x/k) (y/k) hit
      obtain ⟨t,ht,hc⟩ := (pieces u hu).cover x y contains
      exact ⟨t,⟨u,hu,ht⟩,hc⟩
    disjoint := by
      rintro t v x y ⟨u,hu,ht⟩ ⟨u',hu',hv⟩ hit hit'
      have h1 := (pieces u hu).inside t ht x y hit
      have h2 := (pieces u' hu').inside v hv x y hit'
      have eq := T.disjoint u u' (x/k) (y/k) hu hu' h1 h2
      subst u'
      exact (pieces u hu).disjoint t v x y ht hv hit hit' }

theorem dilate_twice (R : Region) (k l : Int) (hk : 0<k) (hl : 0<l) (x y : Int) :
    Dilate (Dilate R k) l x y ↔ Dilate R (k*l) x y := by
  unfold Dilate
  rw [Int.ediv_ediv_of_nonneg (by omega : 0≤l),
    Int.ediv_ediv_of_nonneg (by omega : 0≤l),Int.mul_comm l k]

/-- A single rep dissection yields enlarged copies at arbitrarily large scales. -/
theorem rep_arbitrarily_large {a b c d : Int} (rep : RepTileable a b c d) :
    ∀ N : Nat, ∃ K : Int, (N : Int)≤K ∧ 2≤K ∧ Tiles a b c d (ScaledCross a b c d K) := by
  obtain ⟨k,hk,⟨D⟩⟩ := rep
  have kpos : 0<(k : Int) := by omega
  intro N
  induction N with
  | zero => exact ⟨k,by omega,by omega,⟨D⟩⟩
  | succ N ih =>
    obtain ⟨K,hN,hK,⟨T⟩⟩ := ih
    have kp : 0<K := by omega
    let U := T.substitute kpos D
    have bigger := Int.mul_le_mul_of_nonneg_left (show (2 : Int)≤k by omega) (show 0≤K by omega)
    refine ⟨K*k,?_,?_,?_⟩
    · omega
    · omega
    · refine ⟨U.congr ?_⟩
      intro x y
      change ScaledCross a b c d K (x/k) (y/k) ↔ _
      rw [←dilation_is_scaled_cross a b c d K kp]
      change Dilate (Dilate (Contains ⟨0,0,a,b,c,d⟩) K) k x y ↔ _
      exact (dilate_twice (Contains ⟨0,0,a,b,c,d⟩) K k kp kpos x y).trans
        (dilation_is_scaled_cross a b c d (K*k) (Int.mul_pos kp kpos) x y)

#print axioms rep_arbitrarily_large
end PolyominoFormal

import TilingCore

set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

namespace PositiveConstructions
open CrossUnits
open PolyominoFormal

/-- The two motifs in the width-two strip; the index ranges over all integers. -/
def upTile (a c k : Int) : Cross :=
  ⟨k*(a+c+2)+c, 0, a, 1, c, 0⟩
def downTile (a c k : Int) : Cross :=
  ⟨k*(a+c+2)+a+c+1, 1, c, 0, a, 1⟩

def StripWorld (a c : Int) (t : Cross) : Prop :=
  ∃ k : Int, t=upTile a c k ∨ t=downTile a c k

def JaggedWorld (a : Int) (t : Cross) : Prop :=
  ∃ k : Int, 0≤k ∧ (t=upTile a 1 k ∨ t=downTile a 1 k)

def Jagged (x y : Int) : Prop :=
  (y=0 ∧ 0≤x) ∨ (y=1 ∧ 1≤x)

/-- Coordinate swap followed by translation through (0,1). -/
def swapUp (t : Cross) : Cross :=
  ⟨t.y, t.x+1, t.north, t.east, t.south, t.west⟩

def BentWorld (a : Int) (t : Cross) : Prop :=
  JaggedWorld a t ∨ ∃ u, JaggedWorld a u ∧ t=swapUp u

def BentTwo (x y : Int) : Prop :=
  0≤x ∧ 0≤y ∧ (x<2 ∨ y<2)

theorem up_contains (a c k x y : Int) (ha : 1≤a) (hc : 1≤c) :
    Contains (upTile a c k) x y ↔
    (y=0 ∧ k*(a+c+2)≤x ∧ x≤k*(a+c+2)+a+c) ∨
    (y=1 ∧ x=k*(a+c+2)+c) := by
  unfold Contains upTile
  dsimp
  omega

theorem down_contains (a c k x y : Int) (ha : 1≤a) (hc : 1≤c) :
    Contains (downTile a c k) x y ↔
    (y=0 ∧ x=k*(a+c+2)+a+c+1) ∨
    (y=1 ∧ k*(a+c+2)+c+1≤x ∧ x≤k*(a+c+2)+a+2*c+1) := by
  unfold Contains downTile
  dsimp
  omega

theorem block_unique (n k l z : Int) (hn : 0<n)
    (hk0 : k*n≤z) (hk1 : z<k*n+n)
    (hl0 : l*n≤z) (hl1 : z<l*n+n) : k=l := by
  by_cases hkl : k<l
  · have hm := Int.mul_le_mul_of_nonneg_right (c:=n) (show k+1≤l by omega) (show 0≤n by omega)
    simp only [Int.add_mul, Int.one_mul] at hm
    omega
  · by_cases hlk : l<k
    · have hm := Int.mul_le_mul_of_nonneg_right (c:=n) (show l+1≤k by omega) (show 0≤n by omega)
      simp only [Int.add_mul, Int.one_mul] at hm
      omega
    · omega

theorem pair_bounds (a c k x y : Int) (ha : 1≤a) (hc : 1≤c)
    (h : Contains (upTile a c k) x y ∨ Contains (downTile a c k) x y) :
    k*(a+c+2)≤x-c*y ∧ x-c*y<k*(a+c+2)+(a+c+2) := by
  rw [up_contains a c k x y ha hc, down_contains a c k x y ha hc] at h
  rcases h with (⟨rfl,h0,h1⟩ | ⟨rfl,h0⟩) | (⟨rfl,h0⟩ | ⟨rfl,h0,h1⟩)
  all_goals simp only [Int.mul_zero, Int.mul_one, Int.sub_zero]
  all_goals omega

theorem pair_covers (a c x y : Int) (ha : 1≤a) (hc : 1≤c)
    (hy0 : 0≤y) (hy2 : y<2) :
    Contains (upTile a c ((x-c*y)/(a+c+2))) x y ∨
    Contains (downTile a c ((x-c*y)/(a+c+2))) x y := by
  have hn : 0<a+c+2 := by omega
  have hnz : a+c+2≠0 := by omega
  have hr0 := Int.emod_nonneg (x-c*y) hnz
  have hr1 := Int.emod_lt_of_pos (x-c*y) hn
  have he := Int.emod_add_ediv_mul (x-c*y) (a+c+2)
  have hlo : ((x-c*y)/(a+c+2))*(a+c+2) ≤ x-c*y := by omega
  have hhi : x-c*y ≤ ((x-c*y)/(a+c+2))*(a+c+2)+a+c+1 := by omega
  clear hr0 hr1 he
  rw [up_contains a c ((x-c*y)/(a+c+2)) x y ha hc,
      down_contains a c ((x-c*y)/(a+c+2)) x y ha hc]
  have hy : y=0 ∨ y=1 := by omega
  rcases hy with rfl | rfl
  all_goals simp only [Int.mul_zero, Int.mul_one, Int.sub_zero] at *
  all_goals simp only [Int.reduceEq, true_and, false_and, false_or, or_false]
  all_goals omega

theorem up_down_no_common (a c k x y : Int) (ha : 1≤a) (hc : 1≤c)
    (hu : Contains (upTile a c k) x y)
    (hd : Contains (downTile a c k) x y) : False := by
  rw [up_contains a c k x y ha hc] at hu
  rw [down_contains a c k x y ha hc] at hd
  omega

theorem strip_copies (a c : Int) (t : Cross) (ht : StripWorld a c t) :
    Copy a 1 c 0 t := by
  rcases ht with ⟨k, rfl | rfl⟩
  all_goals simp [Copy, Arms, upTile, downTile]

theorem strip_inside (a c : Int) (ha : 1≤a) (hc : 1≤c)
    (t : Cross) (ht : StripWorld a c t) (x y : Int) (hit : Contains t x y) :
    0≤y ∧ y<2 := by
  rcases ht with ⟨k, rfl | rfl⟩
  · rw [up_contains a c k x y ha hc] at hit; omega
  · rw [down_contains a c k x y ha hc] at hit; omega

theorem strip_cover (a c x y : Int) (ha : 1≤a) (hc : 1≤c)
    (hy : 0≤y ∧ y<2) : ∃ t, StripWorld a c t ∧ Contains t x y := by
  let k := (x-c*y)/(a+c+2)
  rcases pair_covers a c x y ha hc hy.1 hy.2 with hu | hd
  · exact ⟨upTile a c k, ⟨k, Or.inl rfl⟩, hu⟩
  · exact ⟨downTile a c k, ⟨k, Or.inr rfl⟩, hd⟩

theorem strip_disjoint (a c : Int) (ha : 1≤a) (hc : 1≤c)
    (t u : Cross) (ht : StripWorld a c t) (hu : StripWorld a c u)
    (x y : Int) (hit : Contains t x y) (hiu : Contains u x y) : t=u := by
  rcases ht with ⟨k,hkt⟩
  rcases hu with ⟨l,hlu⟩
  have ht' : Contains (upTile a c k) x y ∨ Contains (downTile a c k) x y := by
    rcases hkt with rfl | rfl
    · exact Or.inl hit
    · exact Or.inr hit
  have hu' : Contains (upTile a c l) x y ∨ Contains (downTile a c l) x y := by
    rcases hlu with rfl | rfl
    · exact Or.inl hiu
    · exact Or.inr hiu
  have hk := pair_bounds a c k x y ha hc ht'
  have hl := pair_bounds a c l x y ha hc hu'
  have hkl := block_unique (a+c+2) k l (x-c*y) (by omega) hk.1 hk.2 hl.1 hl.2
  subst l
  rcases hkt with rfl | rfl <;> rcases hlu with rfl | rfl
  · rfl
  · exact False.elim (up_down_no_common a c k x y ha hc hit hiu)
  · exact False.elim (up_down_no_common a c k x y ha hc hiu hit)
  · rfl

theorem jagged_subset_strip (a : Int) (t : Cross) (ht : JaggedWorld a t) :
    StripWorld a 1 t := by
  rcases ht with ⟨k,_,ht⟩
  exact ⟨k,ht⟩

theorem jagged_inside (a : Int) (ha : 1≤a) (t : Cross) (ht : JaggedWorld a t)
    (x y : Int) (hit : Contains t x y) : Jagged x y := by
  rcases ht with ⟨k,hk,rfl | rfl⟩
  · have hm := Int.mul_nonneg hk (show 0≤a+1+2 by omega)
    rw [up_contains a 1 k x y ha (by omega)] at hit
    unfold Jagged
    omega
  · have hm := Int.mul_nonneg hk (show 0≤a+1+2 by omega)
    rw [down_contains a 1 k x y ha (by omega)] at hit
    unfold Jagged
    omega

theorem jagged_cover (a x y : Int) (ha : 1≤a) (hxy : Jagged x y) :
    ∃ t, JaggedWorld a t ∧ Contains t x y := by
  have hz : 0≤x-1*y := by unfold Jagged at hxy; omega
  have hy : 0≤y ∧ y<2 := by unfold Jagged at hxy; omega
  let k := (x-1*y)/(a+1+2)
  have hk : 0≤k := Int.ediv_nonneg hz (by omega)
  rcases pair_covers a 1 x y ha (by omega) hy.1 hy.2 with hu | hd
  · exact ⟨upTile a 1 k, ⟨k,hk,Or.inl rfl⟩,hu⟩
  · exact ⟨downTile a 1 k, ⟨k,hk,Or.inr rfl⟩,hd⟩

theorem jagged_disjoint (a : Int) (ha : 1≤a) (t u : Cross)
    (ht : JaggedWorld a t) (hu : JaggedWorld a u)
    (x y : Int) (hit : Contains t x y) (hiu : Contains u x y) : t=u :=
  strip_disjoint a 1 ha (by omega) t u (jagged_subset_strip a t ht)
    (jagged_subset_strip a u hu) x y hit hiu

theorem swap_contains (t : Cross) (x y : Int) :
    Contains (swapUp t) x y ↔ Contains t (y-1) x := by
  unfold Contains swapUp
  dsimp
  omega

theorem swap_copy (a b c d : Int) (t : Cross) (ht : Copy a b c d t) :
    Copy a b c d (swapUp t) := by
  rcases ht with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, swapUp, he, hn, hw, hs]

theorem bent_partition (x y : Int) :
    BentTwo x y ↔ Jagged x y ∨ Jagged (y-1) x := by
  unfold BentTwo Jagged
  omega

theorem jagged_regions_disjoint (x y : Int) (h : Jagged x y)
    (ht : Jagged (y-1) x) : False := by
  unfold Jagged at *
  omega

theorem bent_copies (a : Int) (t : Cross) (ht : BentWorld a t) : Copy a 1 1 0 t := by
  rcases ht with hh | ⟨u,hu,rfl⟩
  · exact strip_copies a 1 t (jagged_subset_strip a t hh)
  · exact swap_copy a 1 1 0 u (strip_copies a 1 u (jagged_subset_strip a u hu))

theorem bent_inside (a : Int) (ha : 1≤a) (t : Cross) (ht : BentWorld a t)
    (x y : Int) (hit : Contains t x y) : BentTwo x y := by
  rw [bent_partition]
  rcases ht with hh | ⟨u,hu,rfl⟩
  · exact Or.inl (jagged_inside a ha t hh x y hit)
  · exact Or.inr (jagged_inside a ha u hu (y-1) x ((swap_contains u x y).mp hit))

theorem bent_cover (a x y : Int) (ha : 1≤a) (hxy : BentTwo x y) :
    ∃ t, BentWorld a t ∧ Contains t x y := by
  rw [bent_partition] at hxy
  rcases hxy with hh | hv
  · obtain ⟨t,ht,hit⟩ := jagged_cover a x y ha hh
    exact ⟨t,Or.inl ht,hit⟩
  · obtain ⟨t,ht,hit⟩ := jagged_cover a (y-1) x ha hv
    exact ⟨swapUp t,Or.inr ⟨t,ht,rfl⟩,(swap_contains t x y).mpr hit⟩

theorem bent_disjoint (a : Int) (ha : 1≤a) (t u : Cross)
    (ht : BentWorld a t) (hu : BentWorld a u)
    (x y : Int) (hit : Contains t x y) (hiu : Contains u x y) : t=u := by
  rcases ht with ht | ⟨s,hs,rfl⟩ <;> rcases hu with hu | ⟨v,hv,rfl⟩
  · exact jagged_disjoint a ha t u ht hu x y hit hiu
  · exact False.elim (jagged_regions_disjoint x y (jagged_inside a ha t ht x y hit)
      (jagged_inside a ha v hv (y-1) x ((swap_contains v x y).mp hiu)))
  · exact False.elim (jagged_regions_disjoint x y (jagged_inside a ha u hu x y hiu)
      (jagged_inside a ha s hs (y-1) x ((swap_contains s x y).mp hit)))
  · have hsv := jagged_disjoint a ha s v hs hv (y-1) x
      ((swap_contains s x y).mp hit) ((swap_contains v x y).mp hiu)
    exact congrArg swapUp hsv

/-- A genuine infinite tiling of both rows, with no bound on the integer index. -/
def stripTiling (a c : Int) (ha : 1≤a) (hc : 1≤c) :
    Tiling a 1 c 0 (Strip 2) where
  world := StripWorld a c
  copies := strip_copies a c
  inside := strip_inside a c ha hc
  cover x y := strip_cover a c x y ha hc
  disjoint t u x y ht hu hit hiu := strip_disjoint a c ha hc t u ht hu x y hit hiu

/-- A genuine infinite tiling of the L-shaped width-two bent strip. -/
def bentTiling (a : Int) (ha : 1≤a) : Tiling a 1 1 0 (BentStrip 2 2) where
  world := BentWorld a
  copies := bent_copies a
  inside := bent_inside a ha
  cover x y := bent_cover a x y ha
  disjoint t u x y ht hu hit hiu := bent_disjoint a ha t u ht hu x y hit hiu

theorem strip_tiles (a c : Int) (ha : 1≤a) (hc : 1≤c) : Tiles a 1 c 0 (Strip 2) :=
  ⟨stripTiling a c ha hc⟩

theorem bent_tiles (a : Int) (ha : 1≤a) : Tiles a 1 1 0 (BentStrip 2 2) :=
  ⟨bentTiling a ha⟩

theorem strip_tileable (a c : Int) (ha : 1≤a) (hc : 1≤c) : StripTileable a 1 c 0 :=
  ⟨2, by omega, strip_tiles a c ha hc⟩

theorem bent_tileable (a : Int) (ha : 1≤a) : BentStripTileable a 1 1 0 :=
  ⟨2, 2, by omega, by omega, bent_tiles a ha⟩

#print axioms strip_tiles
#print axioms bent_tiles
#print axioms strip_tileable
#print axioms bent_tileable
end PositiveConstructions

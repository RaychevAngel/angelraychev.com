import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o2 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n150_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o2 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o3 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o5 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n151_o7 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_empty (a b : Int)
    (h0 : (((((4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o2 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o5 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o6 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n152_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((6 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (18 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((6 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (9 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o0 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b = (3 : Int)))
    (h2 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h4 : (a = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (b = (3 : Int)))
    (h5 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    (h6 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((10 : Int) > jx) ∨ ((10 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h5 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - b))))
    (h6 : (b = (3 : Int)))
    (h7 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h8 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    (h9 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o3 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o4 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o5 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((10 : Int) > (jx + b)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n153_o7 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h9 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (a = (5 : Int)))
    (h5 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h8 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o2 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o3 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o6 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n154_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : (((jx + a) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - b))))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o3 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o5 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + b) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n155_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (5 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o0 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o5 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n156_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_point (a b : Int)
    (h0 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o0 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (¬ ((((4 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (¬ ((((9 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h3 : (b = (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o3 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o4 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o5 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((9 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o6 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (b = (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n157_o7 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_point (a b : Int)
    (h0 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o1 (a b jx jy : Int)
    (h0 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (¬ ((((9 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h2 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n158_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (8 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o2 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o5 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n159_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (8 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h7 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h8 : (¬ ((((3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h4 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o5 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n160_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_empty (a b : Int)
    (h0 : (((((4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (8 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o2 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o3 (a b jx jy : Int)
    (h0 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o5 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o6 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n161_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((6 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (18 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((6 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((6 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (9 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o0 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (5 : Int)))
    (h6 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h7 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h5 : (b = (3 : Int)))
    (h6 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o2 (a b jx jy : Int)
    (h0 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h1 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - b))))
    (h2 : (((10 : Int) > jx) ∨ ((10 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    (h6 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (b = (3 : Int)))
    (h9 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o4 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o5 (a b jx jy : Int)
    (h0 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o6 (a b jx jy : Int)
    (h0 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n162_o7 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : (b = (3 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (8 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (5 : Int)))
    (h5 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (b = (3 : Int)))
    (h7 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o1 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o3 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o4 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o5 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o6 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n163_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h5 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o0 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + a) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - b))))
    (h2 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o4 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o5 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (((jx + b) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n164_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((8 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((8 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (8 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o1 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h6 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n165_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_point (a b : Int)
    (h0 : (¬ (((12 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((12 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_empty (a b : Int)
    (h0 : (((((12 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (18 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((12 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h5 : (b = (3 : Int)))
    (h6 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o2 (a b jx jy : Int)
    (h0 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o4 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((jx + (0 : Int)) < ((11 : Int) - (3 : Int))) ∨ (((11 : Int) + (0 : Int)) < (jx - b)) ∨ ((9 : Int) > jy) ∨ ((9 : Int) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o5 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h5 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n166_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h3 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_point (a b : Int)
    (h0 : (¬ (((17 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((17 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_empty (a b : Int)
    (h0 : (((((17 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((17 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((17 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((17 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((17 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((17 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o1 (a b jx jy : Int)
    (h0 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : (¬ ((((17 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h5 : ((((17 : Int) ≥ (jx - a)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + (0 : Int)) < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((17 : Int) ≥ (jx - b)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o4 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((17 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h3 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (b = (3 : Int)))
    (h5 : ((((17 : Int) ≥ (jx - b)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((17 : Int) ≥ (jx - a)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (((jx + (0 : Int)) < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((18 : Int) > (jx + b)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n167_o7 (a b jx jy : Int)
    (h0 : (¬ ((((17 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h1 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o0 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a = (5 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h5 : (¬ ((((14 : Int) = jx) ∧ ((8 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h6 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o3 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o5 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((17 : Int) > (jx + b)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n168_o7 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h6 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (3 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o0 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h5 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jy)))
    (h6 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (3 : Int)) < jx) ∨ ((8 : Int) > (jy + (0 : Int))) ∨ ((8 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o2 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (3 : Int)) < jx) ∨ ((8 : Int) > (jy + (0 : Int))) ∨ ((8 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - b)) ∨ (jy < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (3 : Int)) < jx) ∨ ((8 : Int) > (jy + (0 : Int))) ∨ ((8 : Int) < (jy - a))))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o5 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((17 : Int) > (jx + b)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n169_o7 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (3 : Int)) < jx) ∨ ((8 : Int) > (jy + (0 : Int))) ∨ ((8 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o1 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o2 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h6 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o3 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o4 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n170_o7 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((19 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((19 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_empty (a b : Int)
    (h0 : (((((19 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((19 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((19 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((19 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((19 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((19 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((19 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((19 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (18 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((19 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((19 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((19 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((19 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((19 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((19 : Int) ≤ ((17 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (5 : Int))) ∨ (((17 : Int) ≤ (19 : Int)) ∧ ((19 : Int) ≤ (17 : Int)) ∧ ((1 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (((23 : Int) > (jx + a)) ∨ ((23 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : ((((19 : Int) ≥ (jx - (0 : Int))) ∧ ((19 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((23 : Int) - (5 : Int))) ∨ (((23 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((((19 : Int) ≥ (jx - (0 : Int))) ∧ ((19 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o2 (a b jx jy : Int)
    (h0 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((19 : Int) ≥ (jx - a)) ∧ ((19 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o3 (a b jx jy : Int)
    (h0 : ((((19 : Int) ≥ (jx - b)) ∧ ((19 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((23 : Int) > (jx + (0 : Int))) ∨ ((23 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((((19 : Int) ≥ (jx - b)) ∧ ((19 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((23 : Int) - (5 : Int))) ∨ (((23 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((23 : Int) > (jx + (0 : Int))) ∨ ((23 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((19 : Int) ≥ (jx - a)) ∧ ((19 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o6 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((18 : Int) > (jx + b)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((19 : Int) ≥ (jx - (0 : Int))) ∧ ((19 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n171_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b = (3 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((19 : Int) ≥ (jx - (0 : Int))) ∧ ((19 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((19 : Int) ≥ jx) ∧ ((19 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (¬ ((((19 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h7 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((20 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((20 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_empty (a b : Int)
    (h0 : (((((20 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((20 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((20 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((20 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((20 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((20 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((20 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((20 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (18 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((20 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((13 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (5 : Int))))) ∨ ((((20 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((20 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((20 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((20 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((17 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (5 : Int))) ∨ (((17 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (17 : Int)) ∧ ((1 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((20 : Int) ≥ ((19 : Int) - (0 : Int))) ∧ ((20 : Int) ≤ ((19 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((19 : Int) ≤ (20 : Int)) ∧ ((20 : Int) ≤ (19 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((20 : Int) ≥ (jx - (0 : Int))) ∧ ((20 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((23 : Int) - (5 : Int))) ∨ (((23 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o1 (a b jx jy : Int)
    (h0 : ((((20 : Int) ≥ (jx - (0 : Int))) ∧ ((20 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((20 : Int) ≥ (jx - a)) ∧ ((20 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((23 : Int) > (jx + (0 : Int))) ∨ ((23 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : ((((20 : Int) ≥ (jx - b)) ∧ ((20 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((20 : Int) ≥ (jx - b)) ∧ ((20 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((23 : Int) - (5 : Int))) ∨ (((23 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((((20 : Int) ≥ (jx - a)) ∧ ((20 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((23 : Int) > (jx + (0 : Int))) ∨ ((23 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o6 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (0 : Int))) ∨ (((17 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (((18 : Int) > (jx + b)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((20 : Int) ≥ (jx - (0 : Int))) ∧ ((20 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n172_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((20 : Int) ≥ (jx - (0 : Int))) ∧ ((20 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((20 : Int) ≥ jx) ∧ ((20 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((19 : Int) - (0 : Int))) ∨ (((19 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o1 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o2 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o3 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o5 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o6 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n173_o7 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((11 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((11 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_empty (a b : Int)
    (h0 : (((((11 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((11 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((11 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((13 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o0 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (3 : Int)))
    (h5 : (a = (5 : Int)))
    (h6 : (¬ ((((11 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o2 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h5 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h6 : ((((11 : Int) ≥ (jx - a)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (¬ ((((11 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h8 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o3 (a b jx jy : Int)
    (h0 : ((((11 : Int) ≥ (jx - b)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o4 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h2 : ((((11 : Int) ≥ (jx - b)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (¬ ((((11 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h6 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((11 : Int) ≥ (jx - a)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o6 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + b)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n174_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((11 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h2 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

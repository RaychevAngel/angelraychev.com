import CornerCertificateAffineAlphaGeometry

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

section AffineAlpha
variable (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include ha copies separate cover ceiling in
theorem affine_alpha_node140 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known140 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known140 a) ((1 : Int),(1 : Int)) (affine_alpha_branches140 a) copies separate cover ceiling
    (affine_alpha_nonnegative140 a ha) (affine_alpha_window140 a ha world h B state)
    (affine_alpha_empty140 a ha) (affine_alpha_complete140 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node139 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known139 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known139 a) ((1 : Int),(1 : Int)) (affine_alpha_branches139 a) copies separate cover ceiling
    (affine_alpha_nonnegative139 a ha) (affine_alpha_window139 a ha world h B state)
    (affine_alpha_empty139 a ha) (affine_alpha_complete139 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node138 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known138 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known138 a) ((2 : Int),(1 : Int)) (affine_alpha_branches138 a) copies separate cover ceiling
    (affine_alpha_nonnegative138 a ha) (affine_alpha_window138 a ha world h B state)
    (affine_alpha_empty138 a ha) (affine_alpha_complete138 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node137 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known137 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known137 a) ((2 : Int),(1 : Int)) (affine_alpha_branches137 a) copies separate cover ceiling
    (affine_alpha_nonnegative137 a ha) (affine_alpha_window137 a ha world h B state)
    (affine_alpha_empty137 a ha) (affine_alpha_complete137 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node136 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known136 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known136 a) ((1 : Int),(1 : Int)) (affine_alpha_branches136 a) copies separate cover ceiling
    (affine_alpha_nonnegative136 a ha) (affine_alpha_window136 a ha world h B state)
    (affine_alpha_empty136 a ha) (affine_alpha_complete136 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known136,affine_alpha_known137,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known136,affine_alpha_known138,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node137 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node138 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node135 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known135 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known135 a) ((0 : Int),(1 : Int)) (affine_alpha_branches135 a) copies separate cover ceiling
    (affine_alpha_nonnegative135 a ha) (affine_alpha_window135 a ha world h B state)
    (affine_alpha_empty135 a ha) (affine_alpha_complete135 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known135,affine_alpha_known136,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known135,affine_alpha_known139,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known135,affine_alpha_known140,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node136 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node139 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node140 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node134 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known134 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known134 a) ((1 : Int),(2 : Int)) (affine_alpha_branches134 a) copies separate cover ceiling
    (affine_alpha_nonnegative134 a ha) (affine_alpha_window134 a ha world h B state)
    (affine_alpha_empty134 a ha) (affine_alpha_complete134 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node133 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known133 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known133 a) ((1 : Int),(2 : Int)) (affine_alpha_branches133 a) copies separate cover ceiling
    (affine_alpha_nonnegative133 a ha) (affine_alpha_window133 a ha world h B state)
    (affine_alpha_empty133 a ha) (affine_alpha_complete133 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node132 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known132 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known132 a) ((2 : Int),(2 : Int)) (affine_alpha_branches132 a) copies separate cover ceiling
    (affine_alpha_nonnegative132 a ha) (affine_alpha_window132 a ha world h B state)
    (affine_alpha_empty132 a ha) (affine_alpha_complete132 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node131 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known131 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known131 a) ((2 : Int),(2 : Int)) (affine_alpha_branches131 a) copies separate cover ceiling
    (affine_alpha_nonnegative131 a ha) (affine_alpha_window131 a ha world h B state)
    (affine_alpha_empty131 a ha) (affine_alpha_complete131 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node130 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known130 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known130 a) ((1 : Int),(2 : Int)) (affine_alpha_branches130 a) copies separate cover ceiling
    (affine_alpha_nonnegative130 a ha) (affine_alpha_window130 a ha world h B state)
    (affine_alpha_empty130 a ha) (affine_alpha_complete130 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known130,affine_alpha_known131,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known130,affine_alpha_known132,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node131 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node132 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node129 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known129 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known129 a) ((0 : Int),(2 : Int)) (affine_alpha_branches129 a) copies separate cover ceiling
    (affine_alpha_nonnegative129 a ha) (affine_alpha_window129 a ha world h B state)
    (affine_alpha_empty129 a ha) (affine_alpha_complete129 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known129,affine_alpha_known130,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known129,affine_alpha_known133,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known129,affine_alpha_known134,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node130 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node133 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node134 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node128 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known128 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known128 a) ((1 : Int),(4 : Int)) (affine_alpha_branches128 a) copies separate cover ceiling
    (affine_alpha_nonnegative128 a ha) (affine_alpha_window128 a ha world h B state)
    (affine_alpha_empty128 a ha) (affine_alpha_complete128 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node127 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known127 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known127 a) ((2 : Int),(2 : Int)) (affine_alpha_branches127 a) copies separate cover ceiling
    (affine_alpha_nonnegative127 a ha) (affine_alpha_window127 a ha world h B state)
    (affine_alpha_empty127 a ha) (affine_alpha_complete127 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known127,affine_alpha_known128,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node128 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node126 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known126 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known126 a) ((2 : Int),(2 : Int)) (affine_alpha_branches126 a) copies separate cover ceiling
    (affine_alpha_nonnegative126 a ha) (affine_alpha_window126 a ha world h B state)
    (affine_alpha_empty126 a ha) (affine_alpha_complete126 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node125 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known125 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known125 a) ((1 : Int),(4 : Int)) (affine_alpha_branches125 a) copies separate cover ceiling
    (affine_alpha_nonnegative125 a ha) (affine_alpha_window125 a ha world h B state)
    (affine_alpha_empty125 a ha) (affine_alpha_complete125 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node124 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known124 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known124 a) ((2 : Int),(2 : Int)) (affine_alpha_branches124 a) copies separate cover ceiling
    (affine_alpha_nonnegative124 a ha) (affine_alpha_window124 a ha world h B state)
    (affine_alpha_empty124 a ha) (affine_alpha_complete124 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known124,affine_alpha_known125,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node125 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node123 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known123 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known123 a) ((1 : Int),(5 : Int)) (affine_alpha_branches123 a) copies separate cover ceiling
    (affine_alpha_nonnegative123 a ha) (affine_alpha_window123 a ha world h B state)
    (affine_alpha_empty123 a ha) (affine_alpha_complete123 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node122 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known122 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known122 a) ((1 : Int),(5 : Int)) (affine_alpha_branches122 a) copies separate cover ceiling
    (affine_alpha_nonnegative122 a ha) (affine_alpha_window122 a ha world h B state)
    (affine_alpha_empty122 a ha) (affine_alpha_complete122 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node121 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known121 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known121 a) ((3 : Int),(2 : Int)) (affine_alpha_branches121 a) copies separate cover ceiling
    (affine_alpha_nonnegative121 a ha) (affine_alpha_window121 a ha world h B state)
    (affine_alpha_empty121 a ha) (affine_alpha_complete121 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known121,affine_alpha_known122,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known121,affine_alpha_known123,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node122 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node123 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node120 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known120 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known120 a) ((1 : Int),(5 : Int)) (affine_alpha_branches120 a) copies separate cover ceiling
    (affine_alpha_nonnegative120 a ha) (affine_alpha_window120 a ha world h B state)
    (affine_alpha_empty120 a ha) (affine_alpha_complete120 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node119 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known119 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known119 a) ((1 : Int),(5 : Int)) (affine_alpha_branches119 a) copies separate cover ceiling
    (affine_alpha_nonnegative119 a ha) (affine_alpha_window119 a ha world h B state)
    (affine_alpha_empty119 a ha) (affine_alpha_complete119 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node118 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known118 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known118 a) ((3 : Int),(2 : Int)) (affine_alpha_branches118 a) copies separate cover ceiling
    (affine_alpha_nonnegative118 a ha) (affine_alpha_window118 a ha world h B state)
    (affine_alpha_empty118 a ha) (affine_alpha_complete118 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known118,affine_alpha_known119,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known118,affine_alpha_known120,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node119 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node120 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node117 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known117 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known117 a) ((1 : Int),(4 : Int)) (affine_alpha_branches117 a) copies separate cover ceiling
    (affine_alpha_nonnegative117 a ha) (affine_alpha_window117 a ha world h B state)
    (affine_alpha_empty117 a ha) (affine_alpha_complete117 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known117,affine_alpha_known118,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known117,affine_alpha_known121,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node118 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node121 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node116 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known116 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf116 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node115 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known115 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known115 a) ((1 : Int),(3 : Int)) (affine_alpha_branches115 a) copies separate cover ceiling
    (affine_alpha_nonnegative115 a ha) (affine_alpha_window115 a ha world h B state)
    (affine_alpha_empty115 a ha) (affine_alpha_complete115 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known115,affine_alpha_known116,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known115,affine_alpha_known117,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known115,affine_alpha_known124,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known115,affine_alpha_known126,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known115,affine_alpha_known127,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node116 a ha world h nextB nextState
    · exact affine_alpha_node117 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node124 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node126 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node127 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node114 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known114 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf114 a ha world h B state
include ha in
theorem affine_alpha_node113 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known113 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf113 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node112 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known112 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known112 a) ((0 : Int),(2 : Int)) (affine_alpha_branches112 a) copies separate cover ceiling
    (affine_alpha_nonnegative112 a ha) (affine_alpha_window112 a ha world h B state)
    (affine_alpha_empty112 a ha) (affine_alpha_complete112 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known112,affine_alpha_known113,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known112,affine_alpha_known114,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known112,affine_alpha_known115,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node113 a ha world h nextB nextState
    · exact affine_alpha_node114 a ha world h nextB nextState
    · exact affine_alpha_node115 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node111 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known111 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known111 a) ((1 : Int),(2 : Int)) (affine_alpha_branches111 a) copies separate cover ceiling
    (affine_alpha_nonnegative111 a ha) (affine_alpha_window111 a ha world h B state)
    (affine_alpha_empty111 a ha) (affine_alpha_complete111 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node110 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known110 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known110 a) ((1 : Int),(2 : Int)) (affine_alpha_branches110 a) copies separate cover ceiling
    (affine_alpha_nonnegative110 a ha) (affine_alpha_window110 a ha world h B state)
    (affine_alpha_empty110 a ha) (affine_alpha_complete110 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node109 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known109 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known109 a) ((1 : Int),(1 : Int)) (affine_alpha_branches109 a) copies separate cover ceiling
    (affine_alpha_nonnegative109 a ha) (affine_alpha_window109 a ha world h B state)
    (affine_alpha_empty109 a ha) (affine_alpha_complete109 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known109,affine_alpha_known110,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known109,affine_alpha_known111,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node110 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node111 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node108 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known108 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known108 a) ((2 : Int),(2 : Int)) (affine_alpha_branches108 a) copies separate cover ceiling
    (affine_alpha_nonnegative108 a ha) (affine_alpha_window108 a ha world h B state)
    (affine_alpha_empty108 a ha) (affine_alpha_complete108 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node107 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known107 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known107 a) ((2 : Int),(2 : Int)) (affine_alpha_branches107 a) copies separate cover ceiling
    (affine_alpha_nonnegative107 a ha) (affine_alpha_window107 a ha world h B state)
    (affine_alpha_empty107 a ha) (affine_alpha_complete107 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_alpha_node106 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known106 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf106 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node105 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known105 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known105 a) ((4 : Int),(2 : Int)) (affine_alpha_branches105 a) copies separate cover ceiling
    (affine_alpha_nonnegative105 a ha) (affine_alpha_window105 a ha world h B state)
    (affine_alpha_empty105 a ha) (affine_alpha_complete105 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node104 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known104 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known104 a) ((4 : Int),(2 : Int)) (affine_alpha_branches104 a) copies separate cover ceiling
    (affine_alpha_nonnegative104 a ha) (affine_alpha_window104 a ha world h B state)
    (affine_alpha_empty104 a ha) (affine_alpha_complete104 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node103 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known103 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known103 a) ((3 : Int),(2 : Int)) (affine_alpha_branches103 a) copies separate cover ceiling
    (affine_alpha_nonnegative103 a ha) (affine_alpha_window103 a ha world h B state)
    (affine_alpha_empty103 a ha) (affine_alpha_complete103 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known103,affine_alpha_known104,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known103,affine_alpha_known105,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node104 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node105 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node102 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known102 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known102 a) ((4 : Int),(2 : Int)) (affine_alpha_branches102 a) copies separate cover ceiling
    (affine_alpha_nonnegative102 a ha) (affine_alpha_window102 a ha world h B state)
    (affine_alpha_empty102 a ha) (affine_alpha_complete102 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node101 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known101 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known101 a) ((4 : Int),(2 : Int)) (affine_alpha_branches101 a) copies separate cover ceiling
    (affine_alpha_nonnegative101 a ha) (affine_alpha_window101 a ha world h B state)
    (affine_alpha_empty101 a ha) (affine_alpha_complete101 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node100 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known100 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known100 a) ((3 : Int),(2 : Int)) (affine_alpha_branches100 a) copies separate cover ceiling
    (affine_alpha_nonnegative100 a ha) (affine_alpha_window100 a ha world h B state)
    (affine_alpha_empty100 a ha) (affine_alpha_complete100 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known100,affine_alpha_known101,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known100,affine_alpha_known102,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node101 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node102 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node099 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known099 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known099 a) ((1 : Int),(4 : Int)) (affine_alpha_branches099 a) copies separate cover ceiling
    (affine_alpha_nonnegative099 a ha) (affine_alpha_window099 a ha world h B state)
    (affine_alpha_empty099 a ha) (affine_alpha_complete099 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known099,affine_alpha_known100,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known099,affine_alpha_known103,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node100 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node103 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node098 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known098 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known098 a) ((2 : Int),(2 : Int)) (affine_alpha_branches098 a) copies separate cover ceiling
    (affine_alpha_nonnegative098 a ha) (affine_alpha_window098 a ha world h B state)
    (affine_alpha_empty098 a ha) (affine_alpha_complete098 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node097 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known097 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known097 a) ((2 : Int),(2 : Int)) (affine_alpha_branches097 a) copies separate cover ceiling
    (affine_alpha_nonnegative097 a ha) (affine_alpha_window097 a ha world h B state)
    (affine_alpha_empty097 a ha) (affine_alpha_complete097 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node096 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known096 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known096 a) ((3 : Int),(2 : Int)) (affine_alpha_branches096 a) copies separate cover ceiling
    (affine_alpha_nonnegative096 a ha) (affine_alpha_window096 a ha world h B state)
    (affine_alpha_empty096 a ha) (affine_alpha_complete096 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node095 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known095 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known095 a) ((3 : Int),(2 : Int)) (affine_alpha_branches095 a) copies separate cover ceiling
    (affine_alpha_nonnegative095 a ha) (affine_alpha_window095 a ha world h B state)
    (affine_alpha_empty095 a ha) (affine_alpha_complete095 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node094 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known094 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known094 a) ((2 : Int),(2 : Int)) (affine_alpha_branches094 a) copies separate cover ceiling
    (affine_alpha_nonnegative094 a ha) (affine_alpha_window094 a ha world h B state)
    (affine_alpha_empty094 a ha) (affine_alpha_complete094 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known094,affine_alpha_known095,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known094,affine_alpha_known096,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node095 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node096 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node093 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known093 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known093 a) ((1 : Int),(3 : Int)) (affine_alpha_branches093 a) copies separate cover ceiling
    (affine_alpha_nonnegative093 a ha) (affine_alpha_window093 a ha world h B state)
    (affine_alpha_empty093 a ha) (affine_alpha_complete093 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known094,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known097,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known098,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known099,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known106,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known107,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known093,affine_alpha_known108,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node094 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node097 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node098 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node099 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node106 a ha world h nextB nextState
    · exact affine_alpha_node107 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node108 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node092 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known092 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf092 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node091 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known091 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known091 a) ((1 : Int),(1 : Int)) (affine_alpha_branches091 a) copies separate cover ceiling
    (affine_alpha_nonnegative091 a ha) (affine_alpha_window091 a ha world h B state)
    (affine_alpha_empty091 a ha) (affine_alpha_complete091 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known091,affine_alpha_known092,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known091,affine_alpha_known093,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node092 a ha world h nextB nextState
    · exact affine_alpha_node093 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node090 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known090 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf090 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node089 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known089 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known089 a) ((0 : Int),(1 : Int)) (affine_alpha_branches089 a) copies separate cover ceiling
    (affine_alpha_nonnegative089 a ha) (affine_alpha_window089 a ha world h B state)
    (affine_alpha_empty089 a ha) (affine_alpha_complete089 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known089,affine_alpha_known090,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known089,affine_alpha_known091,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known089,affine_alpha_known109,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known089,affine_alpha_known112,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known089,affine_alpha_known129,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node090 a ha world h nextB nextState
    · exact affine_alpha_node091 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node109 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node112 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node129 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node088 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known088 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known088 a) ((1 : Int),(3 : Int)) (affine_alpha_branches088 a) copies separate cover ceiling
    (affine_alpha_nonnegative088 a ha) (affine_alpha_window088 a ha world h B state)
    (affine_alpha_empty088 a ha) (affine_alpha_complete088 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node087 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known087 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known087 a) ((2 : Int),(1 : Int)) (affine_alpha_branches087 a) copies separate cover ceiling
    (affine_alpha_nonnegative087 a ha) (affine_alpha_window087 a ha world h B state)
    (affine_alpha_empty087 a ha) (affine_alpha_complete087 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known087,affine_alpha_known088,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node088 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node086 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known086 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known086 a) ((2 : Int),(1 : Int)) (affine_alpha_branches086 a) copies separate cover ceiling
    (affine_alpha_nonnegative086 a ha) (affine_alpha_window086 a ha world h B state)
    (affine_alpha_empty086 a ha) (affine_alpha_complete086 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node085 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known085 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known085 a) ((1 : Int),(3 : Int)) (affine_alpha_branches085 a) copies separate cover ceiling
    (affine_alpha_nonnegative085 a ha) (affine_alpha_window085 a ha world h B state)
    (affine_alpha_empty085 a ha) (affine_alpha_complete085 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node084 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known084 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known084 a) ((2 : Int),(1 : Int)) (affine_alpha_branches084 a) copies separate cover ceiling
    (affine_alpha_nonnegative084 a ha) (affine_alpha_window084 a ha world h B state)
    (affine_alpha_empty084 a ha) (affine_alpha_complete084 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known084,affine_alpha_known085,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node085 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node083 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known083 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known083 a) ((1 : Int),(4 : Int)) (affine_alpha_branches083 a) copies separate cover ceiling
    (affine_alpha_nonnegative083 a ha) (affine_alpha_window083 a ha world h B state)
    (affine_alpha_empty083 a ha) (affine_alpha_complete083 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node082 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known082 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known082 a) ((1 : Int),(4 : Int)) (affine_alpha_branches082 a) copies separate cover ceiling
    (affine_alpha_nonnegative082 a ha) (affine_alpha_window082 a ha world h B state)
    (affine_alpha_empty082 a ha) (affine_alpha_complete082 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node081 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known081 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known081 a) ((3 : Int),(1 : Int)) (affine_alpha_branches081 a) copies separate cover ceiling
    (affine_alpha_nonnegative081 a ha) (affine_alpha_window081 a ha world h B state)
    (affine_alpha_empty081 a ha) (affine_alpha_complete081 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known081,affine_alpha_known082,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known081,affine_alpha_known083,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node082 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node083 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node080 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known080 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known080 a) ((1 : Int),(4 : Int)) (affine_alpha_branches080 a) copies separate cover ceiling
    (affine_alpha_nonnegative080 a ha) (affine_alpha_window080 a ha world h B state)
    (affine_alpha_empty080 a ha) (affine_alpha_complete080 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node079 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known079 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known079 a) ((1 : Int),(4 : Int)) (affine_alpha_branches079 a) copies separate cover ceiling
    (affine_alpha_nonnegative079 a ha) (affine_alpha_window079 a ha world h B state)
    (affine_alpha_empty079 a ha) (affine_alpha_complete079 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node078 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known078 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known078 a) ((3 : Int),(1 : Int)) (affine_alpha_branches078 a) copies separate cover ceiling
    (affine_alpha_nonnegative078 a ha) (affine_alpha_window078 a ha world h B state)
    (affine_alpha_empty078 a ha) (affine_alpha_complete078 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known078,affine_alpha_known079,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known078,affine_alpha_known080,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node079 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node080 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node077 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known077 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known077 a) ((1 : Int),(3 : Int)) (affine_alpha_branches077 a) copies separate cover ceiling
    (affine_alpha_nonnegative077 a ha) (affine_alpha_window077 a ha world h B state)
    (affine_alpha_empty077 a ha) (affine_alpha_complete077 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known077,affine_alpha_known078,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known077,affine_alpha_known081,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node078 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node081 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node076 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known076 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf076 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node075 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known075 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known075 a) ((1 : Int),(2 : Int)) (affine_alpha_branches075 a) copies separate cover ceiling
    (affine_alpha_nonnegative075 a ha) (affine_alpha_window075 a ha world h B state)
    (affine_alpha_empty075 a ha) (affine_alpha_complete075 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known075,affine_alpha_known076,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known075,affine_alpha_known077,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known075,affine_alpha_known084,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known075,affine_alpha_known086,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known075,affine_alpha_known087,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node076 a ha world h nextB nextState
    · exact affine_alpha_node077 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node084 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node086 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node087 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node074 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known074 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf074 a ha world h B state
include ha in
theorem affine_alpha_node073 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known073 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf073 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node072 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known072 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known072 a) ((0 : Int),(1 : Int)) (affine_alpha_branches072 a) copies separate cover ceiling
    (affine_alpha_nonnegative072 a ha) (affine_alpha_window072 a ha world h B state)
    (affine_alpha_empty072 a ha) (affine_alpha_complete072 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known072,affine_alpha_known073,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known072,affine_alpha_known074,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known072,affine_alpha_known075,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node073 a ha world h nextB nextState
    · exact affine_alpha_node074 a ha world h nextB nextState
    · exact affine_alpha_node075 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node071 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known071 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known071 a) ((1 : Int),(1 : Int)) (affine_alpha_branches071 a) copies separate cover ceiling
    (affine_alpha_nonnegative071 a ha) (affine_alpha_window071 a ha world h B state)
    (affine_alpha_empty071 a ha) (affine_alpha_complete071 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node070 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known070 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known070 a) ((1 : Int),(2 : Int)) (affine_alpha_branches070 a) copies separate cover ceiling
    (affine_alpha_nonnegative070 a ha) (affine_alpha_window070 a ha world h B state)
    (affine_alpha_empty070 a ha) (affine_alpha_complete070 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node069 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known069 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known069 a) ((1 : Int),(2 : Int)) (affine_alpha_branches069 a) copies separate cover ceiling
    (affine_alpha_nonnegative069 a ha) (affine_alpha_window069 a ha world h B state)
    (affine_alpha_empty069 a ha) (affine_alpha_complete069 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node068 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known068 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known068 a) ((1 : Int),(1 : Int)) (affine_alpha_branches068 a) copies separate cover ceiling
    (affine_alpha_nonnegative068 a ha) (affine_alpha_window068 a ha world h B state)
    (affine_alpha_empty068 a ha) (affine_alpha_complete068 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known068,affine_alpha_known069,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known068,affine_alpha_known070,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node069 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node070 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node067 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known067 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known067 a) ((1 : Int),(1 : Int)) (affine_alpha_branches067 a) copies separate cover ceiling
    (affine_alpha_nonnegative067 a ha) (affine_alpha_window067 a ha world h B state)
    (affine_alpha_empty067 a ha) (affine_alpha_complete067 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node066 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known066 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known066 a) ((1 : Int),(0 : Int)) (affine_alpha_branches066 a) copies separate cover ceiling
    (affine_alpha_nonnegative066 a ha) (affine_alpha_window066 a ha world h B state)
    (affine_alpha_empty066 a ha) (affine_alpha_complete066 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known066,affine_alpha_known067,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known066,affine_alpha_known068,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known066,affine_alpha_known071,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node067 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node068 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node071 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node065 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known065 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known065 a) ((2 : Int),(1 : Int)) (affine_alpha_branches065 a) copies separate cover ceiling
    (affine_alpha_nonnegative065 a ha) (affine_alpha_window065 a ha world h B state)
    (affine_alpha_empty065 a ha) (affine_alpha_complete065 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node064 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known064 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known064 a) ((2 : Int),(1 : Int)) (affine_alpha_branches064 a) copies separate cover ceiling
    (affine_alpha_nonnegative064 a ha) (affine_alpha_window064 a ha world h B state)
    (affine_alpha_empty064 a ha) (affine_alpha_complete064 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_alpha_node063 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known063 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf063 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node062 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known062 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known062 a) ((4 : Int),(1 : Int)) (affine_alpha_branches062 a) copies separate cover ceiling
    (affine_alpha_nonnegative062 a ha) (affine_alpha_window062 a ha world h B state)
    (affine_alpha_empty062 a ha) (affine_alpha_complete062 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node061 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known061 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known061 a) ((4 : Int),(1 : Int)) (affine_alpha_branches061 a) copies separate cover ceiling
    (affine_alpha_nonnegative061 a ha) (affine_alpha_window061 a ha world h B state)
    (affine_alpha_empty061 a ha) (affine_alpha_complete061 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node060 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known060 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known060 a) ((3 : Int),(1 : Int)) (affine_alpha_branches060 a) copies separate cover ceiling
    (affine_alpha_nonnegative060 a ha) (affine_alpha_window060 a ha world h B state)
    (affine_alpha_empty060 a ha) (affine_alpha_complete060 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known060,affine_alpha_known061,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known060,affine_alpha_known062,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node061 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node062 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node059 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known059 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known059 a) ((4 : Int),(1 : Int)) (affine_alpha_branches059 a) copies separate cover ceiling
    (affine_alpha_nonnegative059 a ha) (affine_alpha_window059 a ha world h B state)
    (affine_alpha_empty059 a ha) (affine_alpha_complete059 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node058 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known058 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known058 a) ((4 : Int),(1 : Int)) (affine_alpha_branches058 a) copies separate cover ceiling
    (affine_alpha_nonnegative058 a ha) (affine_alpha_window058 a ha world h B state)
    (affine_alpha_empty058 a ha) (affine_alpha_complete058 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node057 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known057 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known057 a) ((3 : Int),(1 : Int)) (affine_alpha_branches057 a) copies separate cover ceiling
    (affine_alpha_nonnegative057 a ha) (affine_alpha_window057 a ha world h B state)
    (affine_alpha_empty057 a ha) (affine_alpha_complete057 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known057,affine_alpha_known058,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known057,affine_alpha_known059,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node058 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node059 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node056 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known056 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known056 a) ((1 : Int),(3 : Int)) (affine_alpha_branches056 a) copies separate cover ceiling
    (affine_alpha_nonnegative056 a ha) (affine_alpha_window056 a ha world h B state)
    (affine_alpha_empty056 a ha) (affine_alpha_complete056 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known056,affine_alpha_known057,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known056,affine_alpha_known060,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node057 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node060 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node055 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known055 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known055 a) ((2 : Int),(1 : Int)) (affine_alpha_branches055 a) copies separate cover ceiling
    (affine_alpha_nonnegative055 a ha) (affine_alpha_window055 a ha world h B state)
    (affine_alpha_empty055 a ha) (affine_alpha_complete055 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node054 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known054 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known054 a) ((2 : Int),(1 : Int)) (affine_alpha_branches054 a) copies separate cover ceiling
    (affine_alpha_nonnegative054 a ha) (affine_alpha_window054 a ha world h B state)
    (affine_alpha_empty054 a ha) (affine_alpha_complete054 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node053 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known053 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known053 a) ((3 : Int),(1 : Int)) (affine_alpha_branches053 a) copies separate cover ceiling
    (affine_alpha_nonnegative053 a ha) (affine_alpha_window053 a ha world h B state)
    (affine_alpha_empty053 a ha) (affine_alpha_complete053 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node052 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known052 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known052 a) ((3 : Int),(1 : Int)) (affine_alpha_branches052 a) copies separate cover ceiling
    (affine_alpha_nonnegative052 a ha) (affine_alpha_window052 a ha world h B state)
    (affine_alpha_empty052 a ha) (affine_alpha_complete052 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node051 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known051 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known051 a) ((2 : Int),(1 : Int)) (affine_alpha_branches051 a) copies separate cover ceiling
    (affine_alpha_nonnegative051 a ha) (affine_alpha_window051 a ha world h B state)
    (affine_alpha_empty051 a ha) (affine_alpha_complete051 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known051,affine_alpha_known052,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known051,affine_alpha_known053,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node052 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node053 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node050 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known050 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known050 a) ((1 : Int),(2 : Int)) (affine_alpha_branches050 a) copies separate cover ceiling
    (affine_alpha_nonnegative050 a ha) (affine_alpha_window050 a ha world h B state)
    (affine_alpha_empty050 a ha) (affine_alpha_complete050 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known051,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known054,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known055,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known056,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known063,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known064,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known050,affine_alpha_known065,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node051 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node054 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node055 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node056 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node063 a ha world h nextB nextState
    · exact affine_alpha_node064 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node065 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node049 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known049 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf049 a ha world h B state
include ha in
theorem affine_alpha_node048 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known048 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf048 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node047 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known047 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known047 a) ((1 : Int),(0 : Int)) (affine_alpha_branches047 a) copies separate cover ceiling
    (affine_alpha_nonnegative047 a ha) (affine_alpha_window047 a ha world h B state)
    (affine_alpha_empty047 a ha) (affine_alpha_complete047 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known047,affine_alpha_known048,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known047,affine_alpha_known049,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known047,affine_alpha_known050,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node048 a ha world h nextB nextState
    · exact affine_alpha_node049 a ha world h nextB nextState
    · exact affine_alpha_node050 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node046 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known046 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known046 a) ((2 : Int),(1 : Int)) (affine_alpha_branches046 a) copies separate cover ceiling
    (affine_alpha_nonnegative046 a ha) (affine_alpha_window046 a ha world h B state)
    (affine_alpha_empty046 a ha) (affine_alpha_complete046 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node045 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known045 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known045 a) ((2 : Int),(1 : Int)) (affine_alpha_branches045 a) copies separate cover ceiling
    (affine_alpha_nonnegative045 a ha) (affine_alpha_window045 a ha world h B state)
    (affine_alpha_empty045 a ha) (affine_alpha_complete045 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node044 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known044 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known044 a) ((1 : Int),(1 : Int)) (affine_alpha_branches044 a) copies separate cover ceiling
    (affine_alpha_nonnegative044 a ha) (affine_alpha_window044 a ha world h B state)
    (affine_alpha_empty044 a ha) (affine_alpha_complete044 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known044,affine_alpha_known045,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known044,affine_alpha_known046,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node045 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node046 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node043 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known043 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf043 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node042 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known042 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known042 a) ((2 : Int),(3 : Int)) (affine_alpha_branches042 a) copies separate cover ceiling
    (affine_alpha_nonnegative042 a ha) (affine_alpha_window042 a ha world h B state)
    (affine_alpha_empty042 a ha) (affine_alpha_complete042 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node041 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known041 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known041 a) ((3 : Int),(1 : Int)) (affine_alpha_branches041 a) copies separate cover ceiling
    (affine_alpha_nonnegative041 a ha) (affine_alpha_window041 a ha world h B state)
    (affine_alpha_empty041 a ha) (affine_alpha_complete041 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known041,affine_alpha_known042,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node042 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node040 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known040 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known040 a) ((3 : Int),(1 : Int)) (affine_alpha_branches040 a) copies separate cover ceiling
    (affine_alpha_nonnegative040 a ha) (affine_alpha_window040 a ha world h B state)
    (affine_alpha_empty040 a ha) (affine_alpha_complete040 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node039 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known039 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known039 a) ((2 : Int),(3 : Int)) (affine_alpha_branches039 a) copies separate cover ceiling
    (affine_alpha_nonnegative039 a ha) (affine_alpha_window039 a ha world h B state)
    (affine_alpha_empty039 a ha) (affine_alpha_complete039 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node038 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known038 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known038 a) ((3 : Int),(1 : Int)) (affine_alpha_branches038 a) copies separate cover ceiling
    (affine_alpha_nonnegative038 a ha) (affine_alpha_window038 a ha world h B state)
    (affine_alpha_empty038 a ha) (affine_alpha_complete038 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known038,affine_alpha_known039,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_alpha_node039 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node037 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known037 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known037 a) ((2 : Int),(4 : Int)) (affine_alpha_branches037 a) copies separate cover ceiling
    (affine_alpha_nonnegative037 a ha) (affine_alpha_window037 a ha world h B state)
    (affine_alpha_empty037 a ha) (affine_alpha_complete037 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node036 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known036 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known036 a) ((2 : Int),(4 : Int)) (affine_alpha_branches036 a) copies separate cover ceiling
    (affine_alpha_nonnegative036 a ha) (affine_alpha_window036 a ha world h B state)
    (affine_alpha_empty036 a ha) (affine_alpha_complete036 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node035 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known035 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known035 a) ((4 : Int),(1 : Int)) (affine_alpha_branches035 a) copies separate cover ceiling
    (affine_alpha_nonnegative035 a ha) (affine_alpha_window035 a ha world h B state)
    (affine_alpha_empty035 a ha) (affine_alpha_complete035 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known035,affine_alpha_known036,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known035,affine_alpha_known037,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node036 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node037 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node034 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known034 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known034 a) ((2 : Int),(4 : Int)) (affine_alpha_branches034 a) copies separate cover ceiling
    (affine_alpha_nonnegative034 a ha) (affine_alpha_window034 a ha world h B state)
    (affine_alpha_empty034 a ha) (affine_alpha_complete034 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node033 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known033 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known033 a) ((2 : Int),(4 : Int)) (affine_alpha_branches033 a) copies separate cover ceiling
    (affine_alpha_nonnegative033 a ha) (affine_alpha_window033 a ha world h B state)
    (affine_alpha_empty033 a ha) (affine_alpha_complete033 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node032 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known032 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known032 a) ((4 : Int),(1 : Int)) (affine_alpha_branches032 a) copies separate cover ceiling
    (affine_alpha_nonnegative032 a ha) (affine_alpha_window032 a ha world h B state)
    (affine_alpha_empty032 a ha) (affine_alpha_complete032 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known032,affine_alpha_known033,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known032,affine_alpha_known034,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node033 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node034 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node031 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known031 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known031 a) ((2 : Int),(3 : Int)) (affine_alpha_branches031 a) copies separate cover ceiling
    (affine_alpha_nonnegative031 a ha) (affine_alpha_window031 a ha world h B state)
    (affine_alpha_empty031 a ha) (affine_alpha_complete031 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known031,affine_alpha_known032,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known031,affine_alpha_known035,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node032 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node035 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node030 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known030 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf030 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node029 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known029 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known029 a) ((2 : Int),(2 : Int)) (affine_alpha_branches029 a) copies separate cover ceiling
    (affine_alpha_nonnegative029 a ha) (affine_alpha_window029 a ha world h B state)
    (affine_alpha_empty029 a ha) (affine_alpha_complete029 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known029,affine_alpha_known030,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known029,affine_alpha_known031,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known029,affine_alpha_known038,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known029,affine_alpha_known040,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known029,affine_alpha_known041,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node030 a ha world h nextB nextState
    · exact affine_alpha_node031 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node038 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node040 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node041 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node028 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known028 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf028 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node027 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known027 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known027 a) ((1 : Int),(1 : Int)) (affine_alpha_branches027 a) copies separate cover ceiling
    (affine_alpha_nonnegative027 a ha) (affine_alpha_window027 a ha world h B state)
    (affine_alpha_empty027 a ha) (affine_alpha_complete027 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known027,affine_alpha_known028,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known027,affine_alpha_known029,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node028 a ha world h nextB nextState
    · exact affine_alpha_node029 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node026 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known026 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known026 a) ((2 : Int),(1 : Int)) (affine_alpha_branches026 a) copies separate cover ceiling
    (affine_alpha_nonnegative026 a ha) (affine_alpha_window026 a ha world h B state)
    (affine_alpha_empty026 a ha) (affine_alpha_complete026 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node025 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known025 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known025 a) ((2 : Int),(2 : Int)) (affine_alpha_branches025 a) copies separate cover ceiling
    (affine_alpha_nonnegative025 a ha) (affine_alpha_window025 a ha world h B state)
    (affine_alpha_empty025 a ha) (affine_alpha_complete025 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node024 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known024 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known024 a) ((2 : Int),(2 : Int)) (affine_alpha_branches024 a) copies separate cover ceiling
    (affine_alpha_nonnegative024 a ha) (affine_alpha_window024 a ha world h B state)
    (affine_alpha_empty024 a ha) (affine_alpha_complete024 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node023 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known023 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known023 a) ((2 : Int),(1 : Int)) (affine_alpha_branches023 a) copies separate cover ceiling
    (affine_alpha_nonnegative023 a ha) (affine_alpha_window023 a ha world h B state)
    (affine_alpha_empty023 a ha) (affine_alpha_complete023 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known023,affine_alpha_known024,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known023,affine_alpha_known025,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node024 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node025 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node022 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known022 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known022 a) ((2 : Int),(1 : Int)) (affine_alpha_branches022 a) copies separate cover ceiling
    (affine_alpha_nonnegative022 a ha) (affine_alpha_window022 a ha world h B state)
    (affine_alpha_empty022 a ha) (affine_alpha_complete022 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node021 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known021 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known021 a) ((2 : Int),(0 : Int)) (affine_alpha_branches021 a) copies separate cover ceiling
    (affine_alpha_nonnegative021 a ha) (affine_alpha_window021 a ha world h B state)
    (affine_alpha_empty021 a ha) (affine_alpha_complete021 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known021,affine_alpha_known022,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known021,affine_alpha_known023,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known021,affine_alpha_known026,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node022 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node023 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node026 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node020 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known020 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known020 a) ((3 : Int),(1 : Int)) (affine_alpha_branches020 a) copies separate cover ceiling
    (affine_alpha_nonnegative020 a ha) (affine_alpha_window020 a ha world h B state)
    (affine_alpha_empty020 a ha) (affine_alpha_complete020 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node019 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known019 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known019 a) ((3 : Int),(1 : Int)) (affine_alpha_branches019 a) copies separate cover ceiling
    (affine_alpha_nonnegative019 a ha) (affine_alpha_window019 a ha world h B state)
    (affine_alpha_empty019 a ha) (affine_alpha_complete019 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches019,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches019,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_alpha_node018 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known018 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf018 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node017 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known017 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known017 a) ((5 : Int),(1 : Int)) (affine_alpha_branches017 a) copies separate cover ceiling
    (affine_alpha_nonnegative017 a ha) (affine_alpha_window017 a ha world h B state)
    (affine_alpha_empty017 a ha) (affine_alpha_complete017 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node016 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known016 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known016 a) ((5 : Int),(1 : Int)) (affine_alpha_branches016 a) copies separate cover ceiling
    (affine_alpha_nonnegative016 a ha) (affine_alpha_window016 a ha world h B state)
    (affine_alpha_empty016 a ha) (affine_alpha_complete016 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node015 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known015 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known015 a) ((4 : Int),(1 : Int)) (affine_alpha_branches015 a) copies separate cover ceiling
    (affine_alpha_nonnegative015 a ha) (affine_alpha_window015 a ha world h B state)
    (affine_alpha_empty015 a ha) (affine_alpha_complete015 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known015,affine_alpha_known016,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known015,affine_alpha_known017,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node016 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node017 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node014 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known014 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known014 a) ((5 : Int),(1 : Int)) (affine_alpha_branches014 a) copies separate cover ceiling
    (affine_alpha_nonnegative014 a ha) (affine_alpha_window014 a ha world h B state)
    (affine_alpha_empty014 a ha) (affine_alpha_complete014 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node013 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known013 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known013 a) ((5 : Int),(1 : Int)) (affine_alpha_branches013 a) copies separate cover ceiling
    (affine_alpha_nonnegative013 a ha) (affine_alpha_window013 a ha world h B state)
    (affine_alpha_empty013 a ha) (affine_alpha_complete013 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node012 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known012 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known012 a) ((4 : Int),(1 : Int)) (affine_alpha_branches012 a) copies separate cover ceiling
    (affine_alpha_nonnegative012 a ha) (affine_alpha_window012 a ha world h B state)
    (affine_alpha_empty012 a ha) (affine_alpha_complete012 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known012,affine_alpha_known013,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known012,affine_alpha_known014,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node013 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node014 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node011 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known011 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known011 a) ((2 : Int),(3 : Int)) (affine_alpha_branches011 a) copies separate cover ceiling
    (affine_alpha_nonnegative011 a ha) (affine_alpha_window011 a ha world h B state)
    (affine_alpha_empty011 a ha) (affine_alpha_complete011 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known011,affine_alpha_known012,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known011,affine_alpha_known015,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node012 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node015 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node010 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known010 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known010 a) ((3 : Int),(1 : Int)) (affine_alpha_branches010 a) copies separate cover ceiling
    (affine_alpha_nonnegative010 a ha) (affine_alpha_window010 a ha world h B state)
    (affine_alpha_empty010 a ha) (affine_alpha_complete010 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node009 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known009 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known009 a) ((3 : Int),(1 : Int)) (affine_alpha_branches009 a) copies separate cover ceiling
    (affine_alpha_nonnegative009 a ha) (affine_alpha_window009 a ha world h B state)
    (affine_alpha_empty009 a ha) (affine_alpha_complete009 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node008 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known008 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known008 a) ((4 : Int),(1 : Int)) (affine_alpha_branches008 a) copies separate cover ceiling
    (affine_alpha_nonnegative008 a ha) (affine_alpha_window008 a ha world h B state)
    (affine_alpha_empty008 a ha) (affine_alpha_complete008 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node007 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known007 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known007 a) ((4 : Int),(1 : Int)) (affine_alpha_branches007 a) copies separate cover ceiling
    (affine_alpha_nonnegative007 a ha) (affine_alpha_window007 a ha world h B state)
    (affine_alpha_empty007 a ha) (affine_alpha_complete007 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_alpha_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_alpha_node006 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known006 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known006 a) ((3 : Int),(1 : Int)) (affine_alpha_branches006 a) copies separate cover ceiling
    (affine_alpha_nonnegative006 a ha) (affine_alpha_window006 a ha world h B state)
    (affine_alpha_empty006 a ha) (affine_alpha_complete006 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known006,affine_alpha_known007,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known006,affine_alpha_known008,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_alpha_node007 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node008 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node005 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known005 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known005 a) ((2 : Int),(2 : Int)) (affine_alpha_branches005 a) copies separate cover ceiling
    (affine_alpha_nonnegative005 a ha) (affine_alpha_window005 a ha world h B state)
    (affine_alpha_empty005 a ha) (affine_alpha_complete005 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches005,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known006,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known009,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known010,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known011,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known018,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known019,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known005,affine_alpha_known020,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches005,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node006 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node009 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node010 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node011 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node018 a ha world h nextB nextState
    · exact affine_alpha_node019 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node020 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_alpha_node004 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known004 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf004 a ha world h B state
include ha in
theorem affine_alpha_node003 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known003 a)) B) : Transition world h .alpha B := by
  exact affine_alpha_leaf003 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_alpha_node002 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known002 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known002 a) ((2 : Int),(0 : Int)) (affine_alpha_branches002 a) copies separate cover ceiling
    (affine_alpha_nonnegative002 a ha) (affine_alpha_window002 a ha world h B state)
    (affine_alpha_empty002 a ha) (affine_alpha_complete002 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known002,affine_alpha_known003,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known002,affine_alpha_known004,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known002,affine_alpha_known005,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_alpha_node003 a ha world h nextB nextState
    · exact affine_alpha_node004 a ha world h nextB nextState
    · exact affine_alpha_node005 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node001 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known001 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known001 a) ((1 : Int),(0 : Int)) (affine_alpha_branches001 a) copies separate cover ceiling
    (affine_alpha_nonnegative001 a ha) (affine_alpha_window001 a ha world h B state)
    (affine_alpha_empty001 a ha) (affine_alpha_complete001 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches001,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known001,affine_alpha_known002,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known001,affine_alpha_known021,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known001,affine_alpha_known027,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known001,affine_alpha_known043,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known001,affine_alpha_known044,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches001,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node002 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node021 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node027 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node043 a ha world h nextB nextState
    · exact affine_alpha_node044 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_alpha_node000 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_alpha_known000 a)) B) : Transition world h .alpha B := by
  apply replay_affine_step a (by omega) world h .alpha (affine_alpha_known000 a) ((0 : Int),(0 : Int)) (affine_alpha_branches000 a) copies separate cover ceiling
    (affine_alpha_nonnegative000 a ha) (affine_alpha_window000 a ha world h B state)
    (affine_alpha_empty000 a ha) (affine_alpha_complete000 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_alpha_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known001,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known047,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known066,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known072,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known089,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_alpha_known000,affine_alpha_known135,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_alpha_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_alpha_node001 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node047 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node066 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node072 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node089 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_alpha_node135 a ha world h copies separate cover ceiling nextB nextState
end AffineAlpha

theorem affine_alpha_seed_eq (a : Int) : SameCells (seed .alpha) (knownCells (affine_alpha_known000 a)) := by
  change SameCells (seed .alpha) (knownCells (affine_alpha_known000 (0 : Int)))
  decide

theorem affine_alpha_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .alpha 0 0 B) : Transition world h .alpha B := by
  exact affine_alpha_node000 a ha world h copies separate cover ceiling B
    (state_congr (affine_alpha_seed_eq a) (seed_state world h .alpha B closed bounded clean))
#print axioms affine_alpha_local

end CornerCertificate

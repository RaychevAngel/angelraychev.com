import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedGeometryDefs
import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedGeometryChunk007
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node513 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap8_9 : Apart (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht8 ht9
  have support : HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b (5 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_point a b ((by simpa only [HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box,HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M] using absent)) (hb) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (5 : Int) (4 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (4 : Int) ∨ Contains (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_empty a b ((by simpa only [LRegionArithmetic.fact_366edf150095_2905, LRegionArithmetic.fact_366edf150095_2577, LRegionArithmetic.fact_366edf150095_4066, LRegionArithmetic.fact_366edf150095_4071, LRegionArithmetic.fact_366edf150095_2580, LRegionArithmetic.fact_366edf150095_3180, LRegionArithmetic.fact_366edf150095_3186, LRegionArithmetic.fact_366edf150095_3182, LRegionArithmetic.fact_366edf150095_2585, LRegionArithmetic.fact_366edf150095_3191, Contains] using occupied)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8
  have pairAllowed9 := avoidPair t (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht ht9
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o0 a b jx jy (hit) (sep6).2.1 (sep8).2.2.1 (insideT) (sep7).2.1 (hb) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((4 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o1 a b jx jy (sep8).2.2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hb) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node514 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o2 a b jx jy (sep5).2.2.1 (ap4_5).1 (hb) (allowed) (hit) (sep9).2.1 (insideT) (hdelta_two) (hlong) (ha) (hstrict) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o3 a b jx jy (hit) (hb) (sep4).2.2.1 (sep7).2.1 (sep6).2.1 (sep9).2.1 (hdelta_two) (insideT) (hlong) (ha) (hstrict) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o4 a b jx jy (hit) (sep9).2.1 (insideT) (hlong) (hb) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o5 a b jx jy (hit) (sep1).1 (hb) (insideT) (sep4).2.1 (sep6).2.1 (sep7).2.1 (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o6 a b jx jy (hit) (sep8).2.2.1 (sep9).2.1 (insideT) (hlong) (hdelta_two) (sep7).2.1 (hb) (ha) (hstrict) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n513_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep6).2.1 (sep8).2.2.1 (insideT) (hit) (sep4).2.2.1 (hdelta_two) (hlong) (hb) (ha) (hstrict) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node516 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node517 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int))] (5 : Int) ((2 : Int) + a) (5 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_short a b (hdelta_two) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_empty a b run_x (hlong) (hx0) ((by simpa only [LRegionArithmetic.fact_366edf150095_2377, LRegionArithmetic.fact_366edf150095_2312, LRegionArithmetic.fact_366edf150095_3520, LRegionArithmetic.fact_366edf150095_3535, LRegionArithmetic.fact_366edf150095_2317, LRegionArithmetic.fact_366edf150095_2959, LRegionArithmetic.fact_366edf150095_2986, LRegionArithmetic.fact_366edf150095_2964, LRegionArithmetic.fact_366edf150095_2328, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_floor a b run_x (hx1) ((by simpa only [LRegionArithmetic.fact_366edf150095_3351, LRegionArithmetic.fact_366edf150095_3300, LRegionArithmetic.fact_366edf150095_5215, LRegionArithmetic.fact_366edf150095_5225, LRegionArithmetic.fact_366edf150095_3310, LRegionArithmetic.fact_366edf150095_3530, LRegionArithmetic.fact_366edf150095_3566, LRegionArithmetic.fact_366edf150095_3544, LRegionArithmetic.fact_366edf150095_3327, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hdelta_two) (hx0) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_left a b ((by simpa only [LRegionArithmetic.fact_366edf150095_3504, LRegionArithmetic.fact_366edf150095_3453, LRegionArithmetic.fact_366edf150095_5780, LRegionArithmetic.fact_366edf150095_5788, LRegionArithmetic.fact_366edf150095_3461, LRegionArithmetic.fact_366edf150095_3699, LRegionArithmetic.fact_366edf150095_3469, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_right a b ((by simpa only [LRegionArithmetic.fact_366edf150095_4119, LRegionArithmetic.fact_366edf150095_3714, LRegionArithmetic.fact_366edf150095_5865, LRegionArithmetic.fact_366edf150095_26, LRegionArithmetic.fact_366edf150095_237, LRegionArithmetic.fact_366edf150095_5948, LRegionArithmetic.fact_366edf150095_109, LRegionArithmetic.fact_366edf150095_324, LRegionArithmetic.fact_366edf150095_3795, LRegionArithmetic.fact_366edf150095_4228, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n517_run_tall a b ((by simpa only [LRegionArithmetic.fact_366edf150095_7366, LRegionArithmetic.fact_366edf150095_4161, LRegionArithmetic.fact_366edf150095_3756, LRegionArithmetic.fact_366edf150095_5907, LRegionArithmetic.fact_366edf150095_68, LRegionArithmetic.fact_366edf150095_279, LRegionArithmetic.fact_366edf150095_5990, LRegionArithmetic.fact_366edf150095_151, LRegionArithmetic.fact_366edf150095_366, LRegionArithmetic.fact_366edf150095_3837, LRegionArithmetic.fact_366edf150095_4270, LRegionArithmetic.fact_366edf150095_4653, LRegionArithmetic.fact_366edf150095_4340, LRegionArithmetic.fact_366edf150095_3941, LRegionArithmetic.fact_366edf150095_3989, LRegionArithmetic.fact_366edf150095_7428, LRegionArithmetic.fact_366edf150095_5123, LRegionArithmetic.fact_366edf150095_4417, LRegionArithmetic.fact_366edf150095_6342, LRegionArithmetic.fact_366edf150095_979, LRegionArithmetic.fact_366edf150095_1239, LRegionArithmetic.fact_366edf150095_6430, LRegionArithmetic.fact_366edf150095_1067, LRegionArithmetic.fact_366edf150095_1327, LRegionArithmetic.fact_366edf150095_4501, LRegionArithmetic.fact_366edf150095_5251, LRegionArithmetic.fact_366edf150095_5436, LRegionArithmetic.fact_366edf150095_5350, LRegionArithmetic.fact_366edf150095_4701, LRegionArithmetic.fact_366edf150095_4841, LRegionArithmetic.fact_366edf150095_4160, LRegionArithmetic.fact_366edf150095_3755, LRegionArithmetic.fact_366edf150095_5906, LRegionArithmetic.fact_366edf150095_67, LRegionArithmetic.fact_366edf150095_278, LRegionArithmetic.fact_366edf150095_5989, LRegionArithmetic.fact_366edf150095_150, LRegionArithmetic.fact_366edf150095_365, LRegionArithmetic.fact_366edf150095_3836, LRegionArithmetic.fact_366edf150095_4269, LRegionArithmetic.fact_366edf150095_4652, LRegionArithmetic.fact_366edf150095_4339, LRegionArithmetic.fact_366edf150095_3940, LRegionArithmetic.fact_366edf150095_3988, LRegionArithmetic.fact_366edf150095_5122, LRegionArithmetic.fact_366edf150095_4416, LRegionArithmetic.fact_366edf150095_6341, LRegionArithmetic.fact_366edf150095_978, LRegionArithmetic.fact_366edf150095_1238, LRegionArithmetic.fact_366edf150095_6429, LRegionArithmetic.fact_366edf150095_1066, LRegionArithmetic.fact_366edf150095_1326, LRegionArithmetic.fact_366edf150095_4500, LRegionArithmetic.fact_366edf150095_5250, LRegionArithmetic.fact_366edf150095_5349, LRegionArithmetic.fact_366edf150095_4700, LRegionArithmetic.fact_366edf150095_4840, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ap4_5).1 (hexception) (hb) (hlong) (ha) (hdelta_two)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node518 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap8_9 : Apart (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b)] ((4 : Int) + a) ((-1 : Int) + ((2 : Int) * a)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hdelta_two) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_empty a b run_x (hx0) (hx1) (hlong) (hb) ((by simpa only [LRegionArithmetic.fact_366edf150095_2374, LRegionArithmetic.fact_366edf150095_2309, LRegionArithmetic.fact_366edf150095_3517, LRegionArithmetic.fact_366edf150095_3532, LRegionArithmetic.fact_366edf150095_2314, LRegionArithmetic.fact_366edf150095_2956, LRegionArithmetic.fact_366edf150095_2983, LRegionArithmetic.fact_366edf150095_2961, LRegionArithmetic.fact_366edf150095_2326, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_floor a b run_x ((by simpa only [LRegionArithmetic.fact_366edf150095_3348, LRegionArithmetic.fact_366edf150095_3297, LRegionArithmetic.fact_366edf150095_5212, LRegionArithmetic.fact_366edf150095_5222, LRegionArithmetic.fact_366edf150095_3307, LRegionArithmetic.fact_366edf150095_3527, LRegionArithmetic.fact_366edf150095_3563, LRegionArithmetic.fact_366edf150095_3541, LRegionArithmetic.fact_366edf150095_3325, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hdelta_two) (hx1) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_left a b ((by simpa only [LRegionArithmetic.fact_366edf150095_4124, LRegionArithmetic.fact_366edf150095_3719, LRegionArithmetic.fact_366edf150095_5870, LRegionArithmetic.fact_366edf150095_31, LRegionArithmetic.fact_366edf150095_242, LRegionArithmetic.fact_366edf150095_5953, LRegionArithmetic.fact_366edf150095_114, LRegionArithmetic.fact_366edf150095_329, LRegionArithmetic.fact_366edf150095_3800, LRegionArithmetic.fact_366edf150095_4233, LRegionArithmetic.fact_366edf150095_4632, LRegionArithmetic.fact_366edf150095_4320, LRegionArithmetic.fact_366edf150095_3924, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_right a b (hlong) ((by simpa only [LRegionArithmetic.fact_366edf150095_5847, LRegionArithmetic.fact_366edf150095_5832, LRegionArithmetic.fact_366edf150095_6955, LRegionArithmetic.fact_366edf150095_2291, LRegionArithmetic.fact_366edf150095_2300, LRegionArithmetic.fact_366edf150095_6958, LRegionArithmetic.fact_366edf150095_2294, LRegionArithmetic.fact_366edf150095_2303, LRegionArithmetic.fact_366edf150095_5835, LRegionArithmetic.fact_366edf150095_6130, LRegionArithmetic.fact_366edf150095_553, LRegionArithmetic.fact_366edf150095_580, LRegionArithmetic.fact_366edf150095_6160, LRegionArithmetic.fact_366edf150095_592, LRegionArithmetic.fact_366edf150095_657, LRegionArithmetic.fact_366edf150095_6138, LRegionArithmetic.fact_366edf150095_561, LRegionArithmetic.fact_366edf150095_597, LRegionArithmetic.fact_366edf150095_5840, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n518_run_tall a b (ap4_5).1 ((by simpa only [LRegionArithmetic.fact_366edf150095_7437, LRegionArithmetic.fact_366edf150095_5139, LRegionArithmetic.fact_366edf150095_4433, LRegionArithmetic.fact_366edf150095_6358, LRegionArithmetic.fact_366edf150095_995, LRegionArithmetic.fact_366edf150095_1255, LRegionArithmetic.fact_366edf150095_6446, LRegionArithmetic.fact_366edf150095_1083, LRegionArithmetic.fact_366edf150095_1343, LRegionArithmetic.fact_366edf150095_4517, LRegionArithmetic.fact_366edf150095_5267, LRegionArithmetic.fact_366edf150095_5446, LRegionArithmetic.fact_366edf150095_5356, LRegionArithmetic.fact_366edf150095_4710, LRegionArithmetic.fact_366edf150095_5582, LRegionArithmetic.fact_366edf150095_7619, LRegionArithmetic.fact_366edf150095_6203, LRegionArithmetic.fact_366edf150095_704, LRegionArithmetic.fact_366edf150095_708, LRegionArithmetic.fact_366edf150095_6147, LRegionArithmetic.fact_366edf150095_570, LRegionArithmetic.fact_366edf150095_645, LRegionArithmetic.fact_366edf150095_7047, LRegionArithmetic.fact_366edf150095_2536, LRegionArithmetic.fact_366edf150095_2551, LRegionArithmetic.fact_366edf150095_7051, LRegionArithmetic.fact_366edf150095_2540, LRegionArithmetic.fact_366edf150095_2555, LRegionArithmetic.fact_366edf150095_6151, LRegionArithmetic.fact_366edf150095_577, LRegionArithmetic.fact_366edf150095_649, LRegionArithmetic.fact_366edf150095_6633, LRegionArithmetic.fact_366edf150095_1559, LRegionArithmetic.fact_366edf150095_1615, LRegionArithmetic.fact_366edf150095_6689, LRegionArithmetic.fact_366edf150095_1626, LRegionArithmetic.fact_366edf150095_1733, LRegionArithmetic.fact_366edf150095_6657, LRegionArithmetic.fact_366edf150095_1583, LRegionArithmetic.fact_366edf150095_1644, LRegionArithmetic.fact_366edf150095_6168, LRegionArithmetic.fact_366edf150095_603, LRegionArithmetic.fact_366edf150095_667, LRegionArithmetic.fact_366edf150095_6703, LRegionArithmetic.fact_366edf150095_1664, LRegionArithmetic.fact_366edf150095_1750, LRegionArithmetic.fact_366edf150095_5138, LRegionArithmetic.fact_366edf150095_4432, LRegionArithmetic.fact_366edf150095_6357, LRegionArithmetic.fact_366edf150095_994, LRegionArithmetic.fact_366edf150095_1254, LRegionArithmetic.fact_366edf150095_6445, LRegionArithmetic.fact_366edf150095_1082, LRegionArithmetic.fact_366edf150095_1342, LRegionArithmetic.fact_366edf150095_4516, LRegionArithmetic.fact_366edf150095_5266, LRegionArithmetic.fact_366edf150095_5445, LRegionArithmetic.fact_366edf150095_5355, LRegionArithmetic.fact_366edf150095_4709, LRegionArithmetic.fact_366edf150095_5581, LRegionArithmetic.fact_366edf150095_6202, LRegionArithmetic.fact_366edf150095_703, LRegionArithmetic.fact_366edf150095_707, LRegionArithmetic.fact_366edf150095_6146, LRegionArithmetic.fact_366edf150095_569, LRegionArithmetic.fact_366edf150095_644, LRegionArithmetic.fact_366edf150095_7046, LRegionArithmetic.fact_366edf150095_2535, LRegionArithmetic.fact_366edf150095_2550, LRegionArithmetic.fact_366edf150095_7050, LRegionArithmetic.fact_366edf150095_2539, LRegionArithmetic.fact_366edf150095_2554, LRegionArithmetic.fact_366edf150095_6150, LRegionArithmetic.fact_366edf150095_576, LRegionArithmetic.fact_366edf150095_648, LRegionArithmetic.fact_366edf150095_6632, LRegionArithmetic.fact_366edf150095_1558, LRegionArithmetic.fact_366edf150095_1614, LRegionArithmetic.fact_366edf150095_6688, LRegionArithmetic.fact_366edf150095_1625, LRegionArithmetic.fact_366edf150095_1732, LRegionArithmetic.fact_366edf150095_6656, LRegionArithmetic.fact_366edf150095_1582, LRegionArithmetic.fact_366edf150095_1643, LRegionArithmetic.fact_366edf150095_6167, LRegionArithmetic.fact_366edf150095_602, LRegionArithmetic.fact_366edf150095_666, LRegionArithmetic.fact_366edf150095_6702, LRegionArithmetic.fact_366edf150095_1663, LRegionArithmetic.fact_366edf150095_1749, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hdelta_two) (hexception) (hlong) (hstrict) (ha)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node509 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have support : HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b (4 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_point a b (hb) ((by simpa only [HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box,HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M] using absent)) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_empty a b ((by simpa only [LRegionArithmetic.fact_366edf150095_2903, LRegionArithmetic.fact_366edf150095_2572, LRegionArithmetic.fact_366edf150095_4059, LRegionArithmetic.fact_366edf150095_4062, LRegionArithmetic.fact_366edf150095_2574, LRegionArithmetic.fact_366edf150095_3173, Contains] using occupied)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o0 a b jx jy (insideT) (sep8).2.2.1 (sep6).2.1 (hit) (hb) (sep7).2.1 (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((4 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o1 a b jx jy (hit) (sep8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node510 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o2 a b jx jy (hit) (sep8).2.1 (insideT) (allowed) (hexception) (hdelta_two) (ap4_5).1 (hlong) (hb) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (4 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o3 a b jx jy (sep4).2.1 (hlong) (sep1).2.2.1 (sep8).2.1 (hdelta_two) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (ha) (hb) (hstrict) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node512 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((4 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o4 a b jx jy (sep8).2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (hit) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node513 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o5 a b jx jy (sep8).2.2.1 (sep8).2.1 (ap4_5).1 (sep7).2.2.1 (hdelta_two) (hlong) (sep6).2.1 (hit) (insideT) (hb) (sep7).2.1 (ha) (hstrict) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (4 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o6 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep8).2.1 (hlong) (hit) (sep8).2.2.1 (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node517 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((4 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n509_o7 a b jx jy (insideT) (hit) (sep8).2.2.1 (sep6).2.1 (sep4).2.2.1 (hlong) (hb) ((by simpa only [Same,eq_comm] using absent)) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node518 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node519 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht8
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b)] (3 : Int) a (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_short a b (hdelta_two) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_empty a b run_x (hx1) (hx0) ((by simpa only [LRegionArithmetic.fact_366edf150095_2379, LRegionArithmetic.fact_366edf150095_2342, LRegionArithmetic.fact_366edf150095_3617, LRegionArithmetic.fact_366edf150095_3618, LRegionArithmetic.fact_366edf150095_2343, LRegionArithmetic.fact_366edf150095_3038, LRegionArithmetic.fact_366edf150095_3039, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hdelta_two) (ha) (hb) (hstrict) (hexception)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_floor a b run_x (hx0) (hdelta_two) (hx1) ((by simpa only [LRegionArithmetic.fact_366edf150095_3343, LRegionArithmetic.fact_366edf150095_3292, LRegionArithmetic.fact_366edf150095_5207, LRegionArithmetic.fact_366edf150095_5217, LRegionArithmetic.fact_366edf150095_3302, LRegionArithmetic.fact_366edf150095_3522, LRegionArithmetic.fact_366edf150095_3569, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_left a b ((by simpa only [LRegionArithmetic.fact_366edf150095_3508, LRegionArithmetic.fact_366edf150095_3474, LRegionArithmetic.fact_366edf150095_5809, LRegionArithmetic.fact_366edf150095_5810, LRegionArithmetic.fact_366edf150095_3475, LRegionArithmetic.fact_366edf150095_4060, LRegionArithmetic.fact_366edf150095_4064, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_right a b (hdelta_two) ((by simpa only [LRegionArithmetic.fact_366edf150095_3234, LRegionArithmetic.fact_366edf150095_3175, LRegionArithmetic.fact_366edf150095_5096, LRegionArithmetic.fact_366edf150095_5097, LRegionArithmetic.fact_366edf150095_3176, LRegionArithmetic.fact_366edf150095_3428, LRegionArithmetic.fact_366edf150095_3429, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ap4_5).1 (hlong) (ha) (hb) (hstrict) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n519_run_tall a b (ap4_5).1 ((by simpa only [LRegionArithmetic.fact_366edf150095_7342, LRegionArithmetic.fact_366edf150095_4142, LRegionArithmetic.fact_366edf150095_3737, LRegionArithmetic.fact_366edf150095_5888, LRegionArithmetic.fact_366edf150095_49, LRegionArithmetic.fact_366edf150095_260, LRegionArithmetic.fact_366edf150095_5971, LRegionArithmetic.fact_366edf150095_132, LRegionArithmetic.fact_366edf150095_347, LRegionArithmetic.fact_366edf150095_3818, LRegionArithmetic.fact_366edf150095_4251, LRegionArithmetic.fact_366edf150095_4640, LRegionArithmetic.fact_366edf150095_4325, LRegionArithmetic.fact_366edf150095_4735, LRegionArithmetic.fact_366edf150095_7313, LRegionArithmetic.fact_366edf150095_3439, LRegionArithmetic.fact_366edf150095_3363, LRegionArithmetic.fact_366edf150095_5235, LRegionArithmetic.fact_366edf150095_5330, LRegionArithmetic.fact_366edf150095_3374, LRegionArithmetic.fact_366edf150095_3631, LRegionArithmetic.fact_366edf150095_3654, LRegionArithmetic.fact_366edf150095_3642, LRegionArithmetic.fact_366edf150095_3668, LRegionArithmetic.fact_366edf150095_4140, LRegionArithmetic.fact_366edf150095_3735, LRegionArithmetic.fact_366edf150095_5886, LRegionArithmetic.fact_366edf150095_47, LRegionArithmetic.fact_366edf150095_258, LRegionArithmetic.fact_366edf150095_5969, LRegionArithmetic.fact_366edf150095_130, LRegionArithmetic.fact_366edf150095_345, LRegionArithmetic.fact_366edf150095_3816, LRegionArithmetic.fact_366edf150095_4249, LRegionArithmetic.fact_366edf150095_4324, LRegionArithmetic.fact_366edf150095_4733, LRegionArithmetic.fact_366edf150095_3438, LRegionArithmetic.fact_366edf150095_3362, LRegionArithmetic.fact_366edf150095_5234, LRegionArithmetic.fact_366edf150095_5329, LRegionArithmetic.fact_366edf150095_3373, LRegionArithmetic.fact_366edf150095_3630, LRegionArithmetic.fact_366edf150095_3641, LRegionArithmetic.fact_366edf150095_3667, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hdelta_two) (hlong) (hb) (ha) (hexception)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node493 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have support : HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_point a b ((by simpa only [HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box,HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M] using absent)) (hlong) (hb) (ha) (hstrict) (hdelta_two) (hexception)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_empty a b ((by simpa only [LRegionArithmetic.fact_366edf150095_2892, LRegionArithmetic.fact_366edf150095_2569, LRegionArithmetic.fact_366edf150095_4056, LRegionArithmetic.fact_366edf150095_4057, LRegionArithmetic.fact_366edf150095_2570, LRegionArithmetic.fact_366edf150095_3165, Contains] using occupied)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o0 a b jx jy (sep7).2.1 (sep6).2.1 (hit) (sep7).2.2.1 (hb) (insideT) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o1 a b jx jy (insideT) (sep7).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node494 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hb) (sep7).2.2.1 (hit) (allowed) (hlong) (insideT) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node497 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o3 a b jx jy (sep7).2.2.1 (sep6).2.1 (hit) (hb) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node503 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o4 a b jx jy (hit) (insideT) (sep7).2.2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node504 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o5 a b jx jy (sep7).2.2.1 (hb) (sep7).2.2.2 (hit) (sep6).2.1 (insideT) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o6 a b jx jy (hb) (sep7).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (hit) (sep6).2.1 (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node509 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o7 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (insideT) (hlong) (allowed) (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node519 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node520 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6 ht7
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b), (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int))] ((2 : Int) + a) ((-1 : Int) + ((2 : Int) * a)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_four a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hdelta_two) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_empty a b run_x (hlong) (ap4_5).1 ((by simpa only [LRegionArithmetic.fact_366edf150095_2374, LRegionArithmetic.fact_366edf150095_2309, LRegionArithmetic.fact_366edf150095_3517, LRegionArithmetic.fact_366edf150095_3532, LRegionArithmetic.fact_366edf150095_2314, LRegionArithmetic.fact_366edf150095_2956, LRegionArithmetic.fact_366edf150095_2983, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hx0) (hx1) (ha) (hstrict) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_floor a b run_x ((by simpa only [LRegionArithmetic.fact_366edf150095_3348, LRegionArithmetic.fact_366edf150095_3297, LRegionArithmetic.fact_366edf150095_5212, LRegionArithmetic.fact_366edf150095_5222, LRegionArithmetic.fact_366edf150095_3307, LRegionArithmetic.fact_366edf150095_3527, LRegionArithmetic.fact_366edf150095_3563, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hx1) (hdelta_two) (ha) (hb) (hstrict) (hlong) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_left a b ((by simpa only [LRegionArithmetic.fact_366edf150095_4120, LRegionArithmetic.fact_366edf150095_3715, LRegionArithmetic.fact_366edf150095_5866, LRegionArithmetic.fact_366edf150095_27, LRegionArithmetic.fact_366edf150095_238, LRegionArithmetic.fact_366edf150095_5949, LRegionArithmetic.fact_366edf150095_110, LRegionArithmetic.fact_366edf150095_325, LRegionArithmetic.fact_366edf150095_3796, LRegionArithmetic.fact_366edf150095_4229, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hdelta_two) (hlong) (ha) (hb) (hstrict) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_right a b ((by simpa only [LRegionArithmetic.fact_366edf150095_5847, LRegionArithmetic.fact_366edf150095_5832, LRegionArithmetic.fact_366edf150095_6955, LRegionArithmetic.fact_366edf150095_2291, LRegionArithmetic.fact_366edf150095_2300, LRegionArithmetic.fact_366edf150095_6958, LRegionArithmetic.fact_366edf150095_2294, LRegionArithmetic.fact_366edf150095_2303, LRegionArithmetic.fact_366edf150095_5835, LRegionArithmetic.fact_366edf150095_6130, LRegionArithmetic.fact_366edf150095_553, LRegionArithmetic.fact_366edf150095_580, LRegionArithmetic.fact_366edf150095_6160, LRegionArithmetic.fact_366edf150095_592, LRegionArithmetic.fact_366edf150095_657, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n520_run_tall a b (hstrict) (hb) (hlong) (ap4_5).1 ((by simpa only [LRegionArithmetic.fact_366edf150095_7319, LRegionArithmetic.fact_366edf150095_5127, LRegionArithmetic.fact_366edf150095_4421, LRegionArithmetic.fact_366edf150095_6346, LRegionArithmetic.fact_366edf150095_983, LRegionArithmetic.fact_366edf150095_1243, LRegionArithmetic.fact_366edf150095_6434, LRegionArithmetic.fact_366edf150095_1071, LRegionArithmetic.fact_366edf150095_1331, LRegionArithmetic.fact_366edf150095_4505, LRegionArithmetic.fact_366edf150095_5255, LRegionArithmetic.fact_366edf150095_5438, LRegionArithmetic.fact_366edf150095_4704, LRegionArithmetic.fact_366edf150095_7364, LRegionArithmetic.fact_366edf150095_6203, LRegionArithmetic.fact_366edf150095_704, LRegionArithmetic.fact_366edf150095_708, LRegionArithmetic.fact_366edf150095_6147, LRegionArithmetic.fact_366edf150095_570, LRegionArithmetic.fact_366edf150095_645, LRegionArithmetic.fact_366edf150095_7047, LRegionArithmetic.fact_366edf150095_2536, LRegionArithmetic.fact_366edf150095_2551, LRegionArithmetic.fact_366edf150095_7051, LRegionArithmetic.fact_366edf150095_2540, LRegionArithmetic.fact_366edf150095_2555, LRegionArithmetic.fact_366edf150095_6151, LRegionArithmetic.fact_366edf150095_577, LRegionArithmetic.fact_366edf150095_649, LRegionArithmetic.fact_366edf150095_6633, LRegionArithmetic.fact_366edf150095_1559, LRegionArithmetic.fact_366edf150095_1615, LRegionArithmetic.fact_366edf150095_6689, LRegionArithmetic.fact_366edf150095_1626, LRegionArithmetic.fact_366edf150095_1733, LRegionArithmetic.fact_366edf150095_6166, LRegionArithmetic.fact_366edf150095_601, LRegionArithmetic.fact_366edf150095_664, LRegionArithmetic.fact_366edf150095_5126, LRegionArithmetic.fact_366edf150095_4420, LRegionArithmetic.fact_366edf150095_6345, LRegionArithmetic.fact_366edf150095_982, LRegionArithmetic.fact_366edf150095_1242, LRegionArithmetic.fact_366edf150095_6433, LRegionArithmetic.fact_366edf150095_1070, LRegionArithmetic.fact_366edf150095_1330, LRegionArithmetic.fact_366edf150095_4504, LRegionArithmetic.fact_366edf150095_5254, LRegionArithmetic.fact_366edf150095_5437, LRegionArithmetic.fact_366edf150095_4703, LRegionArithmetic.fact_366edf150095_6202, LRegionArithmetic.fact_366edf150095_703, LRegionArithmetic.fact_366edf150095_707, LRegionArithmetic.fact_366edf150095_6146, LRegionArithmetic.fact_366edf150095_569, LRegionArithmetic.fact_366edf150095_644, LRegionArithmetic.fact_366edf150095_7046, LRegionArithmetic.fact_366edf150095_2535, LRegionArithmetic.fact_366edf150095_2550, LRegionArithmetic.fact_366edf150095_7050, LRegionArithmetic.fact_366edf150095_2539, LRegionArithmetic.fact_366edf150095_2554, LRegionArithmetic.fact_366edf150095_6150, LRegionArithmetic.fact_366edf150095_576, LRegionArithmetic.fact_366edf150095_648, LRegionArithmetic.fact_366edf150095_6632, LRegionArithmetic.fact_366edf150095_1558, LRegionArithmetic.fact_366edf150095_1614, LRegionArithmetic.fact_366edf150095_6688, LRegionArithmetic.fact_366edf150095_1625, LRegionArithmetic.fact_366edf150095_1732, LRegionArithmetic.fact_366edf150095_6165, LRegionArithmetic.fact_366edf150095_600, LRegionArithmetic.fact_366edf150095_662, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hexception) (ha) (hdelta_two)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node521 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_7 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht7
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b), (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b)] (2 : Int) ((1 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_empty a b run_x ((by simpa only [LRegionArithmetic.fact_366edf150095_2379, LRegionArithmetic.fact_366edf150095_2342, LRegionArithmetic.fact_366edf150095_3617, LRegionArithmetic.fact_366edf150095_3618, LRegionArithmetic.fact_366edf150095_2343, LRegionArithmetic.fact_366edf150095_3038, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hlong) (hx0) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_floor a b run_x (hx1) ((by simpa only [LRegionArithmetic.fact_366edf150095_3343, LRegionArithmetic.fact_366edf150095_3292, LRegionArithmetic.fact_366edf150095_5207, LRegionArithmetic.fact_366edf150095_5217, LRegionArithmetic.fact_366edf150095_3302, LRegionArithmetic.fact_366edf150095_3522, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (ha) (hb) (hstrict) (hlong) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n521_run_tall a b ((by simpa only [LRegionArithmetic.fact_366edf150095_7308, LRegionArithmetic.fact_366edf150095_4141, LRegionArithmetic.fact_366edf150095_3736, LRegionArithmetic.fact_366edf150095_5887, LRegionArithmetic.fact_366edf150095_48, LRegionArithmetic.fact_366edf150095_259, LRegionArithmetic.fact_366edf150095_5970, LRegionArithmetic.fact_366edf150095_131, LRegionArithmetic.fact_366edf150095_346, LRegionArithmetic.fact_366edf150095_3817, LRegionArithmetic.fact_366edf150095_4250, LRegionArithmetic.fact_366edf150095_4639, LRegionArithmetic.fact_366edf150095_4734, LRegionArithmetic.fact_366edf150095_7330, LRegionArithmetic.fact_366edf150095_5174, LRegionArithmetic.fact_366edf150095_4468, LRegionArithmetic.fact_366edf150095_6393, LRegionArithmetic.fact_366edf150095_1030, LRegionArithmetic.fact_366edf150095_1290, LRegionArithmetic.fact_366edf150095_6481, LRegionArithmetic.fact_366edf150095_1118, LRegionArithmetic.fact_366edf150095_1378, LRegionArithmetic.fact_366edf150095_4552, LRegionArithmetic.fact_366edf150095_5302, LRegionArithmetic.fact_366edf150095_5469, LRegionArithmetic.fact_366edf150095_5505, LRegionArithmetic.fact_366edf150095_4139, LRegionArithmetic.fact_366edf150095_3734, LRegionArithmetic.fact_366edf150095_5885, LRegionArithmetic.fact_366edf150095_46, LRegionArithmetic.fact_366edf150095_257, LRegionArithmetic.fact_366edf150095_5968, LRegionArithmetic.fact_366edf150095_129, LRegionArithmetic.fact_366edf150095_344, LRegionArithmetic.fact_366edf150095_3815, LRegionArithmetic.fact_366edf150095_4248, LRegionArithmetic.fact_366edf150095_4732, LRegionArithmetic.fact_366edf150095_5172, LRegionArithmetic.fact_366edf150095_4466, LRegionArithmetic.fact_366edf150095_6391, LRegionArithmetic.fact_366edf150095_1028, LRegionArithmetic.fact_366edf150095_1288, LRegionArithmetic.fact_366edf150095_6479, LRegionArithmetic.fact_366edf150095_1116, LRegionArithmetic.fact_366edf150095_1376, LRegionArithmetic.fact_366edf150095_4550, LRegionArithmetic.fact_366edf150095_5300, LRegionArithmetic.fact_366edf150095_5504, LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ap4_5).2.2.1 (hlong) (hstrict) (hb) (ha) (hdelta_two) (hexception)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node263 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have support : HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_point a b ((by simpa only [HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box,HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M] using absent)) (hb) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_empty a b (hlong) ((by simpa only [Contains] using occupied)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o0 a b jx jy (hb) (sep4).2.2.1 (hit) (insideT) (sep6).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node264 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o1 a b jx jy (hlong) (sep4).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node392 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o2 a b jx jy (hlong) (hit) (sep6).2.1 (insideT) (hb) (ha) (hstrict) (hdelta_two) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o3 a b jx jy (hdelta_two) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep6).2.1 (hlong) (sep1).2.1 (hit) (ha) (hb) (hstrict) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node403 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o4 a b jx jy (sep4).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (insideT) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node404 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o5 a b jx jy (sep6).2.1 (sep4).2.2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (hlong) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node493 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o6 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (sep4).2.2.1 (insideT) (hlong) (sep6).2.1 (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node520 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n263_o7 a b jx jy (hlong) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (sep4).2.2.1 (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node521 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have support : HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_point a b (hb) (hlong) ((by simpa only [HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box,HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M] using absent)) (ha) (hstrict) (hdelta_two) (hexception)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o0 a b jx jy (sep4).2.1 (sep4).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hdelta_two) (insideT) (hlong) (hb) (ha) (hstrict) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node001 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o1 a b jx jy (sep4).2.2.1 (hit) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node005 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o2 a b jx jy (hb) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep4).2.1 (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node263 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o3 a b jx jy (sep4).2.1 (hdelta_two) (ap4_5).1 (sep4).2.2.1 (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (ha) (hb) (hstrict) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node016 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep4).2.2.1 (insideT) (hit) (hlong) (ha) (hb) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node017 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o5 a b jx jy (hit) (hdelta_two) (sep4).2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep1).2.1 (sep2).1 (hb) (ap4_5).1 (hexception) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node076 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o6 a b jx jy (sep4).2.1 (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep4).2.2.1 (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node077 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n000_o7 a b jx jy (sep4).2.2.1 (insideT) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (hb) (ha) (hstrict) (hdelta_two) (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node262 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside t)
    (cover : ∀ x y, HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u)
    (anchor0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor4 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (anchor5 : world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) anchor0 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) anchor0 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) anchor1 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor1 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) anchor1 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) anchor1 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor2 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) anchor2 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) anchor2 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) anchor3 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) anchor3 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)) anchor4 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_optimized_unequal_mixed_nonexception_delta_two_pruned_node000 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover sep avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair anchor0 anchor1 anchor2 anchor3 anchor4 anchor5 rootap0_1 rootap0_2 rootap0_3 rootap0_4 rootap0_5 rootap1_2 rootap1_3 rootap1_4 rootap1_5 rootap2_3 rootap2_4 rootap2_5 rootap3_4 rootap3_5 rootap4_5

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor1 : T.world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor2 : T.world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor3 : T.world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor4 : T.world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (anchor5 : T.world (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair : ∀t u,T.world t → T.world u → ¬HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair a b t u := by
    intro t u ht hu bad
    rcases bad with bad | bad
    ·
      rcases bad with bad | bad
      ·
        rcases bad with bad | bad
        ·
          rcases bad with bad | bad
          ·
            exact avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T t u ht hu bad
          ·
            exact avoid_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
        ·
          exact avoid_same_short_bars a b (by omega) (by omega) T t u ht hu bad
      ·
        exact avoid_outward_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
    ·
      exact avoid_short_upright_long a b (by omega) (by omega) (by omega) T t u ht hu bad
  apply HP_optimized_unequal_mixed_nonexception_delta_two_pruned_bounded_obstruction a b ha hb hstrict hlong hdelta_two hexception T.world T.copies ?_ ?_ T.disjoint (LRunCertificates.tiling_extended_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_down_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_right_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_left_run_obstruction (by omega) (by omega) T) avoid avoidPair anchor0 anchor1 anchor2 anchor3 anchor4 anchor5
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor2 : T.world (shift p 0 (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int))))
    (anchor3 : T.world (shift p 0 (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor4 : T.world (shift p 0 (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int))))
    (anchor5 : T.world (shift p 0 (Cross.mk ((2 : Int) * a) (1 : Int) (0 : Int) a b (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_optimized_unequal_mixed_nonexception_delta_two_pruned_anchored_obstruction a b ha hb hstrict hlong hdelta_two hexception U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor2,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor3,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor4,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor5,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
end PolyominoFormal.LRegion

import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h4 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (fact_9fdb227ae99d_1986 a b jx jy))
    (h8 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : ((jx < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1991 a b jx jy))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h11 : (fact_9fdb227ae99d_2923 a b jy))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1995 a b jx jy))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1998 a b jx jy))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1999 a b jx jy))
    (h7 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h8 : ((jx < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (fact_9fdb227ae99d_1994 a b jx jy))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_1990 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1987 a b jx jy))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_31 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3093 a b) ∨ (fact_9fdb227ae99d_3095 a b) ∨ (fact_9fdb227ae99d_3596 a b) ∨ (fact_9fdb227ae99d_5032 a b) ∨ (fact_9fdb227ae99d_3335 a b) ∨ (fact_9fdb227ae99d_3134 a b) ∨ (fact_9fdb227ae99d_3137 a b) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3097 a b) ∨ (fact_9fdb227ae99d_3337 a b) ∨ ((((-2 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((-2 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - b)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - b)) ∧ ((-2 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_3208 a b))
    (h4 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_1986 a b jx jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : ((jx < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h9 : (fact_9fdb227ae99d_1991 a b jx jy))
    (h10 : ((jy - a) ≥ (0 : Int)))
    (h11 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h7 : (fact_9fdb227ae99d_1995 a b jx jy))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_2924 a b jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_1998 a b jx jy))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1999 a b jx jy))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1994 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_1990 a b jx jy))
    (h6 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n504_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1987 a b jx jy))
    (h2 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5688 a b) ∨ (fact_9fdb227ae99d_5701 a b) ∨ (fact_9fdb227ae99d_6369 a b) ∨ (fact_9fdb227ae99d_6965 a b) ∨ (fact_9fdb227ae99d_5995 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5772 a b) ∨ (fact_9fdb227ae99d_5777 a b) ∨ (fact_9fdb227ae99d_5708 a b) ∨ (fact_9fdb227ae99d_6119 a b) ∨ (fact_9fdb227ae99d_6982 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b + a)) ∧ ((5 : Int) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6987 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (fact_9fdb227ae99d_3499 a b) ∨ (fact_9fdb227ae99d_3527 a b) ∨ (fact_9fdb227ae99d_3536 a b) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4529 a b) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_6887 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∨ (fact_9fdb227ae99d_7923 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_6887 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7923 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_6887 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7923 a b) ∧ (((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6867 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_6887 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7923 a b) ∧ ((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6867 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3048 a b run_x) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((-4 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n505_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + b + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3779 a b run_x) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((2 : Int) + a) ≤ (b + a))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((2 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((2 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3845 a b) ∨ (fact_9fdb227ae99d_3846 a b) ∨ (fact_9fdb227ae99d_5286 a b) ∨ (fact_9fdb227ae99d_5900 a b) ∨ (fact_9fdb227ae99d_4704 a b) ∨ (fact_9fdb227ae99d_4180 a b) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3847 a b) ∨ (fact_9fdb227ae99d_4705 a b) ∨ (fact_9fdb227ae99d_6129 a b) ∨ (fact_9fdb227ae99d_5346 a b) ∨ (fact_9fdb227ae99d_5901 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_right (a b : Int)
    (h0 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (¬ ((fact_9fdb227ae99d_3295 a b) ∨ (fact_9fdb227ae99d_3296 a b) ∨ (fact_9fdb227ae99d_4318 a b) ∨ (fact_9fdb227ae99d_5449 a b) ∨ (fact_9fdb227ae99d_3667 a b) ∨ (fact_9fdb227ae99d_3349 a b) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((1 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((2 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3297 a b) ∨ (fact_9fdb227ae99d_3668 a b) ∨ ((((1 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((1 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((1 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4400 a b) ∨ (fact_9fdb227ae99d_5450 a b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7915 a b) ∨ (fact_9fdb227ae99d_7834 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7915 a b) ∧ (fact_9fdb227ae99d_7834 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7915 a b) ∧ (fact_9fdb227ae99d_7834 a b) ∧ (((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4834 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∨ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((1 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((1 : Int) + a)) ∧ ((-2 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3700 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b)))) ∨ ((fact_9fdb227ae99d_7915 a b) ∧ (fact_9fdb227ae99d_7834 a b) ∧ ((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4834 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∧ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((1 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((1 : Int) + a)) ∧ ((-2 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3700 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b))))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + a) ≤ run_x))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (run_x ≤ (b + a)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_3206 a b))
    (h6 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h10 : ((fact_9fdb227ae99d_2431 a b run_x) ∨ (fact_9fdb227ae99d_2432 a b run_x) ∨ (fact_9fdb227ae99d_3059 a b run_x) ∨ (fact_9fdb227ae99d_3565 a b run_x) ∨ (fact_9fdb227ae99d_2974 a b run_x) ∨ (fact_9fdb227ae99d_2529 a b run_x) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2433 a b run_x) ∨ (fact_9fdb227ae99d_2975 a b run_x) ∨ (fact_9fdb227ae99d_3666 a b run_x) ∨ (fact_9fdb227ae99d_3117 a b run_x) ∨ (fact_9fdb227ae99d_3566 a b run_x)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n506_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (((2 : Int) + a) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (run_x ≤ (b + a)))
    (h4 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h5 : (¬ ((fact_9fdb227ae99d_3172 a b run_x) ∨ (fact_9fdb227ae99d_3182 a b run_x) ∨ (fact_9fdb227ae99d_3725 a b run_x) ∨ (fact_9fdb227ae99d_5190 a b run_x) ∨ (fact_9fdb227ae99d_3484 a b run_x) ∨ (fact_9fdb227ae99d_3210 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3192 a b run_x) ∨ (fact_9fdb227ae99d_3555 a b run_x) ∨ (fact_9fdb227ae99d_5358 a b run_x) ∨ (fact_9fdb227ae99d_3922 a b run_x) ∨ (fact_9fdb227ae99d_5261 a b run_x))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_short (a b : Int)
    (h0 : (¬ (((1 : Int) - (-3 : Int)) < b)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_nonnegative (a b : Int)
    (h0 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5874 a b) ∨ (fact_9fdb227ae99d_5877 a b) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5818 a b) ∨ (fact_9fdb227ae99d_6359 a b) ∨ (fact_9fdb227ae99d_6437 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-3 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7907 a b) ∨ (fact_9fdb227ae99d_7889 a b))) ∨ (((1 : Int) ≥ ((-3 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7907 a b) ∧ (fact_9fdb227ae99d_7889 a b)) ∨ ((1 : Int) ≥ ((-3 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7907 a b) ∧ (fact_9fdb227ae99d_7889 a b) ∧ (((fact_9fdb227ae99d_6445 a b) ∨ (fact_9fdb227ae99d_6459 a b) ∨ (fact_9fdb227ae99d_6955 a b) ∨ (fact_9fdb227ae99d_7133 a b) ∨ (fact_9fdb227ae99d_6851 a b) ∨ (fact_9fdb227ae99d_6501 a b) ∨ (fact_9fdb227ae99d_6523 a b) ∨ (fact_9fdb227ae99d_6527 a b) ∨ (fact_9fdb227ae99d_6468 a b) ∨ (fact_9fdb227ae99d_6875 a b) ∨ (fact_9fdb227ae99d_6893 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6429 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b)))) ∨ ((fact_9fdb227ae99d_7907 a b) ∧ (fact_9fdb227ae99d_7889 a b) ∧ ((fact_9fdb227ae99d_6445 a b) ∨ (fact_9fdb227ae99d_6459 a b) ∨ (fact_9fdb227ae99d_6955 a b) ∨ (fact_9fdb227ae99d_7133 a b) ∨ (fact_9fdb227ae99d_6851 a b) ∨ (fact_9fdb227ae99d_6501 a b) ∨ (fact_9fdb227ae99d_6523 a b) ∨ (fact_9fdb227ae99d_6527 a b) ∨ (fact_9fdb227ae99d_6468 a b) ∨ (fact_9fdb227ae99d_6875 a b) ∨ (fact_9fdb227ae99d_6893 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6423 a b) ∨ (fact_9fdb227ae99d_6429 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_empty (a b run_x : Int)
    (h0 : ((-3 : Int) ≤ run_x))
    (h1 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4220 a b run_x) ∨ (fact_9fdb227ae99d_4280 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4125 a b run_x) ∨ (fact_9fdb227ae99d_5017 a b run_x) ∨ (fact_9fdb227ae99d_5094 a b run_x)))
    (h2 : ((1 : Int) ≥ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n507_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5670 a b run_x) ∨ (fact_9fdb227ae99d_5673 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5626 a b run_x) ∨ (fact_9fdb227ae99d_5957 a b run_x) ∨ (fact_9fdb227ae99d_6002 a b run_x))))
    (h1 : ((-3 : Int) ≤ run_x))
    (h2 : ((1 : Int) ≥ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3622 a b) ∨ (fact_9fdb227ae99d_3626 a b) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (fact_9fdb227ae99d_4390 a b) ∨ (fact_9fdb227ae99d_4485 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3166 a b) ∨ (fact_9fdb227ae99d_3170 a b) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (fact_9fdb227ae99d_3463 a b) ∨ (fact_9fdb227ae99d_3548 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7661 a b) ∨ (fact_9fdb227ae99d_7540 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7661 a b) ∧ (fact_9fdb227ae99d_7540 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7661 a b) ∧ (fact_9fdb227ae99d_7540 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4459 a b) ∨ (fact_9fdb227ae99d_4469 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3530 a b) ∨ (fact_9fdb227ae99d_3539 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b)))) ∨ ((fact_9fdb227ae99d_7661 a b) ∧ (fact_9fdb227ae99d_7540 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4459 a b) ∨ (fact_9fdb227ae99d_4469 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3530 a b) ∨ (fact_9fdb227ae99d_3539 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_empty (a b run_x : Int)
    (h0 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : (b = (5 : Int)))
    (h3 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((3 : Int) ≤ run_x))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2695 a b run_x) ∨ (fact_9fdb227ae99d_2714 a b run_x) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3036 a b run_x) ∨ (fact_9fdb227ae99d_3047 a b run_x)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n508_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3354 a b run_x) ∨ (fact_9fdb227ae99d_3359 a b run_x) ∨ (((((-3 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3721 a b run_x) ∨ (fact_9fdb227ae99d_3747 a b run_x))))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_29 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3128 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3132 a b)))
    (h1 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o2 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n509_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2925 a b jy))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4175 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_4179 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3344 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3348 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7801 a b) ∨ (fact_9fdb227ae99d_7711 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7801 a b) ∧ (fact_9fdb227ae99d_7711 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7801 a b) ∧ (fact_9fdb227ae99d_7711 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7801 a b) ∧ (fact_9fdb227ae99d_7711 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_empty (a b run_x : Int)
    (h0 : (((1 : Int) + a) ≤ run_x))
    (h1 : (run_x ≤ (b + a)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2520 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_2524 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_3207 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n510_run_floor (a b run_x : Int)
    (h0 : (((1 : Int) + a) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3232 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3253 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h5 : (b = (5 : Int)))
    (h6 : (run_x ≤ (b + a)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_2308 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_empty (a b : Int)
    (h0 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((fact_9fdb227ae99d_4314 a b) ∨ (fact_9fdb227ae99d_4315 a b) ∨ (fact_9fdb227ae99d_5447 a b) ∨ (fact_9fdb227ae99d_6127 a b) ∨ (fact_9fdb227ae99d_5103 a b) ∨ (fact_9fdb227ae99d_4395 a b) ∨ (fact_9fdb227ae99d_4396 a b) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((-1 : Int) + ((2 : Int) * b)))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4316 a b) ∨ (fact_9fdb227ae99d_5104 a b) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((2 : Int) * b)))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6314 a b)))
    (h2 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o0 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_3139 a b jx jy))
    (h3 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (fact_9fdb227ae99d_3142 a b jx jy))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_2924 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_3144 a b jx jy))
    (h8 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h9 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_3145 a b jx jy))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o4 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_3146 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_3143 a b jx jy))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_3141 a b jx jy))
    (h1 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n511_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h2 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_3140 a b jx jy))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_2925 a b jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_32 a b))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_empty (a b : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3149 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3662 a b)))
    (h4 : (fact_9fdb227ae99d_3206 a b))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o0 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b = (5 : Int)))
    (h10 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h1 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o3 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o4 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n512_o7 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h1 : (b = (5 : Int)))
    (h2 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (((jx + a) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_29 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3128 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3380 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o4 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h2 : (b = (5 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n513_o7 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4175 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_5034 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3344 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3722 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7813 a b) ∨ (fact_9fdb227ae99d_7732 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7813 a b) ∧ (fact_9fdb227ae99d_7732 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7813 a b) ∧ (fact_9fdb227ae99d_7732 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5510 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_4527 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7813 a b) ∧ (fact_9fdb227ae99d_7732 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5510 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_4527 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_3207 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (run_x ≤ (b + a)))
    (h5 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2520 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_3015 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h6 : (((1 : Int) + a) ≤ run_x))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n514_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3232 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3579 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (b = (5 : Int)))
    (h6 : (((1 : Int) + a) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_2308 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_empty (a b : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h1 : ((fact_9fdb227ae99d_4314 a b) ∨ (fact_9fdb227ae99d_4315 a b) ∨ (fact_9fdb227ae99d_5447 a b) ∨ (fact_9fdb227ae99d_6127 a b) ∨ (fact_9fdb227ae99d_5103 a b) ∨ (fact_9fdb227ae99d_4395 a b) ∨ (fact_9fdb227ae99d_4396 a b) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((-1 : Int) + ((2 : Int) * b)))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4316 a b) ∨ (fact_9fdb227ae99d_5104 a b) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6314 a b)))
    (h2 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h1 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_3139 a b jx jy))
    (h6 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_3142 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o2 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_3144 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_2924 a b jy))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_3145 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o4 (a b jx jy : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_3146 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h9 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (fact_9fdb227ae99d_3143 a b jx jy))
    (h10 : (((jx + (0 : Int)) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h11 : (b = (5 : Int)))
    (h12 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h13 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_3141 a b jx jy))
    (h8 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n515_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_3140 a b jx jy))
    (h1 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_32 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3149 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3662 a b)))
    (h1 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_3206 a b))
    (h4 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o0 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h9 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o1 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_2923 a b jy))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((jx + (0 : Int)) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h4 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o6 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n516_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h6 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h7 : (((jx + a) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_29 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_empty (a b : Int)
    (h0 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3128 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3131 a b)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o0 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((jx < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h6 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o1 (a b jx jy : Int)
    (h0 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h7 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n517_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4175 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_4178 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3344 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3347 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7800 a b) ∨ (fact_9fdb227ae99d_7710 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7800 a b) ∧ (fact_9fdb227ae99d_7710 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7800 a b) ∧ (fact_9fdb227ae99d_7710 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4926 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3712 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7800 a b) ∧ (fact_9fdb227ae99d_7710 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4926 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3712 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_3207 a b))
    (h4 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2520 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_2523 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h5 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((1 : Int) + a) ≤ run_x))
    (h8 : (run_x ≤ (b + a)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n518_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3232 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3251 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h1 : (((1 : Int) + a) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (run_x ≤ (b + a)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_32 a b))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_empty (a b : Int)
    (h0 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_9fdb227ae99d_3478 a b))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3149 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ ((-4 : Int) - a)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_2923 a b jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - b))))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (fact_9fdb227ae99d_2924 a b jy))
    (h10 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h10 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h11 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h10 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h11 : (b = (5 : Int)))
    (h12 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h13 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h14 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < (jy - a))))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h7 : (b = (5 : Int)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n519_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_32 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3149 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ ((-4 : Int) - a)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3662 a b)))
    (h1 : (fact_9fdb227ae99d_3206 a b))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o0 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h6 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o2 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h10 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h11 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h7 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o6 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n520_o7 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (fact_9fdb227ae99d_5757 a b) ∨ (fact_9fdb227ae99d_5771 a b) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (fact_9fdb227ae99d_6118 a b) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3498 a b) ∨ (fact_9fdb227ae99d_3526 a b) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_4143 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7869 a b) ∨ (fact_9fdb227ae99d_7650 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7869 a b) ∧ (fact_9fdb227ae99d_7650 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7869 a b) ∧ (fact_9fdb227ae99d_7650 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6214 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_6295 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6647 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_4286 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7869 a b) ∧ (fact_9fdb227ae99d_7650 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6214 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_6295 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6647 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_4286 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_2948 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((-4 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n521_run_floor (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3559 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3365 a b) ∨ (fact_9fdb227ae99d_3372 a b) ∨ (fact_9fdb227ae99d_4407 a b) ∨ (fact_9fdb227ae99d_5546 a b) ∨ (fact_9fdb227ae99d_3735 a b) ∨ (fact_9fdb227ae99d_3392 a b) ∨ (fact_9fdb227ae99d_3407 a b) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3376 a b) ∨ (fact_9fdb227ae99d_3740 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3752 a b) ∨ (fact_9fdb227ae99d_3784 a b) ∨ (fact_9fdb227ae99d_5162 a b) ∨ (fact_9fdb227ae99d_5840 a b) ∨ (fact_9fdb227ae99d_4535 a b) ∨ (fact_9fdb227ae99d_3900 a b) ∨ (fact_9fdb227ae99d_3968 a b) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3812 a b) ∨ (fact_9fdb227ae99d_4558 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7468 a b) ∨ (fact_9fdb227ae99d_7576 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7468 a b) ∧ (fact_9fdb227ae99d_7576 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7468 a b) ∧ (fact_9fdb227ae99d_7576 a b) ∧ (((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3907 a b) ∨ (fact_9fdb227ae99d_3979 a b) ∨ (fact_9fdb227ae99d_4005 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∨ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4761 a b) ∨ (fact_9fdb227ae99d_4828 a b) ∨ (fact_9fdb227ae99d_4866 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b)))) ∨ ((fact_9fdb227ae99d_7468 a b) ∧ (fact_9fdb227ae99d_7576 a b) ∧ ((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3907 a b) ∨ (fact_9fdb227ae99d_3979 a b) ∨ (fact_9fdb227ae99d_4005 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∧ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4761 a b) ∨ (fact_9fdb227ae99d_4828 a b) ∨ (fact_9fdb227ae99d_4866 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2932 a b run_x)))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n522_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3494 a b run_x))))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_0 a b))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3284 a b) ∨ (fact_9fdb227ae99d_3111 a b) ∨ (fact_9fdb227ae99d_3116 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - a)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)) ∧ ((2 : Int) ≥ ((1 : Int) + a))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3054 a b) ∨ (fact_9fdb227ae99d_3293 a b)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h8 : (b = (5 : Int)))
    (h9 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o6 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n523_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h7 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3368 a b) ∨ (fact_9fdb227ae99d_3375 a b) ∨ (fact_9fdb227ae99d_4410 a b) ∨ (fact_9fdb227ae99d_5549 a b) ∨ (fact_9fdb227ae99d_3737 a b) ∨ (fact_9fdb227ae99d_3394 a b) ∨ (fact_9fdb227ae99d_3409 a b) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3377 a b) ∨ (fact_9fdb227ae99d_3378 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3749 a b) ∨ (fact_9fdb227ae99d_3781 a b) ∨ (fact_9fdb227ae99d_5159 a b) ∨ (fact_9fdb227ae99d_5837 a b) ∨ (fact_9fdb227ae99d_4532 a b) ∨ (fact_9fdb227ae99d_3897 a b) ∨ (fact_9fdb227ae99d_3965 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3811 a b) ∨ (fact_9fdb227ae99d_3829 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7462 a b) ∨ (fact_9fdb227ae99d_7568 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7462 a b) ∧ (fact_9fdb227ae99d_7568 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7462 a b) ∧ (fact_9fdb227ae99d_7568 a b) ∧ (((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3913 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4013 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∨ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4755 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_4856 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4677 a b)))) ∨ ((fact_9fdb227ae99d_7462 a b) ∧ (fact_9fdb227ae99d_7568 a b) ∧ ((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3913 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4013 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∧ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4755 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_4856 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4677 a b))))))
    (h1 : (a > b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2402 a b run_x)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n524_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3201 a b run_x))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3383 a b) ∨ (fact_9fdb227ae99d_3384 a b) ∨ (fact_9fdb227ae99d_4498 a b) ∨ (fact_9fdb227ae99d_5585 a b) ∨ (fact_9fdb227ae99d_3854 a b) ∨ (fact_9fdb227ae99d_3470 a b) ∨ (fact_9fdb227ae99d_3473 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3385 a b) ∨ (fact_9fdb227ae99d_3861 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3856 a b) ∨ (fact_9fdb227ae99d_3858 a b) ∨ (fact_9fdb227ae99d_5288 a b) ∨ (fact_9fdb227ae99d_5903 a b) ∨ (fact_9fdb227ae99d_4709 a b) ∨ (fact_9fdb227ae99d_4183 a b) ∨ (fact_9fdb227ae99d_4185 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3860 a b) ∨ (fact_9fdb227ae99d_4711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7474 a b) ∨ (fact_9fdb227ae99d_7584 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7474 a b) ∧ (fact_9fdb227ae99d_7584 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7474 a b) ∧ (fact_9fdb227ae99d_7584 a b) ∧ (((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3909 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4007 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∨ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4768 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_4872 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_5436 a b)))) ∨ ((fact_9fdb227ae99d_7474 a b) ∧ (fact_9fdb227ae99d_7584 a b) ∧ ((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3909 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4007 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∧ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4768 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_4872 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_5436 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_2446 a b run_x) ∨ (fact_9fdb227ae99d_2447 a b run_x) ∨ (fact_9fdb227ae99d_3070 a b run_x) ∨ (fact_9fdb227ae99d_3571 a b run_x) ∨ (fact_9fdb227ae99d_2982 a b run_x) ∨ (fact_9fdb227ae99d_2535 a b run_x) ∨ (fact_9fdb227ae99d_2538 a b run_x) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2448 a b run_x) ∨ (fact_9fdb227ae99d_2983 a b run_x)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n525_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3174 a b run_x) ∨ (fact_9fdb227ae99d_3184 a b run_x) ∨ (fact_9fdb227ae99d_3727 a b run_x) ∨ (fact_9fdb227ae99d_5192 a b run_x) ∨ (fact_9fdb227ae99d_3486 a b run_x) ∨ (fact_9fdb227ae99d_3212 a b run_x) ∨ (fact_9fdb227ae99d_3234 a b run_x) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3193 a b run_x) ∨ (fact_9fdb227ae99d_3556 a b run_x))))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3466 a b) ∨ (fact_9fdb227ae99d_3469 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3120 a b) ∨ (fact_9fdb227ae99d_3123 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7364 a b) ∨ (fact_9fdb227ae99d_7290 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7364 a b) ∧ (fact_9fdb227ae99d_7290 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7364 a b) ∧ (fact_9fdb227ae99d_7290 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_3998 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3314 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7364 a b) ∧ (fact_9fdb227ae99d_7290 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_3998 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3314 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ a))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2531 a b run_x) ∨ (fact_9fdb227ae99d_2534 a b run_x) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n526_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ a))
    (h3 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3211 a b run_x) ∨ (fact_9fdb227ae99d_3233 a b run_x) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-1 : Int) * a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-1 : Int) * a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_left (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4057 a b) ∨ (fact_9fdb227ae99d_4085 a b) ∨ (fact_9fdb227ae99d_5291 a b) ∨ (fact_9fdb227ae99d_5906 a b) ∨ (fact_9fdb227ae99d_4722 a b) ∨ (fact_9fdb227ae99d_4199 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6155 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3413 a b) ∨ (fact_9fdb227ae99d_3431 a b) ∨ (fact_9fdb227ae99d_4506 a b) ∨ (fact_9fdb227ae99d_5590 a b) ∨ (fact_9fdb227ae99d_3878 a b) ∨ (fact_9fdb227ae99d_3497 a b) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5724 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((-3 : Int) ≥ (((-1 : Int) * a) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7349 a b) ∨ (fact_9fdb227ae99d_7304 a b))) ∨ (((-3 : Int) ≥ (((-1 : Int) * a) + (2 : Int))) ∧ (fact_9fdb227ae99d_7349 a b) ∧ (fact_9fdb227ae99d_7304 a b)) ∨ ((-3 : Int) ≥ (((-1 : Int) * a) + (4 : Int))) ∨ (((-3 : Int) = (((-1 : Int) * a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7349 a b) ∧ (fact_9fdb227ae99d_7304 a b) ∧ (((fact_9fdb227ae99d_4951 a b) ∨ (fact_9fdb227ae99d_4968 a b) ∨ (fact_9fdb227ae99d_5732 a b) ∨ (fact_9fdb227ae99d_6478 a b) ∨ (fact_9fdb227ae99d_5473 a b) ∨ (fact_9fdb227ae99d_5045 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6669 a b)) ∨ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4205 a b) ∨ (fact_9fdb227ae99d_4258 a b) ∨ (fact_9fdb227ae99d_6158 a b)))) ∨ ((fact_9fdb227ae99d_7349 a b) ∧ (fact_9fdb227ae99d_7304 a b) ∧ ((fact_9fdb227ae99d_4951 a b) ∨ (fact_9fdb227ae99d_4968 a b) ∨ (fact_9fdb227ae99d_5732 a b) ∨ (fact_9fdb227ae99d_6478 a b) ∨ (fact_9fdb227ae99d_5473 a b) ∨ (fact_9fdb227ae99d_5045 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6669 a b)) ∧ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4205 a b) ∨ (fact_9fdb227ae99d_4258 a b) ∨ (fact_9fdb227ae99d_6158 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) * a) ≤ run_x))
    (h2 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (fact_9fdb227ae99d_3611 a b run_x)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((-3 : Int) ≥ run_x))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n527_run_floor (a b run_x : Int)
    (h0 : (((-1 : Int) * a) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (fact_9fdb227ae99d_5355 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((-3 : Int) ≥ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h2 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o2 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2924 a b jy))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-3 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h7 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h8 : (b = (5 : Int)))
    (h9 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n528_o7 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2869 a b) ∨ (fact_9fdb227ae99d_2871 a b) ∨ (fact_9fdb227ae99d_3261 a b) ∨ (fact_9fdb227ae99d_4168 a b) ∨ (fact_9fdb227ae99d_3100 a b) ∨ (fact_9fdb227ae99d_2961 a b) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h4 : (b = (5 : Int)))
    (h5 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o0 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2922 a b jy))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n529_o7 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7691 a b) ∨ (fact_9fdb227ae99d_7769 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7691 a b) ∧ (fact_9fdb227ae99d_7769 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7691 a b) ∧ (fact_9fdb227ae99d_7769 a b) ∧ (((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6696 a b) ∨ (fact_9fdb227ae99d_7077 a b) ∨ (fact_9fdb227ae99d_6711 a b)) ∨ ((fact_9fdb227ae99d_6743 a b) ∨ (fact_9fdb227ae99d_6747 a b) ∨ (fact_9fdb227ae99d_6997 a b) ∨ (fact_9fdb227ae99d_7156 a b) ∨ (fact_9fdb227ae99d_6926 a b) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6971 a b) ∨ (fact_9fdb227ae99d_7166 a b) ∨ (fact_9fdb227ae99d_6973 a b)))) ∨ ((fact_9fdb227ae99d_7691 a b) ∧ (fact_9fdb227ae99d_7769 a b) ∧ ((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6696 a b) ∨ (fact_9fdb227ae99d_7077 a b) ∨ (fact_9fdb227ae99d_6711 a b)) ∧ ((fact_9fdb227ae99d_6743 a b) ∨ (fact_9fdb227ae99d_6747 a b) ∨ (fact_9fdb227ae99d_6997 a b) ∨ (fact_9fdb227ae99d_7156 a b) ∨ (fact_9fdb227ae99d_6926 a b) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6971 a b) ∨ (fact_9fdb227ae99d_7166 a b) ∨ (fact_9fdb227ae99d_6973 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_empty (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (run_x ≤ ((-1 : Int) + a)))
    (h5 : ((fact_9fdb227ae99d_3628 a b run_x) ∨ (fact_9fdb227ae99d_3637 a b run_x) ∨ (fact_9fdb227ae99d_5036 a b run_x) ∨ (fact_9fdb227ae99d_5789 a b run_x) ∨ (fact_9fdb227ae99d_4411 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n530_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + a)))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((fact_9fdb227ae99d_5411 a b run_x) ∨ (fact_9fdb227ae99d_5414 a b run_x) ∨ (fact_9fdb227ae99d_5989 a b run_x) ∨ (fact_9fdb227ae99d_6842 a b run_x) ∨ (fact_9fdb227ae99d_5795 a b run_x) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

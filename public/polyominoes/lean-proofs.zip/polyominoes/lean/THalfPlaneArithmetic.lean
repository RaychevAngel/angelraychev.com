import Std.Tactic
set_option maxRecDepth 100000
set_option maxHeartbeats 500000
set_option linter.unusedVariables false
namespace THalfPlaneArithmetic

theorem beside_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (0 : Int)) ∧ ((y + b) ≥ (0 : Int)))) ∧ ((((x + a) < (p - c)) ∨ ((p + a) < (x - c)) ∨ (y < b) ∨ (b < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + b) < b) ∨ (b < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (b - b)) ∨ ((b + (0 : Int)) < (y - (0 : Int))))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (a = c) ∧ (b = b) ∧ (c = a) ∧ ((0 : Int) = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (a = b) ∧ (b = c) ∧ (c = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (a = b) ∧ (b = a) ∧ (c = (0 : Int)) ∧ ((0 : Int) = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (a = (0 : Int)) ∧ (b = c) ∧ (c = b) ∧ ((0 : Int) = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (a = (0 : Int)) ∧ (b = a) ∧ (c = b) ∧ ((0 : Int) = c)))))))) : False := by
  have c1 := h.2.1
  have c0 := h.1
  have c3 := h.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c9 := h.2.2.2.2.2.2
  clear h
  have hy : y=0 := by clear c9; omega
  have hx : x=p+a+1 := by clear c9; omega
  have hac : a=c := by clear c9; omega
  apply c9
  left
  exact ⟨hx,hy,hac,rfl,hac.symm,rfl⟩

theorem beside_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (0 : Int)) ∧ ((y + c) ≥ (0 : Int)))) ∧ ((((x + b) < (p - c)) ∨ ((p + a) < (x - (0 : Int))) ∨ (y < b) ∨ (b < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + c) < b) ∨ (b < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (b - b)) ∨ ((b + (0 : Int)) < (y - a)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (b = c) ∧ (c = b) ∧ ((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (b = b) ∧ (c = c) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (b = b) ∧ (c = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (b = (0 : Int)) ∧ (c = c) ∧ ((0 : Int) = b) ∧ (a = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (b = (0 : Int)) ∧ (c = a) ∧ ((0 : Int) = b) ∧ (a = c)))))))) : False := by
  have c4 := h.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c9 := h.2.2.2.2.2.2
  have c1 := h.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem beside_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (0 : Int)) ∧ ((y + (0 : Int)) ≥ (0 : Int)))) ∧ ((((x + c) < (p - c)) ∨ ((p + a) < (x - a)) ∨ (y < b) ∨ (b < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + (0 : Int)) < b) ∨ (b < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (b - b)) ∨ ((b + (0 : Int)) < (y - b)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (c = c) ∧ ((0 : Int) = b) ∧ (a = a) ∧ (b = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (c = b) ∧ ((0 : Int) = c) ∧ (a = (0 : Int)) ∧ (b = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (c = b) ∧ ((0 : Int) = a) ∧ (a = (0 : Int)) ∧ (b = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (c = (0 : Int)) ∧ ((0 : Int) = c) ∧ (a = b) ∧ (b = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (c = (0 : Int)) ∧ ((0 : Int) = a) ∧ (a = b) ∧ (b = c)))))))) : False := by
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem beside_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (0 : Int)) ∧ ((y + a) ≥ (0 : Int)))) ∧ ((((x + (0 : Int)) < (p - c)) ∨ ((p + a) < (x - b)) ∨ (y < b) ∨ (b < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + a) < b) ∨ (b < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (b - b)) ∨ ((b + (0 : Int)) < (y - c)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ ((0 : Int) = c) ∧ (a = b) ∧ (b = a) ∧ (c = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ ((0 : Int) = b) ∧ (a = c) ∧ (b = (0 : Int)) ∧ (c = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ ((0 : Int) = b) ∧ (a = a) ∧ (b = (0 : Int)) ∧ (c = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = c) ∧ (b = b) ∧ (c = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ (c = c)))))))) : False := by
  have c2 := h.2.2.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c3 := h.2.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem beside_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (0 : Int)) ∧ ((y + c) ≥ (0 : Int)))) ∧ ((((x + (0 : Int)) < (p - c)) ∨ ((p + a) < (x - b)) ∨ (y < b) ∨ (b < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + c) < b) ∨ (b < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (b - b)) ∨ ((b + (0 : Int)) < (y - a)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ ((0 : Int) = c) ∧ (c = b) ∧ (b = a) ∧ (a = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ ((0 : Int) = b) ∧ (c = c) ∧ (b = (0 : Int)) ∧ (a = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ ((0 : Int) = b) ∧ (c = a) ∧ (b = (0 : Int)) ∧ (a = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ ((0 : Int) = (0 : Int)) ∧ (c = c) ∧ (b = b) ∧ (a = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ ((0 : Int) = (0 : Int)) ∧ (c = a) ∧ (b = b) ∧ (a = c)))))))) : False := by
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c3 := h.2.2.2.1
  have c0 := h.1
  have c2 := h.2.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  clear h
  simp_all
  omega

theorem beside_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (0 : Int)) ∧ ((y + b) ≥ (0 : Int)))) ∧ ((((x + c) < (p - c)) ∨ ((p + a) < (x - a)) ∨ (y < b) ∨ (b < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + b) < b) ∨ (b < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (b - b)) ∨ ((b + (0 : Int)) < (y - (0 : Int))))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (c = c) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (c = b) ∧ (b = c) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (c = b) ∧ (b = a) ∧ (a = (0 : Int)) ∧ ((0 : Int) = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (c = (0 : Int)) ∧ (b = c) ∧ (a = b) ∧ ((0 : Int) = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (c = (0 : Int)) ∧ (b = a) ∧ (a = b) ∧ ((0 : Int) = c)))))))) : False := by
  have c0 := h.1
  have c3 := h.2.2.2.1
  have c9 := h.2.2.2.2.2.2
  have c4 := h.2.2.2.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem beside_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (0 : Int)) ∧ ((y + a) ≥ (0 : Int)))) ∧ ((((x + b) < (p - c)) ∨ ((p + a) < (x - (0 : Int))) ∨ (y < b) ∨ (b < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + a) < b) ∨ (b < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (b - b)) ∨ ((b + (0 : Int)) < (y - c)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (b = c) ∧ (a = b) ∧ ((0 : Int) = a) ∧ (c = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (b = b) ∧ (a = c) ∧ ((0 : Int) = (0 : Int)) ∧ (c = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (c = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (b = (0 : Int)) ∧ (a = c) ∧ ((0 : Int) = b) ∧ (c = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (b = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = b) ∧ (c = c)))))))) : False := by
  have c0 := h.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c9 := h.2.2.2.2.2.2
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  clear h
  simp_all
  omega

theorem beside_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (0 : Int)) ∧ (y ≥ (0 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (0 : Int)) ∧ ((y + (0 : Int)) ≥ (0 : Int)))) ∧ ((((x + a) < (p - c)) ∨ ((p + a) < (x - c)) ∨ (y < b) ∨ (b < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + (0 : Int)) < b) ∨ (b < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (b - b)) ∨ ((b + (0 : Int)) < (y - b)))) ∧ (¬ (((x = ((p + a) + (1 : Int))) ∧ (y = (0 : Int)) ∧ (a = c) ∧ ((0 : Int) = b) ∧ (c = a) ∧ (b = (0 : Int))) ∨ (((a + c) < b) ∧ (((x = (p + (1 : Int))) ∧ (y = a) ∧ (a = b) ∧ ((0 : Int) = c) ∧ (c = (0 : Int)) ∧ (b = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (a = b) ∧ ((0 : Int) = a) ∧ (c = (0 : Int)) ∧ (b = c)) ∨ ((x = (p + (1 : Int))) ∧ (y = a) ∧ (a = (0 : Int)) ∧ ((0 : Int) = c) ∧ (c = b) ∧ (b = a)) ∨ ((x = (p + (1 : Int))) ∧ (y = c) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (c = b) ∧ (b = c)))))))) : False := by
  have c0 := h.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c1 := h.2.1
  have c3 := h.2.2.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem enclosed_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + a) < (p - c)) ∨ ((p + a) < (x - c)) ∨ (y < b) ∨ (b < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + b) < b) ∨ (b < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (b - b)) ∨ ((b + (0 : Int)) < (y - (0 : Int))))) ∧ ((((x + a) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c1 := h.2.1
  have c0 := h.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c10 := h.2.2.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem enclosed_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + b) < (p - c)) ∨ ((p + a) < (x - (0 : Int))) ∨ (y < b) ∨ (b < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + c) < b) ∨ (b < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (b - b)) ∨ ((b + (0 : Int)) < (y - a)))) ∧ ((((x + b) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c0 := h.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c10 := h.2.2.2.2.2.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c4 := h.2.2.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem enclosed_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + c) < (p - c)) ∨ ((p + a) < (x - a)) ∨ (y < b) ∨ (b < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + (0 : Int)) < b) ∨ (b < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (b - b)) ∨ ((b + (0 : Int)) < (y - b)))) ∧ ((((x + c) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem enclosed_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - c)) ∨ ((p + a) < (x - b)) ∨ (y < b) ∨ (b < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + a) < b) ∨ (b < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (b - b)) ∨ ((b + (0 : Int)) < (y - c)))) ∧ ((((x + (0 : Int)) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c10 := h.2.2.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c0 := h.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem enclosed_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - c)) ∨ ((p + a) < (x - b)) ∨ (y < b) ∨ (b < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + c) < b) ∨ (b < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (b - b)) ∨ ((b + (0 : Int)) < (y - a)))) ∧ ((((x + (0 : Int)) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c4 := h.2.2.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c10 := h.2.2.2.2.2.2.2.1
  have c1 := h.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem enclosed_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + c) < (p - c)) ∨ ((p + a) < (x - a)) ∨ (y < b) ∨ (b < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + b) < b) ∨ (b < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (b - b)) ∨ ((b + (0 : Int)) < (y - (0 : Int))))) ∧ ((((x + c) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c0 := h.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c12 := h.2.2.2.2.2.2.2.2.2
  clear h
  simp_all
  omega

theorem enclosed_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + b) < (p - c)) ∨ ((p + a) < (x - (0 : Int))) ∨ (y < b) ∨ (b < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + a) < b) ∨ (b < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (b - b)) ∨ ((b + (0 : Int)) < (y - c)))) ∧ ((((x + b) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c6 := h.2.2.2.2.2.1.2.1
  have c3 := h.2.2.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  have c0 := h.1
  have c1 := h.2.1
  have c10 := h.2.2.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem enclosed_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + a) < (p - c)) ∨ ((p + a) < (x - c)) ∨ (y < b) ∨ (b < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (b - b)) ∨ ((b + (0 : Int)) < y)) ∧ ((x < (p - c)) ∨ ((p + a) < x) ∨ ((y + (0 : Int)) < b) ∨ (b < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (b - b)) ∨ ((b + (0 : Int)) < (y - b)))) ∧ ((((x + a) < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + a) + (1 : Int)) - a)) ∨ ((((p + a) + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + a) + (1 : Int))) ∨ (((p + a) + (1 : Int)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c2 := h.2.2.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.1.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < a) ∨ (a < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < a) ∨ (a < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - (0 : Int))))) ∧ ((((x + a) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c12 := h.2.2.2.2.2.2.2.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < a) ∨ (a < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < a) ∨ (a < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - a)))) ∧ ((((x + b) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c4 := h.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < a) ∨ (a < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < a) ∨ (a < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - b)))) ∧ ((((x + c) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c3 := h.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < a) ∨ (a < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < a) ∨ (a < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - c)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c12 := h.2.2.2.2.2.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < a) ∨ (a < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < a) ∨ (a < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - a)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c3 := h.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c5 := h.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < a) ∨ (a < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < a) ∨ (a < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - (0 : Int))))) ∧ ((((x + c) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c13 := h.2.2.2.2.2.2.2.2.2.2
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < a) ∨ (a < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < a) ∨ (a < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - c)))) ∧ ((((x + b) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c3 := h.2.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s0_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < a) ∨ (a < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < a) ∨ (a < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - b)))) ∧ ((((x + a) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c2 := h.2.2.1
  have c1 := h.2.1
  have c3 := h.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < a) ∨ (a < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < a) ∨ (a < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - (0 : Int))))) ∧ ((((x + a) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c13 := h.2.2.2.2.2.2.2.2.2.2
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < a) ∨ (a < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < a) ∨ (a < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - a)))) ∧ ((((x + b) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c1 := h.2.1
  have c3 := h.2.2.2.1
  have c2 := h.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < a) ∨ (a < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < a) ∨ (a < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - b)))) ∧ ((((x + c) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c4 := h.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < a) ∨ (a < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < a) ∨ (a < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - c)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c3 := h.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c1 := h.2.1
  have c12 := h.2.2.2.2.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < a) ∨ (a < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < a) ∨ (a < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - a)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c4 := h.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < a) ∨ (a < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < a) ∨ (a < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - (0 : Int))))) ∧ ((((x + c) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c2 := h.2.2.1
  have c3 := h.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < a) ∨ (a < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < a) ∨ (a < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - c)))) ∧ ((((x + b) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c3 := h.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c2 := h.2.2.1
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r0_s1_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (1 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < a) ∨ (a < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (a - a)) ∨ ((a + ((a + c) - a)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < a) ∨ (a < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (a - a)) ∨ ((a + ((a + c) - a)) < (y - b)))) ∧ ((((x + a) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c3 := h.2.2.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < c) ∨ (c < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < c) ∨ (c < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - (0 : Int))))) ∧ ((((x + a) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c0 := h.1
  have c2 := h.2.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < c) ∨ (c < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < c) ∨ (c < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - a)))) ∧ ((((x + b) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c0 := h.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < c) ∨ (c < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < c) ∨ (c < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - b)))) ∧ ((((x + c) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c4 := h.2.2.2.2.1
  have c2 := h.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < c) ∨ (c < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < c) ∨ (c < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - c)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  have c0 := h.1
  have c5 := h.2.2.2.2.2.1
  have c2 := h.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < c) ∨ (c < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < c) ∨ (c < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - a)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c5 := h.2.2.2.2.2.1
  have c0 := h.1
  have c2 := h.2.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < c) ∨ (c < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < c) ∨ (c < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - (0 : Int))))) ∧ ((((x + c) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c13 := h.2.2.2.2.2.2.2.2.2.2
  have c0 := h.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c4 := h.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < c) ∨ (c < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < c) ∨ (c < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - c)))) ∧ ((((x + b) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c1 := h.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c2 := h.2.2.1
  have c4 := h.2.2.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s0_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < c) ∨ (c < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < c) ∨ (c < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - b)))) ∧ ((((x + a) < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + a) - a)) ∨ ((((p + (1 : Int)) + a) + ((a + c) - a)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + a)) ∨ (((p + (1 : Int)) + a) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c5 := h.2.2.2.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o0 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < c) ∨ (c < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < c) ∨ (c < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - (0 : Int))))) ∧ ((((x + a) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c0 := h.1
  have c13 := h.2.2.2.2.2.2.2.2.2.2
  have c5 := h.2.2.2.2.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o1 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < c) ∨ (c < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < c) ∨ (c < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - a)))) ∧ ((((x + b) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  have c0 := h.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o2 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < c) ∨ (c < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < c) ∨ (c < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - b)))) ∧ ((((x + c) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  have c0 := h.1
  have c5 := h.2.2.2.2.2.1
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o3 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < c) ∨ (c < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < c) ∨ (c < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - c)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c1 := h.2.1
  have c2 := h.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o4 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - a) ≥ (0 : Int)) ∧ ((((x - b) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + (0 : Int))) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - a) ≤ (1 : Int)) ∧ ((y + c) ≥ (1 : Int)))) ∧ ((((x + (0 : Int)) < (p - (0 : Int))) ∨ ((p + b) < (x - b)) ∨ (y < c) ∨ (c < y)) ∧ (((x + (0 : Int)) < p) ∨ (p < (x - b)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + c) < c) ∨ (c < (y - a))) ∧ ((x < p) ∨ (p < x) ∨ ((y + c) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - a)))) ∧ ((((x + (0 : Int)) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - b)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + (0 : Int)) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - b)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + c) < (0 : Int)) ∨ ((y - a) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + c) < (0 : Int)) ∨ (((0 : Int) + b) < (y - a)))))) : False := by
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c2 := h.2.2.1
  have c1 := h.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o5 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - (0 : Int)) ≥ (0 : Int)) ∧ ((((x - a) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + c)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - (0 : Int)) ≤ (1 : Int)) ∧ ((y + b) ≥ (1 : Int)))) ∧ ((((x + c) < (p - (0 : Int))) ∨ ((p + b) < (x - a)) ∨ (y < c) ∨ (c < y)) ∧ (((x + c) < p) ∨ (p < (x - a)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + b) < c) ∨ (c < (y - (0 : Int)))) ∧ ((x < p) ∨ (p < x) ∨ ((y + b) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - (0 : Int))))) ∧ ((((x + c) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - a)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + c) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - a)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + b) < (0 : Int)) ∨ ((y - (0 : Int)) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + b) < (0 : Int)) ∨ (((0 : Int) + b) < (y - (0 : Int))))))) : False := by
  have c2 := h.2.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  have c1 := h.2.1
  have c0 := h.1
  have c4 := h.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  have c11 := h.2.2.2.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o6 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - c) ≥ (0 : Int)) ∧ ((((x - (0 : Int)) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + b)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - c) ≤ (1 : Int)) ∧ ((y + a) ≥ (1 : Int)))) ∧ ((((x + b) < (p - (0 : Int))) ∨ ((p + b) < (x - (0 : Int))) ∨ (y < c) ∨ (c < y)) ∧ (((x + b) < p) ∨ (p < (x - (0 : Int))) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + a) < c) ∨ (c < (y - c))) ∧ ((x < p) ∨ (p < x) ∨ ((y + a) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - c)))) ∧ ((((x + b) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + b) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - (0 : Int))) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + a) < (0 : Int)) ∨ ((y - c) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + a) < (0 : Int)) ∨ (((0 : Int) + b) < (y - c)))))) : False := by
  have c0 := h.1
  have c2 := h.2.2.1
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c1 := h.2.1
  have c4 := h.2.2.2.2.1
  have c5 := h.2.2.2.2.2.1
  clear h
  simp_all
  omega

theorem v_gap_r1_s1_o7 (a b c p x y : Int)
    (h : ((c ≤ a) ∧ (c ≥ (2 : Int)) ∧ (b ≥ (2 : Int)) ∧ (b ≤ a) ∧ ((y - b) ≥ (0 : Int)) ∧ ((((x - c) ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ (x + a)) ∧ (y ≤ (1 : Int)) ∧ (y ≥ (1 : Int))) ∨ ((x ≤ (p + (1 : Int))) ∧ ((p + (1 : Int)) ≤ x) ∧ ((y - b) ≤ (1 : Int)) ∧ ((y + (0 : Int)) ≥ (1 : Int)))) ∧ ((((x + a) < (p - (0 : Int))) ∨ ((p + b) < (x - c)) ∨ (y < c) ∨ (c < y)) ∧ (((x + a) < p) ∨ (p < (x - c)) ∨ (y < (c - c)) ∨ ((c + ((a + c) - c)) < y)) ∧ ((x < (p - (0 : Int))) ∨ ((p + b) < x) ∨ ((y + (0 : Int)) < c) ∨ (c < (y - b))) ∧ ((x < p) ∨ (p < x) ∨ ((y + (0 : Int)) < (c - c)) ∨ ((c + ((a + c) - c)) < (y - b)))) ∧ ((((x + a) < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < (x - c)) ∨ (y < (0 : Int)) ∨ (y > (0 : Int))) ∧ (((x + a) < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < (x - c)) ∨ (y < (0 : Int)) ∨ (((0 : Int) + b) < y)) ∧ ((x < (((p + (1 : Int)) + c) - c)) ∨ ((((p + (1 : Int)) + c) + ((a + c) - c)) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ ((y - b) > (0 : Int))) ∧ ((x < ((p + (1 : Int)) + c)) ∨ (((p + (1 : Int)) + c) < x) ∨ ((y + (0 : Int)) < (0 : Int)) ∨ (((0 : Int) + b) < (y - b)))))) : False := by
  have c8 := h.2.2.2.2.2.2.1.2.2.1
  have c2 := h.2.2.1
  have c0 := h.1
  have c5 := h.2.2.2.2.2.1
  have c12 := h.2.2.2.2.2.2.2.2.2.1
  have c1 := h.2.1
  have c7 := h.2.2.2.2.2.2.1.2.1
  clear h
  simp_all
  omega

end THalfPlaneArithmetic

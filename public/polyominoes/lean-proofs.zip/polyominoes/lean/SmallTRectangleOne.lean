import FiniteRectangle

set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace PolyominoFormal.SmallTRectangles
open CrossUnits FiniteRectangle

def t1Tiles : List Cross := [
  ⟨1,0,1,1,1,0⟩,
  ⟨0,2,1,1,0,1⟩,
  ⟨2,3,1,0,1,1⟩,
  ⟨3,1,0,1,1,1⟩]

theorem t1_copies : copiesCheck t1Tiles 1 1 1 0 = true := by decide
 theorem t1_inside : insideCheck t1Tiles 4 4 = true := by decide
 theorem t1_cover : coverCheck t1Tiles 4 4 = true := by decide
 theorem t1_separate : separateCheck t1Tiles = true := by decide

theorem t1_rectangle : Tiles 1 1 1 0 (Rectangle 4 4) :=
  ⟨tilingOfChecks t1Tiles 1 1 1 0 4 4
    t1_copies t1_inside t1_cover t1_separate⟩

theorem t1_rectangle_tileable : RectangleTileable 1 1 1 0 :=
  ⟨4,4,by decide,by decide,t1_rectangle⟩
#print axioms t1_rectangle_tileable
end PolyominoFormal.SmallTRectangles

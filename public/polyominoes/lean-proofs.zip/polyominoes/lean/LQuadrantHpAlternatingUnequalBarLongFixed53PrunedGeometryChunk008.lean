import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedGeometryDefs
import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedGeometryChunk007
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node479 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-1 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_point a b (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) (-1 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o0 a b jx jy (hlong) (sep2).2.2.2 (sep9).2.1 (sep10).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o1 a b jx jy (sep10).1 (insideT) (hb) (hfixed_a) (sep2).2.2.2 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o2 a b jx jy (insideT) (sep2).2.2.2 (hfixed_a) (allowed) (hit) (hb) (sep10).2.1 (hfixed_b) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node480 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o3 a b jx jy (sep9).2.1 (sep10).2.1 (hit) (sep3).2.1 (hb) (insideT) (hlong) (sep2).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o4 a b jx jy (hfixed_a) (hit) (sep2).2.2.2 (hlong) (hfixed_b) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node484 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o5 a b jx jy (sep9).2.1 (sep2).2.1 (sep10).2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o6 a b jx jy (sep9).2.1 (hb) (sep2).2.2.2 (sep10).2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n479_o7 a b jx jy (hfixed_b) (sep10).2.1 (insideT) (hit) (allowed) (hb) (hlong) (sep9).2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node516 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-1 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (-1 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o0 a b jx jy (sep10).2.1 (insideT) (hit) (hlong) (sep2).2.2.2 (hb) (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o1 a b jx jy (sep10).2.2.1 (insideT) (hit) (sep2).2.2.2 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o2 a b jx jy (sep10).2.1 (sep10).2.2.1 (insideT) (hb) (sep2).2.2.2 (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o3 a b jx jy (sep10).2.1 (insideT) (sep2).2.2.2 (hit) (sep10).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o4 a b jx jy (sep2).2.2.2 (insideT) (hlong) (hit) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o5 a b jx jy (hb) (hlong) (hit) (sep9).2.1 (sep2).2.2.2 (sep10).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o6 a b jx jy (hlong) (hb) (sep10).2.1 (sep9).2.1 (sep2).2.2.2 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n516_o7 a b jx jy (sep10).2.2.1 (allowed) (sep2).2.2.2 (sep9).2.1 (hb) (hit) (insideT)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node520 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ht11 : world (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ht12 : world (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht13 : world (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_13 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_13 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_13 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_13 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_13 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_13 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_13 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_13 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_13 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_13 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_13 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap11_13 : Apart (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap12_13 : Apart (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have in11 := inside (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have in12 := inside (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht12
  have in13 := inside (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht13
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed11 := avoid (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have allowed12 := avoid (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht12
  have allowed13 := avoid (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht13
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int) ∨ Contains (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))))
    · exact ap
  have sep13 : Apart t (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht13 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o0 a b jx jy (hlong) (insideT) (hit) (sep9).2.1 (sep13).2.2.1 (sep13).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o1 a b jx jy (insideT) (hlong) (hit) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o2 a b jx jy (sep12).2.2.1 (insideT) (hit) (hb) (sep13).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o3 a b jx jy (hit) (hlong) (sep12).2.2.1 (insideT) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o4 a b jx jy (hit) (hlong) (sep12).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o5 a b jx jy (hlong) (sep13).2.2.1 (sep13).2.1 (insideT) (hb) (sep9).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o6 a b jx jy (hit) (sep12).2.2.1 (sep13).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n520_o7 a b jx jy (insideT) (allowed) (sep12).2.2.1 (hit) (hb) (sep13).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node519 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ht11 : world (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ht12 : world (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have in11 := inside (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have in12 := inside (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed11 := avoid (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have allowed12 := avoid (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-8 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o0 a b jx jy (hfixed_a) (sep9).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (sep12).2.2.1 (hlong) (hb) (sep9).2.1 (hfixed_b) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11 sep12
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node520 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht12 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 ap0_12 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 ap1_12 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 ap2_12 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 ap3_12 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 ap4_12 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 ap5_12 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 ap6_12 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 ap7_12 (apart_sym sep7) ap8_9 ap8_10 ap8_11 ap8_12 (apart_sym sep8) ap9_10 ap9_11 ap9_12 (apart_sym sep9) ap10_11 ap10_12 (apart_sym sep10) ap11_12 (apart_sym sep11) (apart_sym sep12)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o1 a b jx jy (insideT) (hit) (sep12).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o2 a b jx jy (insideT) (sep9).2.2.1 (sep12).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o3 a b jx jy (insideT) (hit) (sep9).2.1 (hlong) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o4 a b jx jy (insideT) (hit) (hlong) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o5 a b jx jy (sep9).2.1 (hlong) (hit) (sep12).2.2.1 (insideT) (hb) (sep9).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o6 a b jx jy (insideT) (hit) (hlong) (sep12).2.2.1 (hfixed_b)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n519_o7 a b jx jy (hb) (insideT) (sep9).2.2.1 (hit) (sep12).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node521 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ht11 : world (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ht12 : world (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap11_12 : Apart (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have in11 := inside (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have in12 := inside (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed11 := avoid (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have allowed12 := avoid (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_point a b (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o0 a b jx jy (hit) (insideT) (hlong) (hb) (sep9).2.1 (sep12).2.1 (sep9).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o1 a b jx jy (insideT) (hlong) (hit) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o2 a b jx jy (hit) (insideT) (hb) (sep9).2.2.1 (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o3 a b jx jy (sep12).2.2.1 (insideT) (sep9).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o4 a b jx jy (hit) (insideT) (hlong) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o5 a b jx jy (sep9).2.2.1 (hit) (sep9).2.1 (sep12).2.2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o6 a b jx jy (hit) (sep12).2.2.1 (hlong) (sep12).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n521_o7 a b jx jy (sep12).2.2.1 (sep9).2.2.1 (insideT) (hit) (hb)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node518 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ht11 : world (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have in11 := inside (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed11 := avoid (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht11
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-2 : Int) (5 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_point a b (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-2 : Int) (5 : Int) ∨ Contains (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (-2 : Int) (5 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (5 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o0 a b jx jy (sep11).2.1 (hlong) (sep9).2.2.2 (insideT) (hfixed_b) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node519 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o1 a b jx jy (hlong) (insideT) (sep11).2.2.1 (allowed) (hit) (sep9).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o2 a b jx jy (allowed) (hit) (hb) (sep11).2.1 (sep11).2.2.1 (sep9).2.2.2 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o3 a b jx jy (sep11).2.1 (hlong) (sep11).2.2.1 (sep9).2.2.2 (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o4 a b jx jy (allowed) (hit) (sep11).2.2.1 (hlong) (sep9).2.2.2 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o5 a b jx jy (insideT) (sep11).2.1 (hb) (sep11).2.2.1 (hit) (sep9).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o6 a b jx jy (hit) (hfixed_b) (hlong) (insideT) (hb) (sep9).2.2.2 (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (-7 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n518_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep11).2.1 (insideT) (hfixed_a) (sep9).2.2.2 (hlong) (sep11).2.2.1 (hb) (hfixed_b) (hit) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node521 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node517 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-1 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_point a b (hb) (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-1 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-1 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o0 a b jx jy (insideT) (sep10).2.1 (sep9).2.1 (hb) (hlong) (hit) (sep2).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o1 a b jx jy (sep2).2.2.2 (sep10).2.2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o2 a b jx jy (hfixed_b) (hfixed_a) (hb) (sep10).2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (allowed) (sep2).2.2.2
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node518 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o3 a b jx jy (sep10).2.1 (insideT) (sep9).2.1 (hb) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o4 a b jx jy (insideT) (hit) (hlong) (sep10).2.2.1 (sep2).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o5 a b jx jy (sep10).2.1 (hit) (sep2).2.2.2 (hb) (hlong) (sep9).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o6 a b jx jy (hlong) (sep2).2.2.2 (insideT) (sep10).2.2.1 (sep9).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n517_o7 a b jx jy (sep10).2.2.1 (allowed) (sep9).2.1 (insideT) (hit) (sep10).2.1 (hb) (hlong)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node525 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ht13 : world (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap0_13 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap1_13 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap2_13 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap3_13 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap4_13 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap5_13 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap6_13 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap7_13 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap8_13 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap9_13 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap10_13 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap11_13 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap12_13 : Apart (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht12
  have in13 := inside (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht13
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht12
  have allowed13 := avoid (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht13
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_point a b (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) (3 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))))
    · exact ap
  have sep13 : Apart t (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht ht13 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o0 a b jx jy (sep11).2.1 (insideT) (sep10).2.2.1 (sep13).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o1 a b jx jy (insideT) (hit) (hlong) (sep10).2.2.1 (sep13).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o2 a b jx jy (hb) (insideT) (sep13).2.2.1 (sep13).2.1 (sep10).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o3 a b jx jy (insideT) (hit) (sep13).2.1 (hlong) (sep10).2.2.1 (sep13).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o4 a b jx jy (sep10).2.2.1 (insideT) (hit) (hlong) (sep13).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o5 a b jx jy (hit) (hb) (hlong) (sep13).2.2.1 (insideT) (sep11).2.1 (sep13).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o6 a b jx jy (hb) (sep11).2.1 (hit) (hlong) (sep13).2.1 (insideT) (sep13).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n525_o7 a b jx jy (hb) (sep10).2.2.1 (sep13).2.2.1 (allowed) (insideT) (hit) (sep11).2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node524 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_point a b (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o0 a b jx jy (sep11).2.1 (sep12).2.1 (hit) (insideT) (hlong) (sep11).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o1 a b jx jy (insideT) (sep10).2.2.1 (sep11).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o2 a b jx jy (allowed) (hb) (hlong) (sep8).2.1 (insideT) (sep10).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (6 : Int) (3 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hfixed_b) (sep10).2.2.1 (hlong) (hit) (sep11).2.2.1 (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11 sep12
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node525 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht12 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 ap0_12 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 ap1_12 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 ap2_12 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 ap3_12 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 ap4_12 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 ap5_12 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 ap6_12 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 ap7_12 (apart_sym sep7) ap8_9 ap8_10 ap8_11 ap8_12 (apart_sym sep8) ap9_10 ap9_11 ap9_12 (apart_sym sep9) ap10_11 ap10_12 (apart_sym sep10) ap11_12 (apart_sym sep11) (apart_sym sep12)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o4 a b jx jy (hlong) (sep11).2.2.1 (insideT) (hit) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o5 a b jx jy (sep11).2.1 (sep12).2.1 (sep11).2.2.1 (insideT) (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o6 a b jx jy (insideT) (hit) (sep11).2.2.1 (sep10).2.2.1 (sep11).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n524_o7 a b jx jy (allowed) (insideT) (hb) (sep12).2.1 (sep10).2.2.1 (hlong) (hit)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node527 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht13 : world (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_13 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_13 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_13 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_13 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_13 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_13 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_13 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_13 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_13 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_13 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_13 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_13 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    (ap12_13 : Apart (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have in13 := inside (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht13
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have allowed13 := avoid (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht13
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))))
    · exact ap
  have sep13 : Apart t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) ht ht13 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o0 a b jx jy (sep11).2.1 (hb) (insideT) (hit) (sep13).2.2.1 (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o1 a b jx jy (hlong) (sep13).2.2.1 (insideT) (hit) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o2 a b jx jy (hb) (allowed) (insideT) (sep13).2.2.1 (sep11).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o3 a b jx jy (insideT) (sep13).2.2.1 (hit) (hlong) (hb) (sep13).2.1 (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o4 a b jx jy (hlong) (sep13).2.2.1 (hit) (insideT) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o5 a b jx jy (hb) (hlong) (sep11).2.1 (hit) (sep13).2.1 (insideT) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o6 a b jx jy (sep11).2.1 (hlong) (insideT) (hit) (hb) (sep13).2.2.1 (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n527_o7 a b jx jy (allowed) (insideT) (sep11).2.2.1 (hit) (hb) (sep13).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node529 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht13 : world (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht14 : world (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_13 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_14 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_13 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_14 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_13 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_14 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_13 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_14 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_13 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_14 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_13 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_14 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_13 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_14 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_13 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_14 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_13 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_14 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_13 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_14 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_13 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_14 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_13 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_14 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap12_13 : Apart (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap12_14 : Apart (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap13_14 : Apart (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have in13 := inside (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht13
  have in14 := inside (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht14
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have allowed13 := avoid (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht13
  have allowed14 := avoid (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht14
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))))
    · exact ap
  have sep13 : Apart t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht13 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))))
    · exact ap
  have sep14 : Apart t (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht14 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o0 a b jx jy (sep11).2.1 (sep14).2.2.1 (hlong) (insideT) (hit) (sep14).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o1 a b jx jy (insideT) (sep13).2.2.1 (hit) (sep14).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o2 a b jx jy (sep14).2.1 (insideT) (hit) (hlong) (sep13).2.2.1 (sep14).2.2.1 (hfixed_a) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o3 a b jx jy (sep14).2.2.1 (hit) (sep14).2.1 (sep13).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o4 a b jx jy (hlong) (hit) (sep14).2.2.1 (insideT) (sep13).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o5 a b jx jy (sep14).2.2.1 (sep14).2.1 (sep11).2.1 (hb) (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o6 a b jx jy (hb) (hlong) (sep13).2.2.1 (insideT) (hit) (sep11).2.1 (sep14).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n529_o7 a b jx jy (insideT) (sep14).2.2.1 (hb) (hfixed_a) (hlong) (sep11).2.1 (hit) (sep11).2.2.1 (sep13).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node528 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht13 : world (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_13 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_13 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_13 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_13 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_13 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_13 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_13 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_13 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_13 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_13 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_13 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_13 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap12_13 : Apart (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have in13 := inside (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht13
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have allowed13 := avoid (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht13
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_point a b (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))))
    · exact ap
  have sep13 : Apart t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht13 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o0 a b jx jy (sep13).2.2.1 (sep11).2.1 (hlong) (hb) (hit) (sep11).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o1 a b jx jy (insideT) (hit) (sep13).2.2.1 (sep11).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o2 a b jx jy (allowed) (sep13).2.2.1 (hit) (sep11).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o3 a b jx jy (insideT) (hfixed_b) (sep11).2.2.1 (hit) (sep13).2.2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o4 a b jx jy (hit) (insideT) (sep11).2.2.1 (sep13).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (8 : Int) (3 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o5 a b jx jy (hfixed_b) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (sep11).2.1 (hit) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11 sep12 sep13
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node529 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht12 ht13 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 ap0_12 ap0_13 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 ap1_12 ap1_13 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 ap2_12 ap2_13 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 ap3_12 ap3_13 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 ap4_12 ap4_13 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 ap5_12 ap5_13 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 ap6_12 ap6_13 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 ap7_12 ap7_13 (apart_sym sep7) ap8_9 ap8_10 ap8_11 ap8_12 ap8_13 (apart_sym sep8) ap9_10 ap9_11 ap9_12 ap9_13 (apart_sym sep9) ap10_11 ap10_12 ap10_13 (apart_sym sep10) ap11_12 ap11_13 (apart_sym sep11) ap12_13 (apart_sym sep12) (apart_sym sep13)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o6 a b jx jy (hlong) (sep11).2.2.1 (insideT) (sep13).2.2.1 (hb) (sep11).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n528_o7 a b jx jy (sep13).2.2.1 (allowed) (sep11).2.2.1 (hb) (insideT) (hit)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node526 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (2 : Int) (6 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (6 : Int) ∨ Contains (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (6 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (6 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o0 a b jx jy (hb) (insideT) (hit) (sep11).2.2.2 (sep10).2.2.1 (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o1 a b jx jy (sep8).2.1 (sep10).2.2.1 (hlong) (sep11).2.2.2 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o2 a b jx jy (hfixed_b) (hlong) (hb) (hit) (hfixed_a) (sep10).2.2.1 (sep8).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11 sep12
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node527 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht12 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 ap0_12 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 ap1_12 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 ap2_12 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 ap3_12 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 ap4_12 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 ap5_12 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 ap6_12 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 ap7_12 (apart_sym sep7) ap8_9 ap8_10 ap8_11 ap8_12 (apart_sym sep8) ap9_10 ap9_11 ap9_12 (apart_sym sep9) ap10_11 ap10_12 (apart_sym sep10) ap11_12 (apart_sym sep11) (apart_sym sep12)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o3 a b jx jy (hit) (hfixed_b) (hlong) (sep11).2.2.2 (hb) (sep10).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o4 a b jx jy (sep12).2.2.1 (hb) (hit) (hfixed_b) (hlong) (sep11).2.2.2 (sep10).2.2.1 (insideT) (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (7 : Int) (6 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o5 a b jx jy (hit) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (sep8).2.1 (sep11).2.2.2 (hb) (hfixed_b) (sep10).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11 sep12
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node528 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht12 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 ap0_12 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 ap1_12 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 ap2_12 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 ap3_12 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 ap4_12 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 ap5_12 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 ap6_12 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 ap7_12 (apart_sym sep7) ap8_9 ap8_10 ap8_11 ap8_12 (apart_sym sep8) ap9_10 ap9_11 ap9_12 (apart_sym sep9) ap10_11 ap10_12 (apart_sym sep10) ap11_12 (apart_sym sep11) (apart_sym sep12)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o6 a b jx jy (insideT) (hit) (sep8).2.1 (sep11).2.2.2 (hlong) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n526_o7 a b jx jy (hit) (insideT) (sep10).2.2.1 (hb) (sep8).2.1 (sep11).2.2.2

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node523 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht11
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (5 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_point a b (hb) (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (5 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (5 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o0 a b jx jy (insideT) (hb) (sep11).2.2.1 (sep8).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o1 a b jx jy (insideT) (sep11).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o2 a b jx jy (insideT) (hit) (sep11).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (8 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o3 a b jx jy (sep11).2.2.1 (hit) (hfixed_a) (hfixed_b) (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node524 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o4 a b jx jy (hit) (sep11).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (10 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o5 a b jx jy (hit) (sep11).2.2.1 (hb) (insideT) (sep4).2.1 (sep8).1 (hfixed_b) (hlong) (hfixed_a) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node526 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o6 a b jx jy (hlong) (hit) (sep8).1 (insideT) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n523_o7 a b jx jy (hb) (sep11).2.2.1 (insideT) (hit)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node531 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht12 : world (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap11_12 : Apart (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht11
  have in12 := inside (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht11
  have allowed12 := avoid (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o0 a b jx jy (insideT) (sep11).2.1 (hb) (hlong) (hit) (sep12).2.1 (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o1 a b jx jy (hlong) (sep12).2.2.1 (sep11).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o2 a b jx jy (sep12).2.2.1 (hit) (allowed) (sep11).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o3 a b jx jy (sep12).2.2.1 (insideT) (sep11).2.2.1 (hit) (hb) (hlong) (sep11).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o4 a b jx jy (sep11).2.2.1 (hit) (hlong) (sep12).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o5 a b jx jy (insideT) (sep11).2.2.1 (sep12).2.2.1 (hit) (hb) (sep11).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o6 a b jx jy (insideT) (hlong) (sep12).2.2.1 (sep12).2.1 (sep11).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n531_o7 a b jx jy (sep11).2.2.1 (insideT) (hb) (allowed) (hit) (sep12).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node530 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht11
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht11
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o0 a b jx jy (insideT) (sep11).2.2.1 (hlong) (sep8).2.1 (hb) (hit) (sep11).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o1 a b jx jy (sep11).2.2.1 (hlong) (sep10).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o2 a b jx jy (hb) (hit) (allowed) (hlong) (insideT) (sep8).2.1 (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o3 a b jx jy (hit) (sep10).2.2.1 (insideT) (hlong) (hfixed_b) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o4 a b jx jy (hlong) (insideT) (sep10).2.2.1 (hit) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o5 a b jx jy (hit) (sep11).2.1 (hb) (hlong) (insideT) (sep8).2.2.1 (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o6 a b jx jy (hit) (insideT) (hlong) (sep11).2.2.1 (sep8).2.1 (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) (6 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n530_o7 a b jx jy (hb) (sep10).2.2.1 (hfixed_b) (insideT) (hfixed_a) (hit) (sep11).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node531 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node533 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht12 : world (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_12 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_12 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_12 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_12 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_12 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_12 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_12 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_12 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_12 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_12 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap10_12 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap11_12 : Apart (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht11
  have in12 := inside (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht11
  have allowed12 := avoid (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht12
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_point a b (hb) (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))))
    · exact ap
  have sep12 : Apart t (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht12 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o0 a b jx jy (sep11).2.2.1 (hb) (hit) (sep11).2.1 (insideT) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o1 a b jx jy (hlong) (insideT) (sep11).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o2 a b jx jy (insideT) (hb) (allowed) (sep11).2.2.1 (hit) (sep12).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o3 a b jx jy (hit) (hlong) (sep12).2.1 (insideT) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o4 a b jx jy (hlong) (insideT) (hit) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o5 a b jx jy (hb) (sep11).2.2.1 (sep12).2.1 (sep12).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o6 a b jx jy (hlong) (sep11).2.1 (insideT) (hit) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n533_o7 a b jx jy (insideT) (hb) (sep12).2.2.1 (sep11).2.2.1 (allowed) (hit)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node532 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht11 : world (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_11 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_11 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_11 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_11 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_11 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_11 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_11 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_11 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_11 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_11 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap10_11 : Apart (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have in11 := inside (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht11
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed11 := avoid (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht11
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_point a b (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))))
    · exact ap
  have sep11 : Apart t (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht11 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o0 a b jx jy (insideT) (sep8).2.2.1 (hb) (hit) (sep11).2.1 (sep11).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o1 a b jx jy (hlong) (sep11).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o2 a b jx jy (sep8).2.2.1 (hb) (insideT) (hit) (sep11).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o3 a b jx jy (hit) (insideT) (hlong) (sep11).2.2.1 (hfixed_b)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o4 a b jx jy (insideT) (hit) (sep11).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (8 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o5 a b jx jy (hfixed_a) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep8).2.2.1 (hit) (insideT) (hfixed_b) (sep11).2.1 (sep11).2.2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10 sep11
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node533 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht11 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 ap0_11 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 ap1_11 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 ap2_11 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 ap3_11 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 ap4_11 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 ap5_11 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 ap6_11 (apart_sym sep6) ap7_8 ap7_9 ap7_10 ap7_11 (apart_sym sep7) ap8_9 ap8_10 ap8_11 (apart_sym sep8) ap9_10 ap9_11 (apart_sym sep9) ap10_11 (apart_sym sep10) (apart_sym sep11)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o6 a b jx jy (sep11).2.2.1 (hlong) (sep11).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n532_o7 a b jx jy (sep11).2.2.1 (hit) (sep8).2.2.1 (hb) (insideT)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node522 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap9_10 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o0 a b jx jy (sep8).2.2.1 (sep8).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (hfixed_b) (hb) (insideT) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node523 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o1 a b jx jy (sep8).2.2.1 (hlong) (hit) (sep10).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o2 a b jx jy (sep10).2.2.1 (hb) (hit) (sep8).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o3 a b jx jy (sep8).2.2.1 (insideT) (hlong) (hit) (hfixed_b) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o4 a b jx jy (sep10).2.2.1 (sep8).2.2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (7 : Int) (2 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o5 a b jx jy (sep8).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (hfixed_b) (hlong) (insideT) (sep8).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node530 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o6 a b jx jy (sep10).2.2.1 (hlong) (insideT) (hit) (sep8).2.1 (sep8).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) (5 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n522_o7 a b jx jy (hlong) (hfixed_a) (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hfixed_b) (hit) (sep8).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9 sep10
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node532 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht10 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 ap0_10 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 ap1_10 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 ap2_10 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 ap3_10 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 ap4_10 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 ap5_10 (apart_sym sep5) ap6_7 ap6_8 ap6_9 ap6_10 (apart_sym sep6) ap7_8 ap7_9 ap7_10 (apart_sym sep7) ap8_9 ap8_10 (apart_sym sep8) ap9_10 (apart_sym sep9) (apart_sym sep10)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node478 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (0 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_point a b (hb) (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o0 a b jx jy (insideT) (sep3).2.2.2 (hit) (hlong) (sep9).2.1 (hb) (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (0 : Int) (9 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o1 a b jx jy (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep3).2.2.2 (hfixed_b) (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node479 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (0 : Int) (7 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o2 a b jx jy (hfixed_b) (hit) (hfixed_a) (hb) (sep8).2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep3).2.2.2
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node516 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o3 a b jx jy (hb) (hit) (sep8).2.1 (hlong) (sep3).2.2.2 (sep9).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (0 : Int) (9 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o4 a b jx jy (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hlong) (hfixed_b) (sep3).2.2.2
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node517 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o5 a b jx jy (sep8).2.1 (insideT) (sep9).2.1 (sep3).2.2.2 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o6 a b jx jy (hlong) (insideT) (sep9).2.1 (hit) (sep8).2.1 (sep3).2.2.2 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (0 : Int) (7 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n478_o7 a b jx jy (sep9).2.1 (sep3).2.2.2 (hb) (hit) (hfixed_a) (hfixed_b) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.2
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node522 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node535 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    (ap9_10 : Apart (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (0 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_point a b (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (0 : Int) (4 : Int) ∨ Contains (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) (0 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o0 a b jx jy (insideT) (sep10).2.2.1 (hb) (sep10).2.1 (sep3).2.2.2 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o1 a b jx jy (hit) (sep10).2.2.1 (sep3).2.2.2 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o2 a b jx jy (allowed) (hit) (sep10).2.2.1 (sep3).2.2.2 (sep8).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o3 a b jx jy (insideT) (hlong) (sep8).2.1 (sep3).2.2.2 (hit) (sep10).2.2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o4 a b jx jy (sep10).2.2.1 (hlong) (hit) (insideT) (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o5 a b jx jy (sep3).2.2.2 (hb) (sep8).2.1 (sep3).2.1 (insideT) (hit) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o6 a b jx jy (sep8).2.1 (sep10).2.1 (hit) (insideT) (sep3).2.2.2 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n535_o7 a b jx jy (sep8).2.1 (hit) (sep10).2.2.1 (hb) (hlong) (insideT) (sep3).2.2.2 (sep10).2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node536 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht10 : world (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_10 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_10 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_10 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_10 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_10 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_10 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_10 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_10 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap8_10 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    (ap9_10 : Apart (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have in10 := inside (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have allowed10 := avoid (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht10
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_point a b (hlong) (hb) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))))
    · exact ap
  have sep10 : Apart t (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) ht ht10 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o0 a b jx jy (sep9).2.2.1 (hlong) (sep9).2.1 (hb) (sep10).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o1 a b jx jy (hit) (sep9).2.2.1 (insideT) (sep10).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o2 a b jx jy (hb) (insideT) (hlong) (hit) (sep10).2.2.1 (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o3 a b jx jy (sep10).2.1 (insideT) (sep9).2.2.1 (hit) (sep10).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o4 a b jx jy (hit) (sep10).2.2.1 (hlong) (sep9).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o5 a b jx jy (insideT) (hb) (sep9).2.1 (sep9).2.2.1 (hlong) (sep10).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o6 a b jx jy (sep9).2.1 (hit) (sep9).2.2.1 (hlong) (insideT) (sep10).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n536_o7 a b jx jy (sep10).2.2.1 (hlong) (hit) (insideT) (hb) (sep10).2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node534 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht9
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o0 a b jx jy (hit) (sep9).2.1 (hlong) (insideT) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (-2 : Int) (7 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (hit) (hfixed_a) (hfixed_b) (sep9).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node535 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o2 a b jx jy (hfixed_b) (hb) (insideT) (hlong) (hit) (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o3 a b jx jy (hlong) (insideT) (sep2).2.1 (sep9).2.2.1 (hb) (hit) (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (7 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o4 a b jx jy (hit) (sep9).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hfixed_a) (insideT) (hfixed_b)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8 sep9
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node536 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht9 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 ap0_9 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 ap1_9 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 ap2_9 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 ap3_9 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 ap4_9 (apart_sym sep4) ap5_6 ap5_7 ap5_8 ap5_9 (apart_sym sep5) ap6_7 ap6_8 ap6_9 (apart_sym sep6) ap7_8 ap7_9 (apart_sym sep7) ap8_9 (apart_sym sep8) (apart_sym sep9)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o5 a b jx jy (hb) (sep2).2.1 (hlong) (insideT) (sep9).2.2.1 (hit) (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o6 a b jx jy (sep2).2.1 (hit) (insideT) (hb) (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n534_o7 a b jx jy (hit) (hlong) (hb) (insideT) (sep8).2.1 (hfixed_b)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node315 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht8
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (-7 : Int) (1 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o0 a b jx jy (hlong) (hfixed_b) (insideT) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (hit) (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node316 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o1 a b jx jy (sep8).2.1 (hfixed_a) (insideT) (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) (4 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o2 a b jx jy (hfixed_b) (allowed) (hb) (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hfixed_a)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node373 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o3 a b jx jy (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hlong) (sep2).2.2.1 (hit) (hfixed_b) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node375 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (6 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o4 a b jx jy (hit) (hfixed_b) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (insideT) (hlong) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node463 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o5 a b jx jy (hfixed_b) ((by simpa only [Same,eq_comm] using absent)) (hfixed_a) (hb) (insideT) (sep2).2.2.1 (sep2).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node478 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (-5 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o6 a b jx jy (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (hfixed_b) (hit) (insideT) (sep2).2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node534 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n315_o7 a b jx jy (sep8).2.1 (hb) (insideT) (hlong) (hit) (hfixed_b)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node538 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ht9 : world (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_9 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_9 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_9 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_9 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_9 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_9 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_9 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht8
  have in9 := inside (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht8
  have allowed9 := avoid (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht9
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o0 a b jx jy (insideT) (sep9).2.2.1 (hit) (hb) (sep8).2.1 (sep8).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o1 a b jx jy (insideT) (hit) (sep8).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o2 a b jx jy (sep9).2.2.1 (insideT) (hb) (sep8).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o3 a b jx jy (hlong) (sep8).2.2.1 (sep9).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o4 a b jx jy (hlong) (hit) (insideT) (sep8).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o5 a b jx jy (insideT) (hb) (hit) (sep9).2.2.1 (sep8).2.2.1 (sep9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o6 a b jx jy (sep8).2.2.1 (insideT) (hlong) (hit) (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n538_o7 a b jx jy (sep8).2.2.1 (hb) (insideT) (hit) (sep9).2.2.1

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node537 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    (ap7_8 : Apart (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht8
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_point a b ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o0 a b jx jy (hit) (sep8).2.1 (sep3).2.2.1 (hlong) (hb) (insideT) (sep8).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o1 a b jx jy (hit) (insideT) (hlong) (sep8).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o2 a b jx jy (hb) (allowed) (hit) (sep8).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o3 a b jx jy (sep8).2.2.1 (insideT) (hfixed_b) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o4 a b jx jy (hit) (insideT) (sep8).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (7 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o5 a b jx jy (hlong) (hit) (insideT) (sep8).2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hfixed_b) (hfixed_a) (sep3).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node538 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o6 a b jx jy (hlong) (hit) (sep3).2.1 (sep8).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n537_o7 a b jx jy (hit) (allowed) (hb) (sep8).2.2.1 (insideT)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (ht0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht7
  have support : HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_point a b (hb) (hlong) ((by simpa only [HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box,HP_alternating_unequal_bar_long_fixed_5_3_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o0 a b jx jy (hb) (hfixed_a) (hfixed_b) (hlong) (insideT) (hit) (sep3).2.1 (sep3).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node001 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) (6 : Int) (3 : Int) (0 : Int) (0 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o1 a b jx jy (hfixed_b) (hlong) (hit) (insideT) (hfixed_a) (allowed) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node263 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) (4 : Int) (0 : Int) (0 : Int) (5 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o2 a b jx jy (hb) (hfixed_a) (hfixed_b) (hit) (insideT) (allowed) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node278 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (1 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o3 a b jx jy (hfixed_a) (hfixed_b) (hb) (sep3).2.1 (hit) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node282 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) (6 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o4 a b jx jy (hit) (allowed) (hfixed_a) (hfixed_b) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node290 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (6 : Int) (1 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o5 a b jx jy (hfixed_b) (insideT) (hb) (hit) (hlong) (hfixed_a) ((by simpa only [Same,eq_comm] using absent)) (sep3).2.2.1 (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node295 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) (3 : Int) (5 : Int) (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o6 a b jx jy (hlong) (hfixed_b) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hfixed_a) (sep3).2.2.1 (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node315 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (1 : Int) (4 : Int) (5 : Int) (0 : Int) (0 : Int) (3 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_alternating_unequal_bar_long_fixed_5_3_pruned_n000_o7 a b jx jy (hit) (hb) (hfixed_a) (hfixed_b) ((by simpa only [Same,eq_comm] using absent)) (allowed) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node537 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside t)
    (cover : ∀ x y, HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (anchor0 : world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor3 : world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor4 : world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor5 : world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor6 : world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor7 : world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_2 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor0 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_3 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor0 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_4 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor0 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_5 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor0 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_6 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor0 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_7 : Apart (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor0 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_2 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor1 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_3 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor1 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_4 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor1 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_5 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor1 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_6 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor1 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_7 : Apart (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor1 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor2 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor2 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor2 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor2 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor2 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_4 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor3 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_5 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor3 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_6 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor3 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_7 : Apart (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor3 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap4_5 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor4 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap4_6 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor4 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap4_7 : Apart (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor4 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap5_6 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) anchor5 anchor6 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap5_7 : Apart (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor5 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap6_7 : Apart (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)) (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)) anchor6 anchor7 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_node000 a b ha hb hstrict hlong hfixed_a hfixed_b world copies inside cover sep avoid anchor0 anchor1 anchor2 anchor3 anchor4 anchor5 anchor6 anchor7 rootap0_1 rootap0_2 rootap0_3 rootap0_4 rootap0_5 rootap0_6 rootap0_7 rootap1_2 rootap1_3 rootap1_4 rootap1_5 rootap1_6 rootap1_7 rootap2_3 rootap2_4 rootap2_5 rootap2_6 rootap2_7 rootap3_4 rootap3_5 rootap3_6 rootap3_7 rootap4_5 rootap4_6 rootap4_7 rootap5_6 rootap5_7 rootap6_7

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor2 : T.world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor3 : T.world (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor4 : T.world (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor5 : T.world (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    (anchor6 : T.world (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int)))
    (anchor7 : T.world (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  apply HP_alternating_unequal_bar_long_fixed_5_3_pruned_bounded_obstruction a b ha hb hstrict hlong hfixed_a hfixed_b T.world T.copies ?_ ?_ T.disjoint avoid anchor0 anchor1 anchor2 anchor3 anchor4 anchor5 anchor6 anchor7
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hfixed_a : (a = (5 : Int)))
    (hfixed_b : (b = (3 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (-13 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (-12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int))))
    (anchor2 : T.world (shift p 0 (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int))))
    (anchor3 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int))))
    (anchor4 : T.world (shift p 0 (Cross.mk (11 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int))))
    (anchor5 : T.world (shift p 0 (Cross.mk (12 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int))))
    (anchor6 : T.world (shift p 0 (Cross.mk (23 : Int) (0 : Int) (0 : Int) (3 : Int) (5 : Int) (0 : Int))))
    (anchor7 : T.world (shift p 0 (Cross.mk (24 : Int) (0 : Int) (5 : Int) (3 : Int) (0 : Int) (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_alternating_unequal_bar_long_fixed_5_3_pruned_anchored_obstruction a b ha hb hstrict hlong hfixed_a hfixed_b U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor2,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor3,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor4,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor5,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor6,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor7,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
end PolyominoFormal.LRegion

import TPlaneDeep
import TPlaneShort
import TPlaneTwoLongBridge
set_option maxHeartbeats 500000
set_option maxRecDepth 20000
set_option linter.unusedVariables false
namespace PolyominoFormal.TPlaneTwoLong
open CrossUnits TBoundary CornerCertificate THalfPlaneStarters THalfPlaneGaps THalfPlaneDeepGaps TPlaneDeep

theorem antiparallel_impossible {a b c e s : Int}
    (ha : c≤a) (hc : 2≤c) (long : a+c≤b) (tall : a+4≤b)
    (he : e=a ∨ e=c) (hs : s=a ∨ s=c)
    (T : Tiling a b c 0 Plane) (ho : T.world ⟨0,0,e,b,a+c-e,0⟩)
    (hu : T.world ⟨1+s,1,a+c-s,0,s,b⟩) : False := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 2 True.intro
  have empty : ¬(Contains ⟨0,0,e,b,a+c-e,0⟩ 1 2 ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ 1 2) := by dsimp [Contains]; omega
  have avoid : ∀{x y}, (Contains ⟨0,0,e,b,a+c-e,0⟩ x y ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ x y) → ¬Contains t x y :=
    fun blocked => avoid_closed (pair_closed T ho hu) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := TPlaneShort.corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by left; right; dsimp; omega)) (avoid (by right; left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    apply blocked_deep_run (L:=1) (R:=r) (h:=3) ha (by omega) long
      (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ (1+r) 1 ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have yy := congrArg Cross.y eq; dsimp at yy; omega
  · subst t
    let U : Tiling a b c 0 Plane := T.transpose
    have hu' : U.world ⟨1,1+s,0,a+c-s,b,s⟩ := ⟨_,hu,rfl⟩
    have ht' : U.world ⟨2+r,1,a+c-r,b,r,0⟩ := ⟨_,ht,rfl⟩
    apply blocked_deep_run (L:=2) (R:=1+r) (h:=2) ha (by omega) long
      (by omega) (by omega) U _ (pair_closed U hu' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ 0 (2+r) ht ho
      (by left; dsimp; omega) (by right; dsimp; omega)
    have xx := congrArg Cross.x eq; dsimp at xx; omega
  · subst t
    let o : Cross := ⟨0,0,e,b,a+c-e,0⟩
    let v : Cross := ⟨1+b,2,0,a+c-r,b,r⟩
    apply deep_left_run (L:=1) (R:=b) (h:=3) ha hc long (by omega) T
      (fun x y => Contains o x y ∨ Contains v x y) (Contains o)
      (pair_closed T ho ht) (single_closed T ho) (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [o,v,Contains]; omega
    · intro x h0 h1; right; left; dsimp [v]; omega
    · intro y h0 h1; right; dsimp [o]; omega
    · intro x h0 h1; dsimp [o,Contains]; omega
    · right; right; dsimp [v]; omega
  · subst t
    let U : Tiling a b c 0 Plane := T.transpose
    let u : Cross := ⟨1,1+s,0,a+c-s,b,s⟩
    let v : Cross := ⟨2+b,1,0,a+c-r,b,r⟩
    have hu' : U.world u := ⟨_,hu,rfl⟩
    have ht' : U.world v := ⟨_,ht,rfl⟩
    apply deep_left_run (L:=2) (R:=1+b) (h:=2) ha hc long (by omega) U
      (fun x y => Contains u x y ∨ Contains v x y) (Contains u)
      (pair_closed U hu' ht') (single_closed U hu') (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [u,v,Contains]; omega
    · intro x h0 h1; right; left; dsimp [v]; omega
    · intro y h0 h1; right; dsimp [u]; omega
    · intro x h0 h1; dsimp [u,Contains]; omega
    · right; right; dsimp [v]; omega



theorem concave_right {a b e : Int} (ha : 2≤a) (long : a+4≤b)
    (he : e=a ∨ e=2) (T : Tiling a b 2 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+2-e,0⟩) {t : Cross}
    (ht : T.world t) (hit : Contains t 1 1) :
    t=⟨1,3,b,a,0,2⟩ ∨ ∃r,(r=a ∨ r=2) ∧ t=⟨1,b+1,a+2-r,0,r,b⟩ := by
  have empty : ¬Contains ⟨0,0,e,b,a+2-e,0⟩ 1 1 := by dsimp [Contains]; omega
  have avoid : ∀{x y}, Contains ⟨0,0,e,b,a+2-e,0⟩ x y → ¬Contains t x y :=
    fun blocked => avoid_closed (single_closed T ho) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := TPlaneShort.corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by right; dsimp; omega)) (avoid (by left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    exfalso
    apply blocked_deep_run (L:=1) (R:=r) (h:=2) (by omega) (by omega) (by omega)
      (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · subst t
    exact False.elim (antiparallel_impossible (by omega) (by omega) (by omega) long he hr T ho ht)
  · subst t
    by_cases short : r=2
    · subst r
      left
      apply same_eq; dsimp [Same]; omega
    · exfalso
      have rr : 3≤r := by omega
      let U : Tiling a b 2 0 Plane := T.transpose.mirrorX
      let o : Cross := ⟨0,0,0,e,b,a+2-e⟩
      let v : Cross := ⟨-(1+r),1,r,b,a+2-r,0⟩
      have ho' : U.world o := ⟨_,⟨_,ho,rfl⟩,rfl⟩
      have ht' : U.world v := ⟨_,⟨_,ht,rfl⟩,rfl⟩
      apply deep_left_run (L:= -r) (R:= -1) (h:=2) (by omega) (by omega) (by omega)
        (by omega) U (fun x y => Contains o x y ∨ Contains v x y) (Contains v)
        (pair_closed U ho' ht') (single_closed U ht') (fun _ _ h => Or.inr h)
      · intros; trivial
      · intros; trivial
      · intro x h0 h1; dsimp [o,v,Contains]; omega
      · intro x h0 h1; right; left; dsimp [v]; omega
      · intro y h0 h1; right; dsimp [v]; omega
      · intro x h0 h1; dsimp [v,Contains]; omega
      · left; right; dsimp [o]; omega
  · subst t
    have eq := T.disjoint _ _ 0 (1+r) ht ho
      (by left; dsimp; omega) (by right; dsimp; omega)
    have xx := congrArg Cross.x eq; dsimp at xx; omega
  · subst t
    exfalso
    let o : Cross := ⟨0,0,e,b,a+2-e,0⟩
    let v : Cross := ⟨1+b,1,0,a+2-r,b,r⟩
    apply deep_left_run (L:=1) (R:=b) (h:=2) (by omega) (by omega) (by omega) (by omega) T
      (fun x y => Contains o x y ∨ Contains v x y) (Contains o)
      (pair_closed T ho ht) (single_closed T ho) (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [o,v,Contains]; omega
    · intro x h0 h1; right; left; dsimp [v]; omega
    · intro y h0 h1; right; dsimp [o]; omega
    · intro x h0 h1; dsimp [o,Contains]; omega
    · right; right; dsimp [v]; omega
  · right
    refine ⟨r,hr,?_⟩
    have ey : 1+b=b+1 := by omega
    simpa only [ey] using eq

theorem left_away_of_right_stem {a b e r : Int} (ha : 2≤a) (long : a+4≤b)
    (he : e=a ∨ e=2) (hr : r=a ∨ r=2) (T : Tiling a b 2 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+2-e,0⟩)
    (hs : T.world ⟨1,b+1,a+2-r,0,r,b⟩) : T.world ⟨-1,3,0,a,b,2⟩ := by
  let U : Tiling a b 2 0 Plane := T.mirrorX
  have he' : a+2-e=a ∨ a+2-e=2 := by omega
  have ho' : U.world ⟨0,0,a+2-e,b,e,0⟩ := ⟨_,ho,rfl⟩
  have ho'' : U.world ⟨0,0,a+2-e,b,a+2-(a+2-e),0⟩ := by
    have hh : a+2-(a+2-e)=e := by omega
    simpa only [hh] using ho'
  obtain ⟨t,ht,hit⟩ := U.cover 1 1 True.intro
  obtain eq | ⟨s,hss,eq⟩ := concave_right ha long he' U ho'' ht hit
  · subst t
    rcases ht with ⟨v,hv,eq⟩
    have back : v=⟨-1,3,0,a,b,2⟩ := by
      have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      have he := congrArg Cross.east eq
      have hn := congrArg Cross.north eq
      have hw := congrArg Cross.west eq
      have hs := congrArg Cross.south eq
      apply same_eq
      dsimp [mirrorX] at hx hy he hn hw hs
      dsimp [Same]
      omega
    exact back ▸ hv
  · subst t
    have hs' : U.world ⟨-1,b+1,r,0,a+2-r,b⟩ := ⟨_,hs,rfl⟩
    have eq := U.disjoint _ _ 0 (b+1) ht hs'
      (by left; dsimp; omega) (by left; dsimp; omega)
    have xx := congrArg Cross.x eq
    dsimp at xx
    omega



theorem transpose_world_back {a b c d : Int} {region : Region}
    (T : Tiling a b c d region) {t : Cross} (ht : T.transpose.world t) :
    T.world (transpose t) := by
  obtain ⟨u,hu,eq⟩ := ht
  rw [←eq]
  exact hu

theorem mirrorY_world_back {a b c d : Int} {region : Region}
    (T : Tiling a b c d region) {t : Cross} (ht : T.mirrorY.world t) :
    T.world (mirrorY t) := by
  obtain ⟨u,hu,eq⟩ := ht
  have invol : mirrorY (mirrorY u)=u := by cases u; simp [mirrorY]
  rw [←eq,invol]
  exact hu

theorem translate_world_back {a b c d p q : Int} {region : Region}
    (T : Tiling a b c d region) {t : Cross} (ht : (T.translate p q).world t) :
    T.world (shift (-p) (-q) t) := by
  obtain ⟨u,hu,eq⟩ := ht
  rw [←eq,shift_add]
  have hp : p + -p=0 := by omega
  have hq : q + -q=0 := by omega
  simpa only [hp,hq,shift_zero] using hu

theorem forced_R_W {a b e : Int} (ha : 2≤a) (long : a+4≤b)
    (he : e=a ∨ e=2) (T : Tiling a b 2 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+2-e,0⟩)
    (hu : T.world ⟨1,3,b,a,0,2⟩) :
    ∃r w,(r=a ∨ r=2) ∧ (w=a ∨ w=2) ∧
      T.world ⟨2+r,1,a+2-r,0,r,b⟩ ∧ T.world ⟨b+2,2,0,w,b,a+2-w⟩ := by
  let U : Tiling a b 2 0 Plane := T.transpose
  let o : Cross := ⟨0,0,b,e,0,a+2-e⟩
  let v : Cross := ⟨3,1,a,b,2,0⟩
  have ho' : U.world o := ⟨_,ho,rfl⟩
  have hu' : U.world v := ⟨_,hu,rfl⟩
  let B : Region := fun x y => Contains o x y ∨ Contains v x y
  have closed : TileClosed U.world B := pair_closed U ho' hu'
  have choose : ∀p,(1:Int)≤p → p≤2 → ∃ t,U.world t ∧ Starter a b 2 p 2 t := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := U.cover p 2 True.intro
    have empty : ¬B p 2 := by dsimp [B,o,v,Contains]; omega
    have avoid : ∀{x y},B x y → ¬Contains t x y := fun blocked => avoid_closed closed ht hit empty blocked
    refine ⟨t,ht,short_run_forms (L:=1) (R:=2) (by omega) (by omega) (by omega)
      (by omega) hp0 hp1 (U.copies t ht) hit ?_ ?_ ?_ ?_⟩
    · apply avoid; left; right; dsimp [o]; omega
    · apply avoid; right; right; dsimp [v]; omega
    · apply avoid; right; left; dsimp [v]; omega
    · intro hx0 hx1
      apply avoid; right; left; dsimp [v]; omega
  obtain ⟨t,ht,st⟩ := choose 1 (by omega) (by omega)
  obtain ⟨u,hw,su⟩ := choose 2 (by omega) (by omega)
  have second : u=⟨2,2+b,a,0,2,b⟩ ∨ u=⟨2,2+b,2,0,a,b⟩ := by
    rcases su with eq | eq | eq | eq | eq | eq
    · subst u
      have same := U.disjoint _ _ 3 (2+a) hw hu'
        (by left; dsimp; omega) (by right; dsimp [v]; omega)
      have xx := congrArg Cross.x same; dsimp [v] at xx; omega
    · subst u
      have same := U.disjoint _ _ 3 (2+2) hw hu'
        (by left; dsimp; omega) (by right; dsimp [v]; omega)
      have xx := congrArg Cross.x same; dsimp [v] at xx; omega
    · subst u
      exact False.elim (left_v_hits_previous (by omega) (by omega) (by omega) (Or.inl rfl) U
        (by simpa only [show a+2-a=2 by omega] using hw) ht st)
    · subst u
      exact False.elim (left_v_hits_previous (by omega) (by omega) (by omega) (Or.inr rfl) U
        (by simpa only [show a+2-2=a by omega] using hw) ht st)
    · exact Or.inl eq
    · exact Or.inr eq
  have first : ∃r,(r=a ∨ r=2) ∧ t=⟨1,2+r,0,a+2-r,b,r⟩ := by
    rcases st with eq | eq | eq | eq | eq | eq
    · subst t
      exact False.elim (right_v_hits_next (by omega) (by omega) (by omega) (Or.inl rfl) U
        (by simpa only [show a+2-a=2 by omega] using ht) hw su)
    · subst t
      exact False.elim (right_v_hits_next (by omega) (by omega) (by omega) (Or.inr rfl) U
        (by simpa only [show a+2-2=a by omega] using ht) hw su)
    · refine ⟨a,Or.inl rfl,?_⟩
      simpa only [show a+2-a=2 by omega] using eq
    · refine ⟨2,Or.inr rfl,?_⟩
      simpa only [show a+2-2=a by omega] using eq
    · subst t
      have hit : Contains u 2 (2+b) := by rcases second with rfl | rfl <;> left <;> dsimp <;> omega
      have same := U.disjoint _ _ 2 (2+b) ht hw (by left; dsimp; omega) hit
      have ux : u.x=2 := by rcases second with rfl | rfl <;> rfl
      have xx := congrArg Cross.x same; dsimp at xx; omega
    · subst t
      have hit : Contains u 2 (2+b) := by rcases second with rfl | rfl <;> left <;> dsimp <;> omega
      have same := U.disjoint _ _ 2 (2+b) ht hw (by left; dsimp; omega) hit
      have ux : u.x=2 := by rcases second with rfl | rfl <;> rfl
      have xx := congrArg Cross.x same; dsimp at xx; omega
  obtain ⟨r,hr,rfl⟩ := first
  have backR := transpose_world_back T ht
  rcases second with rfl | rfl
  · refine ⟨r,a,hr,Or.inl rfl,backR,?_⟩
    have backW := transpose_world_back T hw
    simpa only [transpose,show 2+b=b+2 by omega,show a+2-a=2 by omega] using backW
  · refine ⟨r,2,hr,Or.inr rfl,backR,?_⟩
    have backW := transpose_world_back T hw
    simpa only [transpose,show 2+b=b+2 by omega,show a+2-2=a by omega] using backW



theorem forced_Z {a b w : Int} (ha : 2≤a) (long : a+4≤b)
    (hw : w=a ∨ w=2) (T : Tiling a b 2 0 Plane)
    (hU : T.world ⟨1,3,b,a,0,2⟩)
    (hW : T.world ⟨b+2,2,0,w,b,a+2-w⟩) : T.world ⟨b-1,1,2,0,a,b⟩ := by
  let U : Tiling a b 2 0 Plane := (T.translate (-b-2) (-2)).transpose.mirrorY
  have ho : U.world ⟨0,0,w,b,a+2-w,0⟩ := by
    refine ⟨_,⟨_,⟨_,hW,rfl⟩,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,mirrorY,transpose,shift]; omega
  have hs : U.world ⟨1,b+1,a,0,2,b⟩ := by
    refine ⟨_,⟨_,⟨_,hU,rfl⟩,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,mirrorY,transpose,shift]; omega
  have hs' : U.world ⟨1,b+1,a+2-2,0,2,b⟩ := by
    simpa only [show a+2-2=a by omega] using hs
  have hz := left_away_of_right_stem ha long hw (Or.inr rfl) U ho hs'
  have hz1 := mirrorY_world_back ((T.translate (-b-2) (-2)).transpose) hz
  have hz2 := transpose_world_back (T.translate (-b-2) (-2)) hz1
  have hz3 := translate_world_back T hz2
  have back : shift (-(-b-2)) (-(-2)) (transpose (mirrorY ⟨-1,3,0,a,b,2⟩))=
      ⟨b-1,1,2,0,a,b⟩ := by
    apply same_eq; dsimp [Same,mirrorY,transpose,shift]; omega
  exact back ▸ hz3

theorem away_corner_impossible {a b e : Int} (ha : 2≤a) (long : a+4≤b)
    (he : e=a ∨ e=2) (T : Tiling a b 2 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+2-e,0⟩)
    (hu : T.world ⟨1,3,b,a,0,2⟩) : False := by
  obtain ⟨r,w,hr,hw,hR,hW⟩ := forced_R_W ha long he T ho hu
  have hZ := forced_Z ha long hw T hu hW
  let U : Tiling a b 2 0 Plane := T.mirrorY.translate 0 1
  have hU' : U.world ⟨1,-2,b,2,0,a⟩ := ⟨_,⟨_,hu,rfl⟩,rfl⟩
  have hW' : U.world ⟨b+2,-1,0,a+2-w,b,a+2-(a+2-w)⟩ := by
    refine ⟨_,⟨_,hW,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,mirrorY,shift]; omega
  have hR' : U.world ⟨2+r,0,a+2-r,b,r,0⟩ := by
    refine ⟨_,⟨_,hR,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,mirrorY,shift]; omega
  have hZ' : U.world ⟨b-1,0,2,b,a,0⟩ := by
    refine ⟨_,⟨_,hZ,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,mirrorY,shift]; omega
  exact TPlaneTwoLongBridge.finite_bridge_impossible ha long hr (by omega) U hU' hW' hR' hZ'

theorem no_plane {a b : Int} (ha : 2≤a) (long : a+4≤b) :
    ¬Tiles a b 2 0 Plane := by
  rintro ⟨original⟩
  obtain ⟨T,ho⟩ := normalize_plane original
  have ho' : T.world ⟨0,0,a,b,a+2-a,0⟩ := by
    simpa only [show a+2-a=2 by omega] using ho
  obtain ⟨t,ht,hit⟩ := T.cover 1 1 True.intro
  obtain eq | ⟨r,hr,eq⟩ := concave_right ha long (Or.inl rfl) T ho' ht hit
  · subst t
    exact away_corner_impossible ha long (Or.inl rfl) T ho' ht
  · subst t
    have left := left_away_of_right_stem ha long (Or.inl rfl) hr T ho' ht
    let U : Tiling a b 2 0 Plane := T.mirrorX
    have hu : U.world ⟨1,3,b,a,0,2⟩ := ⟨_,left,rfl⟩
    have ho'' : U.world ⟨0,0,2,b,a,0⟩ := ⟨_,ho,rfl⟩
    have ho''' : U.world ⟨0,0,2,b,a+2-2,0⟩ := by
      simpa only [show a+2-2=a by omega] using ho''
    exact away_corner_impossible ha long (Or.inr rfl) U ho''' hu

#print axioms forced_Z
#print axioms no_plane
end PolyominoFormal.TPlaneTwoLong

import LHalfPlaneShortbarAssembly
import LHalfPlaneFiveThree
import LQuadrantHpUnequalNestedShortDeltaOnePrunedGeometry
import LQuadrantHpOptimizedUnequalNestedShortBfourDeltaTwoPrunedGeometry
import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedGeometry
import LQuadrantHpOptimizedUnequalNestedShortBge6DeltaTwoPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

/-- The two nested upward short bars are impossible in both near parameter
families. The fixed point (5,3) uses its separately proved half-plane theorem. -/
theorem nested_short_near_obstruction (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (hnear : a≤b+2) :
    LHalfPlaneShortbarAssembly.PairObstruction a b ⟨1,1,b,a,0,0⟩ := by
  intro T hO hS
  by_cases one : a=b+1
  · exact HP_unequal_nested_short_delta_one_pruned_anchored_obstruction a b
      (by omega) hb hab ha one T hO hS
  · have two : a=b+2 := by omega
    by_cases three : b=3
    · have five : a=5 := by omega
      subst a; subst b
      exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
    · by_cases four : b=4
      · exact HP_optimized_unequal_nested_short_bfour_delta_two_pruned_anchored_obstruction
          a b (by omega) hb hab ha four two T hO hS
      · by_cases five : b=5
        · exact HP_optimized_unequal_nested_short_bfive_delta_two_pruned_anchored_obstruction
            a b (by omega) hb hab ha five two T hO hS
        · exact HP_optimized_unequal_nested_short_bge6_delta_two_pruned_anchored_obstruction
            a b (by omega) hb hab ha (by omega) two T hO hS

#print axioms nested_short_near_obstruction
end PolyominoFormal.LRegion

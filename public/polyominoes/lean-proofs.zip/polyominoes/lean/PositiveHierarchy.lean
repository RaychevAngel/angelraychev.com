import PositiveConstructions

set_option maxRecDepth 10000
set_option maxHeartbeats 500000

namespace PositiveHierarchy
open CrossUnits PolyominoFormal

theorem div_bounds (n z : Int) (hn : 0<n) :
    (z/n)*n≤z ∧ z<(z/n)*n+n := by
  have hr0 := Int.emod_nonneg z (show n≠0 by omega)
  have hr1 := Int.emod_lt_of_pos z hn
  have he := Int.emod_add_ediv_mul z n
  omega

/-- Stack any chosen integer-indexed selection of disjoint copies of a strip. -/
def stackStrip {a b c d h : Int} (hh : 0<h)
    (T : Tiling a b c d (Strip h)) (K : Int→Prop) :
    Tiling a b c d (fun _ y => ∃ k, K k ∧ 0≤y-k*h ∧ y-k*h<h) where
  world t := ∃ k u, K k ∧ T.world u ∧ t=shift 0 (k*h) u
  copies := by
    rintro t ⟨k,u,hk,hu,rfl⟩
    exact (copy_shift _ _ _ _ _ _ _).mpr (T.copies u hu)
  inside := by
    rintro t ⟨k,u,hk,hu,rfl⟩ x y hit
    have hc : Contains u x (y-k*h) := by simpa using (contains_shift _ _ _ _ _).mp hit
    have hin := T.inside u hu x (y-k*h) hc
    exact ⟨k,hk,hin⟩
  cover := by
    rintro x y ⟨k,hk,hy⟩
    obtain ⟨t,ht,hit⟩ := T.cover x (y-k*h) hy
    refine ⟨shift 0 (k*h) t, ⟨k,t,hk,ht,rfl⟩, ?_⟩
    exact (contains_shift 0 (k*h) x y t).mpr (by simpa using hit)
  disjoint := by
    rintro t u x y ⟨k,v,hk,hv,rfl⟩ ⟨l,w,hl,hw,rfl⟩ hit hiu
    have hv' : Contains v x (y-k*h) := by simpa using (contains_shift _ _ _ _ _).mp hit
    have hw' : Contains w x (y-l*h) := by simpa using (contains_shift _ _ _ _ _).mp hiu
    have hkv := T.inside v hv x (y-k*h) hv'
    have hlw := T.inside w hw x (y-l*h) hw'
    simp only [Strip] at hkv hlw
    have hkl := PositiveConstructions.block_unique h k l y hh
      (by omega) (by omega) (by omega) (by omega)
    subst l
    exact congrArg (shift 0 (k*h)) (T.disjoint v w x (y-k*h) hv hw hv' hw')

def stripToHalfPlane {a b c d h : Int} (hh : 0<h)
    (T : Tiling a b c d (Strip h)) : Tiling a b c d HalfPlane :=
  (stackStrip hh T (fun k => 0≤k)).congr (by
    intro x y
    constructor
    · rintro ⟨k,hk,hy0,hyh⟩
      have hkh := Int.mul_nonneg hk (show 0≤h by omega)
      exact show 0≤y by omega
    · intro hy
      have hk : 0≤y/h := Int.ediv_nonneg hy (by omega)
      have hb := div_bounds h y hh
      exact ⟨y/h,hk,by omega,by omega⟩)

def stripToPlane {a b c d h : Int} (hh : 0<h)
    (T : Tiling a b c d (Strip h)) : Tiling a b c d Plane :=
  (stackStrip hh T (fun _ => True)).congr (by
    intro x y
    constructor
    · intro _; trivial
    · intro _
      have hb := div_bounds h y hh
      exact ⟨y/h,True.intro,by omega,by omega⟩)

theorem strip_tiles_halfplane {a b c d : Int} (h : StripTileable a b c d) :
    Tiles a b c d HalfPlane := by
  obtain ⟨w,hw,⟨T⟩⟩ := h
  exact ⟨stripToHalfPlane hw T⟩

theorem strip_tiles_plane {a b c d : Int} (h : StripTileable a b c d) :
    Tiles a b c d Plane := by
  obtain ⟨w,hw,⟨T⟩⟩ := h
  exact ⟨stripToPlane hw T⟩

theorem bent_block_unique (w h k l x y : Int) (hw : 0<w) (hh : 0<h)
    (hk : BentStrip w h (x-k*w) (y-k*h))
    (hl : BentStrip w h (x-l*w) (y-l*h)) : k=l := by
  unfold BentStrip at hk hl
  by_cases hkl : k<l
  · have hx := Int.mul_le_mul_of_nonneg_right (c:=w) (show k+1≤l by omega) (by omega)
    have hy := Int.mul_le_mul_of_nonneg_right (c:=h) (show k+1≤l by omega) (by omega)
    simp only [Int.add_mul, Int.one_mul] at hx hy
    omega
  · by_cases hlk : l<k
    · have hx := Int.mul_le_mul_of_nonneg_right (c:=w) (show l+1≤k by omega) (by omega)
      have hy := Int.mul_le_mul_of_nonneg_right (c:=h) (show l+1≤k by omega) (by omega)
      simp only [Int.add_mul, Int.one_mul] at hx hy
      omega
    · omega

/-- Nested diagonal translates of a bent strip partition the quadrant. -/
def bentToQuadrant {a b c d w h : Int} (hw : 0<w) (hh : 0<h)
    (T : Tiling a b c d (BentStrip w h)) : Tiling a b c d Quadrant where
  world t := ∃ k u, 0≤k ∧ T.world u ∧ t=shift (k*w) (k*h) u
  copies := by
    rintro t ⟨k,u,hk,hu,rfl⟩
    exact (copy_shift _ _ _ _ _ _ _).mpr (T.copies u hu)
  inside := by
    rintro t ⟨k,u,hk,hu,rfl⟩ x y hit
    have hin := T.inside u hu (x-k*w) (y-k*h) ((contains_shift _ _ _ _ _).mp hit)
    have hx := Int.mul_nonneg hk (show 0≤w by omega)
    have hy := Int.mul_nonneg hk (show 0≤h by omega)
    unfold BentStrip at hin
    exact show 0≤x ∧ 0≤y by omega
  cover := by
    intro x y hxy
    have hx : 0≤x := hxy.1
    have hy : 0≤y := hxy.2
    have hxb := div_bounds w x hw
    have hyb := div_bounds h y hh
    have hg : ∃ k, 0≤k ∧ BentStrip w h (x-k*w) (y-k*h) := by
      by_cases hq : x/w≤y/h
      · have hkh := Int.mul_le_mul_of_nonneg_right (c:=h) hq (by omega)
        refine ⟨x/w, Int.ediv_nonneg hx (by omega), ?_⟩
        unfold BentStrip
        omega
      · have hkw := Int.mul_le_mul_of_nonneg_right (c:=w) (show y/h≤x/w by omega) (by omega)
        refine ⟨y/h, Int.ediv_nonneg hy (by omega), ?_⟩
        unfold BentStrip
        omega
    obtain ⟨k,hk,hxy'⟩ := hg
    obtain ⟨u,hu,hit⟩ := T.cover (x-k*w) (y-k*h) hxy'
    exact ⟨shift (k*w) (k*h) u, ⟨k,u,hk,hu,rfl⟩, (contains_shift _ _ _ _ _).mpr hit⟩
  disjoint := by
    rintro t u x y ⟨k,v,hk,hv,rfl⟩ ⟨l,z,hl,hz,rfl⟩ hit hiu
    have hv' := (contains_shift _ _ _ _ _).mp hit
    have hz' := (contains_shift _ _ _ _ _).mp hiu
    have hkv := T.inside v hv _ _ hv'
    have hlz := T.inside z hz _ _ hz'
    have hkl := bent_block_unique w h k l x y hw hh hkv hlz
    subst l
    exact congrArg (shift (k*w) (k*h)) (T.disjoint v z _ _ hv hz hv' hz')

theorem bent_tiles_quadrant {a b c d : Int} (h : BentStripTileable a b c d) :
    Tiles a b c d Quadrant := by
  obtain ⟨w,h,hw,hh,⟨T⟩⟩ := h
  exact ⟨bentToQuadrant hw hh T⟩

def mirrorX (t : Cross) : Cross :=
  ⟨-t.x-1,t.y,t.west,t.north,t.east,t.south⟩

theorem mirrorX_contains (t : Cross) (x y : Int) :
    Contains (mirrorX t) x y ↔ Contains t (-x-1) y := by
  unfold Contains mirrorX
  dsimp
  omega

theorem mirrorX_copy (a b c d : Int) (t : Cross) (ht : Copy a b c d t) :
    Copy a b c d (mirrorX t) := by
  rcases ht with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, mirrorX, he, hn, hw, hs]

def reflectRegion {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling a b c d (fun x y => R (-x-1) y) where
  world t := ∃ u, T.world u ∧ t=mirrorX u
  copies := by
    rintro t ⟨u,hu,rfl⟩
    exact mirrorX_copy _ _ _ _ u (T.copies u hu)
  inside := by
    rintro t ⟨u,hu,rfl⟩ x y hit
    exact T.inside u hu _ _ ((mirrorX_contains _ _ _).mp hit)
  cover := by
    intro x y hxy
    obtain ⟨u,hu,hit⟩ := T.cover (-x-1) y hxy
    exact ⟨mirrorX u,⟨u,hu,rfl⟩,(mirrorX_contains _ _ _).mpr hit⟩
  disjoint := by
    rintro t u x y ⟨v,hv,rfl⟩ ⟨z,hz,rfl⟩ hit hiu
    exact congrArg mirrorX (T.disjoint v z _ _ hv hz
      ((mirrorX_contains _ _ _).mp hit) ((mirrorX_contains _ _ _).mp hiu))

def quadrantToHalfPlane {a b c d : Int} (T : Tiling a b c d Quadrant) :
    Tiling a b c d HalfPlane :=
  (T.union (reflectRegion T) (by
    intro x y hxy hxy'
    unfold Quadrant at *
    omega)).congr (by
      intro x y
      unfold Quadrant HalfPlane
      omega)

theorem quadrant_tiles_halfplane {a b c d : Int} (h : Tiles a b c d Quadrant) :
    Tiles a b c d HalfPlane := by
  obtain ⟨T⟩ := h
  exact ⟨quadrantToHalfPlane T⟩

theorem t_unit_stem_halfplane (a c : Int) (ha : 1≤a) (hc : 1≤c) :
    Tiles a 1 c 0 HalfPlane :=
  strip_tiles_halfplane (PositiveConstructions.strip_tileable a c ha hc)

theorem t_unit_stem_plane (a c : Int) (ha : 1≤a) (hc : 1≤c) :
    Tiles a 1 c 0 Plane :=
  strip_tiles_plane (PositiveConstructions.strip_tileable a c ha hc)

theorem t_two_units_quadrant (a : Int) (ha : 1≤a) : Tiles a 1 1 0 Quadrant :=
  bent_tiles_quadrant (PositiveConstructions.bent_tileable a ha)

#print axioms strip_tiles_halfplane
#print axioms strip_tiles_plane
#print axioms bent_tiles_quadrant
#print axioms quadrant_tiles_halfplane

end PositiveHierarchy

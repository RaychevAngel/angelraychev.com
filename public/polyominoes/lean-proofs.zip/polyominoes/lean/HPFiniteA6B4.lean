import HPFiniteA6B4Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp6_4_node1831 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1831 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1831 ((11 : Int),(1 : Int)) hp6_4_branches1831 hp6_4_evidence1831 hp6_4_check1831 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1831,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1830 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1830 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1830 ((9 : Int),(1 : Int)) hp6_4_branches1830 hp6_4_evidence1830 hp6_4_check1830 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1829 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1829 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1829 ((9 : Int),(1 : Int)) hp6_4_branches1829 hp6_4_evidence1829 hp6_4_check1829 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1829,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1828 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1828 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1828 ((7 : Int),(1 : Int)) hp6_4_branches1828 hp6_4_evidence1828 hp6_4_check1828 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1827 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1827 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1827 ((10 : Int),(1 : Int)) hp6_4_branches1827 hp6_4_evidence1827 hp6_4_check1827 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1827,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1828 T childKnown
  · exact hp6_4_node1829 T childKnown
  · exact hp6_4_node1830 T childKnown
  · exact hp6_4_node1831 T childKnown
theorem hp6_4_node1826 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1826 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1826 ((8 : Int),(1 : Int)) hp6_4_branches1826 hp6_4_evidence1826 hp6_4_check1826 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1826,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1825 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1825 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1825 ((8 : Int),(1 : Int)) hp6_4_branches1825 hp6_4_evidence1825 hp6_4_check1825 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1825,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1824 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1824 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1824 ((0 : Int),(2 : Int)) hp6_4_branches1824 hp6_4_evidence1824 hp6_4_check1824 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1823 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1823 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1823 ((4 : Int),(1 : Int)) hp6_4_branches1823 hp6_4_evidence1823 hp6_4_check1823 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1823,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1824 T childKnown
theorem hp6_4_node1822 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1822 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1822 ((11 : Int),(2 : Int)) hp6_4_branches1822 hp6_4_evidence1822 hp6_4_check1822 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1822,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1821 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1821 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1821 ((10 : Int),(2 : Int)) hp6_4_branches1821 hp6_4_evidence1821 hp6_4_check1821 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1822 T childKnown
theorem hp6_4_node1820 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1820 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1820 ((18 : Int),(1 : Int)) hp6_4_branches1820 hp6_4_evidence1820 hp6_4_check1820 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1819 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1819 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1819 ((16 : Int),(0 : Int)) hp6_4_branches1819 hp6_4_evidence1819 hp6_4_check1819 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1819,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1820 T childKnown
theorem hp6_4_node1818 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1818 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1818 ((12 : Int),(2 : Int)) hp6_4_branches1818 hp6_4_evidence1818 hp6_4_check1818 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1818,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1819 T childKnown
theorem hp6_4_node1817 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1817 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1817 ((10 : Int),(2 : Int)) hp6_4_branches1817 hp6_4_evidence1817 hp6_4_check1817 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1817,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1818 T childKnown
theorem hp6_4_node1816 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1816 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1816 ((11 : Int),(2 : Int)) hp6_4_branches1816 hp6_4_evidence1816 hp6_4_check1816 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1816,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1815 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1815 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1815 ((11 : Int),(1 : Int)) hp6_4_branches1815 hp6_4_evidence1815 hp6_4_check1815 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1816 T childKnown
theorem hp6_4_node1814 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1814 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1814 ((10 : Int),(1 : Int)) hp6_4_branches1814 hp6_4_evidence1814 hp6_4_check1814 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1814,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1815 T childKnown
  · exact hp6_4_node1817 T childKnown
  · exact hp6_4_node1821 T childKnown
theorem hp6_4_node1813 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1813 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1813 ((3 : Int),(2 : Int)) hp6_4_branches1813 hp6_4_evidence1813 hp6_4_check1813 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1814 T childKnown
theorem hp6_4_node1812 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1812 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1812 ((5 : Int),(2 : Int)) hp6_4_branches1812 hp6_4_evidence1812 hp6_4_check1812 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1812,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1813 T childKnown
theorem hp6_4_node1811 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1811 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1811 ((0 : Int),(2 : Int)) hp6_4_branches1811 hp6_4_evidence1811 hp6_4_check1811 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1811,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1810 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1810 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1810 ((3 : Int),(2 : Int)) hp6_4_branches1810 hp6_4_evidence1810 hp6_4_check1810 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1810,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1811 T childKnown
theorem hp6_4_node1809 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1809 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1809 ((5 : Int),(1 : Int)) hp6_4_branches1809 hp6_4_evidence1809 hp6_4_check1809 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1809,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1810 T childKnown
  · exact hp6_4_node1812 T childKnown
  · exact hp6_4_node1823 T childKnown
theorem hp6_4_node1808 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1808 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1808 ((8 : Int),(1 : Int)) hp6_4_branches1808 hp6_4_evidence1808 hp6_4_check1808 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1808,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1809 T childKnown
theorem hp6_4_node1807 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1807 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1807 ((8 : Int),(1 : Int)) hp6_4_branches1807 hp6_4_evidence1807 hp6_4_check1807 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1807,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1806 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1806 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1806 ((7 : Int),(1 : Int)) hp6_4_branches1806 hp6_4_evidence1806 hp6_4_check1806 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1806,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1807 T childKnown
  · exact hp6_4_node1808 T childKnown
  · exact hp6_4_node1825 T childKnown
  · exact hp6_4_node1826 T childKnown
theorem hp6_4_node1805 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1805 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1805 ((9 : Int),(1 : Int)) hp6_4_branches1805 hp6_4_evidence1805 hp6_4_check1805 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1805,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1804 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1804 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1804 ((9 : Int),(1 : Int)) hp6_4_branches1804 hp6_4_evidence1804 hp6_4_check1804 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1804,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1803 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1803 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1803 ((9 : Int),(0 : Int)) hp6_4_branches1803 hp6_4_evidence1803 hp6_4_check1803 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1803,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1804 T childKnown
  · exact hp6_4_node1805 T childKnown
theorem hp6_4_node1802 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1802 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1802 ((7 : Int),(1 : Int)) hp6_4_branches1802 hp6_4_evidence1802 hp6_4_check1802 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1802,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1803 T childKnown
theorem hp6_4_node1801 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1801 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1801 ((0 : Int),(2 : Int)) hp6_4_branches1801 hp6_4_evidence1801 hp6_4_check1801 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1801,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1800 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1800 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1800 ((4 : Int),(1 : Int)) hp6_4_branches1800 hp6_4_evidence1800 hp6_4_check1800 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1800,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1801 T childKnown
theorem hp6_4_node1799 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1799 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1799 ((17 : Int),(1 : Int)) hp6_4_branches1799 hp6_4_evidence1799 hp6_4_check1799 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1799,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1798 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1798 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1798 ((16 : Int),(1 : Int)) hp6_4_branches1798 hp6_4_evidence1798 hp6_4_check1798 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1798,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1799 T childKnown
theorem hp6_4_node1797 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1797 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1797 ((17 : Int),(1 : Int)) hp6_4_branches1797 hp6_4_evidence1797 hp6_4_check1797 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1797,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1796 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1796 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1796 ((16 : Int),(1 : Int)) hp6_4_branches1796 hp6_4_evidence1796 hp6_4_check1796 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1797 T childKnown
theorem hp6_4_node1795 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1795 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1795 ((16 : Int),(1 : Int)) hp6_4_branches1795 hp6_4_evidence1795 hp6_4_check1795 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1795,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1794 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1794 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1794 ((17 : Int),(0 : Int)) hp6_4_branches1794 hp6_4_evidence1794 hp6_4_check1794 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1794,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1795 T childKnown
  · exact hp6_4_node1796 T childKnown
  · exact hp6_4_node1798 T childKnown
theorem hp6_4_node1793 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1793 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1793 ((14 : Int),(1 : Int)) hp6_4_branches1793 hp6_4_evidence1793 hp6_4_check1793 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1793,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1794 T childKnown
theorem hp6_4_node1792 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1792 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1792 ((13 : Int),(1 : Int)) hp6_4_branches1792 hp6_4_evidence1792 hp6_4_check1792 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1792,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1791 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1791 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1791 ((10 : Int),(2 : Int)) hp6_4_branches1791 hp6_4_evidence1791 hp6_4_check1791 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1791,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1792 T childKnown
theorem hp6_4_node1790 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1790 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1790 ((13 : Int),(1 : Int)) hp6_4_branches1790 hp6_4_evidence1790 hp6_4_check1790 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1790,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1789 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1789 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1789 ((9 : Int),(2 : Int)) hp6_4_branches1789 hp6_4_evidence1789 hp6_4_check1789 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1789,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1790 T childKnown
  · exact hp6_4_node1791 T childKnown
  · exact hp6_4_node1793 T childKnown
theorem hp6_4_node1788 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1788 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1788 ((3 : Int),(2 : Int)) hp6_4_branches1788 hp6_4_evidence1788 hp6_4_check1788 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1788,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1789 T childKnown
theorem hp6_4_node1787 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1787 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1787 ((5 : Int),(2 : Int)) hp6_4_branches1787 hp6_4_evidence1787 hp6_4_check1787 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1787,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1788 T childKnown
theorem hp6_4_node1786 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1786 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1786 ((0 : Int),(2 : Int)) hp6_4_branches1786 hp6_4_evidence1786 hp6_4_check1786 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1786,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1785 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1785 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1785 ((3 : Int),(2 : Int)) hp6_4_branches1785 hp6_4_evidence1785 hp6_4_check1785 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1785,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1786 T childKnown
theorem hp6_4_node1784 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1784 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1784 ((5 : Int),(1 : Int)) hp6_4_branches1784 hp6_4_evidence1784 hp6_4_check1784 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1784,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1785 T childKnown
  · exact hp6_4_node1787 T childKnown
  · exact hp6_4_node1800 T childKnown
theorem hp6_4_node1783 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1783 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1783 ((9 : Int),(0 : Int)) hp6_4_branches1783 hp6_4_evidence1783 hp6_4_check1783 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1784 T childKnown
theorem hp6_4_node1782 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1782 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1782 ((7 : Int),(1 : Int)) hp6_4_branches1782 hp6_4_evidence1782 hp6_4_check1782 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1783 T childKnown
theorem hp6_4_node1781 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1781 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1781 ((7 : Int),(1 : Int)) hp6_4_branches1781 hp6_4_evidence1781 hp6_4_check1781 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1781,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1780 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1780 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1780 ((7 : Int),(1 : Int)) hp6_4_branches1780 hp6_4_evidence1780 hp6_4_check1780 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1779 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1779 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1779 ((8 : Int),(0 : Int)) hp6_4_branches1779 hp6_4_evidence1779 hp6_4_check1779 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1779,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1780 T childKnown
  · exact hp6_4_node1781 T childKnown
  · exact hp6_4_node1782 T childKnown
  · exact hp6_4_node1802 T childKnown
  · exact hp6_4_node1806 T childKnown
  · exact hp6_4_node1827 T childKnown
theorem hp6_4_node1778 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1778 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1778 ((11 : Int),(1 : Int)) hp6_4_branches1778 hp6_4_evidence1778 hp6_4_check1778 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1777 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1777 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1777 ((9 : Int),(2 : Int)) hp6_4_branches1777 hp6_4_evidence1777 hp6_4_check1777 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1777,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1776 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1776 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1776 ((9 : Int),(2 : Int)) hp6_4_branches1776 hp6_4_evidence1776 hp6_4_check1776 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1775 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1775 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1775 ((10 : Int),(1 : Int)) hp6_4_branches1775 hp6_4_evidence1775 hp6_4_check1775 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1775,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1776 T childKnown
  · exact hp6_4_node1777 T childKnown
  · exact hp6_4_node1778 T childKnown
theorem hp6_4_node1774 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1774 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1774 ((8 : Int),(0 : Int)) hp6_4_branches1774 hp6_4_evidence1774 hp6_4_check1774 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1774,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1775 T childKnown
theorem hp6_4_node1773 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1773 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1773 ((10 : Int),(1 : Int)) hp6_4_branches1773 hp6_4_evidence1773 hp6_4_check1773 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1773,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1772 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1772 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1772 ((10 : Int),(1 : Int)) hp6_4_branches1772 hp6_4_evidence1772 hp6_4_check1772 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1771 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1771 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1771 ((10 : Int),(1 : Int)) hp6_4_branches1771 hp6_4_evidence1771 hp6_4_check1771 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1771,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1770 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1770 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1770 ((5 : Int),(2 : Int)) hp6_4_branches1770 hp6_4_evidence1770 hp6_4_check1770 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1770,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1771 T childKnown
theorem hp6_4_node1769 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1769 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1769 ((4 : Int),(2 : Int)) hp6_4_branches1769 hp6_4_evidence1769 hp6_4_check1769 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1769,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1770 T childKnown
  · exact hp6_4_node1772 T childKnown
  · exact hp6_4_node1773 T childKnown
theorem hp6_4_node1768 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1768 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1768 ((10 : Int),(1 : Int)) hp6_4_branches1768 hp6_4_evidence1768 hp6_4_check1768 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1768,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1767 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1767 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1767 ((4 : Int),(2 : Int)) hp6_4_branches1767 hp6_4_evidence1767 hp6_4_check1767 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1767,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1768 T childKnown
theorem hp6_4_node1766 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1766 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1766 ((0 : Int),(2 : Int)) hp6_4_branches1766 hp6_4_evidence1766 hp6_4_check1766 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1765 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1765 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1765 ((10 : Int),(1 : Int)) hp6_4_branches1765 hp6_4_evidence1765 hp6_4_check1765 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1764 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1764 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1764 ((10 : Int),(1 : Int)) hp6_4_branches1764 hp6_4_evidence1764 hp6_4_check1764 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1764,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1763 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1763 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1763 ((10 : Int),(1 : Int)) hp6_4_branches1763 hp6_4_evidence1763 hp6_4_check1763 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1763,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1762 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1762 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1762 ((10 : Int),(1 : Int)) hp6_4_branches1762 hp6_4_evidence1762 hp6_4_check1762 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1762,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1761 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1761 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1761 ((5 : Int),(2 : Int)) hp6_4_branches1761 hp6_4_evidence1761 hp6_4_check1761 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1762 T childKnown
  · exact hp6_4_node1763 T childKnown
theorem hp6_4_node1760 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1760 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1760 ((10 : Int),(1 : Int)) hp6_4_branches1760 hp6_4_evidence1760 hp6_4_check1760 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1760,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1759 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1759 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1759 ((5 : Int),(2 : Int)) hp6_4_branches1759 hp6_4_evidence1759 hp6_4_check1759 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1759,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1760 T childKnown
theorem hp6_4_node1758 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1758 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1758 ((10 : Int),(1 : Int)) hp6_4_branches1758 hp6_4_evidence1758 hp6_4_check1758 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1758,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1757 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1757 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1757 ((5 : Int),(2 : Int)) hp6_4_branches1757 hp6_4_evidence1757 hp6_4_check1757 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1757,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1758 T childKnown
theorem hp6_4_node1756 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1756 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1756 ((4 : Int),(2 : Int)) hp6_4_branches1756 hp6_4_evidence1756 hp6_4_check1756 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1756,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1757 T childKnown
  · exact hp6_4_node1759 T childKnown
  · exact hp6_4_node1761 T childKnown
  · exact hp6_4_node1764 T childKnown
  · exact hp6_4_node1765 T childKnown
theorem hp6_4_node1755 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1755 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1755 ((10 : Int),(1 : Int)) hp6_4_branches1755 hp6_4_evidence1755 hp6_4_check1755 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1754 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1754 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1754 ((10 : Int),(1 : Int)) hp6_4_branches1754 hp6_4_evidence1754 hp6_4_check1754 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1754,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1753 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1753 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1753 ((10 : Int),(1 : Int)) hp6_4_branches1753 hp6_4_evidence1753 hp6_4_check1753 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1753,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1752 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1752 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1752 ((10 : Int),(1 : Int)) hp6_4_branches1752 hp6_4_evidence1752 hp6_4_check1752 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1751 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1751 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1751 ((5 : Int),(2 : Int)) hp6_4_branches1751 hp6_4_evidence1751 hp6_4_check1751 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1751,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1752 T childKnown
  · exact hp6_4_node1753 T childKnown
theorem hp6_4_node1750 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1750 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1750 ((10 : Int),(1 : Int)) hp6_4_branches1750 hp6_4_evidence1750 hp6_4_check1750 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1750,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1749 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1749 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1749 ((5 : Int),(2 : Int)) hp6_4_branches1749 hp6_4_evidence1749 hp6_4_check1749 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1749,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1750 T childKnown
theorem hp6_4_node1748 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1748 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1748 ((10 : Int),(1 : Int)) hp6_4_branches1748 hp6_4_evidence1748 hp6_4_check1748 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1748,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1747 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1747 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1747 ((5 : Int),(2 : Int)) hp6_4_branches1747 hp6_4_evidence1747 hp6_4_check1747 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1748 T childKnown
theorem hp6_4_node1746 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1746 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1746 ((4 : Int),(2 : Int)) hp6_4_branches1746 hp6_4_evidence1746 hp6_4_check1746 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1746,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1747 T childKnown
  · exact hp6_4_node1749 T childKnown
  · exact hp6_4_node1751 T childKnown
  · exact hp6_4_node1754 T childKnown
  · exact hp6_4_node1755 T childKnown
theorem hp6_4_node1745 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1745 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1745 ((0 : Int),(2 : Int)) hp6_4_branches1745 hp6_4_evidence1745 hp6_4_check1745 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1745,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1746 T childKnown
theorem hp6_4_node1744 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1744 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1744 ((10 : Int),(1 : Int)) hp6_4_branches1744 hp6_4_evidence1744 hp6_4_check1744 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1744,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1743 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1743 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1743 ((10 : Int),(1 : Int)) hp6_4_branches1743 hp6_4_evidence1743 hp6_4_check1743 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1743,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1742 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1742 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1742 ((10 : Int),(1 : Int)) hp6_4_branches1742 hp6_4_evidence1742 hp6_4_check1742 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1741 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1741 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1741 ((10 : Int),(1 : Int)) hp6_4_branches1741 hp6_4_evidence1741 hp6_4_check1741 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1740 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1740 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1740 ((5 : Int),(2 : Int)) hp6_4_branches1740 hp6_4_evidence1740 hp6_4_check1740 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1740,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1741 T childKnown
  · exact hp6_4_node1742 T childKnown
theorem hp6_4_node1739 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1739 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1739 ((10 : Int),(1 : Int)) hp6_4_branches1739 hp6_4_evidence1739 hp6_4_check1739 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1739,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1738 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1738 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1738 ((5 : Int),(2 : Int)) hp6_4_branches1738 hp6_4_evidence1738 hp6_4_check1738 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1739 T childKnown
theorem hp6_4_node1737 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1737 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1737 ((10 : Int),(1 : Int)) hp6_4_branches1737 hp6_4_evidence1737 hp6_4_check1737 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1737,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1736 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1736 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1736 ((5 : Int),(2 : Int)) hp6_4_branches1736 hp6_4_evidence1736 hp6_4_check1736 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1736,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1737 T childKnown
theorem hp6_4_node1735 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1735 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1735 ((4 : Int),(2 : Int)) hp6_4_branches1735 hp6_4_evidence1735 hp6_4_check1735 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1735,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1736 T childKnown
  · exact hp6_4_node1738 T childKnown
  · exact hp6_4_node1740 T childKnown
  · exact hp6_4_node1743 T childKnown
  · exact hp6_4_node1744 T childKnown
theorem hp6_4_node1734 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1734 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1734 ((0 : Int),(2 : Int)) hp6_4_branches1734 hp6_4_evidence1734 hp6_4_check1734 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1734,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1735 T childKnown
theorem hp6_4_node1733 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1733 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1733 ((0 : Int),(1 : Int)) hp6_4_branches1733 hp6_4_evidence1733 hp6_4_check1733 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1733,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1734 T childKnown
  · exact hp6_4_node1745 T childKnown
  · exact hp6_4_node1756 T childKnown
  · exact hp6_4_node1766 T childKnown
theorem hp6_4_node1732 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1732 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1732 ((10 : Int),(1 : Int)) hp6_4_branches1732 hp6_4_evidence1732 hp6_4_check1732 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1731 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1731 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1731 ((10 : Int),(1 : Int)) hp6_4_branches1731 hp6_4_evidence1731 hp6_4_check1731 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1731,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1730 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1730 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1730 ((10 : Int),(1 : Int)) hp6_4_branches1730 hp6_4_evidence1730 hp6_4_check1730 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1730,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1729 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1729 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1729 ((10 : Int),(1 : Int)) hp6_4_branches1729 hp6_4_evidence1729 hp6_4_check1729 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1729,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1728 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1728 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1728 ((5 : Int),(2 : Int)) hp6_4_branches1728 hp6_4_evidence1728 hp6_4_check1728 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1728,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1729 T childKnown
  · exact hp6_4_node1730 T childKnown
theorem hp6_4_node1727 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1727 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1727 ((10 : Int),(1 : Int)) hp6_4_branches1727 hp6_4_evidence1727 hp6_4_check1727 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1727,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1726 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1726 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1726 ((5 : Int),(2 : Int)) hp6_4_branches1726 hp6_4_evidence1726 hp6_4_check1726 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1727 T childKnown
theorem hp6_4_node1725 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1725 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1725 ((10 : Int),(1 : Int)) hp6_4_branches1725 hp6_4_evidence1725 hp6_4_check1725 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1725,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1724 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1724 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1724 ((10 : Int),(1 : Int)) hp6_4_branches1724 hp6_4_evidence1724 hp6_4_check1724 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1724,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1723 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1723 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1723 ((10 : Int),(1 : Int)) hp6_4_branches1723 hp6_4_evidence1723 hp6_4_check1723 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1723,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1722 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1722 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1722 ((12 : Int),(1 : Int)) hp6_4_branches1722 hp6_4_evidence1722 hp6_4_check1722 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1721 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1721 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1721 ((11 : Int),(1 : Int)) hp6_4_branches1721 hp6_4_evidence1721 hp6_4_check1721 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1721,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1722 T childKnown
theorem hp6_4_node1720 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1720 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1720 ((10 : Int),(1 : Int)) hp6_4_branches1720 hp6_4_evidence1720 hp6_4_check1720 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1720,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1719 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1719 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1719 ((6 : Int),(2 : Int)) hp6_4_branches1719 hp6_4_evidence1719 hp6_4_check1719 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1719,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1720 T childKnown
  · exact hp6_4_node1721 T childKnown
  · exact hp6_4_node1723 T childKnown
theorem hp6_4_node1718 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1718 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1718 ((10 : Int),(1 : Int)) hp6_4_branches1718 hp6_4_evidence1718 hp6_4_check1718 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1718,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1717 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1717 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1717 ((12 : Int),(1 : Int)) hp6_4_branches1717 hp6_4_evidence1717 hp6_4_check1717 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1717,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1716 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1716 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1716 ((11 : Int),(1 : Int)) hp6_4_branches1716 hp6_4_evidence1716 hp6_4_check1716 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1716,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1717 T childKnown
theorem hp6_4_node1715 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1715 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1715 ((6 : Int),(2 : Int)) hp6_4_branches1715 hp6_4_evidence1715 hp6_4_check1715 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1715,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1716 T childKnown
  · exact hp6_4_node1718 T childKnown
theorem hp6_4_node1714 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1714 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1714 ((5 : Int),(2 : Int)) hp6_4_branches1714 hp6_4_evidence1714 hp6_4_check1714 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1714,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1715 T childKnown
  · exact hp6_4_node1719 T childKnown
  · exact hp6_4_node1724 T childKnown
  · exact hp6_4_node1725 T childKnown
theorem hp6_4_node1713 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1713 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1713 ((4 : Int),(2 : Int)) hp6_4_branches1713 hp6_4_evidence1713 hp6_4_check1713 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1713,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1714 T childKnown
  · exact hp6_4_node1726 T childKnown
  · exact hp6_4_node1728 T childKnown
  · exact hp6_4_node1731 T childKnown
  · exact hp6_4_node1732 T childKnown
theorem hp6_4_node1712 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1712 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1712 ((0 : Int),(1 : Int)) hp6_4_branches1712 hp6_4_evidence1712 hp6_4_check1712 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1712,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1711 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1711 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1711 ((0 : Int),(2 : Int)) hp6_4_branches1711 hp6_4_evidence1711 hp6_4_check1711 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1711,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1712 T childKnown
  · exact hp6_4_node1713 T childKnown
theorem hp6_4_node1710 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1710 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1710 ((2 : Int),(2 : Int)) hp6_4_branches1710 hp6_4_evidence1710 hp6_4_check1710 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1710,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1711 T childKnown
  · exact hp6_4_node1733 T childKnown
  · exact hp6_4_node1767 T childKnown
  · exact hp6_4_node1769 T childKnown
theorem hp6_4_node1709 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1709 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1709 ((8 : Int),(0 : Int)) hp6_4_branches1709 hp6_4_evidence1709 hp6_4_check1709 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1710 T childKnown
theorem hp6_4_node1708 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1708 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1708 ((3 : Int),(2 : Int)) hp6_4_branches1708 hp6_4_evidence1708 hp6_4_check1708 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1708,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1707 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1707 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1707 ((3 : Int),(2 : Int)) hp6_4_branches1707 hp6_4_evidence1707 hp6_4_check1707 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1706 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1706 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1706 ((3 : Int),(1 : Int)) hp6_4_branches1706 hp6_4_evidence1706 hp6_4_check1706 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1706,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1707 T childKnown
  · exact hp6_4_node1708 T childKnown
theorem hp6_4_node1705 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1705 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1705 ((12 : Int),(1 : Int)) hp6_4_branches1705 hp6_4_evidence1705 hp6_4_check1705 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1705,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1704 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1704 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1704 ((10 : Int),(2 : Int)) hp6_4_branches1704 hp6_4_evidence1704 hp6_4_check1704 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1704,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1703 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1703 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1703 ((7 : Int),(2 : Int)) hp6_4_branches1703 hp6_4_evidence1703 hp6_4_check1703 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1703,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1702 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1702 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1702 ((11 : Int),(1 : Int)) hp6_4_branches1702 hp6_4_evidence1702 hp6_4_check1702 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1702,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1703 T childKnown
  · exact hp6_4_node1704 T childKnown
  · exact hp6_4_node1705 T childKnown
theorem hp6_4_node1701 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1701 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1701 ((8 : Int),(0 : Int)) hp6_4_branches1701 hp6_4_evidence1701 hp6_4_check1701 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1701,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1702 T childKnown
theorem hp6_4_node1700 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1700 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1700 ((3 : Int),(1 : Int)) hp6_4_branches1700 hp6_4_evidence1700 hp6_4_check1700 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1700,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1701 T childKnown
theorem hp6_4_node1699 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1699 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1699 ((3 : Int),(2 : Int)) hp6_4_branches1699 hp6_4_evidence1699 hp6_4_check1699 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1698 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1698 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1698 ((3 : Int),(1 : Int)) hp6_4_branches1698 hp6_4_evidence1698 hp6_4_check1698 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1699 T childKnown
theorem hp6_4_node1697 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1697 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1697 ((0 : Int),(2 : Int)) hp6_4_branches1697 hp6_4_evidence1697 hp6_4_check1697 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1696 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1696 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1696 ((4 : Int),(2 : Int)) hp6_4_branches1696 hp6_4_evidence1696 hp6_4_check1696 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1696,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1695 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1695 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1695 ((4 : Int),(2 : Int)) hp6_4_branches1695 hp6_4_evidence1695 hp6_4_check1695 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1695,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1694 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1694 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1694 ((3 : Int),(2 : Int)) hp6_4_branches1694 hp6_4_evidence1694 hp6_4_check1694 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1694,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1695 T childKnown
  · exact hp6_4_node1696 T childKnown
theorem hp6_4_node1693 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1693 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1693 ((8 : Int),(0 : Int)) hp6_4_branches1693 hp6_4_evidence1693 hp6_4_check1693 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1693,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1694 T childKnown
theorem hp6_4_node1692 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1692 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1692 ((11 : Int),(1 : Int)) hp6_4_branches1692 hp6_4_evidence1692 hp6_4_check1692 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1692,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1691 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1691 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1691 ((11 : Int),(1 : Int)) hp6_4_branches1691 hp6_4_evidence1691 hp6_4_check1691 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1691,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1690 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1690 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1690 ((11 : Int),(1 : Int)) hp6_4_branches1690 hp6_4_evidence1690 hp6_4_check1690 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1689 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1689 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1689 ((6 : Int),(2 : Int)) hp6_4_branches1689 hp6_4_evidence1689 hp6_4_check1689 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1689,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1690 T childKnown
theorem hp6_4_node1688 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1688 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1688 ((5 : Int),(2 : Int)) hp6_4_branches1688 hp6_4_evidence1688 hp6_4_check1688 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1689 T childKnown
  · exact hp6_4_node1691 T childKnown
  · exact hp6_4_node1692 T childKnown
theorem hp6_4_node1687 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1687 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1687 ((8 : Int),(0 : Int)) hp6_4_branches1687 hp6_4_evidence1687 hp6_4_check1687 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1687,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1688 T childKnown
theorem hp6_4_node1686 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1686 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1686 ((3 : Int),(2 : Int)) hp6_4_branches1686 hp6_4_evidence1686 hp6_4_check1686 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1686,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1687 T childKnown
theorem hp6_4_node1685 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1685 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1685 ((4 : Int),(2 : Int)) hp6_4_branches1685 hp6_4_evidence1685 hp6_4_check1685 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1685,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1684 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1684 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1684 ((4 : Int),(2 : Int)) hp6_4_branches1684 hp6_4_evidence1684 hp6_4_check1684 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1683 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1683 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1683 ((4 : Int),(2 : Int)) hp6_4_branches1683 hp6_4_evidence1683 hp6_4_check1683 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1683,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1682 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1682 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1682 ((4 : Int),(1 : Int)) hp6_4_branches1682 hp6_4_evidence1682 hp6_4_check1682 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1682,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1683 T childKnown
  · exact hp6_4_node1684 T childKnown
  · exact hp6_4_node1685 T childKnown
theorem hp6_4_node1681 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1681 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1681 ((13 : Int),(1 : Int)) hp6_4_branches1681 hp6_4_evidence1681 hp6_4_check1681 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1681,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1680 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1680 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1680 ((11 : Int),(2 : Int)) hp6_4_branches1680 hp6_4_evidence1680 hp6_4_check1680 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1680,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1679 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1679 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1679 ((8 : Int),(2 : Int)) hp6_4_branches1679 hp6_4_evidence1679 hp6_4_check1679 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1679,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1678 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1678 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1678 ((12 : Int),(1 : Int)) hp6_4_branches1678 hp6_4_evidence1678 hp6_4_check1678 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1678,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1679 T childKnown
  · exact hp6_4_node1680 T childKnown
  · exact hp6_4_node1681 T childKnown
theorem hp6_4_node1677 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1677 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1677 ((8 : Int),(0 : Int)) hp6_4_branches1677 hp6_4_evidence1677 hp6_4_check1677 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1677,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1678 T childKnown
theorem hp6_4_node1676 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1676 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1676 ((10 : Int),(1 : Int)) hp6_4_branches1676 hp6_4_evidence1676 hp6_4_check1676 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1676,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1675 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1675 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1675 ((10 : Int),(1 : Int)) hp6_4_branches1675 hp6_4_evidence1675 hp6_4_check1675 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1674 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1674 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1674 ((9 : Int),(1 : Int)) hp6_4_branches1674 hp6_4_evidence1674 hp6_4_check1674 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1674,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1675 T childKnown
  · exact hp6_4_node1676 T childKnown
theorem hp6_4_node1673 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1673 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1673 ((12 : Int),(2 : Int)) hp6_4_branches1673 hp6_4_evidence1673 hp6_4_check1673 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1673,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1672 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1672 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1672 ((11 : Int),(2 : Int)) hp6_4_branches1672 hp6_4_evidence1672 hp6_4_check1672 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1673 T childKnown
theorem hp6_4_node1671 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1671 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1671 ((19 : Int),(1 : Int)) hp6_4_branches1671 hp6_4_evidence1671 hp6_4_check1671 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1671,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1670 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1670 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1670 ((17 : Int),(0 : Int)) hp6_4_branches1670 hp6_4_evidence1670 hp6_4_check1670 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1670,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1671 T childKnown
theorem hp6_4_node1669 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1669 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1669 ((13 : Int),(2 : Int)) hp6_4_branches1669 hp6_4_evidence1669 hp6_4_check1669 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1669,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1670 T childKnown
theorem hp6_4_node1668 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1668 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1668 ((11 : Int),(2 : Int)) hp6_4_branches1668 hp6_4_evidence1668 hp6_4_check1668 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1668,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1669 T childKnown
theorem hp6_4_node1667 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1667 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1667 ((12 : Int),(2 : Int)) hp6_4_branches1667 hp6_4_evidence1667 hp6_4_check1667 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1666 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1666 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1666 ((12 : Int),(1 : Int)) hp6_4_branches1666 hp6_4_evidence1666 hp6_4_check1666 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1666,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1667 T childKnown
theorem hp6_4_node1665 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1665 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1665 ((11 : Int),(1 : Int)) hp6_4_branches1665 hp6_4_evidence1665 hp6_4_check1665 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1665,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1666 T childKnown
  · exact hp6_4_node1668 T childKnown
  · exact hp6_4_node1672 T childKnown
theorem hp6_4_node1664 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1664 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1664 ((9 : Int),(1 : Int)) hp6_4_branches1664 hp6_4_evidence1664 hp6_4_check1664 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1664,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1665 T childKnown
theorem hp6_4_node1663 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1663 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1663 ((10 : Int),(1 : Int)) hp6_4_branches1663 hp6_4_evidence1663 hp6_4_check1663 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1662 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1662 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1662 ((10 : Int),(1 : Int)) hp6_4_branches1662 hp6_4_evidence1662 hp6_4_check1662 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1662,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1661 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1661 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1661 ((10 : Int),(0 : Int)) hp6_4_branches1661 hp6_4_evidence1661 hp6_4_check1661 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1661,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1662 T childKnown
  · exact hp6_4_node1663 T childKnown
theorem hp6_4_node1660 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1660 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1660 ((18 : Int),(1 : Int)) hp6_4_branches1660 hp6_4_evidence1660 hp6_4_check1660 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1660,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1659 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1659 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1659 ((17 : Int),(1 : Int)) hp6_4_branches1659 hp6_4_evidence1659 hp6_4_check1659 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1660 T childKnown
theorem hp6_4_node1658 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1658 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1658 ((18 : Int),(1 : Int)) hp6_4_branches1658 hp6_4_evidence1658 hp6_4_check1658 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1658,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1657 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1657 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1657 ((17 : Int),(1 : Int)) hp6_4_branches1657 hp6_4_evidence1657 hp6_4_check1657 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1657,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1658 T childKnown
theorem hp6_4_node1656 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1656 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1656 ((17 : Int),(1 : Int)) hp6_4_branches1656 hp6_4_evidence1656 hp6_4_check1656 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1655 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1655 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1655 ((18 : Int),(0 : Int)) hp6_4_branches1655 hp6_4_evidence1655 hp6_4_check1655 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1655,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1656 T childKnown
  · exact hp6_4_node1657 T childKnown
  · exact hp6_4_node1659 T childKnown
theorem hp6_4_node1654 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1654 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1654 ((15 : Int),(1 : Int)) hp6_4_branches1654 hp6_4_evidence1654 hp6_4_check1654 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1654,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1655 T childKnown
theorem hp6_4_node1653 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1653 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1653 ((14 : Int),(1 : Int)) hp6_4_branches1653 hp6_4_evidence1653 hp6_4_check1653 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1653,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1652 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1652 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1652 ((11 : Int),(2 : Int)) hp6_4_branches1652 hp6_4_evidence1652 hp6_4_check1652 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1653 T childKnown
theorem hp6_4_node1651 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1651 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1651 ((14 : Int),(1 : Int)) hp6_4_branches1651 hp6_4_evidence1651 hp6_4_check1651 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1651,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1650 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1650 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1650 ((11 : Int),(2 : Int)) hp6_4_branches1650 hp6_4_evidence1650 hp6_4_check1650 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1649 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1649 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1649 ((13 : Int),(2 : Int)) hp6_4_branches1649 hp6_4_evidence1649 hp6_4_check1649 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1648 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1648 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1648 ((14 : Int),(1 : Int)) hp6_4_branches1648 hp6_4_evidence1648 hp6_4_check1648 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1648,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1649 T childKnown
  · exact hp6_4_node1650 T childKnown
theorem hp6_4_node1647 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1647 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1647 ((10 : Int),(2 : Int)) hp6_4_branches1647 hp6_4_evidence1647 hp6_4_check1647 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1647,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1648 T childKnown
  · exact hp6_4_node1651 T childKnown
  · exact hp6_4_node1652 T childKnown
  · exact hp6_4_node1654 T childKnown
theorem hp6_4_node1646 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1646 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1646 ((10 : Int),(0 : Int)) hp6_4_branches1646 hp6_4_evidence1646 hp6_4_check1646 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1647 T childKnown
theorem hp6_4_node1645 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1645 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1645 ((9 : Int),(0 : Int)) hp6_4_branches1645 hp6_4_evidence1645 hp6_4_check1645 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1645,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1646 T childKnown
  · exact hp6_4_node1661 T childKnown
  · exact hp6_4_node1664 T childKnown
  · exact hp6_4_node1674 T childKnown
theorem hp6_4_node1644 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1644 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1644 ((4 : Int),(1 : Int)) hp6_4_branches1644 hp6_4_evidence1644 hp6_4_check1644 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1644,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1645 T childKnown
  · exact hp6_4_node1677 T childKnown
theorem hp6_4_node1643 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1643 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1643 ((3 : Int),(1 : Int)) hp6_4_branches1643 hp6_4_evidence1643 hp6_4_check1643 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1644 T childKnown
  · exact hp6_4_node1682 T childKnown
  · exact hp6_4_node1686 T childKnown
  · exact hp6_4_node1693 T childKnown
theorem hp6_4_node1642 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1642 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1642 ((4 : Int),(2 : Int)) hp6_4_branches1642 hp6_4_evidence1642 hp6_4_check1642 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1642,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1641 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1641 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1641 ((4 : Int),(2 : Int)) hp6_4_branches1641 hp6_4_evidence1641 hp6_4_check1641 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1641,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1640 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1640 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1640 ((3 : Int),(2 : Int)) hp6_4_branches1640 hp6_4_evidence1640 hp6_4_check1640 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1640,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1641 T childKnown
  · exact hp6_4_node1642 T childKnown
theorem hp6_4_node1639 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1639 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1639 ((8 : Int),(0 : Int)) hp6_4_branches1639 hp6_4_evidence1639 hp6_4_check1639 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1640 T childKnown
theorem hp6_4_node1638 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1638 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1638 ((11 : Int),(1 : Int)) hp6_4_branches1638 hp6_4_evidence1638 hp6_4_check1638 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1637 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1637 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1637 ((11 : Int),(1 : Int)) hp6_4_branches1637 hp6_4_evidence1637 hp6_4_check1637 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1637,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1636 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1636 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1636 ((11 : Int),(1 : Int)) hp6_4_branches1636 hp6_4_evidence1636 hp6_4_check1636 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1636,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1635 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1635 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1635 ((6 : Int),(2 : Int)) hp6_4_branches1635 hp6_4_evidence1635 hp6_4_check1635 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1635,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1636 T childKnown
theorem hp6_4_node1634 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1634 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1634 ((5 : Int),(2 : Int)) hp6_4_branches1634 hp6_4_evidence1634 hp6_4_check1634 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1634,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1635 T childKnown
  · exact hp6_4_node1637 T childKnown
  · exact hp6_4_node1638 T childKnown
theorem hp6_4_node1633 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1633 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1633 ((8 : Int),(0 : Int)) hp6_4_branches1633 hp6_4_evidence1633 hp6_4_check1633 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1633,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1634 T childKnown
theorem hp6_4_node1632 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1632 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1632 ((3 : Int),(2 : Int)) hp6_4_branches1632 hp6_4_evidence1632 hp6_4_check1632 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1632,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1633 T childKnown
theorem hp6_4_node1631 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1631 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1631 ((4 : Int),(2 : Int)) hp6_4_branches1631 hp6_4_evidence1631 hp6_4_check1631 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1630 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1630 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1630 ((4 : Int),(2 : Int)) hp6_4_branches1630 hp6_4_evidence1630 hp6_4_check1630 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1630,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1629 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1629 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1629 ((4 : Int),(2 : Int)) hp6_4_branches1629 hp6_4_evidence1629 hp6_4_check1629 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1629,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1628 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1628 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1628 ((4 : Int),(1 : Int)) hp6_4_branches1628 hp6_4_evidence1628 hp6_4_check1628 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1628,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1629 T childKnown
  · exact hp6_4_node1630 T childKnown
  · exact hp6_4_node1631 T childKnown
theorem hp6_4_node1627 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1627 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1627 ((13 : Int),(1 : Int)) hp6_4_branches1627 hp6_4_evidence1627 hp6_4_check1627 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1626 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1626 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1626 ((11 : Int),(2 : Int)) hp6_4_branches1626 hp6_4_evidence1626 hp6_4_check1626 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1626,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1625 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1625 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1625 ((8 : Int),(2 : Int)) hp6_4_branches1625 hp6_4_evidence1625 hp6_4_check1625 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1625,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1624 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1624 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1624 ((12 : Int),(1 : Int)) hp6_4_branches1624 hp6_4_evidence1624 hp6_4_check1624 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1624,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1625 T childKnown
  · exact hp6_4_node1626 T childKnown
  · exact hp6_4_node1627 T childKnown
theorem hp6_4_node1623 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1623 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1623 ((8 : Int),(0 : Int)) hp6_4_branches1623 hp6_4_evidence1623 hp6_4_check1623 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1623,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1624 T childKnown
theorem hp6_4_node1622 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1622 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1622 ((10 : Int),(1 : Int)) hp6_4_branches1622 hp6_4_evidence1622 hp6_4_check1622 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1622,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1621 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1621 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1621 ((10 : Int),(1 : Int)) hp6_4_branches1621 hp6_4_evidence1621 hp6_4_check1621 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1621,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1620 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1620 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1620 ((9 : Int),(1 : Int)) hp6_4_branches1620 hp6_4_evidence1620 hp6_4_check1620 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1620,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1621 T childKnown
  · exact hp6_4_node1622 T childKnown
theorem hp6_4_node1619 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1619 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1619 ((12 : Int),(2 : Int)) hp6_4_branches1619 hp6_4_evidence1619 hp6_4_check1619 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1619,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1618 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1618 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1618 ((11 : Int),(2 : Int)) hp6_4_branches1618 hp6_4_evidence1618 hp6_4_check1618 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1619 T childKnown
theorem hp6_4_node1617 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1617 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1617 ((19 : Int),(1 : Int)) hp6_4_branches1617 hp6_4_evidence1617 hp6_4_check1617 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1617,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1616 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1616 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1616 ((17 : Int),(0 : Int)) hp6_4_branches1616 hp6_4_evidence1616 hp6_4_check1616 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1616,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1617 T childKnown
theorem hp6_4_node1615 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1615 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1615 ((13 : Int),(2 : Int)) hp6_4_branches1615 hp6_4_evidence1615 hp6_4_check1615 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1615,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1616 T childKnown
theorem hp6_4_node1614 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1614 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1614 ((11 : Int),(2 : Int)) hp6_4_branches1614 hp6_4_evidence1614 hp6_4_check1614 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1614,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1615 T childKnown
theorem hp6_4_node1613 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1613 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1613 ((12 : Int),(2 : Int)) hp6_4_branches1613 hp6_4_evidence1613 hp6_4_check1613 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1612 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1612 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1612 ((12 : Int),(1 : Int)) hp6_4_branches1612 hp6_4_evidence1612 hp6_4_check1612 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1613 T childKnown
theorem hp6_4_node1611 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1611 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1611 ((11 : Int),(1 : Int)) hp6_4_branches1611 hp6_4_evidence1611 hp6_4_check1611 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1612 T childKnown
  · exact hp6_4_node1614 T childKnown
  · exact hp6_4_node1618 T childKnown
theorem hp6_4_node1610 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1610 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1610 ((9 : Int),(1 : Int)) hp6_4_branches1610 hp6_4_evidence1610 hp6_4_check1610 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1610,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1611 T childKnown
theorem hp6_4_node1609 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1609 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1609 ((10 : Int),(1 : Int)) hp6_4_branches1609 hp6_4_evidence1609 hp6_4_check1609 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1609,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1608 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1608 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1608 ((10 : Int),(1 : Int)) hp6_4_branches1608 hp6_4_evidence1608 hp6_4_check1608 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1607 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1607 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1607 ((10 : Int),(0 : Int)) hp6_4_branches1607 hp6_4_evidence1607 hp6_4_check1607 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1608 T childKnown
  · exact hp6_4_node1609 T childKnown
theorem hp6_4_node1606 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1606 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1606 ((18 : Int),(1 : Int)) hp6_4_branches1606 hp6_4_evidence1606 hp6_4_check1606 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1606,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1605 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1605 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1605 ((17 : Int),(1 : Int)) hp6_4_branches1605 hp6_4_evidence1605 hp6_4_check1605 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1606 T childKnown
theorem hp6_4_node1604 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1604 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1604 ((18 : Int),(1 : Int)) hp6_4_branches1604 hp6_4_evidence1604 hp6_4_check1604 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1603 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1603 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1603 ((17 : Int),(1 : Int)) hp6_4_branches1603 hp6_4_evidence1603 hp6_4_check1603 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1603,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1604 T childKnown
theorem hp6_4_node1602 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1602 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1602 ((17 : Int),(1 : Int)) hp6_4_branches1602 hp6_4_evidence1602 hp6_4_check1602 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1601 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1601 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1601 ((18 : Int),(0 : Int)) hp6_4_branches1601 hp6_4_evidence1601 hp6_4_check1601 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1602 T childKnown
  · exact hp6_4_node1603 T childKnown
  · exact hp6_4_node1605 T childKnown
theorem hp6_4_node1600 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1600 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1600 ((15 : Int),(1 : Int)) hp6_4_branches1600 hp6_4_evidence1600 hp6_4_check1600 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1600,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1601 T childKnown
theorem hp6_4_node1599 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1599 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1599 ((14 : Int),(1 : Int)) hp6_4_branches1599 hp6_4_evidence1599 hp6_4_check1599 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1599,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1598 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1598 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1598 ((11 : Int),(2 : Int)) hp6_4_branches1598 hp6_4_evidence1598 hp6_4_check1598 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1598,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1599 T childKnown
theorem hp6_4_node1597 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1597 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1597 ((14 : Int),(1 : Int)) hp6_4_branches1597 hp6_4_evidence1597 hp6_4_check1597 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1597,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1596 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1596 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1596 ((11 : Int),(2 : Int)) hp6_4_branches1596 hp6_4_evidence1596 hp6_4_check1596 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1596,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1595 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1595 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1595 ((13 : Int),(2 : Int)) hp6_4_branches1595 hp6_4_evidence1595 hp6_4_check1595 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1594 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1594 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1594 ((14 : Int),(1 : Int)) hp6_4_branches1594 hp6_4_evidence1594 hp6_4_check1594 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1594,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1595 T childKnown
  · exact hp6_4_node1596 T childKnown
theorem hp6_4_node1593 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1593 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1593 ((10 : Int),(2 : Int)) hp6_4_branches1593 hp6_4_evidence1593 hp6_4_check1593 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1594 T childKnown
  · exact hp6_4_node1597 T childKnown
  · exact hp6_4_node1598 T childKnown
  · exact hp6_4_node1600 T childKnown
theorem hp6_4_node1592 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1592 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1592 ((10 : Int),(0 : Int)) hp6_4_branches1592 hp6_4_evidence1592 hp6_4_check1592 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1592,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1593 T childKnown
theorem hp6_4_node1591 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1591 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1591 ((9 : Int),(0 : Int)) hp6_4_branches1591 hp6_4_evidence1591 hp6_4_check1591 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1591,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1592 T childKnown
  · exact hp6_4_node1607 T childKnown
  · exact hp6_4_node1610 T childKnown
  · exact hp6_4_node1620 T childKnown
theorem hp6_4_node1590 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1590 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1590 ((4 : Int),(1 : Int)) hp6_4_branches1590 hp6_4_evidence1590 hp6_4_check1590 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1591 T childKnown
  · exact hp6_4_node1623 T childKnown
theorem hp6_4_node1589 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1589 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1589 ((3 : Int),(1 : Int)) hp6_4_branches1589 hp6_4_evidence1589 hp6_4_check1589 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1589,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1590 T childKnown
  · exact hp6_4_node1628 T childKnown
  · exact hp6_4_node1632 T childKnown
  · exact hp6_4_node1639 T childKnown
theorem hp6_4_node1588 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1588 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1588 ((0 : Int),(2 : Int)) hp6_4_branches1588 hp6_4_evidence1588 hp6_4_check1588 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1588,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1589 T childKnown
theorem hp6_4_node1587 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1587 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1587 ((4 : Int),(2 : Int)) hp6_4_branches1587 hp6_4_evidence1587 hp6_4_check1587 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1586 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1586 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1586 ((4 : Int),(2 : Int)) hp6_4_branches1586 hp6_4_evidence1586 hp6_4_check1586 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1586,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1585 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1585 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1585 ((3 : Int),(2 : Int)) hp6_4_branches1585 hp6_4_evidence1585 hp6_4_check1585 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1585,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1586 T childKnown
  · exact hp6_4_node1587 T childKnown
theorem hp6_4_node1584 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1584 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1584 ((8 : Int),(0 : Int)) hp6_4_branches1584 hp6_4_evidence1584 hp6_4_check1584 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1585 T childKnown
theorem hp6_4_node1583 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1583 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1583 ((11 : Int),(1 : Int)) hp6_4_branches1583 hp6_4_evidence1583 hp6_4_check1583 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1583,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1582 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1582 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1582 ((11 : Int),(1 : Int)) hp6_4_branches1582 hp6_4_evidence1582 hp6_4_check1582 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1581 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1581 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1581 ((11 : Int),(1 : Int)) hp6_4_branches1581 hp6_4_evidence1581 hp6_4_check1581 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1581,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1580 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1580 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1580 ((6 : Int),(2 : Int)) hp6_4_branches1580 hp6_4_evidence1580 hp6_4_check1580 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1580,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1581 T childKnown
theorem hp6_4_node1579 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1579 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1579 ((5 : Int),(2 : Int)) hp6_4_branches1579 hp6_4_evidence1579 hp6_4_check1579 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1580 T childKnown
  · exact hp6_4_node1582 T childKnown
  · exact hp6_4_node1583 T childKnown
theorem hp6_4_node1578 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1578 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1578 ((8 : Int),(0 : Int)) hp6_4_branches1578 hp6_4_evidence1578 hp6_4_check1578 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1578,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1579 T childKnown
theorem hp6_4_node1577 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1577 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1577 ((3 : Int),(2 : Int)) hp6_4_branches1577 hp6_4_evidence1577 hp6_4_check1577 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1578 T childKnown
theorem hp6_4_node1576 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1576 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1576 ((4 : Int),(2 : Int)) hp6_4_branches1576 hp6_4_evidence1576 hp6_4_check1576 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1575 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1575 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1575 ((4 : Int),(2 : Int)) hp6_4_branches1575 hp6_4_evidence1575 hp6_4_check1575 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1574 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1574 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1574 ((4 : Int),(2 : Int)) hp6_4_branches1574 hp6_4_evidence1574 hp6_4_check1574 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1573 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1573 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1573 ((4 : Int),(1 : Int)) hp6_4_branches1573 hp6_4_evidence1573 hp6_4_check1573 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1573,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1574 T childKnown
  · exact hp6_4_node1575 T childKnown
  · exact hp6_4_node1576 T childKnown
theorem hp6_4_node1572 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1572 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1572 ((13 : Int),(1 : Int)) hp6_4_branches1572 hp6_4_evidence1572 hp6_4_check1572 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1571 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1571 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1571 ((11 : Int),(2 : Int)) hp6_4_branches1571 hp6_4_evidence1571 hp6_4_check1571 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1571,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1570 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1570 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1570 ((8 : Int),(2 : Int)) hp6_4_branches1570 hp6_4_evidence1570 hp6_4_check1570 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1569 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1569 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1569 ((12 : Int),(1 : Int)) hp6_4_branches1569 hp6_4_evidence1569 hp6_4_check1569 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1569,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1570 T childKnown
  · exact hp6_4_node1571 T childKnown
  · exact hp6_4_node1572 T childKnown
theorem hp6_4_node1568 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1568 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1568 ((8 : Int),(0 : Int)) hp6_4_branches1568 hp6_4_evidence1568 hp6_4_check1568 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1568,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1569 T childKnown
theorem hp6_4_node1567 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1567 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1567 ((10 : Int),(1 : Int)) hp6_4_branches1567 hp6_4_evidence1567 hp6_4_check1567 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1567,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1566 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1566 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1566 ((10 : Int),(1 : Int)) hp6_4_branches1566 hp6_4_evidence1566 hp6_4_check1566 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1565 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1565 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1565 ((9 : Int),(1 : Int)) hp6_4_branches1565 hp6_4_evidence1565 hp6_4_check1565 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1566 T childKnown
  · exact hp6_4_node1567 T childKnown
theorem hp6_4_node1564 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1564 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1564 ((12 : Int),(2 : Int)) hp6_4_branches1564 hp6_4_evidence1564 hp6_4_check1564 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1564,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1563 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1563 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1563 ((11 : Int),(2 : Int)) hp6_4_branches1563 hp6_4_evidence1563 hp6_4_check1563 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1564 T childKnown
theorem hp6_4_node1562 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1562 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1562 ((19 : Int),(1 : Int)) hp6_4_branches1562 hp6_4_evidence1562 hp6_4_check1562 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1561 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1561 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1561 ((17 : Int),(0 : Int)) hp6_4_branches1561 hp6_4_evidence1561 hp6_4_check1561 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1561,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1562 T childKnown
theorem hp6_4_node1560 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1560 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1560 ((13 : Int),(2 : Int)) hp6_4_branches1560 hp6_4_evidence1560 hp6_4_check1560 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1561 T childKnown
theorem hp6_4_node1559 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1559 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1559 ((11 : Int),(2 : Int)) hp6_4_branches1559 hp6_4_evidence1559 hp6_4_check1559 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1559,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1560 T childKnown
theorem hp6_4_node1558 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1558 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1558 ((12 : Int),(2 : Int)) hp6_4_branches1558 hp6_4_evidence1558 hp6_4_check1558 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1557 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1557 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1557 ((12 : Int),(1 : Int)) hp6_4_branches1557 hp6_4_evidence1557 hp6_4_check1557 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1557,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1558 T childKnown
theorem hp6_4_node1556 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1556 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1556 ((11 : Int),(1 : Int)) hp6_4_branches1556 hp6_4_evidence1556 hp6_4_check1556 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1557 T childKnown
  · exact hp6_4_node1559 T childKnown
  · exact hp6_4_node1563 T childKnown
theorem hp6_4_node1555 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1555 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1555 ((9 : Int),(1 : Int)) hp6_4_branches1555 hp6_4_evidence1555 hp6_4_check1555 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1556 T childKnown
theorem hp6_4_node1554 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1554 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1554 ((10 : Int),(1 : Int)) hp6_4_branches1554 hp6_4_evidence1554 hp6_4_check1554 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1554,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1553 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1553 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1553 ((10 : Int),(1 : Int)) hp6_4_branches1553 hp6_4_evidence1553 hp6_4_check1553 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1553,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1552 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1552 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1552 ((10 : Int),(0 : Int)) hp6_4_branches1552 hp6_4_evidence1552 hp6_4_check1552 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1553 T childKnown
  · exact hp6_4_node1554 T childKnown
theorem hp6_4_node1551 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1551 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1551 ((18 : Int),(1 : Int)) hp6_4_branches1551 hp6_4_evidence1551 hp6_4_check1551 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1551,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1550 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1550 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1550 ((17 : Int),(1 : Int)) hp6_4_branches1550 hp6_4_evidence1550 hp6_4_check1550 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1550,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1551 T childKnown
theorem hp6_4_node1549 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1549 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1549 ((18 : Int),(1 : Int)) hp6_4_branches1549 hp6_4_evidence1549 hp6_4_check1549 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1548 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1548 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1548 ((17 : Int),(1 : Int)) hp6_4_branches1548 hp6_4_evidence1548 hp6_4_check1548 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1548,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1549 T childKnown
theorem hp6_4_node1547 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1547 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1547 ((17 : Int),(1 : Int)) hp6_4_branches1547 hp6_4_evidence1547 hp6_4_check1547 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1547,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1546 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1546 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1546 ((18 : Int),(0 : Int)) hp6_4_branches1546 hp6_4_evidence1546 hp6_4_check1546 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1547 T childKnown
  · exact hp6_4_node1548 T childKnown
  · exact hp6_4_node1550 T childKnown
theorem hp6_4_node1545 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1545 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1545 ((15 : Int),(1 : Int)) hp6_4_branches1545 hp6_4_evidence1545 hp6_4_check1545 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1545,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1546 T childKnown
theorem hp6_4_node1544 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1544 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1544 ((14 : Int),(1 : Int)) hp6_4_branches1544 hp6_4_evidence1544 hp6_4_check1544 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1543 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1543 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1543 ((11 : Int),(2 : Int)) hp6_4_branches1543 hp6_4_evidence1543 hp6_4_check1543 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1544 T childKnown
theorem hp6_4_node1542 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1542 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1542 ((14 : Int),(1 : Int)) hp6_4_branches1542 hp6_4_evidence1542 hp6_4_check1542 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1541 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1541 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1541 ((11 : Int),(2 : Int)) hp6_4_branches1541 hp6_4_evidence1541 hp6_4_check1541 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1541,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1540 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1540 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1540 ((13 : Int),(2 : Int)) hp6_4_branches1540 hp6_4_evidence1540 hp6_4_check1540 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1539 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1539 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1539 ((14 : Int),(1 : Int)) hp6_4_branches1539 hp6_4_evidence1539 hp6_4_check1539 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1540 T childKnown
  · exact hp6_4_node1541 T childKnown
theorem hp6_4_node1538 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1538 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1538 ((10 : Int),(2 : Int)) hp6_4_branches1538 hp6_4_evidence1538 hp6_4_check1538 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1539 T childKnown
  · exact hp6_4_node1542 T childKnown
  · exact hp6_4_node1543 T childKnown
  · exact hp6_4_node1545 T childKnown
theorem hp6_4_node1537 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1537 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1537 ((10 : Int),(0 : Int)) hp6_4_branches1537 hp6_4_evidence1537 hp6_4_check1537 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1537,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1538 T childKnown
theorem hp6_4_node1536 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1536 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1536 ((9 : Int),(0 : Int)) hp6_4_branches1536 hp6_4_evidence1536 hp6_4_check1536 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1536,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1537 T childKnown
  · exact hp6_4_node1552 T childKnown
  · exact hp6_4_node1555 T childKnown
  · exact hp6_4_node1565 T childKnown
theorem hp6_4_node1535 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1535 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1535 ((4 : Int),(1 : Int)) hp6_4_branches1535 hp6_4_evidence1535 hp6_4_check1535 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1535,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1536 T childKnown
  · exact hp6_4_node1568 T childKnown
theorem hp6_4_node1534 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1534 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1534 ((3 : Int),(1 : Int)) hp6_4_branches1534 hp6_4_evidence1534 hp6_4_check1534 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1534,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1535 T childKnown
  · exact hp6_4_node1573 T childKnown
  · exact hp6_4_node1577 T childKnown
  · exact hp6_4_node1584 T childKnown
theorem hp6_4_node1533 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1533 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1533 ((0 : Int),(2 : Int)) hp6_4_branches1533 hp6_4_evidence1533 hp6_4_check1533 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1533,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1534 T childKnown
theorem hp6_4_node1532 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1532 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1532 ((0 : Int),(1 : Int)) hp6_4_branches1532 hp6_4_evidence1532 hp6_4_check1532 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1533 T childKnown
  · exact hp6_4_node1588 T childKnown
  · exact hp6_4_node1643 T childKnown
  · exact hp6_4_node1697 T childKnown
theorem hp6_4_node1531 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1531 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1531 ((0 : Int),(2 : Int)) hp6_4_branches1531 hp6_4_evidence1531 hp6_4_check1531 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1530 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1530 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1530 ((0 : Int),(1 : Int)) hp6_4_branches1530 hp6_4_evidence1530 hp6_4_check1530 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1531 T childKnown
theorem hp6_4_node1529 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1529 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1529 ((2 : Int),(1 : Int)) hp6_4_branches1529 hp6_4_evidence1529 hp6_4_check1529 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1529,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1530 T childKnown
  · exact hp6_4_node1532 T childKnown
  · exact hp6_4_node1698 T childKnown
  · exact hp6_4_node1700 T childKnown
  · exact hp6_4_node1706 T childKnown
  · exact hp6_4_node1709 T childKnown
  · exact hp6_4_node1774 T childKnown
theorem hp6_4_node1528 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1528 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1528 ((1 : Int),(1 : Int)) hp6_4_branches1528 hp6_4_evidence1528 hp6_4_check1528 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1528,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1527 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1527 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1527 ((1 : Int),(1 : Int)) hp6_4_branches1527 hp6_4_evidence1527 hp6_4_check1527 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1526 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1526 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1526 ((1 : Int),(0 : Int)) hp6_4_branches1526 hp6_4_evidence1526 hp6_4_check1526 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1526,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1527 T childKnown
  · exact hp6_4_node1528 T childKnown
theorem hp6_4_node1525 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1525 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1525 ((9 : Int),(1 : Int)) hp6_4_branches1525 hp6_4_evidence1525 hp6_4_check1525 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1524 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1524 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1524 ((8 : Int),(1 : Int)) hp6_4_branches1524 hp6_4_evidence1524 hp6_4_check1524 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1525 T childKnown
theorem hp6_4_node1523 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1523 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1523 ((9 : Int),(1 : Int)) hp6_4_branches1523 hp6_4_evidence1523 hp6_4_check1523 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1522 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1522 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1522 ((8 : Int),(1 : Int)) hp6_4_branches1522 hp6_4_evidence1522 hp6_4_check1522 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1523 T childKnown
theorem hp6_4_node1521 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1521 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1521 ((8 : Int),(1 : Int)) hp6_4_branches1521 hp6_4_evidence1521 hp6_4_check1521 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1520 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1520 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1520 ((9 : Int),(0 : Int)) hp6_4_branches1520 hp6_4_evidence1520 hp6_4_check1520 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1520,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1521 T childKnown
  · exact hp6_4_node1522 T childKnown
  · exact hp6_4_node1524 T childKnown
theorem hp6_4_node1519 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1519 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1519 ((6 : Int),(1 : Int)) hp6_4_branches1519 hp6_4_evidence1519 hp6_4_check1519 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1519,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1520 T childKnown
theorem hp6_4_node1518 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1518 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1518 ((5 : Int),(1 : Int)) hp6_4_branches1518 hp6_4_evidence1518 hp6_4_check1518 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1517 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1517 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1517 ((2 : Int),(2 : Int)) hp6_4_branches1517 hp6_4_evidence1517 hp6_4_check1517 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1517,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1518 T childKnown
theorem hp6_4_node1516 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1516 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1516 ((5 : Int),(1 : Int)) hp6_4_branches1516 hp6_4_evidence1516 hp6_4_check1516 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1516,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1515 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1515 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1515 ((2 : Int),(2 : Int)) hp6_4_branches1515 hp6_4_evidence1515 hp6_4_check1515 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1514 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1514 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1514 ((4 : Int),(2 : Int)) hp6_4_branches1514 hp6_4_evidence1514 hp6_4_check1514 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1514,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1513 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1513 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1513 ((5 : Int),(1 : Int)) hp6_4_branches1513 hp6_4_evidence1513 hp6_4_check1513 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1513,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1514 T childKnown
  · exact hp6_4_node1515 T childKnown
theorem hp6_4_node1512 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1512 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1512 ((1 : Int),(2 : Int)) hp6_4_branches1512 hp6_4_evidence1512 hp6_4_check1512 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1513 T childKnown
  · exact hp6_4_node1516 T childKnown
  · exact hp6_4_node1517 T childKnown
  · exact hp6_4_node1519 T childKnown
theorem hp6_4_node1511 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1511 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1511 ((1 : Int),(0 : Int)) hp6_4_branches1511 hp6_4_evidence1511 hp6_4_check1511 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1512 T childKnown
theorem hp6_4_node1510 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1510 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1510 ((1 : Int),(1 : Int)) hp6_4_branches1510 hp6_4_evidence1510 hp6_4_check1510 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1509 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1509 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1509 ((1 : Int),(0 : Int)) hp6_4_branches1509 hp6_4_evidence1509 hp6_4_check1509 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1509,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1510 T childKnown
theorem hp6_4_node1508 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1508 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1508 ((10 : Int),(1 : Int)) hp6_4_branches1508 hp6_4_evidence1508 hp6_4_check1508 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1508,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1507 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1507 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1507 ((8 : Int),(1 : Int)) hp6_4_branches1507 hp6_4_evidence1507 hp6_4_check1507 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1506 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1506 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1506 ((8 : Int),(1 : Int)) hp6_4_branches1506 hp6_4_evidence1506 hp6_4_check1506 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1506,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1505 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1505 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1505 ((6 : Int),(1 : Int)) hp6_4_branches1505 hp6_4_evidence1505 hp6_4_check1505 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1504 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1504 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1504 ((9 : Int),(1 : Int)) hp6_4_branches1504 hp6_4_evidence1504 hp6_4_check1504 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1504,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1505 T childKnown
  · exact hp6_4_node1506 T childKnown
  · exact hp6_4_node1507 T childKnown
  · exact hp6_4_node1508 T childKnown
theorem hp6_4_node1503 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1503 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1503 ((7 : Int),(1 : Int)) hp6_4_branches1503 hp6_4_evidence1503 hp6_4_check1503 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1502 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1502 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1502 ((7 : Int),(1 : Int)) hp6_4_branches1502 hp6_4_evidence1502 hp6_4_check1502 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1501 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1501 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1501 ((0 : Int),(2 : Int)) hp6_4_branches1501 hp6_4_evidence1501 hp6_4_check1501 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1500 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1500 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1500 ((3 : Int),(1 : Int)) hp6_4_branches1500 hp6_4_evidence1500 hp6_4_check1500 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1501 T childKnown
theorem hp6_4_node1499 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1499 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1499 ((10 : Int),(2 : Int)) hp6_4_branches1499 hp6_4_evidence1499 hp6_4_check1499 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1498 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1498 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1498 ((9 : Int),(2 : Int)) hp6_4_branches1498 hp6_4_evidence1498 hp6_4_check1498 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1499 T childKnown
theorem hp6_4_node1497 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1497 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1497 ((17 : Int),(1 : Int)) hp6_4_branches1497 hp6_4_evidence1497 hp6_4_check1497 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1496 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1496 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1496 ((15 : Int),(0 : Int)) hp6_4_branches1496 hp6_4_evidence1496 hp6_4_check1496 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1497 T childKnown
theorem hp6_4_node1495 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1495 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1495 ((11 : Int),(2 : Int)) hp6_4_branches1495 hp6_4_evidence1495 hp6_4_check1495 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1495,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1496 T childKnown
theorem hp6_4_node1494 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1494 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1494 ((9 : Int),(2 : Int)) hp6_4_branches1494 hp6_4_evidence1494 hp6_4_check1494 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1494,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1495 T childKnown
theorem hp6_4_node1493 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1493 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1493 ((10 : Int),(2 : Int)) hp6_4_branches1493 hp6_4_evidence1493 hp6_4_check1493 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1492 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1492 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1492 ((10 : Int),(1 : Int)) hp6_4_branches1492 hp6_4_evidence1492 hp6_4_check1492 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1492,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1493 T childKnown
theorem hp6_4_node1491 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1491 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1491 ((9 : Int),(1 : Int)) hp6_4_branches1491 hp6_4_evidence1491 hp6_4_check1491 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1491,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1492 T childKnown
  · exact hp6_4_node1494 T childKnown
  · exact hp6_4_node1498 T childKnown
theorem hp6_4_node1490 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1490 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1490 ((2 : Int),(2 : Int)) hp6_4_branches1490 hp6_4_evidence1490 hp6_4_check1490 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1491 T childKnown
theorem hp6_4_node1489 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1489 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1489 ((4 : Int),(2 : Int)) hp6_4_branches1489 hp6_4_evidence1489 hp6_4_check1489 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1490 T childKnown
theorem hp6_4_node1488 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1488 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1488 ((0 : Int),(2 : Int)) hp6_4_branches1488 hp6_4_evidence1488 hp6_4_check1488 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1487 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1487 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1487 ((2 : Int),(2 : Int)) hp6_4_branches1487 hp6_4_evidence1487 hp6_4_check1487 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1488 T childKnown
theorem hp6_4_node1486 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1486 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1486 ((4 : Int),(1 : Int)) hp6_4_branches1486 hp6_4_evidence1486 hp6_4_check1486 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1486,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1487 T childKnown
  · exact hp6_4_node1489 T childKnown
  · exact hp6_4_node1500 T childKnown
theorem hp6_4_node1485 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1485 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1485 ((7 : Int),(1 : Int)) hp6_4_branches1485 hp6_4_evidence1485 hp6_4_check1485 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1485,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1486 T childKnown
theorem hp6_4_node1484 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1484 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1484 ((7 : Int),(1 : Int)) hp6_4_branches1484 hp6_4_evidence1484 hp6_4_check1484 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1483 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1483 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1483 ((6 : Int),(1 : Int)) hp6_4_branches1483 hp6_4_evidence1483 hp6_4_check1483 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1484 T childKnown
  · exact hp6_4_node1485 T childKnown
  · exact hp6_4_node1502 T childKnown
  · exact hp6_4_node1503 T childKnown
theorem hp6_4_node1482 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1482 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1482 ((8 : Int),(1 : Int)) hp6_4_branches1482 hp6_4_evidence1482 hp6_4_check1482 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1481 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1481 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1481 ((8 : Int),(1 : Int)) hp6_4_branches1481 hp6_4_evidence1481 hp6_4_check1481 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1480 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1480 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1480 ((8 : Int),(0 : Int)) hp6_4_branches1480 hp6_4_evidence1480 hp6_4_check1480 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1480,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1481 T childKnown
  · exact hp6_4_node1482 T childKnown
theorem hp6_4_node1479 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1479 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1479 ((6 : Int),(1 : Int)) hp6_4_branches1479 hp6_4_evidence1479 hp6_4_check1479 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1480 T childKnown
theorem hp6_4_node1478 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1478 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1478 ((0 : Int),(2 : Int)) hp6_4_branches1478 hp6_4_evidence1478 hp6_4_check1478 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1477 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1477 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1477 ((3 : Int),(1 : Int)) hp6_4_branches1477 hp6_4_evidence1477 hp6_4_check1477 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1477,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1478 T childKnown
theorem hp6_4_node1476 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1476 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1476 ((16 : Int),(1 : Int)) hp6_4_branches1476 hp6_4_evidence1476 hp6_4_check1476 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1476,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1475 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1475 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1475 ((15 : Int),(1 : Int)) hp6_4_branches1475 hp6_4_evidence1475 hp6_4_check1475 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1475,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1476 T childKnown
theorem hp6_4_node1474 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1474 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1474 ((16 : Int),(1 : Int)) hp6_4_branches1474 hp6_4_evidence1474 hp6_4_check1474 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1473 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1473 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1473 ((15 : Int),(1 : Int)) hp6_4_branches1473 hp6_4_evidence1473 hp6_4_check1473 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1474 T childKnown
theorem hp6_4_node1472 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1472 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1472 ((15 : Int),(1 : Int)) hp6_4_branches1472 hp6_4_evidence1472 hp6_4_check1472 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1471 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1471 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1471 ((16 : Int),(0 : Int)) hp6_4_branches1471 hp6_4_evidence1471 hp6_4_check1471 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1471,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1472 T childKnown
  · exact hp6_4_node1473 T childKnown
  · exact hp6_4_node1475 T childKnown
theorem hp6_4_node1470 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1470 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1470 ((13 : Int),(1 : Int)) hp6_4_branches1470 hp6_4_evidence1470 hp6_4_check1470 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1471 T childKnown
theorem hp6_4_node1469 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1469 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1469 ((12 : Int),(1 : Int)) hp6_4_branches1469 hp6_4_evidence1469 hp6_4_check1469 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1469,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1468 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1468 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1468 ((9 : Int),(2 : Int)) hp6_4_branches1468 hp6_4_evidence1468 hp6_4_check1468 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1468,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1469 T childKnown
theorem hp6_4_node1467 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1467 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1467 ((12 : Int),(1 : Int)) hp6_4_branches1467 hp6_4_evidence1467 hp6_4_check1467 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1466 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1466 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1466 ((8 : Int),(2 : Int)) hp6_4_branches1466 hp6_4_evidence1466 hp6_4_check1466 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1467 T childKnown
  · exact hp6_4_node1468 T childKnown
  · exact hp6_4_node1470 T childKnown
theorem hp6_4_node1465 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1465 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1465 ((2 : Int),(2 : Int)) hp6_4_branches1465 hp6_4_evidence1465 hp6_4_check1465 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1466 T childKnown
theorem hp6_4_node1464 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1464 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1464 ((4 : Int),(2 : Int)) hp6_4_branches1464 hp6_4_evidence1464 hp6_4_check1464 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1464,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1465 T childKnown
theorem hp6_4_node1463 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1463 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1463 ((0 : Int),(2 : Int)) hp6_4_branches1463 hp6_4_evidence1463 hp6_4_check1463 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1462 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1462 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1462 ((2 : Int),(2 : Int)) hp6_4_branches1462 hp6_4_evidence1462 hp6_4_check1462 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1462,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1463 T childKnown
theorem hp6_4_node1461 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1461 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1461 ((4 : Int),(1 : Int)) hp6_4_branches1461 hp6_4_evidence1461 hp6_4_check1461 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1461,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1462 T childKnown
  · exact hp6_4_node1464 T childKnown
  · exact hp6_4_node1477 T childKnown
theorem hp6_4_node1460 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1460 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1460 ((8 : Int),(0 : Int)) hp6_4_branches1460 hp6_4_evidence1460 hp6_4_check1460 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1461 T childKnown
theorem hp6_4_node1459 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1459 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1459 ((6 : Int),(1 : Int)) hp6_4_branches1459 hp6_4_evidence1459 hp6_4_check1459 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1459,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1460 T childKnown
theorem hp6_4_node1458 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1458 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1458 ((6 : Int),(1 : Int)) hp6_4_branches1458 hp6_4_evidence1458 hp6_4_check1458 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1457 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1457 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1457 ((6 : Int),(1 : Int)) hp6_4_branches1457 hp6_4_evidence1457 hp6_4_check1457 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1456 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1456 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1456 ((7 : Int),(0 : Int)) hp6_4_branches1456 hp6_4_evidence1456 hp6_4_check1456 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1456,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1457 T childKnown
  · exact hp6_4_node1458 T childKnown
  · exact hp6_4_node1459 T childKnown
  · exact hp6_4_node1479 T childKnown
  · exact hp6_4_node1483 T childKnown
  · exact hp6_4_node1504 T childKnown
theorem hp6_4_node1455 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1455 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1455 ((10 : Int),(1 : Int)) hp6_4_branches1455 hp6_4_evidence1455 hp6_4_check1455 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1454 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1454 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1454 ((8 : Int),(2 : Int)) hp6_4_branches1454 hp6_4_evidence1454 hp6_4_check1454 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1454,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1453 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1453 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1453 ((8 : Int),(2 : Int)) hp6_4_branches1453 hp6_4_evidence1453 hp6_4_check1453 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1453,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1452 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1452 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1452 ((9 : Int),(1 : Int)) hp6_4_branches1452 hp6_4_evidence1452 hp6_4_check1452 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1452,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1453 T childKnown
  · exact hp6_4_node1454 T childKnown
  · exact hp6_4_node1455 T childKnown
theorem hp6_4_node1451 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1451 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1451 ((7 : Int),(0 : Int)) hp6_4_branches1451 hp6_4_evidence1451 hp6_4_check1451 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1452 T childKnown
theorem hp6_4_node1450 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1450 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1450 ((9 : Int),(1 : Int)) hp6_4_branches1450 hp6_4_evidence1450 hp6_4_check1450 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1449 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1449 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1449 ((9 : Int),(1 : Int)) hp6_4_branches1449 hp6_4_evidence1449 hp6_4_check1449 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1448 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1448 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1448 ((9 : Int),(1 : Int)) hp6_4_branches1448 hp6_4_evidence1448 hp6_4_check1448 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1447 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1447 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1447 ((4 : Int),(2 : Int)) hp6_4_branches1447 hp6_4_evidence1447 hp6_4_check1447 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1447,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1448 T childKnown
theorem hp6_4_node1446 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1446 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1446 ((3 : Int),(2 : Int)) hp6_4_branches1446 hp6_4_evidence1446 hp6_4_check1446 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1447 T childKnown
  · exact hp6_4_node1449 T childKnown
  · exact hp6_4_node1450 T childKnown
theorem hp6_4_node1445 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1445 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1445 ((9 : Int),(1 : Int)) hp6_4_branches1445 hp6_4_evidence1445 hp6_4_check1445 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1445,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1444 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1444 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1444 ((3 : Int),(2 : Int)) hp6_4_branches1444 hp6_4_evidence1444 hp6_4_check1444 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1444,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1445 T childKnown
theorem hp6_4_node1443 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1443 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1443 ((9 : Int),(1 : Int)) hp6_4_branches1443 hp6_4_evidence1443 hp6_4_check1443 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1442 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1442 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1442 ((9 : Int),(1 : Int)) hp6_4_branches1442 hp6_4_evidence1442 hp6_4_check1442 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1442,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1441 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1441 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1441 ((9 : Int),(1 : Int)) hp6_4_branches1441 hp6_4_evidence1441 hp6_4_check1441 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1440 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1440 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1440 ((9 : Int),(1 : Int)) hp6_4_branches1440 hp6_4_evidence1440 hp6_4_check1440 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1439 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1439 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1439 ((4 : Int),(2 : Int)) hp6_4_branches1439 hp6_4_evidence1439 hp6_4_check1439 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1439,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1440 T childKnown
  · exact hp6_4_node1441 T childKnown
theorem hp6_4_node1438 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1438 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1438 ((9 : Int),(1 : Int)) hp6_4_branches1438 hp6_4_evidence1438 hp6_4_check1438 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1437 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1437 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1437 ((4 : Int),(2 : Int)) hp6_4_branches1437 hp6_4_evidence1437 hp6_4_check1437 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1438 T childKnown
theorem hp6_4_node1436 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1436 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1436 ((9 : Int),(1 : Int)) hp6_4_branches1436 hp6_4_evidence1436 hp6_4_check1436 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1435 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1435 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1435 ((4 : Int),(2 : Int)) hp6_4_branches1435 hp6_4_evidence1435 hp6_4_check1435 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1435,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1436 T childKnown
theorem hp6_4_node1434 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1434 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1434 ((3 : Int),(2 : Int)) hp6_4_branches1434 hp6_4_evidence1434 hp6_4_check1434 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1434,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1435 T childKnown
  · exact hp6_4_node1437 T childKnown
  · exact hp6_4_node1439 T childKnown
  · exact hp6_4_node1442 T childKnown
  · exact hp6_4_node1443 T childKnown
theorem hp6_4_node1433 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1433 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1433 ((9 : Int),(1 : Int)) hp6_4_branches1433 hp6_4_evidence1433 hp6_4_check1433 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1432 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1432 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1432 ((9 : Int),(1 : Int)) hp6_4_branches1432 hp6_4_evidence1432 hp6_4_check1432 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1432,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1431 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1431 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1431 ((9 : Int),(1 : Int)) hp6_4_branches1431 hp6_4_evidence1431 hp6_4_check1431 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1431,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1430 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1430 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1430 ((9 : Int),(1 : Int)) hp6_4_branches1430 hp6_4_evidence1430 hp6_4_check1430 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1430,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1429 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1429 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1429 ((4 : Int),(2 : Int)) hp6_4_branches1429 hp6_4_evidence1429 hp6_4_check1429 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1430 T childKnown
  · exact hp6_4_node1431 T childKnown
theorem hp6_4_node1428 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1428 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1428 ((9 : Int),(1 : Int)) hp6_4_branches1428 hp6_4_evidence1428 hp6_4_check1428 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1427 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1427 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1427 ((4 : Int),(2 : Int)) hp6_4_branches1427 hp6_4_evidence1427 hp6_4_check1427 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1427,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1428 T childKnown
theorem hp6_4_node1426 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1426 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1426 ((9 : Int),(1 : Int)) hp6_4_branches1426 hp6_4_evidence1426 hp6_4_check1426 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1426,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1425 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1425 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1425 ((9 : Int),(1 : Int)) hp6_4_branches1425 hp6_4_evidence1425 hp6_4_check1425 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1425,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1424 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1424 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1424 ((9 : Int),(1 : Int)) hp6_4_branches1424 hp6_4_evidence1424 hp6_4_check1424 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1423 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1423 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1423 ((11 : Int),(1 : Int)) hp6_4_branches1423 hp6_4_evidence1423 hp6_4_check1423 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1422 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1422 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1422 ((10 : Int),(1 : Int)) hp6_4_branches1422 hp6_4_evidence1422 hp6_4_check1422 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1423 T childKnown
theorem hp6_4_node1421 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1421 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1421 ((9 : Int),(1 : Int)) hp6_4_branches1421 hp6_4_evidence1421 hp6_4_check1421 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1420 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1420 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1420 ((5 : Int),(2 : Int)) hp6_4_branches1420 hp6_4_evidence1420 hp6_4_check1420 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1420,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1421 T childKnown
  · exact hp6_4_node1422 T childKnown
  · exact hp6_4_node1424 T childKnown
theorem hp6_4_node1419 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1419 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1419 ((9 : Int),(1 : Int)) hp6_4_branches1419 hp6_4_evidence1419 hp6_4_check1419 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1419,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1418 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1418 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1418 ((11 : Int),(1 : Int)) hp6_4_branches1418 hp6_4_evidence1418 hp6_4_check1418 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1417 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1417 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1417 ((10 : Int),(1 : Int)) hp6_4_branches1417 hp6_4_evidence1417 hp6_4_check1417 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1417,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1418 T childKnown
theorem hp6_4_node1416 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1416 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1416 ((5 : Int),(2 : Int)) hp6_4_branches1416 hp6_4_evidence1416 hp6_4_check1416 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1417 T childKnown
  · exact hp6_4_node1419 T childKnown
theorem hp6_4_node1415 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1415 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1415 ((4 : Int),(2 : Int)) hp6_4_branches1415 hp6_4_evidence1415 hp6_4_check1415 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1415,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1416 T childKnown
  · exact hp6_4_node1420 T childKnown
  · exact hp6_4_node1425 T childKnown
  · exact hp6_4_node1426 T childKnown
theorem hp6_4_node1414 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1414 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1414 ((3 : Int),(2 : Int)) hp6_4_branches1414 hp6_4_evidence1414 hp6_4_check1414 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1415 T childKnown
  · exact hp6_4_node1427 T childKnown
  · exact hp6_4_node1429 T childKnown
  · exact hp6_4_node1432 T childKnown
  · exact hp6_4_node1433 T childKnown
theorem hp6_4_node1413 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1413 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1413 ((1 : Int),(2 : Int)) hp6_4_branches1413 hp6_4_evidence1413 hp6_4_check1413 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1413,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1414 T childKnown
  · exact hp6_4_node1434 T childKnown
  · exact hp6_4_node1444 T childKnown
  · exact hp6_4_node1446 T childKnown
theorem hp6_4_node1412 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1412 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1412 ((7 : Int),(0 : Int)) hp6_4_branches1412 hp6_4_evidence1412 hp6_4_check1412 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1412,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1413 T childKnown
theorem hp6_4_node1411 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1411 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1411 ((2 : Int),(2 : Int)) hp6_4_branches1411 hp6_4_evidence1411 hp6_4_check1411 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1410 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1410 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1410 ((2 : Int),(2 : Int)) hp6_4_branches1410 hp6_4_evidence1410 hp6_4_check1410 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1410,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1409 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1409 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1409 ((2 : Int),(1 : Int)) hp6_4_branches1409 hp6_4_evidence1409 hp6_4_check1409 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1409,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1410 T childKnown
  · exact hp6_4_node1411 T childKnown
theorem hp6_4_node1408 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1408 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1408 ((11 : Int),(1 : Int)) hp6_4_branches1408 hp6_4_evidence1408 hp6_4_check1408 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1408,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1407 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1407 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1407 ((9 : Int),(2 : Int)) hp6_4_branches1407 hp6_4_evidence1407 hp6_4_check1407 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1406 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1406 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1406 ((6 : Int),(2 : Int)) hp6_4_branches1406 hp6_4_evidence1406 hp6_4_check1406 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1406,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1405 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1405 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1405 ((10 : Int),(1 : Int)) hp6_4_branches1405 hp6_4_evidence1405 hp6_4_check1405 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1406 T childKnown
  · exact hp6_4_node1407 T childKnown
  · exact hp6_4_node1408 T childKnown
theorem hp6_4_node1404 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1404 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1404 ((7 : Int),(0 : Int)) hp6_4_branches1404 hp6_4_evidence1404 hp6_4_check1404 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1404,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1405 T childKnown
theorem hp6_4_node1403 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1403 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1403 ((2 : Int),(1 : Int)) hp6_4_branches1403 hp6_4_evidence1403 hp6_4_check1403 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1403,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1404 T childKnown
theorem hp6_4_node1402 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1402 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1402 ((2 : Int),(2 : Int)) hp6_4_branches1402 hp6_4_evidence1402 hp6_4_check1402 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1401 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1401 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1401 ((2 : Int),(1 : Int)) hp6_4_branches1401 hp6_4_evidence1401 hp6_4_check1401 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1401,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1402 T childKnown
theorem hp6_4_node1400 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1400 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1400 ((3 : Int),(2 : Int)) hp6_4_branches1400 hp6_4_evidence1400 hp6_4_check1400 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1399 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1399 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1399 ((3 : Int),(2 : Int)) hp6_4_branches1399 hp6_4_evidence1399 hp6_4_check1399 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1398 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1398 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1398 ((2 : Int),(2 : Int)) hp6_4_branches1398 hp6_4_evidence1398 hp6_4_check1398 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1398,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1399 T childKnown
  · exact hp6_4_node1400 T childKnown
theorem hp6_4_node1397 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1397 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1397 ((7 : Int),(0 : Int)) hp6_4_branches1397 hp6_4_evidence1397 hp6_4_check1397 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1398 T childKnown
theorem hp6_4_node1396 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1396 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1396 ((10 : Int),(1 : Int)) hp6_4_branches1396 hp6_4_evidence1396 hp6_4_check1396 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1395 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1395 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1395 ((10 : Int),(1 : Int)) hp6_4_branches1395 hp6_4_evidence1395 hp6_4_check1395 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1395,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1394 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1394 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1394 ((10 : Int),(1 : Int)) hp6_4_branches1394 hp6_4_evidence1394 hp6_4_check1394 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1394,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1393 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1393 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1393 ((5 : Int),(2 : Int)) hp6_4_branches1393 hp6_4_evidence1393 hp6_4_check1393 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1393,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1394 T childKnown
theorem hp6_4_node1392 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1392 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1392 ((4 : Int),(2 : Int)) hp6_4_branches1392 hp6_4_evidence1392 hp6_4_check1392 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1392,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1393 T childKnown
  · exact hp6_4_node1395 T childKnown
  · exact hp6_4_node1396 T childKnown
theorem hp6_4_node1391 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1391 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1391 ((7 : Int),(0 : Int)) hp6_4_branches1391 hp6_4_evidence1391 hp6_4_check1391 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1391,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1392 T childKnown
theorem hp6_4_node1390 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1390 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1390 ((2 : Int),(2 : Int)) hp6_4_branches1390 hp6_4_evidence1390 hp6_4_check1390 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1390,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1391 T childKnown
theorem hp6_4_node1389 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1389 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1389 ((3 : Int),(2 : Int)) hp6_4_branches1389 hp6_4_evidence1389 hp6_4_check1389 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1388 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1388 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1388 ((3 : Int),(2 : Int)) hp6_4_branches1388 hp6_4_evidence1388 hp6_4_check1388 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1388,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1387 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1387 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1387 ((3 : Int),(2 : Int)) hp6_4_branches1387 hp6_4_evidence1387 hp6_4_check1387 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1386 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1386 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1386 ((3 : Int),(1 : Int)) hp6_4_branches1386 hp6_4_evidence1386 hp6_4_check1386 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1386,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1387 T childKnown
  · exact hp6_4_node1388 T childKnown
  · exact hp6_4_node1389 T childKnown
theorem hp6_4_node1385 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1385 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1385 ((12 : Int),(1 : Int)) hp6_4_branches1385 hp6_4_evidence1385 hp6_4_check1385 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1385,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1384 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1384 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1384 ((10 : Int),(2 : Int)) hp6_4_branches1384 hp6_4_evidence1384 hp6_4_check1384 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1384,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1383 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1383 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1383 ((7 : Int),(2 : Int)) hp6_4_branches1383 hp6_4_evidence1383 hp6_4_check1383 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1382 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1382 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1382 ((11 : Int),(1 : Int)) hp6_4_branches1382 hp6_4_evidence1382 hp6_4_check1382 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1382,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1383 T childKnown
  · exact hp6_4_node1384 T childKnown
  · exact hp6_4_node1385 T childKnown
theorem hp6_4_node1381 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1381 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1381 ((7 : Int),(0 : Int)) hp6_4_branches1381 hp6_4_evidence1381 hp6_4_check1381 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1381,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1382 T childKnown
theorem hp6_4_node1380 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1380 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1380 ((9 : Int),(1 : Int)) hp6_4_branches1380 hp6_4_evidence1380 hp6_4_check1380 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1380,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1379 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1379 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1379 ((9 : Int),(1 : Int)) hp6_4_branches1379 hp6_4_evidence1379 hp6_4_check1379 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1378 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1378 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1378 ((8 : Int),(1 : Int)) hp6_4_branches1378 hp6_4_evidence1378 hp6_4_check1378 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1378,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1379 T childKnown
  · exact hp6_4_node1380 T childKnown
theorem hp6_4_node1377 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1377 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1377 ((11 : Int),(2 : Int)) hp6_4_branches1377 hp6_4_evidence1377 hp6_4_check1377 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1377,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1376 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1376 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1376 ((10 : Int),(2 : Int)) hp6_4_branches1376 hp6_4_evidence1376 hp6_4_check1376 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1376,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1377 T childKnown
theorem hp6_4_node1375 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1375 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1375 ((18 : Int),(1 : Int)) hp6_4_branches1375 hp6_4_evidence1375 hp6_4_check1375 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1374 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1374 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1374 ((16 : Int),(0 : Int)) hp6_4_branches1374 hp6_4_evidence1374 hp6_4_check1374 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1374,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1375 T childKnown
theorem hp6_4_node1373 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1373 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1373 ((12 : Int),(2 : Int)) hp6_4_branches1373 hp6_4_evidence1373 hp6_4_check1373 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1374 T childKnown
theorem hp6_4_node1372 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1372 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1372 ((10 : Int),(2 : Int)) hp6_4_branches1372 hp6_4_evidence1372 hp6_4_check1372 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1373 T childKnown
theorem hp6_4_node1371 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1371 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1371 ((11 : Int),(2 : Int)) hp6_4_branches1371 hp6_4_evidence1371 hp6_4_check1371 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1371,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1370 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1370 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1370 ((11 : Int),(1 : Int)) hp6_4_branches1370 hp6_4_evidence1370 hp6_4_check1370 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1370,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1371 T childKnown
theorem hp6_4_node1369 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1369 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1369 ((10 : Int),(1 : Int)) hp6_4_branches1369 hp6_4_evidence1369 hp6_4_check1369 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1369,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1370 T childKnown
  · exact hp6_4_node1372 T childKnown
  · exact hp6_4_node1376 T childKnown
theorem hp6_4_node1368 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1368 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1368 ((8 : Int),(1 : Int)) hp6_4_branches1368 hp6_4_evidence1368 hp6_4_check1368 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1369 T childKnown
theorem hp6_4_node1367 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1367 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1367 ((9 : Int),(1 : Int)) hp6_4_branches1367 hp6_4_evidence1367 hp6_4_check1367 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1366 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1366 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1366 ((9 : Int),(1 : Int)) hp6_4_branches1366 hp6_4_evidence1366 hp6_4_check1366 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1365 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1365 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1365 ((9 : Int),(0 : Int)) hp6_4_branches1365 hp6_4_evidence1365 hp6_4_check1365 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1366 T childKnown
  · exact hp6_4_node1367 T childKnown
theorem hp6_4_node1364 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1364 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1364 ((17 : Int),(1 : Int)) hp6_4_branches1364 hp6_4_evidence1364 hp6_4_check1364 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1363 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1363 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1363 ((16 : Int),(1 : Int)) hp6_4_branches1363 hp6_4_evidence1363 hp6_4_check1363 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1363,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1364 T childKnown
theorem hp6_4_node1362 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1362 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1362 ((17 : Int),(1 : Int)) hp6_4_branches1362 hp6_4_evidence1362 hp6_4_check1362 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1361 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1361 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1361 ((16 : Int),(1 : Int)) hp6_4_branches1361 hp6_4_evidence1361 hp6_4_check1361 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1361,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1362 T childKnown
theorem hp6_4_node1360 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1360 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1360 ((16 : Int),(1 : Int)) hp6_4_branches1360 hp6_4_evidence1360 hp6_4_check1360 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1359 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1359 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1359 ((17 : Int),(0 : Int)) hp6_4_branches1359 hp6_4_evidence1359 hp6_4_check1359 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1359,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1360 T childKnown
  · exact hp6_4_node1361 T childKnown
  · exact hp6_4_node1363 T childKnown
theorem hp6_4_node1358 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1358 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1358 ((14 : Int),(1 : Int)) hp6_4_branches1358 hp6_4_evidence1358 hp6_4_check1358 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1358,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1359 T childKnown
theorem hp6_4_node1357 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1357 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1357 ((13 : Int),(1 : Int)) hp6_4_branches1357 hp6_4_evidence1357 hp6_4_check1357 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1357,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1356 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1356 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1356 ((10 : Int),(2 : Int)) hp6_4_branches1356 hp6_4_evidence1356 hp6_4_check1356 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1356,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1357 T childKnown
theorem hp6_4_node1355 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1355 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1355 ((13 : Int),(1 : Int)) hp6_4_branches1355 hp6_4_evidence1355 hp6_4_check1355 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1355,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1354 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1354 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1354 ((10 : Int),(2 : Int)) hp6_4_branches1354 hp6_4_evidence1354 hp6_4_check1354 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1353 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1353 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1353 ((12 : Int),(2 : Int)) hp6_4_branches1353 hp6_4_evidence1353 hp6_4_check1353 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1353,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1352 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1352 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1352 ((13 : Int),(1 : Int)) hp6_4_branches1352 hp6_4_evidence1352 hp6_4_check1352 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1353 T childKnown
  · exact hp6_4_node1354 T childKnown
theorem hp6_4_node1351 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1351 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1351 ((9 : Int),(2 : Int)) hp6_4_branches1351 hp6_4_evidence1351 hp6_4_check1351 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1352 T childKnown
  · exact hp6_4_node1355 T childKnown
  · exact hp6_4_node1356 T childKnown
  · exact hp6_4_node1358 T childKnown
theorem hp6_4_node1350 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1350 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1350 ((9 : Int),(0 : Int)) hp6_4_branches1350 hp6_4_evidence1350 hp6_4_check1350 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1350,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1351 T childKnown
theorem hp6_4_node1349 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1349 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1349 ((8 : Int),(0 : Int)) hp6_4_branches1349 hp6_4_evidence1349 hp6_4_check1349 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1349,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1350 T childKnown
  · exact hp6_4_node1365 T childKnown
  · exact hp6_4_node1368 T childKnown
  · exact hp6_4_node1378 T childKnown
theorem hp6_4_node1348 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1348 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1348 ((3 : Int),(1 : Int)) hp6_4_branches1348 hp6_4_evidence1348 hp6_4_check1348 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1348,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1349 T childKnown
  · exact hp6_4_node1381 T childKnown
theorem hp6_4_node1347 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1347 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1347 ((2 : Int),(1 : Int)) hp6_4_branches1347 hp6_4_evidence1347 hp6_4_check1347 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1347,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1348 T childKnown
  · exact hp6_4_node1386 T childKnown
  · exact hp6_4_node1390 T childKnown
  · exact hp6_4_node1397 T childKnown
theorem hp6_4_node1346 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1346 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1346 ((2 : Int),(2 : Int)) hp6_4_branches1346 hp6_4_evidence1346 hp6_4_check1346 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1346,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1345 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1345 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1345 ((2 : Int),(2 : Int)) hp6_4_branches1345 hp6_4_evidence1345 hp6_4_check1345 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1345,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1344 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1344 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1344 ((2 : Int),(1 : Int)) hp6_4_branches1344 hp6_4_evidence1344 hp6_4_check1344 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1345 T childKnown
  · exact hp6_4_node1346 T childKnown
theorem hp6_4_node1343 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1343 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1343 ((1 : Int),(1 : Int)) hp6_4_branches1343 hp6_4_evidence1343 hp6_4_check1343 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1343,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1344 T childKnown
  · exact hp6_4_node1347 T childKnown
  · exact hp6_4_node1401 T childKnown
  · exact hp6_4_node1403 T childKnown
  · exact hp6_4_node1409 T childKnown
  · exact hp6_4_node1412 T childKnown
  · exact hp6_4_node1451 T childKnown
theorem hp6_4_node1342 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1342 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1342 ((9 : Int),(1 : Int)) hp6_4_branches1342 hp6_4_evidence1342 hp6_4_check1342 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1341 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1341 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1341 ((7 : Int),(1 : Int)) hp6_4_branches1341 hp6_4_evidence1341 hp6_4_check1341 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1341,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1340 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1340 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1340 ((7 : Int),(1 : Int)) hp6_4_branches1340 hp6_4_evidence1340 hp6_4_check1340 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1339 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1339 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1339 ((5 : Int),(1 : Int)) hp6_4_branches1339 hp6_4_evidence1339 hp6_4_check1339 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1338 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1338 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1338 ((8 : Int),(1 : Int)) hp6_4_branches1338 hp6_4_evidence1338 hp6_4_check1338 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1339 T childKnown
  · exact hp6_4_node1340 T childKnown
  · exact hp6_4_node1341 T childKnown
  · exact hp6_4_node1342 T childKnown
theorem hp6_4_node1337 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1337 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1337 ((6 : Int),(1 : Int)) hp6_4_branches1337 hp6_4_evidence1337 hp6_4_check1337 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1336 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1336 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1336 ((6 : Int),(1 : Int)) hp6_4_branches1336 hp6_4_evidence1336 hp6_4_check1336 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1335 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1335 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1335 ((0 : Int),(2 : Int)) hp6_4_branches1335 hp6_4_evidence1335 hp6_4_check1335 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1335,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1334 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1334 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1334 ((2 : Int),(1 : Int)) hp6_4_branches1334 hp6_4_evidence1334 hp6_4_check1334 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1334,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1335 T childKnown
theorem hp6_4_node1333 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1333 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1333 ((9 : Int),(2 : Int)) hp6_4_branches1333 hp6_4_evidence1333 hp6_4_check1333 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1333,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1332 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1332 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1332 ((8 : Int),(2 : Int)) hp6_4_branches1332 hp6_4_evidence1332 hp6_4_check1332 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1333 T childKnown
theorem hp6_4_node1331 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1331 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1331 ((16 : Int),(1 : Int)) hp6_4_branches1331 hp6_4_evidence1331 hp6_4_check1331 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1331,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1330 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1330 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1330 ((14 : Int),(0 : Int)) hp6_4_branches1330 hp6_4_evidence1330 hp6_4_check1330 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1330,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1331 T childKnown
theorem hp6_4_node1329 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1329 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1329 ((10 : Int),(2 : Int)) hp6_4_branches1329 hp6_4_evidence1329 hp6_4_check1329 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1329,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1330 T childKnown
theorem hp6_4_node1328 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1328 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1328 ((8 : Int),(2 : Int)) hp6_4_branches1328 hp6_4_evidence1328 hp6_4_check1328 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1328,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1329 T childKnown
theorem hp6_4_node1327 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1327 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1327 ((9 : Int),(2 : Int)) hp6_4_branches1327 hp6_4_evidence1327 hp6_4_check1327 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1326 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1326 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1326 ((9 : Int),(1 : Int)) hp6_4_branches1326 hp6_4_evidence1326 hp6_4_check1326 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1326,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1327 T childKnown
theorem hp6_4_node1325 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1325 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1325 ((8 : Int),(1 : Int)) hp6_4_branches1325 hp6_4_evidence1325 hp6_4_check1325 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1326 T childKnown
  · exact hp6_4_node1328 T childKnown
  · exact hp6_4_node1332 T childKnown
theorem hp6_4_node1324 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1324 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1324 ((1 : Int),(2 : Int)) hp6_4_branches1324 hp6_4_evidence1324 hp6_4_check1324 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1324,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1325 T childKnown
theorem hp6_4_node1323 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1323 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1323 ((3 : Int),(2 : Int)) hp6_4_branches1323 hp6_4_evidence1323 hp6_4_check1323 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1324 T childKnown
theorem hp6_4_node1322 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1322 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1322 ((0 : Int),(2 : Int)) hp6_4_branches1322 hp6_4_evidence1322 hp6_4_check1322 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1321 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1321 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1321 ((1 : Int),(2 : Int)) hp6_4_branches1321 hp6_4_evidence1321 hp6_4_check1321 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1321,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1322 T childKnown
theorem hp6_4_node1320 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1320 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1320 ((3 : Int),(1 : Int)) hp6_4_branches1320 hp6_4_evidence1320 hp6_4_check1320 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1321 T childKnown
  · exact hp6_4_node1323 T childKnown
  · exact hp6_4_node1334 T childKnown
theorem hp6_4_node1319 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1319 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1319 ((6 : Int),(1 : Int)) hp6_4_branches1319 hp6_4_evidence1319 hp6_4_check1319 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1319,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1320 T childKnown
theorem hp6_4_node1318 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1318 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1318 ((6 : Int),(1 : Int)) hp6_4_branches1318 hp6_4_evidence1318 hp6_4_check1318 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1317 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1317 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1317 ((5 : Int),(1 : Int)) hp6_4_branches1317 hp6_4_evidence1317 hp6_4_check1317 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1317,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1318 T childKnown
  · exact hp6_4_node1319 T childKnown
  · exact hp6_4_node1336 T childKnown
  · exact hp6_4_node1337 T childKnown
theorem hp6_4_node1316 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1316 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1316 ((7 : Int),(1 : Int)) hp6_4_branches1316 hp6_4_evidence1316 hp6_4_check1316 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1315 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1315 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1315 ((7 : Int),(1 : Int)) hp6_4_branches1315 hp6_4_evidence1315 hp6_4_check1315 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1315,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1314 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1314 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1314 ((7 : Int),(0 : Int)) hp6_4_branches1314 hp6_4_evidence1314 hp6_4_check1314 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1314,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1315 T childKnown
  · exact hp6_4_node1316 T childKnown
theorem hp6_4_node1313 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1313 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1313 ((5 : Int),(1 : Int)) hp6_4_branches1313 hp6_4_evidence1313 hp6_4_check1313 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1313,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1314 T childKnown
theorem hp6_4_node1312 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1312 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1312 ((0 : Int),(2 : Int)) hp6_4_branches1312 hp6_4_evidence1312 hp6_4_check1312 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1312,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1311 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1311 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1311 ((2 : Int),(1 : Int)) hp6_4_branches1311 hp6_4_evidence1311 hp6_4_check1311 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1312 T childKnown
theorem hp6_4_node1310 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1310 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1310 ((15 : Int),(1 : Int)) hp6_4_branches1310 hp6_4_evidence1310 hp6_4_check1310 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1310,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1309 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1309 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1309 ((14 : Int),(1 : Int)) hp6_4_branches1309 hp6_4_evidence1309 hp6_4_check1309 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1310 T childKnown
theorem hp6_4_node1308 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1308 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1308 ((15 : Int),(1 : Int)) hp6_4_branches1308 hp6_4_evidence1308 hp6_4_check1308 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1307 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1307 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1307 ((14 : Int),(1 : Int)) hp6_4_branches1307 hp6_4_evidence1307 hp6_4_check1307 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1307,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1308 T childKnown
theorem hp6_4_node1306 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1306 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1306 ((14 : Int),(1 : Int)) hp6_4_branches1306 hp6_4_evidence1306 hp6_4_check1306 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1305 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1305 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1305 ((15 : Int),(0 : Int)) hp6_4_branches1305 hp6_4_evidence1305 hp6_4_check1305 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1305,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1306 T childKnown
  · exact hp6_4_node1307 T childKnown
  · exact hp6_4_node1309 T childKnown
theorem hp6_4_node1304 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1304 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1304 ((12 : Int),(1 : Int)) hp6_4_branches1304 hp6_4_evidence1304 hp6_4_check1304 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1304,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1305 T childKnown
theorem hp6_4_node1303 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1303 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1303 ((11 : Int),(1 : Int)) hp6_4_branches1303 hp6_4_evidence1303 hp6_4_check1303 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1302 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1302 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1302 ((8 : Int),(2 : Int)) hp6_4_branches1302 hp6_4_evidence1302 hp6_4_check1302 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1302,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1303 T childKnown
theorem hp6_4_node1301 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1301 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1301 ((11 : Int),(1 : Int)) hp6_4_branches1301 hp6_4_evidence1301 hp6_4_check1301 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1300 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1300 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1300 ((7 : Int),(2 : Int)) hp6_4_branches1300 hp6_4_evidence1300 hp6_4_check1300 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1301 T childKnown
  · exact hp6_4_node1302 T childKnown
  · exact hp6_4_node1304 T childKnown
theorem hp6_4_node1299 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1299 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1299 ((1 : Int),(2 : Int)) hp6_4_branches1299 hp6_4_evidence1299 hp6_4_check1299 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1299,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1300 T childKnown
theorem hp6_4_node1298 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1298 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1298 ((3 : Int),(2 : Int)) hp6_4_branches1298 hp6_4_evidence1298 hp6_4_check1298 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1299 T childKnown
theorem hp6_4_node1297 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1297 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1297 ((0 : Int),(2 : Int)) hp6_4_branches1297 hp6_4_evidence1297 hp6_4_check1297 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1297,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1296 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1296 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1296 ((1 : Int),(2 : Int)) hp6_4_branches1296 hp6_4_evidence1296 hp6_4_check1296 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1296,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1297 T childKnown
theorem hp6_4_node1295 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1295 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1295 ((3 : Int),(1 : Int)) hp6_4_branches1295 hp6_4_evidence1295 hp6_4_check1295 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1296 T childKnown
  · exact hp6_4_node1298 T childKnown
  · exact hp6_4_node1311 T childKnown
theorem hp6_4_node1294 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1294 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1294 ((7 : Int),(0 : Int)) hp6_4_branches1294 hp6_4_evidence1294 hp6_4_check1294 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1295 T childKnown
theorem hp6_4_node1293 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1293 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1293 ((5 : Int),(1 : Int)) hp6_4_branches1293 hp6_4_evidence1293 hp6_4_check1293 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1293,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1294 T childKnown
theorem hp6_4_node1292 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1292 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1292 ((5 : Int),(1 : Int)) hp6_4_branches1292 hp6_4_evidence1292 hp6_4_check1292 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1291 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1291 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1291 ((5 : Int),(1 : Int)) hp6_4_branches1291 hp6_4_evidence1291 hp6_4_check1291 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1291,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1290 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1290 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1290 ((6 : Int),(0 : Int)) hp6_4_branches1290 hp6_4_evidence1290 hp6_4_check1290 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1290,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1291 T childKnown
  · exact hp6_4_node1292 T childKnown
  · exact hp6_4_node1293 T childKnown
  · exact hp6_4_node1313 T childKnown
  · exact hp6_4_node1317 T childKnown
  · exact hp6_4_node1338 T childKnown
theorem hp6_4_node1289 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1289 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1289 ((9 : Int),(1 : Int)) hp6_4_branches1289 hp6_4_evidence1289 hp6_4_check1289 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1288 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1288 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1288 ((7 : Int),(2 : Int)) hp6_4_branches1288 hp6_4_evidence1288 hp6_4_check1288 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1287 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1287 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1287 ((7 : Int),(2 : Int)) hp6_4_branches1287 hp6_4_evidence1287 hp6_4_check1287 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1286 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1286 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1286 ((8 : Int),(1 : Int)) hp6_4_branches1286 hp6_4_evidence1286 hp6_4_check1286 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1286,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1287 T childKnown
  · exact hp6_4_node1288 T childKnown
  · exact hp6_4_node1289 T childKnown
theorem hp6_4_node1285 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1285 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1285 ((6 : Int),(0 : Int)) hp6_4_branches1285 hp6_4_evidence1285 hp6_4_check1285 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1286 T childKnown
theorem hp6_4_node1284 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1284 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1284 ((8 : Int),(1 : Int)) hp6_4_branches1284 hp6_4_evidence1284 hp6_4_check1284 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1283 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1283 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1283 ((8 : Int),(1 : Int)) hp6_4_branches1283 hp6_4_evidence1283 hp6_4_check1283 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1282 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1282 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1282 ((8 : Int),(1 : Int)) hp6_4_branches1282 hp6_4_evidence1282 hp6_4_check1282 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1281 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1281 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1281 ((3 : Int),(2 : Int)) hp6_4_branches1281 hp6_4_evidence1281 hp6_4_check1281 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1282 T childKnown
theorem hp6_4_node1280 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1280 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1280 ((2 : Int),(2 : Int)) hp6_4_branches1280 hp6_4_evidence1280 hp6_4_check1280 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1280,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1281 T childKnown
  · exact hp6_4_node1283 T childKnown
  · exact hp6_4_node1284 T childKnown
theorem hp6_4_node1279 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1279 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1279 ((8 : Int),(1 : Int)) hp6_4_branches1279 hp6_4_evidence1279 hp6_4_check1279 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1278 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1278 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1278 ((2 : Int),(2 : Int)) hp6_4_branches1278 hp6_4_evidence1278 hp6_4_check1278 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1279 T childKnown
theorem hp6_4_node1277 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1277 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1277 ((8 : Int),(1 : Int)) hp6_4_branches1277 hp6_4_evidence1277 hp6_4_check1277 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1276 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1276 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1276 ((8 : Int),(1 : Int)) hp6_4_branches1276 hp6_4_evidence1276 hp6_4_check1276 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1275 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1275 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1275 ((8 : Int),(1 : Int)) hp6_4_branches1275 hp6_4_evidence1275 hp6_4_check1275 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1274 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1274 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1274 ((8 : Int),(1 : Int)) hp6_4_branches1274 hp6_4_evidence1274 hp6_4_check1274 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1273 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1273 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1273 ((3 : Int),(2 : Int)) hp6_4_branches1273 hp6_4_evidence1273 hp6_4_check1273 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1274 T childKnown
  · exact hp6_4_node1275 T childKnown
theorem hp6_4_node1272 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1272 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1272 ((8 : Int),(1 : Int)) hp6_4_branches1272 hp6_4_evidence1272 hp6_4_check1272 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1271 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1271 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1271 ((3 : Int),(2 : Int)) hp6_4_branches1271 hp6_4_evidence1271 hp6_4_check1271 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1272 T childKnown
theorem hp6_4_node1270 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1270 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1270 ((8 : Int),(1 : Int)) hp6_4_branches1270 hp6_4_evidence1270 hp6_4_check1270 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1270,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1269 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1269 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1269 ((3 : Int),(2 : Int)) hp6_4_branches1269 hp6_4_evidence1269 hp6_4_check1269 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1270 T childKnown
theorem hp6_4_node1268 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1268 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1268 ((2 : Int),(2 : Int)) hp6_4_branches1268 hp6_4_evidence1268 hp6_4_check1268 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1268,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1269 T childKnown
  · exact hp6_4_node1271 T childKnown
  · exact hp6_4_node1273 T childKnown
  · exact hp6_4_node1276 T childKnown
  · exact hp6_4_node1277 T childKnown
theorem hp6_4_node1267 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1267 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1267 ((8 : Int),(1 : Int)) hp6_4_branches1267 hp6_4_evidence1267 hp6_4_check1267 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1266 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1266 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1266 ((8 : Int),(1 : Int)) hp6_4_branches1266 hp6_4_evidence1266 hp6_4_check1266 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1265 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1265 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1265 ((8 : Int),(1 : Int)) hp6_4_branches1265 hp6_4_evidence1265 hp6_4_check1265 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1264 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1264 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1264 ((8 : Int),(1 : Int)) hp6_4_branches1264 hp6_4_evidence1264 hp6_4_check1264 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1264,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1263 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1263 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1263 ((3 : Int),(2 : Int)) hp6_4_branches1263 hp6_4_evidence1263 hp6_4_check1263 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1263,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1264 T childKnown
  · exact hp6_4_node1265 T childKnown
theorem hp6_4_node1262 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1262 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1262 ((8 : Int),(1 : Int)) hp6_4_branches1262 hp6_4_evidence1262 hp6_4_check1262 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1261 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1261 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1261 ((3 : Int),(2 : Int)) hp6_4_branches1261 hp6_4_evidence1261 hp6_4_check1261 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1261,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1262 T childKnown
theorem hp6_4_node1260 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1260 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1260 ((8 : Int),(1 : Int)) hp6_4_branches1260 hp6_4_evidence1260 hp6_4_check1260 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1259 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1259 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1259 ((8 : Int),(1 : Int)) hp6_4_branches1259 hp6_4_evidence1259 hp6_4_check1259 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1258 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1258 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1258 ((8 : Int),(1 : Int)) hp6_4_branches1258 hp6_4_evidence1258 hp6_4_check1258 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1258,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1257 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1257 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1257 ((10 : Int),(1 : Int)) hp6_4_branches1257 hp6_4_evidence1257 hp6_4_check1257 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1257,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1256 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1256 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1256 ((9 : Int),(1 : Int)) hp6_4_branches1256 hp6_4_evidence1256 hp6_4_check1256 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1257 T childKnown
theorem hp6_4_node1255 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1255 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1255 ((8 : Int),(1 : Int)) hp6_4_branches1255 hp6_4_evidence1255 hp6_4_check1255 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1254 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1254 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1254 ((4 : Int),(2 : Int)) hp6_4_branches1254 hp6_4_evidence1254 hp6_4_check1254 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1254,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1255 T childKnown
  · exact hp6_4_node1256 T childKnown
  · exact hp6_4_node1258 T childKnown
theorem hp6_4_node1253 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1253 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1253 ((8 : Int),(1 : Int)) hp6_4_branches1253 hp6_4_evidence1253 hp6_4_check1253 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1252 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1252 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1252 ((10 : Int),(1 : Int)) hp6_4_branches1252 hp6_4_evidence1252 hp6_4_check1252 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1251 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1251 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1251 ((9 : Int),(1 : Int)) hp6_4_branches1251 hp6_4_evidence1251 hp6_4_check1251 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1251,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1252 T childKnown
theorem hp6_4_node1250 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1250 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1250 ((4 : Int),(2 : Int)) hp6_4_branches1250 hp6_4_evidence1250 hp6_4_check1250 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1251 T childKnown
  · exact hp6_4_node1253 T childKnown
theorem hp6_4_node1249 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1249 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1249 ((3 : Int),(2 : Int)) hp6_4_branches1249 hp6_4_evidence1249 hp6_4_check1249 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1250 T childKnown
  · exact hp6_4_node1254 T childKnown
  · exact hp6_4_node1259 T childKnown
  · exact hp6_4_node1260 T childKnown
theorem hp6_4_node1248 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1248 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1248 ((2 : Int),(2 : Int)) hp6_4_branches1248 hp6_4_evidence1248 hp6_4_check1248 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1249 T childKnown
  · exact hp6_4_node1261 T childKnown
  · exact hp6_4_node1263 T childKnown
  · exact hp6_4_node1266 T childKnown
  · exact hp6_4_node1267 T childKnown
theorem hp6_4_node1247 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1247 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1247 ((0 : Int),(2 : Int)) hp6_4_branches1247 hp6_4_evidence1247 hp6_4_check1247 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1247,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1248 T childKnown
  · exact hp6_4_node1268 T childKnown
  · exact hp6_4_node1278 T childKnown
  · exact hp6_4_node1280 T childKnown
theorem hp6_4_node1246 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1246 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1246 ((6 : Int),(0 : Int)) hp6_4_branches1246 hp6_4_evidence1246 hp6_4_check1246 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1247 T childKnown
theorem hp6_4_node1245 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1245 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1245 ((1 : Int),(2 : Int)) hp6_4_branches1245 hp6_4_evidence1245 hp6_4_check1245 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1244 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1244 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1244 ((1 : Int),(2 : Int)) hp6_4_branches1244 hp6_4_evidence1244 hp6_4_check1244 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1243 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1243 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1243 ((1 : Int),(1 : Int)) hp6_4_branches1243 hp6_4_evidence1243 hp6_4_check1243 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1243,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1244 T childKnown
  · exact hp6_4_node1245 T childKnown
theorem hp6_4_node1242 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1242 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1242 ((10 : Int),(1 : Int)) hp6_4_branches1242 hp6_4_evidence1242 hp6_4_check1242 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1241 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1241 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1241 ((8 : Int),(2 : Int)) hp6_4_branches1241 hp6_4_evidence1241 hp6_4_check1241 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1241,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1240 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1240 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1240 ((5 : Int),(2 : Int)) hp6_4_branches1240 hp6_4_evidence1240 hp6_4_check1240 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1239 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1239 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1239 ((9 : Int),(1 : Int)) hp6_4_branches1239 hp6_4_evidence1239 hp6_4_check1239 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1240 T childKnown
  · exact hp6_4_node1241 T childKnown
  · exact hp6_4_node1242 T childKnown
theorem hp6_4_node1238 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1238 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1238 ((6 : Int),(0 : Int)) hp6_4_branches1238 hp6_4_evidence1238 hp6_4_check1238 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1239 T childKnown
theorem hp6_4_node1237 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1237 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1237 ((1 : Int),(1 : Int)) hp6_4_branches1237 hp6_4_evidence1237 hp6_4_check1237 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1237,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1238 T childKnown
theorem hp6_4_node1236 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1236 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1236 ((1 : Int),(2 : Int)) hp6_4_branches1236 hp6_4_evidence1236 hp6_4_check1236 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1236,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1235 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1235 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1235 ((1 : Int),(1 : Int)) hp6_4_branches1235 hp6_4_evidence1235 hp6_4_check1235 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1236 T childKnown
theorem hp6_4_node1234 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1234 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1234 ((2 : Int),(2 : Int)) hp6_4_branches1234 hp6_4_evidence1234 hp6_4_check1234 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1233 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1233 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1233 ((2 : Int),(2 : Int)) hp6_4_branches1233 hp6_4_evidence1233 hp6_4_check1233 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1233,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1232 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1232 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1232 ((1 : Int),(2 : Int)) hp6_4_branches1232 hp6_4_evidence1232 hp6_4_check1232 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1233 T childKnown
  · exact hp6_4_node1234 T childKnown
theorem hp6_4_node1231 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1231 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1231 ((6 : Int),(0 : Int)) hp6_4_branches1231 hp6_4_evidence1231 hp6_4_check1231 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1232 T childKnown
theorem hp6_4_node1230 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1230 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1230 ((9 : Int),(1 : Int)) hp6_4_branches1230 hp6_4_evidence1230 hp6_4_check1230 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1229 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1229 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1229 ((9 : Int),(1 : Int)) hp6_4_branches1229 hp6_4_evidence1229 hp6_4_check1229 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1229,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1228 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1228 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1228 ((9 : Int),(1 : Int)) hp6_4_branches1228 hp6_4_evidence1228 hp6_4_check1228 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1227 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1227 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1227 ((4 : Int),(2 : Int)) hp6_4_branches1227 hp6_4_evidence1227 hp6_4_check1227 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1227,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1228 T childKnown
theorem hp6_4_node1226 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1226 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1226 ((3 : Int),(2 : Int)) hp6_4_branches1226 hp6_4_evidence1226 hp6_4_check1226 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1226,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1227 T childKnown
  · exact hp6_4_node1229 T childKnown
  · exact hp6_4_node1230 T childKnown
theorem hp6_4_node1225 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1225 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1225 ((6 : Int),(0 : Int)) hp6_4_branches1225 hp6_4_evidence1225 hp6_4_check1225 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1225,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1226 T childKnown
theorem hp6_4_node1224 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1224 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1224 ((1 : Int),(2 : Int)) hp6_4_branches1224 hp6_4_evidence1224 hp6_4_check1224 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1224,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1225 T childKnown
theorem hp6_4_node1223 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1223 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1223 ((2 : Int),(2 : Int)) hp6_4_branches1223 hp6_4_evidence1223 hp6_4_check1223 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1222 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1222 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1222 ((2 : Int),(2 : Int)) hp6_4_branches1222 hp6_4_evidence1222 hp6_4_check1222 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1222,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1221 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1221 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1221 ((2 : Int),(2 : Int)) hp6_4_branches1221 hp6_4_evidence1221 hp6_4_check1221 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1220 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1220 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1220 ((2 : Int),(1 : Int)) hp6_4_branches1220 hp6_4_evidence1220 hp6_4_check1220 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1220,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1221 T childKnown
  · exact hp6_4_node1222 T childKnown
  · exact hp6_4_node1223 T childKnown
theorem hp6_4_node1219 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1219 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1219 ((11 : Int),(1 : Int)) hp6_4_branches1219 hp6_4_evidence1219 hp6_4_check1219 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1219,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1218 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1218 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1218 ((9 : Int),(2 : Int)) hp6_4_branches1218 hp6_4_evidence1218 hp6_4_check1218 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1217 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1217 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1217 ((6 : Int),(2 : Int)) hp6_4_branches1217 hp6_4_evidence1217 hp6_4_check1217 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1216 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1216 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1216 ((10 : Int),(1 : Int)) hp6_4_branches1216 hp6_4_evidence1216 hp6_4_check1216 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1216,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1217 T childKnown
  · exact hp6_4_node1218 T childKnown
  · exact hp6_4_node1219 T childKnown
theorem hp6_4_node1215 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1215 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1215 ((6 : Int),(0 : Int)) hp6_4_branches1215 hp6_4_evidence1215 hp6_4_check1215 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1215,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1216 T childKnown
theorem hp6_4_node1214 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1214 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1214 ((8 : Int),(1 : Int)) hp6_4_branches1214 hp6_4_evidence1214 hp6_4_check1214 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1213 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1213 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1213 ((8 : Int),(1 : Int)) hp6_4_branches1213 hp6_4_evidence1213 hp6_4_check1213 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1212 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1212 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1212 ((7 : Int),(1 : Int)) hp6_4_branches1212 hp6_4_evidence1212 hp6_4_check1212 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1212,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1213 T childKnown
  · exact hp6_4_node1214 T childKnown
theorem hp6_4_node1211 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1211 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1211 ((10 : Int),(2 : Int)) hp6_4_branches1211 hp6_4_evidence1211 hp6_4_check1211 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1210 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1210 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1210 ((9 : Int),(2 : Int)) hp6_4_branches1210 hp6_4_evidence1210 hp6_4_check1210 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1211 T childKnown
theorem hp6_4_node1209 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1209 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1209 ((17 : Int),(1 : Int)) hp6_4_branches1209 hp6_4_evidence1209 hp6_4_check1209 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1209,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1208 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1208 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1208 ((15 : Int),(0 : Int)) hp6_4_branches1208 hp6_4_evidence1208 hp6_4_check1208 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1209 T childKnown
theorem hp6_4_node1207 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1207 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1207 ((11 : Int),(2 : Int)) hp6_4_branches1207 hp6_4_evidence1207 hp6_4_check1207 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1208 T childKnown
theorem hp6_4_node1206 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1206 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1206 ((9 : Int),(2 : Int)) hp6_4_branches1206 hp6_4_evidence1206 hp6_4_check1206 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1206,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1207 T childKnown
theorem hp6_4_node1205 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1205 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1205 ((10 : Int),(2 : Int)) hp6_4_branches1205 hp6_4_evidence1205 hp6_4_check1205 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1204 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1204 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1204 ((10 : Int),(1 : Int)) hp6_4_branches1204 hp6_4_evidence1204 hp6_4_check1204 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1204,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1205 T childKnown
theorem hp6_4_node1203 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1203 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1203 ((9 : Int),(1 : Int)) hp6_4_branches1203 hp6_4_evidence1203 hp6_4_check1203 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1203,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1204 T childKnown
  · exact hp6_4_node1206 T childKnown
  · exact hp6_4_node1210 T childKnown
theorem hp6_4_node1202 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1202 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1202 ((7 : Int),(1 : Int)) hp6_4_branches1202 hp6_4_evidence1202 hp6_4_check1202 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1203 T childKnown
theorem hp6_4_node1201 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1201 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1201 ((8 : Int),(1 : Int)) hp6_4_branches1201 hp6_4_evidence1201 hp6_4_check1201 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1200 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1200 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1200 ((8 : Int),(1 : Int)) hp6_4_branches1200 hp6_4_evidence1200 hp6_4_check1200 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1199 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1199 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1199 ((8 : Int),(0 : Int)) hp6_4_branches1199 hp6_4_evidence1199 hp6_4_check1199 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1200 T childKnown
  · exact hp6_4_node1201 T childKnown
theorem hp6_4_node1198 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1198 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1198 ((16 : Int),(1 : Int)) hp6_4_branches1198 hp6_4_evidence1198 hp6_4_check1198 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1198,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1197 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1197 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1197 ((15 : Int),(1 : Int)) hp6_4_branches1197 hp6_4_evidence1197 hp6_4_check1197 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1198 T childKnown
theorem hp6_4_node1196 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1196 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1196 ((16 : Int),(1 : Int)) hp6_4_branches1196 hp6_4_evidence1196 hp6_4_check1196 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1195 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1195 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1195 ((15 : Int),(1 : Int)) hp6_4_branches1195 hp6_4_evidence1195 hp6_4_check1195 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1195,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1196 T childKnown
theorem hp6_4_node1194 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1194 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1194 ((15 : Int),(1 : Int)) hp6_4_branches1194 hp6_4_evidence1194 hp6_4_check1194 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1193 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1193 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1193 ((16 : Int),(0 : Int)) hp6_4_branches1193 hp6_4_evidence1193 hp6_4_check1193 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1193,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1194 T childKnown
  · exact hp6_4_node1195 T childKnown
  · exact hp6_4_node1197 T childKnown
theorem hp6_4_node1192 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1192 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1192 ((13 : Int),(1 : Int)) hp6_4_branches1192 hp6_4_evidence1192 hp6_4_check1192 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1192,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1193 T childKnown
theorem hp6_4_node1191 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1191 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1191 ((12 : Int),(1 : Int)) hp6_4_branches1191 hp6_4_evidence1191 hp6_4_check1191 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1190 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1190 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1190 ((9 : Int),(2 : Int)) hp6_4_branches1190 hp6_4_evidence1190 hp6_4_check1190 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1191 T childKnown
theorem hp6_4_node1189 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1189 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1189 ((12 : Int),(1 : Int)) hp6_4_branches1189 hp6_4_evidence1189 hp6_4_check1189 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1189,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1188 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1188 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1188 ((9 : Int),(2 : Int)) hp6_4_branches1188 hp6_4_evidence1188 hp6_4_check1188 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1188,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1187 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1187 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1187 ((11 : Int),(2 : Int)) hp6_4_branches1187 hp6_4_evidence1187 hp6_4_check1187 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1186 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1186 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1186 ((12 : Int),(1 : Int)) hp6_4_branches1186 hp6_4_evidence1186 hp6_4_check1186 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1187 T childKnown
  · exact hp6_4_node1188 T childKnown
theorem hp6_4_node1185 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1185 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1185 ((8 : Int),(2 : Int)) hp6_4_branches1185 hp6_4_evidence1185 hp6_4_check1185 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1185,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1186 T childKnown
  · exact hp6_4_node1189 T childKnown
  · exact hp6_4_node1190 T childKnown
  · exact hp6_4_node1192 T childKnown
theorem hp6_4_node1184 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1184 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1184 ((8 : Int),(0 : Int)) hp6_4_branches1184 hp6_4_evidence1184 hp6_4_check1184 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1184,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1185 T childKnown
theorem hp6_4_node1183 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1183 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1183 ((7 : Int),(0 : Int)) hp6_4_branches1183 hp6_4_evidence1183 hp6_4_check1183 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1184 T childKnown
  · exact hp6_4_node1199 T childKnown
  · exact hp6_4_node1202 T childKnown
  · exact hp6_4_node1212 T childKnown
theorem hp6_4_node1182 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1182 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1182 ((2 : Int),(1 : Int)) hp6_4_branches1182 hp6_4_evidence1182 hp6_4_check1182 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1182,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1183 T childKnown
  · exact hp6_4_node1215 T childKnown
theorem hp6_4_node1181 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1181 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1181 ((1 : Int),(1 : Int)) hp6_4_branches1181 hp6_4_evidence1181 hp6_4_check1181 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1182 T childKnown
  · exact hp6_4_node1220 T childKnown
  · exact hp6_4_node1224 T childKnown
  · exact hp6_4_node1231 T childKnown
theorem hp6_4_node1180 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1180 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1180 ((1 : Int),(2 : Int)) hp6_4_branches1180 hp6_4_evidence1180 hp6_4_check1180 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1180,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1179 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1179 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1179 ((1 : Int),(2 : Int)) hp6_4_branches1179 hp6_4_evidence1179 hp6_4_check1179 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1178 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1178 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1178 ((1 : Int),(1 : Int)) hp6_4_branches1178 hp6_4_evidence1178 hp6_4_check1178 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1179 T childKnown
  · exact hp6_4_node1180 T childKnown
theorem hp6_4_node1177 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1177 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1177 ((0 : Int),(1 : Int)) hp6_4_branches1177 hp6_4_evidence1177 hp6_4_check1177 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1177,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1178 T childKnown
  · exact hp6_4_node1181 T childKnown
  · exact hp6_4_node1235 T childKnown
  · exact hp6_4_node1237 T childKnown
  · exact hp6_4_node1243 T childKnown
  · exact hp6_4_node1246 T childKnown
  · exact hp6_4_node1285 T childKnown
theorem hp6_4_node1176 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1176 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1176 ((8 : Int),(1 : Int)) hp6_4_branches1176 hp6_4_evidence1176 hp6_4_check1176 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1175 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1175 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1175 ((6 : Int),(1 : Int)) hp6_4_branches1175 hp6_4_evidence1175 hp6_4_check1175 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1175,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1174 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1174 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1174 ((6 : Int),(1 : Int)) hp6_4_branches1174 hp6_4_evidence1174 hp6_4_check1174 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1174,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1173 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1173 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1173 ((4 : Int),(1 : Int)) hp6_4_branches1173 hp6_4_evidence1173 hp6_4_check1173 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1173,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1172 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1172 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1172 ((7 : Int),(1 : Int)) hp6_4_branches1172 hp6_4_evidence1172 hp6_4_check1172 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1173 T childKnown
  · exact hp6_4_node1174 T childKnown
  · exact hp6_4_node1175 T childKnown
  · exact hp6_4_node1176 T childKnown
theorem hp6_4_node1171 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1171 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1171 ((5 : Int),(1 : Int)) hp6_4_branches1171 hp6_4_evidence1171 hp6_4_check1171 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1170 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1170 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1170 ((5 : Int),(1 : Int)) hp6_4_branches1170 hp6_4_evidence1170 hp6_4_check1170 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1169 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1169 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1169 ((0 : Int),(2 : Int)) hp6_4_branches1169 hp6_4_evidence1169 hp6_4_check1169 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1168 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1168 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1168 ((1 : Int),(1 : Int)) hp6_4_branches1168 hp6_4_evidence1168 hp6_4_check1168 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1168,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1169 T childKnown
theorem hp6_4_node1167 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1167 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1167 ((8 : Int),(2 : Int)) hp6_4_branches1167 hp6_4_evidence1167 hp6_4_check1167 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1166 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1166 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1166 ((7 : Int),(2 : Int)) hp6_4_branches1166 hp6_4_evidence1166 hp6_4_check1166 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1167 T childKnown
theorem hp6_4_node1165 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1165 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1165 ((15 : Int),(1 : Int)) hp6_4_branches1165 hp6_4_evidence1165 hp6_4_check1165 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1164 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1164 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1164 ((13 : Int),(0 : Int)) hp6_4_branches1164 hp6_4_evidence1164 hp6_4_check1164 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1164,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1165 T childKnown
theorem hp6_4_node1163 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1163 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1163 ((9 : Int),(2 : Int)) hp6_4_branches1163 hp6_4_evidence1163 hp6_4_check1163 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1163,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1164 T childKnown
theorem hp6_4_node1162 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1162 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1162 ((7 : Int),(2 : Int)) hp6_4_branches1162 hp6_4_evidence1162 hp6_4_check1162 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1163 T childKnown
theorem hp6_4_node1161 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1161 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1161 ((8 : Int),(2 : Int)) hp6_4_branches1161 hp6_4_evidence1161 hp6_4_check1161 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1160 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1160 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1160 ((8 : Int),(1 : Int)) hp6_4_branches1160 hp6_4_evidence1160 hp6_4_check1160 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1161 T childKnown
theorem hp6_4_node1159 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1159 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1159 ((7 : Int),(1 : Int)) hp6_4_branches1159 hp6_4_evidence1159 hp6_4_check1159 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1160 T childKnown
  · exact hp6_4_node1162 T childKnown
  · exact hp6_4_node1166 T childKnown
theorem hp6_4_node1158 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1158 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1158 ((0 : Int),(2 : Int)) hp6_4_branches1158 hp6_4_evidence1158 hp6_4_check1158 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1159 T childKnown
theorem hp6_4_node1157 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1157 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1157 ((2 : Int),(2 : Int)) hp6_4_branches1157 hp6_4_evidence1157 hp6_4_check1157 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1158 T childKnown
theorem hp6_4_node1156 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1156 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1156 ((1 : Int),(2 : Int)) hp6_4_branches1156 hp6_4_evidence1156 hp6_4_check1156 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1156,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1155 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1155 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1155 ((0 : Int),(2 : Int)) hp6_4_branches1155 hp6_4_evidence1155 hp6_4_check1155 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1155,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1156 T childKnown
theorem hp6_4_node1154 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1154 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1154 ((2 : Int),(1 : Int)) hp6_4_branches1154 hp6_4_evidence1154 hp6_4_check1154 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1155 T childKnown
  · exact hp6_4_node1157 T childKnown
  · exact hp6_4_node1168 T childKnown
theorem hp6_4_node1153 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1153 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1153 ((5 : Int),(1 : Int)) hp6_4_branches1153 hp6_4_evidence1153 hp6_4_check1153 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1154 T childKnown
theorem hp6_4_node1152 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1152 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1152 ((5 : Int),(1 : Int)) hp6_4_branches1152 hp6_4_evidence1152 hp6_4_check1152 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1152,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1151 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1151 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1151 ((4 : Int),(1 : Int)) hp6_4_branches1151 hp6_4_evidence1151 hp6_4_check1151 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1152 T childKnown
  · exact hp6_4_node1153 T childKnown
  · exact hp6_4_node1170 T childKnown
  · exact hp6_4_node1171 T childKnown
theorem hp6_4_node1150 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1150 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1150 ((6 : Int),(1 : Int)) hp6_4_branches1150 hp6_4_evidence1150 hp6_4_check1150 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1150,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1149 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1149 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1149 ((6 : Int),(1 : Int)) hp6_4_branches1149 hp6_4_evidence1149 hp6_4_check1149 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1148 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1148 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1148 ((6 : Int),(0 : Int)) hp6_4_branches1148 hp6_4_evidence1148 hp6_4_check1148 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1148,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1149 T childKnown
  · exact hp6_4_node1150 T childKnown
theorem hp6_4_node1147 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1147 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1147 ((4 : Int),(1 : Int)) hp6_4_branches1147 hp6_4_evidence1147 hp6_4_check1147 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1147,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1148 T childKnown
theorem hp6_4_node1146 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1146 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1146 ((0 : Int),(2 : Int)) hp6_4_branches1146 hp6_4_evidence1146 hp6_4_check1146 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1145 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1145 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1145 ((1 : Int),(1 : Int)) hp6_4_branches1145 hp6_4_evidence1145 hp6_4_check1145 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1145,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1146 T childKnown
theorem hp6_4_node1144 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1144 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1144 ((14 : Int),(1 : Int)) hp6_4_branches1144 hp6_4_evidence1144 hp6_4_check1144 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1144,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1143 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1143 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1143 ((13 : Int),(1 : Int)) hp6_4_branches1143 hp6_4_evidence1143 hp6_4_check1143 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1143,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1144 T childKnown
theorem hp6_4_node1142 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1142 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1142 ((14 : Int),(1 : Int)) hp6_4_branches1142 hp6_4_evidence1142 hp6_4_check1142 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1141 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1141 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1141 ((13 : Int),(1 : Int)) hp6_4_branches1141 hp6_4_evidence1141 hp6_4_check1141 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1141,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1142 T childKnown
theorem hp6_4_node1140 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1140 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1140 ((13 : Int),(1 : Int)) hp6_4_branches1140 hp6_4_evidence1140 hp6_4_check1140 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1139 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1139 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1139 ((14 : Int),(0 : Int)) hp6_4_branches1139 hp6_4_evidence1139 hp6_4_check1139 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1140 T childKnown
  · exact hp6_4_node1141 T childKnown
  · exact hp6_4_node1143 T childKnown
theorem hp6_4_node1138 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1138 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1138 ((11 : Int),(1 : Int)) hp6_4_branches1138 hp6_4_evidence1138 hp6_4_check1138 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1139 T childKnown
theorem hp6_4_node1137 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1137 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1137 ((10 : Int),(1 : Int)) hp6_4_branches1137 hp6_4_evidence1137 hp6_4_check1137 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1136 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1136 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1136 ((7 : Int),(2 : Int)) hp6_4_branches1136 hp6_4_evidence1136 hp6_4_check1136 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1137 T childKnown
theorem hp6_4_node1135 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1135 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1135 ((10 : Int),(1 : Int)) hp6_4_branches1135 hp6_4_evidence1135 hp6_4_check1135 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1134 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1134 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1134 ((6 : Int),(2 : Int)) hp6_4_branches1134 hp6_4_evidence1134 hp6_4_check1134 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1134,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1135 T childKnown
  · exact hp6_4_node1136 T childKnown
  · exact hp6_4_node1138 T childKnown
theorem hp6_4_node1133 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1133 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1133 ((0 : Int),(2 : Int)) hp6_4_branches1133 hp6_4_evidence1133 hp6_4_check1133 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1134 T childKnown
theorem hp6_4_node1132 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1132 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1132 ((2 : Int),(2 : Int)) hp6_4_branches1132 hp6_4_evidence1132 hp6_4_check1132 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1133 T childKnown
theorem hp6_4_node1131 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1131 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1131 ((1 : Int),(2 : Int)) hp6_4_branches1131 hp6_4_evidence1131 hp6_4_check1131 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1130 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1130 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1130 ((0 : Int),(2 : Int)) hp6_4_branches1130 hp6_4_evidence1130 hp6_4_check1130 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1131 T childKnown
theorem hp6_4_node1129 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1129 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1129 ((2 : Int),(1 : Int)) hp6_4_branches1129 hp6_4_evidence1129 hp6_4_check1129 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1129,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1130 T childKnown
  · exact hp6_4_node1132 T childKnown
  · exact hp6_4_node1145 T childKnown
theorem hp6_4_node1128 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1128 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1128 ((6 : Int),(0 : Int)) hp6_4_branches1128 hp6_4_evidence1128 hp6_4_check1128 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1128,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1129 T childKnown
theorem hp6_4_node1127 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1127 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1127 ((4 : Int),(1 : Int)) hp6_4_branches1127 hp6_4_evidence1127 hp6_4_check1127 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1127,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1128 T childKnown
theorem hp6_4_node1126 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1126 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1126 ((4 : Int),(1 : Int)) hp6_4_branches1126 hp6_4_evidence1126 hp6_4_check1126 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1125 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1125 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1125 ((4 : Int),(1 : Int)) hp6_4_branches1125 hp6_4_evidence1125 hp6_4_check1125 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1124 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1124 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1124 ((5 : Int),(0 : Int)) hp6_4_branches1124 hp6_4_evidence1124 hp6_4_check1124 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1125 T childKnown
  · exact hp6_4_node1126 T childKnown
  · exact hp6_4_node1127 T childKnown
  · exact hp6_4_node1147 T childKnown
  · exact hp6_4_node1151 T childKnown
  · exact hp6_4_node1172 T childKnown
theorem hp6_4_node1123 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1123 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1123 ((16 : Int),(1 : Int)) hp6_4_branches1123 hp6_4_evidence1123 hp6_4_check1123 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1122 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1122 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1122 ((14 : Int),(1 : Int)) hp6_4_branches1122 hp6_4_evidence1122 hp6_4_check1122 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1122,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1121 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1121 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1121 ((14 : Int),(1 : Int)) hp6_4_branches1121 hp6_4_evidence1121 hp6_4_check1121 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1120 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1120 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1120 ((12 : Int),(1 : Int)) hp6_4_branches1120 hp6_4_evidence1120 hp6_4_check1120 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1120,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1119 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1119 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1119 ((15 : Int),(1 : Int)) hp6_4_branches1119 hp6_4_evidence1119 hp6_4_check1119 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1119,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1120 T childKnown
  · exact hp6_4_node1121 T childKnown
  · exact hp6_4_node1122 T childKnown
  · exact hp6_4_node1123 T childKnown
theorem hp6_4_node1118 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1118 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1118 ((13 : Int),(1 : Int)) hp6_4_branches1118 hp6_4_evidence1118 hp6_4_check1118 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1117 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1117 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1117 ((13 : Int),(1 : Int)) hp6_4_branches1117 hp6_4_evidence1117 hp6_4_check1117 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1116 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1116 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1116 ((4 : Int),(2 : Int)) hp6_4_branches1116 hp6_4_evidence1116 hp6_4_check1116 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1115 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1115 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1115 ((9 : Int),(1 : Int)) hp6_4_branches1115 hp6_4_evidence1115 hp6_4_check1115 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1116 T childKnown
theorem hp6_4_node1114 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1114 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1114 ((1 : Int),(1 : Int)) hp6_4_branches1114 hp6_4_evidence1114 hp6_4_check1114 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1113 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1113 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1113 ((8 : Int),(2 : Int)) hp6_4_branches1113 hp6_4_evidence1113 hp6_4_check1113 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1114 T childKnown
theorem hp6_4_node1112 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1112 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1112 ((10 : Int),(2 : Int)) hp6_4_branches1112 hp6_4_evidence1112 hp6_4_check1112 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1112,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1113 T childKnown
theorem hp6_4_node1111 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1111 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1111 ((5 : Int),(2 : Int)) hp6_4_branches1111 hp6_4_evidence1111 hp6_4_check1111 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1110 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1110 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1110 ((8 : Int),(2 : Int)) hp6_4_branches1110 hp6_4_evidence1110 hp6_4_check1110 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1110,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1111 T childKnown
theorem hp6_4_node1109 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1109 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1109 ((10 : Int),(1 : Int)) hp6_4_branches1109 hp6_4_evidence1109 hp6_4_check1109 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1109,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1110 T childKnown
  · exact hp6_4_node1112 T childKnown
  · exact hp6_4_node1115 T childKnown
theorem hp6_4_node1108 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1108 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1108 ((13 : Int),(1 : Int)) hp6_4_branches1108 hp6_4_evidence1108 hp6_4_check1108 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1108,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1109 T childKnown
theorem hp6_4_node1107 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1107 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1107 ((13 : Int),(1 : Int)) hp6_4_branches1107 hp6_4_evidence1107 hp6_4_check1107 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1107,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1106 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1106 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1106 ((12 : Int),(1 : Int)) hp6_4_branches1106 hp6_4_evidence1106 hp6_4_check1106 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1107 T childKnown
  · exact hp6_4_node1108 T childKnown
  · exact hp6_4_node1117 T childKnown
  · exact hp6_4_node1118 T childKnown
theorem hp6_4_node1105 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1105 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1105 ((14 : Int),(1 : Int)) hp6_4_branches1105 hp6_4_evidence1105 hp6_4_check1105 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1104 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1104 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1104 ((14 : Int),(1 : Int)) hp6_4_branches1104 hp6_4_evidence1104 hp6_4_check1104 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1104,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1103 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1103 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1103 ((14 : Int),(0 : Int)) hp6_4_branches1103 hp6_4_evidence1103 hp6_4_check1103 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1103,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1104 T childKnown
  · exact hp6_4_node1105 T childKnown
theorem hp6_4_node1102 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1102 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1102 ((12 : Int),(1 : Int)) hp6_4_branches1102 hp6_4_evidence1102 hp6_4_check1102 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1102,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1103 T childKnown
theorem hp6_4_node1101 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1101 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1101 ((4 : Int),(2 : Int)) hp6_4_branches1101 hp6_4_evidence1101 hp6_4_check1101 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1100 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1100 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1100 ((9 : Int),(1 : Int)) hp6_4_branches1100 hp6_4_evidence1100 hp6_4_check1100 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1100,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1101 T childKnown
theorem hp6_4_node1099 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1099 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1099 ((1 : Int),(1 : Int)) hp6_4_branches1099 hp6_4_evidence1099 hp6_4_check1099 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1099,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1098 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1098 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1098 ((8 : Int),(2 : Int)) hp6_4_branches1098 hp6_4_evidence1098 hp6_4_check1098 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1098,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1099 T childKnown
theorem hp6_4_node1097 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1097 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1097 ((10 : Int),(2 : Int)) hp6_4_branches1097 hp6_4_evidence1097 hp6_4_check1097 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1097,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1098 T childKnown
theorem hp6_4_node1096 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1096 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1096 ((5 : Int),(2 : Int)) hp6_4_branches1096 hp6_4_evidence1096 hp6_4_check1096 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1096,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1095 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1095 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1095 ((8 : Int),(2 : Int)) hp6_4_branches1095 hp6_4_evidence1095 hp6_4_check1095 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1095,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1096 T childKnown
theorem hp6_4_node1094 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1094 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1094 ((10 : Int),(1 : Int)) hp6_4_branches1094 hp6_4_evidence1094 hp6_4_check1094 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1094,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1095 T childKnown
  · exact hp6_4_node1097 T childKnown
  · exact hp6_4_node1100 T childKnown
theorem hp6_4_node1093 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1093 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1093 ((14 : Int),(0 : Int)) hp6_4_branches1093 hp6_4_evidence1093 hp6_4_check1093 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1093,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1094 T childKnown
theorem hp6_4_node1092 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1092 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1092 ((12 : Int),(1 : Int)) hp6_4_branches1092 hp6_4_evidence1092 hp6_4_check1092 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1092,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1093 T childKnown
theorem hp6_4_node1091 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1091 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1091 ((12 : Int),(1 : Int)) hp6_4_branches1091 hp6_4_evidence1091 hp6_4_check1091 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1091,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1090 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1090 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1090 ((12 : Int),(1 : Int)) hp6_4_branches1090 hp6_4_evidence1090 hp6_4_check1090 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1090,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1089 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1089 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1089 ((13 : Int),(0 : Int)) hp6_4_branches1089 hp6_4_evidence1089 hp6_4_check1089 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1089,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1090 T childKnown
  · exact hp6_4_node1091 T childKnown
  · exact hp6_4_node1092 T childKnown
  · exact hp6_4_node1102 T childKnown
  · exact hp6_4_node1106 T childKnown
  · exact hp6_4_node1119 T childKnown
theorem hp6_4_node1088 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1088 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1088 ((3 : Int),(1 : Int)) hp6_4_branches1088 hp6_4_evidence1088 hp6_4_check1088 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1088,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1087 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1087 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1087 ((1 : Int),(1 : Int)) hp6_4_branches1087 hp6_4_evidence1087 hp6_4_check1087 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1087,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1086 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1086 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1086 ((1 : Int),(1 : Int)) hp6_4_branches1086 hp6_4_evidence1086 hp6_4_check1086 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1086,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1085 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1085 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1085 ((0 : Int),(1 : Int)) hp6_4_branches1085 hp6_4_evidence1085 hp6_4_check1085 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1085,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1084 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1084 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1084 ((2 : Int),(1 : Int)) hp6_4_branches1084 hp6_4_evidence1084 hp6_4_check1084 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1084,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1085 T childKnown
  · exact hp6_4_node1086 T childKnown
  · exact hp6_4_node1087 T childKnown
  · exact hp6_4_node1088 T childKnown
theorem hp6_4_node1083 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1083 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1083 ((0 : Int),(1 : Int)) hp6_4_branches1083 hp6_4_evidence1083 hp6_4_check1083 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1083,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1082 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1082 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1082 ((0 : Int),(1 : Int)) hp6_4_branches1082 hp6_4_evidence1082 hp6_4_check1082 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1082,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1081 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1081 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1081 ((1 : Int),(1 : Int)) hp6_4_branches1081 hp6_4_evidence1081 hp6_4_check1081 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1081,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1082 T childKnown
  · exact hp6_4_node1083 T childKnown
theorem hp6_4_node1080 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1080 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1080 ((0 : Int),(1 : Int)) hp6_4_branches1080 hp6_4_evidence1080 hp6_4_check1080 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1080,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1079 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1079 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1079 ((0 : Int),(1 : Int)) hp6_4_branches1079 hp6_4_evidence1079 hp6_4_check1079 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1079,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1078 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1078 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1078 ((1 : Int),(1 : Int)) hp6_4_branches1078 hp6_4_evidence1078 hp6_4_check1078 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1078,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1079 T childKnown
  · exact hp6_4_node1080 T childKnown
theorem hp6_4_node1077 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1077 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1077 ((6 : Int),(0 : Int)) hp6_4_branches1077 hp6_4_evidence1077 hp6_4_check1077 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1077,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1078 T childKnown
theorem hp6_4_node1076 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1076 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1076 ((4 : Int),(1 : Int)) hp6_4_branches1076 hp6_4_evidence1076 hp6_4_check1076 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1076,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1075 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1075 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1075 ((4 : Int),(1 : Int)) hp6_4_branches1075 hp6_4_evidence1075 hp6_4_check1075 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1075,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1074 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1074 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1074 ((1 : Int),(2 : Int)) hp6_4_branches1074 hp6_4_evidence1074 hp6_4_check1074 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1074,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1073 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1073 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1073 ((7 : Int),(1 : Int)) hp6_4_branches1073 hp6_4_evidence1073 hp6_4_check1073 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1073,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1072 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1072 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1072 ((7 : Int),(1 : Int)) hp6_4_branches1072 hp6_4_evidence1072 hp6_4_check1072 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1072,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1071 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1071 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1071 ((6 : Int),(1 : Int)) hp6_4_branches1071 hp6_4_evidence1071 hp6_4_check1071 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1071,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1072 T childKnown
  · exact hp6_4_node1073 T childKnown
theorem hp6_4_node1070 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1070 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1070 ((9 : Int),(2 : Int)) hp6_4_branches1070 hp6_4_evidence1070 hp6_4_check1070 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1070,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1069 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1069 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1069 ((8 : Int),(2 : Int)) hp6_4_branches1069 hp6_4_evidence1069 hp6_4_check1069 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1069,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1070 T childKnown
theorem hp6_4_node1068 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1068 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1068 ((16 : Int),(1 : Int)) hp6_4_branches1068 hp6_4_evidence1068 hp6_4_check1068 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1068,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1067 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1067 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1067 ((14 : Int),(0 : Int)) hp6_4_branches1067 hp6_4_evidence1067 hp6_4_check1067 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1067,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1068 T childKnown
theorem hp6_4_node1066 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1066 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1066 ((10 : Int),(2 : Int)) hp6_4_branches1066 hp6_4_evidence1066 hp6_4_check1066 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1066,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1067 T childKnown
theorem hp6_4_node1065 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1065 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1065 ((8 : Int),(2 : Int)) hp6_4_branches1065 hp6_4_evidence1065 hp6_4_check1065 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1065,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1066 T childKnown
theorem hp6_4_node1064 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1064 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1064 ((9 : Int),(2 : Int)) hp6_4_branches1064 hp6_4_evidence1064 hp6_4_check1064 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1064,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1063 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1063 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1063 ((9 : Int),(1 : Int)) hp6_4_branches1063 hp6_4_evidence1063 hp6_4_check1063 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1063,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1064 T childKnown
theorem hp6_4_node1062 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1062 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1062 ((8 : Int),(1 : Int)) hp6_4_branches1062 hp6_4_evidence1062 hp6_4_check1062 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1062,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1063 T childKnown
  · exact hp6_4_node1065 T childKnown
  · exact hp6_4_node1069 T childKnown
theorem hp6_4_node1061 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1061 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1061 ((6 : Int),(1 : Int)) hp6_4_branches1061 hp6_4_evidence1061 hp6_4_check1061 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1061,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1062 T childKnown
theorem hp6_4_node1060 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1060 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1060 ((7 : Int),(1 : Int)) hp6_4_branches1060 hp6_4_evidence1060 hp6_4_check1060 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1060,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1059 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1059 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1059 ((7 : Int),(1 : Int)) hp6_4_branches1059 hp6_4_evidence1059 hp6_4_check1059 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1059,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1058 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1058 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1058 ((7 : Int),(0 : Int)) hp6_4_branches1058 hp6_4_evidence1058 hp6_4_check1058 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1058,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1059 T childKnown
  · exact hp6_4_node1060 T childKnown
theorem hp6_4_node1057 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1057 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1057 ((15 : Int),(1 : Int)) hp6_4_branches1057 hp6_4_evidence1057 hp6_4_check1057 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1057,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1056 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1056 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1056 ((14 : Int),(1 : Int)) hp6_4_branches1056 hp6_4_evidence1056 hp6_4_check1056 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1056,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1057 T childKnown
theorem hp6_4_node1055 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1055 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1055 ((15 : Int),(1 : Int)) hp6_4_branches1055 hp6_4_evidence1055 hp6_4_check1055 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1055,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1054 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1054 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1054 ((14 : Int),(1 : Int)) hp6_4_branches1054 hp6_4_evidence1054 hp6_4_check1054 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1054,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1055 T childKnown
theorem hp6_4_node1053 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1053 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1053 ((14 : Int),(1 : Int)) hp6_4_branches1053 hp6_4_evidence1053 hp6_4_check1053 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1053,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1052 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1052 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1052 ((15 : Int),(0 : Int)) hp6_4_branches1052 hp6_4_evidence1052 hp6_4_check1052 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1052,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1053 T childKnown
  · exact hp6_4_node1054 T childKnown
  · exact hp6_4_node1056 T childKnown
theorem hp6_4_node1051 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1051 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1051 ((12 : Int),(1 : Int)) hp6_4_branches1051 hp6_4_evidence1051 hp6_4_check1051 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1051,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1052 T childKnown
theorem hp6_4_node1050 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1050 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1050 ((11 : Int),(1 : Int)) hp6_4_branches1050 hp6_4_evidence1050 hp6_4_check1050 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1050,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1049 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1049 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1049 ((8 : Int),(2 : Int)) hp6_4_branches1049 hp6_4_evidence1049 hp6_4_check1049 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1049,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1050 T childKnown
theorem hp6_4_node1048 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1048 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1048 ((11 : Int),(1 : Int)) hp6_4_branches1048 hp6_4_evidence1048 hp6_4_check1048 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1048,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1047 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1047 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1047 ((8 : Int),(2 : Int)) hp6_4_branches1047 hp6_4_evidence1047 hp6_4_check1047 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1047,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1046 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1046 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1046 ((10 : Int),(2 : Int)) hp6_4_branches1046 hp6_4_evidence1046 hp6_4_check1046 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1046,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1045 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1045 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1045 ((11 : Int),(1 : Int)) hp6_4_branches1045 hp6_4_evidence1045 hp6_4_check1045 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1045,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1046 T childKnown
  · exact hp6_4_node1047 T childKnown
theorem hp6_4_node1044 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1044 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1044 ((7 : Int),(2 : Int)) hp6_4_branches1044 hp6_4_evidence1044 hp6_4_check1044 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1044,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1045 T childKnown
  · exact hp6_4_node1048 T childKnown
  · exact hp6_4_node1049 T childKnown
  · exact hp6_4_node1051 T childKnown
theorem hp6_4_node1043 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1043 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1043 ((7 : Int),(0 : Int)) hp6_4_branches1043 hp6_4_evidence1043 hp6_4_check1043 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1043,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1044 T childKnown
theorem hp6_4_node1042 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1042 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1042 ((6 : Int),(0 : Int)) hp6_4_branches1042 hp6_4_evidence1042 hp6_4_check1042 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1042,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1043 T childKnown
  · exact hp6_4_node1058 T childKnown
  · exact hp6_4_node1061 T childKnown
  · exact hp6_4_node1071 T childKnown
theorem hp6_4_node1041 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1041 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1041 ((2 : Int),(2 : Int)) hp6_4_branches1041 hp6_4_evidence1041 hp6_4_check1041 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1041,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1040 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1040 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1040 ((1 : Int),(2 : Int)) hp6_4_branches1040 hp6_4_evidence1040 hp6_4_check1040 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1040,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1041 T childKnown
theorem hp6_4_node1039 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1039 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1039 ((1 : Int),(2 : Int)) hp6_4_branches1039 hp6_4_evidence1039 hp6_4_check1039 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1039,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1038 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1038 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1038 ((0 : Int),(1 : Int)) hp6_4_branches1038 hp6_4_evidence1038 hp6_4_check1038 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1038,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1039 T childKnown
  · exact hp6_4_node1040 T childKnown
  · exact hp6_4_node1042 T childKnown
  · exact hp6_4_node1074 T childKnown
theorem hp6_4_node1037 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1037 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1037 ((0 : Int),(1 : Int)) hp6_4_branches1037 hp6_4_evidence1037 hp6_4_check1037 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1037,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1036 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1036 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1036 ((5 : Int),(0 : Int)) hp6_4_branches1036 hp6_4_evidence1036 hp6_4_check1036 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1036,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1037 T childKnown
  · exact hp6_4_node1038 T childKnown
  · exact hp6_4_node1075 T childKnown
  · exact hp6_4_node1076 T childKnown
  · exact hp6_4_node1077 T childKnown
  · exact hp6_4_node1081 T childKnown
  · exact hp6_4_node1084 T childKnown
  · exact hp6_4_node1089 T childKnown
theorem hp6_4_node1035 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1035 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1035 ((2 : Int),(1 : Int)) hp6_4_branches1035 hp6_4_evidence1035 hp6_4_check1035 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1035,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1034 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1034 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1034 ((2 : Int),(1 : Int)) hp6_4_branches1034 hp6_4_evidence1034 hp6_4_check1034 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1034,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1033 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1033 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1033 ((1 : Int),(1 : Int)) hp6_4_branches1033 hp6_4_evidence1033 hp6_4_check1033 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1033,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1034 T childKnown
  · exact hp6_4_node1035 T childKnown
theorem hp6_4_node1032 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1032 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1032 ((4 : Int),(2 : Int)) hp6_4_branches1032 hp6_4_evidence1032 hp6_4_check1032 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1032,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1031 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1031 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1031 ((3 : Int),(2 : Int)) hp6_4_branches1031 hp6_4_evidence1031 hp6_4_check1031 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1031,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1032 T childKnown
theorem hp6_4_node1030 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1030 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1030 ((11 : Int),(1 : Int)) hp6_4_branches1030 hp6_4_evidence1030 hp6_4_check1030 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1030,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1029 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1029 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1029 ((9 : Int),(0 : Int)) hp6_4_branches1029 hp6_4_evidence1029 hp6_4_check1029 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1029,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1030 T childKnown
theorem hp6_4_node1028 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1028 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1028 ((5 : Int),(2 : Int)) hp6_4_branches1028 hp6_4_evidence1028 hp6_4_check1028 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1028,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1029 T childKnown
theorem hp6_4_node1027 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1027 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1027 ((3 : Int),(2 : Int)) hp6_4_branches1027 hp6_4_evidence1027 hp6_4_check1027 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1027,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1028 T childKnown
theorem hp6_4_node1026 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1026 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1026 ((4 : Int),(2 : Int)) hp6_4_branches1026 hp6_4_evidence1026 hp6_4_check1026 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1026,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1025 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1025 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1025 ((4 : Int),(1 : Int)) hp6_4_branches1025 hp6_4_evidence1025 hp6_4_check1025 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1025,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1026 T childKnown
theorem hp6_4_node1024 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1024 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1024 ((3 : Int),(1 : Int)) hp6_4_branches1024 hp6_4_evidence1024 hp6_4_check1024 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1024,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1025 T childKnown
  · exact hp6_4_node1027 T childKnown
  · exact hp6_4_node1031 T childKnown
theorem hp6_4_node1023 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1023 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1023 ((1 : Int),(1 : Int)) hp6_4_branches1023 hp6_4_evidence1023 hp6_4_check1023 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1023,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1024 T childKnown
theorem hp6_4_node1022 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1022 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1022 ((2 : Int),(1 : Int)) hp6_4_branches1022 hp6_4_evidence1022 hp6_4_check1022 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1022,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1021 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1021 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1021 ((2 : Int),(1 : Int)) hp6_4_branches1021 hp6_4_evidence1021 hp6_4_check1021 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1021,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1020 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1020 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1020 ((2 : Int),(0 : Int)) hp6_4_branches1020 hp6_4_evidence1020 hp6_4_check1020 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1020,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1021 T childKnown
  · exact hp6_4_node1022 T childKnown
theorem hp6_4_node1019 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1019 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1019 ((10 : Int),(1 : Int)) hp6_4_branches1019 hp6_4_evidence1019 hp6_4_check1019 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1019,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1018 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1018 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1018 ((9 : Int),(1 : Int)) hp6_4_branches1018 hp6_4_evidence1018 hp6_4_check1018 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1018,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1019 T childKnown
theorem hp6_4_node1017 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1017 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1017 ((10 : Int),(1 : Int)) hp6_4_branches1017 hp6_4_evidence1017 hp6_4_check1017 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1017,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1016 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1016 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1016 ((9 : Int),(1 : Int)) hp6_4_branches1016 hp6_4_evidence1016 hp6_4_check1016 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1016,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1017 T childKnown
theorem hp6_4_node1015 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1015 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1015 ((9 : Int),(1 : Int)) hp6_4_branches1015 hp6_4_evidence1015 hp6_4_check1015 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1015,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1014 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1014 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1014 ((10 : Int),(0 : Int)) hp6_4_branches1014 hp6_4_evidence1014 hp6_4_check1014 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1014,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node1015 T childKnown
  · exact hp6_4_node1016 T childKnown
  · exact hp6_4_node1018 T childKnown
theorem hp6_4_node1013 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1013 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1013 ((7 : Int),(1 : Int)) hp6_4_branches1013 hp6_4_evidence1013 hp6_4_check1013 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1013,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1014 T childKnown
theorem hp6_4_node1012 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1012 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1012 ((6 : Int),(1 : Int)) hp6_4_branches1012 hp6_4_evidence1012 hp6_4_check1012 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1012,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1011 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1011 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1011 ((3 : Int),(2 : Int)) hp6_4_branches1011 hp6_4_evidence1011 hp6_4_check1011 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1011,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1012 T childKnown
theorem hp6_4_node1010 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1010 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1010 ((6 : Int),(1 : Int)) hp6_4_branches1010 hp6_4_evidence1010 hp6_4_check1010 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1010,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1009 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1009 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1009 ((3 : Int),(2 : Int)) hp6_4_branches1009 hp6_4_evidence1009 hp6_4_check1009 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1009,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1008 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1008 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1008 ((5 : Int),(2 : Int)) hp6_4_branches1008 hp6_4_evidence1008 hp6_4_check1008 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1008,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1007 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1007 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1007 ((6 : Int),(1 : Int)) hp6_4_branches1007 hp6_4_evidence1007 hp6_4_check1007 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1007,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1008 T childKnown
  · exact hp6_4_node1009 T childKnown
theorem hp6_4_node1006 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1006 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1006 ((2 : Int),(2 : Int)) hp6_4_branches1006 hp6_4_evidence1006 hp6_4_check1006 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1006,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1007 T childKnown
  · exact hp6_4_node1010 T childKnown
  · exact hp6_4_node1011 T childKnown
  · exact hp6_4_node1013 T childKnown
theorem hp6_4_node1005 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1005 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1005 ((2 : Int),(0 : Int)) hp6_4_branches1005 hp6_4_evidence1005 hp6_4_check1005 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1005,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1006 T childKnown
theorem hp6_4_node1004 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1004 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1004 ((1 : Int),(0 : Int)) hp6_4_branches1004 hp6_4_evidence1004 hp6_4_check1004 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1004,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node1005 T childKnown
  · exact hp6_4_node1020 T childKnown
  · exact hp6_4_node1023 T childKnown
  · exact hp6_4_node1033 T childKnown
theorem hp6_4_node1003 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1003 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1003 ((2 : Int),(1 : Int)) hp6_4_branches1003 hp6_4_evidence1003 hp6_4_check1003 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1003,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1002 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1002 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1002 ((2 : Int),(1 : Int)) hp6_4_branches1002 hp6_4_evidence1002 hp6_4_check1002 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1002,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1001 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1001 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1001 ((1 : Int),(1 : Int)) hp6_4_branches1001 hp6_4_evidence1001 hp6_4_check1001 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1001,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node1002 T childKnown
  · exact hp6_4_node1003 T childKnown
theorem hp6_4_node1000 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1000 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1000 ((4 : Int),(2 : Int)) hp6_4_branches1000 hp6_4_evidence1000 hp6_4_check1000 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1000,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node999 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected999 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected999 ((3 : Int),(2 : Int)) hp6_4_branches999 hp6_4_evidence999 hp6_4_check999 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches999,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node1000 T childKnown
theorem hp6_4_node998 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected998 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected998 ((11 : Int),(1 : Int)) hp6_4_branches998 hp6_4_evidence998 hp6_4_check998 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches998,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node997 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected997 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected997 ((9 : Int),(0 : Int)) hp6_4_branches997 hp6_4_evidence997 hp6_4_check997 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches997,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node998 T childKnown
theorem hp6_4_node996 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected996 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected996 ((5 : Int),(2 : Int)) hp6_4_branches996 hp6_4_evidence996 hp6_4_check996 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches996,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node997 T childKnown
theorem hp6_4_node995 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected995 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected995 ((3 : Int),(2 : Int)) hp6_4_branches995 hp6_4_evidence995 hp6_4_check995 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches995,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node996 T childKnown
theorem hp6_4_node994 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected994 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected994 ((4 : Int),(2 : Int)) hp6_4_branches994 hp6_4_evidence994 hp6_4_check994 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches994,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node993 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected993 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected993 ((4 : Int),(1 : Int)) hp6_4_branches993 hp6_4_evidence993 hp6_4_check993 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches993,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node994 T childKnown
theorem hp6_4_node992 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected992 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected992 ((3 : Int),(1 : Int)) hp6_4_branches992 hp6_4_evidence992 hp6_4_check992 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches992,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node993 T childKnown
  · exact hp6_4_node995 T childKnown
  · exact hp6_4_node999 T childKnown
theorem hp6_4_node991 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected991 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected991 ((1 : Int),(1 : Int)) hp6_4_branches991 hp6_4_evidence991 hp6_4_check991 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches991,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node992 T childKnown
theorem hp6_4_node990 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected990 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected990 ((2 : Int),(1 : Int)) hp6_4_branches990 hp6_4_evidence990 hp6_4_check990 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches990,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node989 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected989 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected989 ((2 : Int),(1 : Int)) hp6_4_branches989 hp6_4_evidence989 hp6_4_check989 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches989,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node988 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected988 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected988 ((2 : Int),(0 : Int)) hp6_4_branches988 hp6_4_evidence988 hp6_4_check988 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches988,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node989 T childKnown
  · exact hp6_4_node990 T childKnown
theorem hp6_4_node987 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected987 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected987 ((10 : Int),(1 : Int)) hp6_4_branches987 hp6_4_evidence987 hp6_4_check987 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches987,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node986 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected986 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected986 ((9 : Int),(1 : Int)) hp6_4_branches986 hp6_4_evidence986 hp6_4_check986 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches986,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node987 T childKnown
theorem hp6_4_node985 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected985 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected985 ((10 : Int),(1 : Int)) hp6_4_branches985 hp6_4_evidence985 hp6_4_check985 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches985,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node984 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected984 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected984 ((9 : Int),(1 : Int)) hp6_4_branches984 hp6_4_evidence984 hp6_4_check984 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches984,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node985 T childKnown
theorem hp6_4_node983 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected983 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected983 ((9 : Int),(1 : Int)) hp6_4_branches983 hp6_4_evidence983 hp6_4_check983 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches983,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node982 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected982 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected982 ((10 : Int),(0 : Int)) hp6_4_branches982 hp6_4_evidence982 hp6_4_check982 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches982,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node983 T childKnown
  · exact hp6_4_node984 T childKnown
  · exact hp6_4_node986 T childKnown
theorem hp6_4_node981 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected981 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected981 ((7 : Int),(1 : Int)) hp6_4_branches981 hp6_4_evidence981 hp6_4_check981 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches981,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node982 T childKnown
theorem hp6_4_node980 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected980 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected980 ((6 : Int),(1 : Int)) hp6_4_branches980 hp6_4_evidence980 hp6_4_check980 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches980,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node979 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected979 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected979 ((3 : Int),(2 : Int)) hp6_4_branches979 hp6_4_evidence979 hp6_4_check979 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches979,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node980 T childKnown
theorem hp6_4_node978 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected978 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected978 ((6 : Int),(1 : Int)) hp6_4_branches978 hp6_4_evidence978 hp6_4_check978 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches978,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node977 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected977 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected977 ((3 : Int),(2 : Int)) hp6_4_branches977 hp6_4_evidence977 hp6_4_check977 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches977,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node976 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected976 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected976 ((5 : Int),(2 : Int)) hp6_4_branches976 hp6_4_evidence976 hp6_4_check976 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches976,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node975 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected975 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected975 ((6 : Int),(1 : Int)) hp6_4_branches975 hp6_4_evidence975 hp6_4_check975 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches975,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node976 T childKnown
  · exact hp6_4_node977 T childKnown
theorem hp6_4_node974 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected974 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected974 ((2 : Int),(2 : Int)) hp6_4_branches974 hp6_4_evidence974 hp6_4_check974 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches974,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node975 T childKnown
  · exact hp6_4_node978 T childKnown
  · exact hp6_4_node979 T childKnown
  · exact hp6_4_node981 T childKnown
theorem hp6_4_node973 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected973 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected973 ((2 : Int),(0 : Int)) hp6_4_branches973 hp6_4_evidence973 hp6_4_check973 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches973,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node974 T childKnown
theorem hp6_4_node972 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected972 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected972 ((1 : Int),(0 : Int)) hp6_4_branches972 hp6_4_evidence972 hp6_4_check972 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches972,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node973 T childKnown
  · exact hp6_4_node988 T childKnown
  · exact hp6_4_node991 T childKnown
  · exact hp6_4_node1001 T childKnown
theorem hp6_4_node971 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected971 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected971 ((7 : Int),(1 : Int)) hp6_4_branches971 hp6_4_evidence971 hp6_4_check971 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches971,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node970 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected970 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected970 ((5 : Int),(1 : Int)) hp6_4_branches970 hp6_4_evidence970 hp6_4_check970 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches970,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node969 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected969 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected969 ((5 : Int),(1 : Int)) hp6_4_branches969 hp6_4_evidence969 hp6_4_check969 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches969,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node968 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected968 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected968 ((3 : Int),(1 : Int)) hp6_4_branches968 hp6_4_evidence968 hp6_4_check968 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches968,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node967 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected967 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected967 ((6 : Int),(1 : Int)) hp6_4_branches967 hp6_4_evidence967 hp6_4_check967 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches967,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node968 T childKnown
  · exact hp6_4_node969 T childKnown
  · exact hp6_4_node970 T childKnown
  · exact hp6_4_node971 T childKnown
theorem hp6_4_node966 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected966 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected966 ((4 : Int),(1 : Int)) hp6_4_branches966 hp6_4_evidence966 hp6_4_check966 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches966,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node965 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected965 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected965 ((4 : Int),(1 : Int)) hp6_4_branches965 hp6_4_evidence965 hp6_4_check965 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches965,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node964 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected964 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected964 ((0 : Int),(2 : Int)) hp6_4_branches964 hp6_4_evidence964 hp6_4_check964 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches964,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node963 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected963 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected963 ((0 : Int),(1 : Int)) hp6_4_branches963 hp6_4_evidence963 hp6_4_check963 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches963,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node964 T childKnown
theorem hp6_4_node962 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected962 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected962 ((7 : Int),(2 : Int)) hp6_4_branches962 hp6_4_evidence962 hp6_4_check962 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches962,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node961 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected961 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected961 ((6 : Int),(2 : Int)) hp6_4_branches961 hp6_4_evidence961 hp6_4_check961 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches961,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node962 T childKnown
theorem hp6_4_node960 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected960 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected960 ((14 : Int),(1 : Int)) hp6_4_branches960 hp6_4_evidence960 hp6_4_check960 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches960,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node959 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected959 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected959 ((12 : Int),(0 : Int)) hp6_4_branches959 hp6_4_evidence959 hp6_4_check959 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches959,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node960 T childKnown
theorem hp6_4_node958 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected958 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected958 ((8 : Int),(2 : Int)) hp6_4_branches958 hp6_4_evidence958 hp6_4_check958 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches958,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node959 T childKnown
theorem hp6_4_node957 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected957 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected957 ((6 : Int),(2 : Int)) hp6_4_branches957 hp6_4_evidence957 hp6_4_check957 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches957,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node958 T childKnown
theorem hp6_4_node956 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected956 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected956 ((7 : Int),(2 : Int)) hp6_4_branches956 hp6_4_evidence956 hp6_4_check956 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches956,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node955 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected955 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected955 ((7 : Int),(1 : Int)) hp6_4_branches955 hp6_4_evidence955 hp6_4_check955 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches955,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node956 T childKnown
theorem hp6_4_node954 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected954 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected954 ((6 : Int),(1 : Int)) hp6_4_branches954 hp6_4_evidence954 hp6_4_check954 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches954,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node955 T childKnown
  · exact hp6_4_node957 T childKnown
  · exact hp6_4_node961 T childKnown
theorem hp6_4_node953 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected953 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected953 ((1 : Int),(2 : Int)) hp6_4_branches953 hp6_4_evidence953 hp6_4_check953 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches953,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node954 T childKnown
theorem hp6_4_node952 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected952 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected952 ((1 : Int),(2 : Int)) hp6_4_branches952 hp6_4_evidence952 hp6_4_check952 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches952,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node951 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected951 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected951 ((0 : Int),(2 : Int)) hp6_4_branches951 hp6_4_evidence951 hp6_4_check951 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches951,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node952 T childKnown
theorem hp6_4_node950 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected950 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected950 ((1 : Int),(1 : Int)) hp6_4_branches950 hp6_4_evidence950 hp6_4_check950 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches950,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node951 T childKnown
  · exact hp6_4_node953 T childKnown
  · exact hp6_4_node963 T childKnown
theorem hp6_4_node949 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected949 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected949 ((4 : Int),(1 : Int)) hp6_4_branches949 hp6_4_evidence949 hp6_4_check949 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches949,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node950 T childKnown
theorem hp6_4_node948 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected948 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected948 ((4 : Int),(1 : Int)) hp6_4_branches948 hp6_4_evidence948 hp6_4_check948 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches948,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node947 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected947 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected947 ((3 : Int),(1 : Int)) hp6_4_branches947 hp6_4_evidence947 hp6_4_check947 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches947,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node948 T childKnown
  · exact hp6_4_node949 T childKnown
  · exact hp6_4_node965 T childKnown
  · exact hp6_4_node966 T childKnown
theorem hp6_4_node946 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected946 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected946 ((5 : Int),(1 : Int)) hp6_4_branches946 hp6_4_evidence946 hp6_4_check946 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches946,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node945 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected945 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected945 ((5 : Int),(1 : Int)) hp6_4_branches945 hp6_4_evidence945 hp6_4_check945 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches945,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node944 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected944 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected944 ((5 : Int),(0 : Int)) hp6_4_branches944 hp6_4_evidence944 hp6_4_check944 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches944,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node945 T childKnown
  · exact hp6_4_node946 T childKnown
theorem hp6_4_node943 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected943 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected943 ((3 : Int),(1 : Int)) hp6_4_branches943 hp6_4_evidence943 hp6_4_check943 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches943,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node944 T childKnown
theorem hp6_4_node942 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected942 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected942 ((0 : Int),(2 : Int)) hp6_4_branches942 hp6_4_evidence942 hp6_4_check942 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches942,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node941 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected941 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected941 ((0 : Int),(1 : Int)) hp6_4_branches941 hp6_4_evidence941 hp6_4_check941 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches941,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node942 T childKnown
theorem hp6_4_node940 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected940 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected940 ((13 : Int),(1 : Int)) hp6_4_branches940 hp6_4_evidence940 hp6_4_check940 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches940,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node939 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected939 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected939 ((12 : Int),(1 : Int)) hp6_4_branches939 hp6_4_evidence939 hp6_4_check939 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches939,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node940 T childKnown
theorem hp6_4_node938 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected938 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected938 ((13 : Int),(1 : Int)) hp6_4_branches938 hp6_4_evidence938 hp6_4_check938 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches938,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node937 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected937 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected937 ((12 : Int),(1 : Int)) hp6_4_branches937 hp6_4_evidence937 hp6_4_check937 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches937,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node938 T childKnown
theorem hp6_4_node936 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected936 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected936 ((12 : Int),(1 : Int)) hp6_4_branches936 hp6_4_evidence936 hp6_4_check936 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches936,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node935 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected935 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected935 ((13 : Int),(0 : Int)) hp6_4_branches935 hp6_4_evidence935 hp6_4_check935 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches935,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node936 T childKnown
  · exact hp6_4_node937 T childKnown
  · exact hp6_4_node939 T childKnown
theorem hp6_4_node934 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected934 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected934 ((10 : Int),(1 : Int)) hp6_4_branches934 hp6_4_evidence934 hp6_4_check934 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches934,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node935 T childKnown
theorem hp6_4_node933 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected933 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected933 ((9 : Int),(1 : Int)) hp6_4_branches933 hp6_4_evidence933 hp6_4_check933 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches933,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node932 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected932 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected932 ((6 : Int),(2 : Int)) hp6_4_branches932 hp6_4_evidence932 hp6_4_check932 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches932,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node933 T childKnown
theorem hp6_4_node931 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected931 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected931 ((9 : Int),(1 : Int)) hp6_4_branches931 hp6_4_evidence931 hp6_4_check931 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches931,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node930 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected930 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected930 ((5 : Int),(2 : Int)) hp6_4_branches930 hp6_4_evidence930 hp6_4_check930 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches930,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node931 T childKnown
  · exact hp6_4_node932 T childKnown
  · exact hp6_4_node934 T childKnown
theorem hp6_4_node929 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected929 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected929 ((1 : Int),(2 : Int)) hp6_4_branches929 hp6_4_evidence929 hp6_4_check929 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches929,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node930 T childKnown
theorem hp6_4_node928 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected928 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected928 ((1 : Int),(2 : Int)) hp6_4_branches928 hp6_4_evidence928 hp6_4_check928 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches928,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node927 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected927 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected927 ((0 : Int),(2 : Int)) hp6_4_branches927 hp6_4_evidence927 hp6_4_check927 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches927,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node928 T childKnown
theorem hp6_4_node926 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected926 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected926 ((1 : Int),(1 : Int)) hp6_4_branches926 hp6_4_evidence926 hp6_4_check926 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches926,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node927 T childKnown
  · exact hp6_4_node929 T childKnown
  · exact hp6_4_node941 T childKnown
theorem hp6_4_node925 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected925 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected925 ((5 : Int),(0 : Int)) hp6_4_branches925 hp6_4_evidence925 hp6_4_check925 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches925,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node926 T childKnown
theorem hp6_4_node924 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected924 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected924 ((3 : Int),(1 : Int)) hp6_4_branches924 hp6_4_evidence924 hp6_4_check924 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches924,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node925 T childKnown
theorem hp6_4_node923 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected923 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected923 ((3 : Int),(1 : Int)) hp6_4_branches923 hp6_4_evidence923 hp6_4_check923 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches923,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node922 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected922 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected922 ((3 : Int),(1 : Int)) hp6_4_branches922 hp6_4_evidence922 hp6_4_check922 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node921 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected921 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected921 ((4 : Int),(0 : Int)) hp6_4_branches921 hp6_4_evidence921 hp6_4_check921 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node922 T childKnown
  · exact hp6_4_node923 T childKnown
  · exact hp6_4_node924 T childKnown
  · exact hp6_4_node943 T childKnown
  · exact hp6_4_node947 T childKnown
  · exact hp6_4_node967 T childKnown
theorem hp6_4_node920 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected920 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected920 ((15 : Int),(1 : Int)) hp6_4_branches920 hp6_4_evidence920 hp6_4_check920 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node919 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected919 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected919 ((13 : Int),(1 : Int)) hp6_4_branches919 hp6_4_evidence919 hp6_4_check919 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node918 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected918 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected918 ((13 : Int),(1 : Int)) hp6_4_branches918 hp6_4_evidence918 hp6_4_check918 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node917 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected917 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected917 ((11 : Int),(1 : Int)) hp6_4_branches917 hp6_4_evidence917 hp6_4_check917 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node916 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected916 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected916 ((14 : Int),(1 : Int)) hp6_4_branches916 hp6_4_evidence916 hp6_4_check916 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node917 T childKnown
  · exact hp6_4_node918 T childKnown
  · exact hp6_4_node919 T childKnown
  · exact hp6_4_node920 T childKnown
theorem hp6_4_node915 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected915 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected915 ((12 : Int),(1 : Int)) hp6_4_branches915 hp6_4_evidence915 hp6_4_check915 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node914 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected914 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected914 ((12 : Int),(1 : Int)) hp6_4_branches914 hp6_4_evidence914 hp6_4_check914 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node913 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected913 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected913 ((3 : Int),(2 : Int)) hp6_4_branches913 hp6_4_evidence913 hp6_4_check913 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node912 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected912 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected912 ((8 : Int),(1 : Int)) hp6_4_branches912 hp6_4_evidence912 hp6_4_check912 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node913 T childKnown
theorem hp6_4_node911 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected911 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected911 ((0 : Int),(1 : Int)) hp6_4_branches911 hp6_4_evidence911 hp6_4_check911 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node910 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected910 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected910 ((7 : Int),(2 : Int)) hp6_4_branches910 hp6_4_evidence910 hp6_4_check910 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node911 T childKnown
theorem hp6_4_node909 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected909 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected909 ((9 : Int),(2 : Int)) hp6_4_branches909 hp6_4_evidence909 hp6_4_check909 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node910 T childKnown
theorem hp6_4_node908 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected908 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected908 ((4 : Int),(2 : Int)) hp6_4_branches908 hp6_4_evidence908 hp6_4_check908 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node907 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected907 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected907 ((7 : Int),(2 : Int)) hp6_4_branches907 hp6_4_evidence907 hp6_4_check907 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node908 T childKnown
theorem hp6_4_node906 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected906 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected906 ((9 : Int),(1 : Int)) hp6_4_branches906 hp6_4_evidence906 hp6_4_check906 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node907 T childKnown
  · exact hp6_4_node909 T childKnown
  · exact hp6_4_node912 T childKnown
theorem hp6_4_node905 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected905 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected905 ((12 : Int),(1 : Int)) hp6_4_branches905 hp6_4_evidence905 hp6_4_check905 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node906 T childKnown
theorem hp6_4_node904 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected904 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected904 ((12 : Int),(1 : Int)) hp6_4_branches904 hp6_4_evidence904 hp6_4_check904 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node903 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected903 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected903 ((11 : Int),(1 : Int)) hp6_4_branches903 hp6_4_evidence903 hp6_4_check903 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node904 T childKnown
  · exact hp6_4_node905 T childKnown
  · exact hp6_4_node914 T childKnown
  · exact hp6_4_node915 T childKnown
theorem hp6_4_node902 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected902 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected902 ((13 : Int),(1 : Int)) hp6_4_branches902 hp6_4_evidence902 hp6_4_check902 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node901 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected901 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected901 ((13 : Int),(1 : Int)) hp6_4_branches901 hp6_4_evidence901 hp6_4_check901 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node900 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected900 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected900 ((13 : Int),(0 : Int)) hp6_4_branches900 hp6_4_evidence900 hp6_4_check900 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node901 T childKnown
  · exact hp6_4_node902 T childKnown
theorem hp6_4_node899 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected899 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected899 ((11 : Int),(1 : Int)) hp6_4_branches899 hp6_4_evidence899 hp6_4_check899 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node900 T childKnown
theorem hp6_4_node898 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected898 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected898 ((3 : Int),(2 : Int)) hp6_4_branches898 hp6_4_evidence898 hp6_4_check898 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node897 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected897 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected897 ((8 : Int),(1 : Int)) hp6_4_branches897 hp6_4_evidence897 hp6_4_check897 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node898 T childKnown
theorem hp6_4_node896 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected896 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected896 ((0 : Int),(1 : Int)) hp6_4_branches896 hp6_4_evidence896 hp6_4_check896 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node895 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected895 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected895 ((7 : Int),(2 : Int)) hp6_4_branches895 hp6_4_evidence895 hp6_4_check895 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node896 T childKnown
theorem hp6_4_node894 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected894 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected894 ((9 : Int),(2 : Int)) hp6_4_branches894 hp6_4_evidence894 hp6_4_check894 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node895 T childKnown
theorem hp6_4_node893 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected893 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected893 ((4 : Int),(2 : Int)) hp6_4_branches893 hp6_4_evidence893 hp6_4_check893 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node892 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected892 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected892 ((7 : Int),(2 : Int)) hp6_4_branches892 hp6_4_evidence892 hp6_4_check892 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node893 T childKnown
theorem hp6_4_node891 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected891 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected891 ((9 : Int),(1 : Int)) hp6_4_branches891 hp6_4_evidence891 hp6_4_check891 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node892 T childKnown
  · exact hp6_4_node894 T childKnown
  · exact hp6_4_node897 T childKnown
theorem hp6_4_node890 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected890 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected890 ((13 : Int),(0 : Int)) hp6_4_branches890 hp6_4_evidence890 hp6_4_check890 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node891 T childKnown
theorem hp6_4_node889 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected889 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected889 ((11 : Int),(1 : Int)) hp6_4_branches889 hp6_4_evidence889 hp6_4_check889 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node890 T childKnown
theorem hp6_4_node888 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected888 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected888 ((11 : Int),(1 : Int)) hp6_4_branches888 hp6_4_evidence888 hp6_4_check888 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node887 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected887 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected887 ((11 : Int),(1 : Int)) hp6_4_branches887 hp6_4_evidence887 hp6_4_check887 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node886 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected886 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected886 ((12 : Int),(0 : Int)) hp6_4_branches886 hp6_4_evidence886 hp6_4_check886 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node887 T childKnown
  · exact hp6_4_node888 T childKnown
  · exact hp6_4_node889 T childKnown
  · exact hp6_4_node899 T childKnown
  · exact hp6_4_node903 T childKnown
  · exact hp6_4_node916 T childKnown
theorem hp6_4_node885 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected885 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected885 ((2 : Int),(1 : Int)) hp6_4_branches885 hp6_4_evidence885 hp6_4_check885 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node884 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected884 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected884 ((0 : Int),(1 : Int)) hp6_4_branches884 hp6_4_evidence884 hp6_4_check884 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node883 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected883 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected883 ((0 : Int),(1 : Int)) hp6_4_branches883 hp6_4_evidence883 hp6_4_check883 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node882 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected882 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected882 ((0 : Int),(1 : Int)) hp6_4_branches882 hp6_4_evidence882 hp6_4_check882 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node881 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected881 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected881 ((1 : Int),(1 : Int)) hp6_4_branches881 hp6_4_evidence881 hp6_4_check881 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node882 T childKnown
  · exact hp6_4_node883 T childKnown
  · exact hp6_4_node884 T childKnown
  · exact hp6_4_node885 T childKnown
theorem hp6_4_node880 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected880 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected880 ((1 : Int),(1 : Int)) hp6_4_branches880 hp6_4_evidence880 hp6_4_check880 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node879 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected879 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected879 ((1 : Int),(1 : Int)) hp6_4_branches879 hp6_4_evidence879 hp6_4_check879 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node878 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected878 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected878 ((0 : Int),(1 : Int)) hp6_4_branches878 hp6_4_evidence878 hp6_4_check878 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node879 T childKnown
  · exact hp6_4_node880 T childKnown
theorem hp6_4_node877 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected877 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected877 ((1 : Int),(1 : Int)) hp6_4_branches877 hp6_4_evidence877 hp6_4_check877 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node876 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected876 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected876 ((1 : Int),(1 : Int)) hp6_4_branches876 hp6_4_evidence876 hp6_4_check876 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node875 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected875 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected875 ((0 : Int),(1 : Int)) hp6_4_branches875 hp6_4_evidence875 hp6_4_check875 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node876 T childKnown
  · exact hp6_4_node877 T childKnown
theorem hp6_4_node874 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected874 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected874 ((5 : Int),(0 : Int)) hp6_4_branches874 hp6_4_evidence874 hp6_4_check874 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node875 T childKnown
theorem hp6_4_node873 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected873 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected873 ((3 : Int),(1 : Int)) hp6_4_branches873 hp6_4_evidence873 hp6_4_check873 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node872 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected872 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected872 ((3 : Int),(1 : Int)) hp6_4_branches872 hp6_4_evidence872 hp6_4_check872 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node871 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected871 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected871 ((5 : Int),(1 : Int)) hp6_4_branches871 hp6_4_evidence871 hp6_4_check871 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node870 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected870 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected870 ((5 : Int),(1 : Int)) hp6_4_branches870 hp6_4_evidence870 hp6_4_check870 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node869 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected869 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected869 ((6 : Int),(1 : Int)) hp6_4_branches869 hp6_4_evidence869 hp6_4_check869 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node868 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected868 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected868 ((6 : Int),(1 : Int)) hp6_4_branches868 hp6_4_evidence868 hp6_4_check868 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node867 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected867 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected867 ((6 : Int),(0 : Int)) hp6_4_branches867 hp6_4_evidence867 hp6_4_check867 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node868 T childKnown
  · exact hp6_4_node869 T childKnown
theorem hp6_4_node866 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected866 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected866 ((14 : Int),(1 : Int)) hp6_4_branches866 hp6_4_evidence866 hp6_4_check866 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node865 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected865 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected865 ((13 : Int),(1 : Int)) hp6_4_branches865 hp6_4_evidence865 hp6_4_check865 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node866 T childKnown
theorem hp6_4_node864 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected864 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected864 ((14 : Int),(1 : Int)) hp6_4_branches864 hp6_4_evidence864 hp6_4_check864 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node863 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected863 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected863 ((13 : Int),(1 : Int)) hp6_4_branches863 hp6_4_evidence863 hp6_4_check863 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node864 T childKnown
theorem hp6_4_node862 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected862 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected862 ((13 : Int),(1 : Int)) hp6_4_branches862 hp6_4_evidence862 hp6_4_check862 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node861 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected861 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected861 ((14 : Int),(0 : Int)) hp6_4_branches861 hp6_4_evidence861 hp6_4_check861 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node862 T childKnown
  · exact hp6_4_node863 T childKnown
  · exact hp6_4_node865 T childKnown
theorem hp6_4_node860 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected860 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected860 ((11 : Int),(1 : Int)) hp6_4_branches860 hp6_4_evidence860 hp6_4_check860 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node861 T childKnown
theorem hp6_4_node859 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected859 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected859 ((6 : Int),(2 : Int)) hp6_4_branches859 hp6_4_evidence859 hp6_4_check859 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node860 T childKnown
theorem hp6_4_node858 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected858 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected858 ((6 : Int),(0 : Int)) hp6_4_branches858 hp6_4_evidence858 hp6_4_check858 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node859 T childKnown
theorem hp6_4_node857 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected857 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected857 ((5 : Int),(0 : Int)) hp6_4_branches857 hp6_4_evidence857 hp6_4_check857 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node858 T childKnown
  · exact hp6_4_node867 T childKnown
  · exact hp6_4_node870 T childKnown
  · exact hp6_4_node871 T childKnown
theorem hp6_4_node856 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected856 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected856 ((1 : Int),(2 : Int)) hp6_4_branches856 hp6_4_evidence856 hp6_4_check856 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node855 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected855 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected855 ((1 : Int),(2 : Int)) hp6_4_branches855 hp6_4_evidence855 hp6_4_check855 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node854 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected854 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected854 ((0 : Int),(2 : Int)) hp6_4_branches854 hp6_4_evidence854 hp6_4_check854 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node855 T childKnown
  · exact hp6_4_node856 T childKnown
  · exact hp6_4_node857 T childKnown
theorem hp6_4_node853 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected853 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected853 ((6 : Int),(1 : Int)) hp6_4_branches853 hp6_4_evidence853 hp6_4_check853 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node852 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected852 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected852 ((6 : Int),(1 : Int)) hp6_4_branches852 hp6_4_evidence852 hp6_4_check852 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node851 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected851 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected851 ((5 : Int),(1 : Int)) hp6_4_branches851 hp6_4_evidence851 hp6_4_check851 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node852 T childKnown
  · exact hp6_4_node853 T childKnown
theorem hp6_4_node850 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected850 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected850 ((8 : Int),(2 : Int)) hp6_4_branches850 hp6_4_evidence850 hp6_4_check850 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node849 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected849 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected849 ((7 : Int),(2 : Int)) hp6_4_branches849 hp6_4_evidence849 hp6_4_check849 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node850 T childKnown
theorem hp6_4_node848 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected848 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected848 ((15 : Int),(1 : Int)) hp6_4_branches848 hp6_4_evidence848 hp6_4_check848 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node847 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected847 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected847 ((13 : Int),(0 : Int)) hp6_4_branches847 hp6_4_evidence847 hp6_4_check847 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node848 T childKnown
theorem hp6_4_node846 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected846 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected846 ((9 : Int),(2 : Int)) hp6_4_branches846 hp6_4_evidence846 hp6_4_check846 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node847 T childKnown
theorem hp6_4_node845 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected845 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected845 ((7 : Int),(2 : Int)) hp6_4_branches845 hp6_4_evidence845 hp6_4_check845 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node846 T childKnown
theorem hp6_4_node844 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected844 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected844 ((8 : Int),(2 : Int)) hp6_4_branches844 hp6_4_evidence844 hp6_4_check844 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node843 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected843 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected843 ((8 : Int),(1 : Int)) hp6_4_branches843 hp6_4_evidence843 hp6_4_check843 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node844 T childKnown
theorem hp6_4_node842 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected842 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected842 ((7 : Int),(1 : Int)) hp6_4_branches842 hp6_4_evidence842 hp6_4_check842 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node843 T childKnown
  · exact hp6_4_node845 T childKnown
  · exact hp6_4_node849 T childKnown
theorem hp6_4_node841 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected841 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected841 ((5 : Int),(1 : Int)) hp6_4_branches841 hp6_4_evidence841 hp6_4_check841 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node842 T childKnown
theorem hp6_4_node840 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected840 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected840 ((6 : Int),(1 : Int)) hp6_4_branches840 hp6_4_evidence840 hp6_4_check840 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node839 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected839 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected839 ((6 : Int),(1 : Int)) hp6_4_branches839 hp6_4_evidence839 hp6_4_check839 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node838 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected838 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected838 ((6 : Int),(0 : Int)) hp6_4_branches838 hp6_4_evidence838 hp6_4_check838 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node839 T childKnown
  · exact hp6_4_node840 T childKnown
theorem hp6_4_node837 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected837 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected837 ((14 : Int),(1 : Int)) hp6_4_branches837 hp6_4_evidence837 hp6_4_check837 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node836 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected836 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected836 ((13 : Int),(1 : Int)) hp6_4_branches836 hp6_4_evidence836 hp6_4_check836 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node837 T childKnown
theorem hp6_4_node835 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected835 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected835 ((14 : Int),(1 : Int)) hp6_4_branches835 hp6_4_evidence835 hp6_4_check835 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node834 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected834 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected834 ((13 : Int),(1 : Int)) hp6_4_branches834 hp6_4_evidence834 hp6_4_check834 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node835 T childKnown
theorem hp6_4_node833 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected833 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected833 ((13 : Int),(1 : Int)) hp6_4_branches833 hp6_4_evidence833 hp6_4_check833 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node832 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected832 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected832 ((14 : Int),(0 : Int)) hp6_4_branches832 hp6_4_evidence832 hp6_4_check832 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node833 T childKnown
  · exact hp6_4_node834 T childKnown
  · exact hp6_4_node836 T childKnown
theorem hp6_4_node831 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected831 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected831 ((11 : Int),(1 : Int)) hp6_4_branches831 hp6_4_evidence831 hp6_4_check831 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node832 T childKnown
theorem hp6_4_node830 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected830 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected830 ((10 : Int),(1 : Int)) hp6_4_branches830 hp6_4_evidence830 hp6_4_check830 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node829 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected829 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected829 ((7 : Int),(2 : Int)) hp6_4_branches829 hp6_4_evidence829 hp6_4_check829 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node830 T childKnown
theorem hp6_4_node828 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected828 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected828 ((10 : Int),(1 : Int)) hp6_4_branches828 hp6_4_evidence828 hp6_4_check828 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node827 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected827 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected827 ((6 : Int),(2 : Int)) hp6_4_branches827 hp6_4_evidence827 hp6_4_check827 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node828 T childKnown
  · exact hp6_4_node829 T childKnown
  · exact hp6_4_node831 T childKnown
theorem hp6_4_node826 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected826 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected826 ((6 : Int),(0 : Int)) hp6_4_branches826 hp6_4_evidence826 hp6_4_check826 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node827 T childKnown
theorem hp6_4_node825 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected825 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected825 ((5 : Int),(0 : Int)) hp6_4_branches825 hp6_4_evidence825 hp6_4_check825 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node826 T childKnown
  · exact hp6_4_node838 T childKnown
  · exact hp6_4_node841 T childKnown
  · exact hp6_4_node851 T childKnown
theorem hp6_4_node824 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected824 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected824 ((2 : Int),(2 : Int)) hp6_4_branches824 hp6_4_evidence824 hp6_4_check824 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node825 T childKnown
theorem hp6_4_node823 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected823 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected823 ((6 : Int),(1 : Int)) hp6_4_branches823 hp6_4_evidence823 hp6_4_check823 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node822 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected822 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected822 ((6 : Int),(1 : Int)) hp6_4_branches822 hp6_4_evidence822 hp6_4_check822 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node821 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected821 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected821 ((5 : Int),(1 : Int)) hp6_4_branches821 hp6_4_evidence821 hp6_4_check821 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node822 T childKnown
  · exact hp6_4_node823 T childKnown
theorem hp6_4_node820 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected820 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected820 ((8 : Int),(2 : Int)) hp6_4_branches820 hp6_4_evidence820 hp6_4_check820 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node819 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected819 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected819 ((7 : Int),(2 : Int)) hp6_4_branches819 hp6_4_evidence819 hp6_4_check819 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node820 T childKnown
theorem hp6_4_node818 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected818 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected818 ((15 : Int),(1 : Int)) hp6_4_branches818 hp6_4_evidence818 hp6_4_check818 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node817 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected817 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected817 ((13 : Int),(0 : Int)) hp6_4_branches817 hp6_4_evidence817 hp6_4_check817 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node818 T childKnown
theorem hp6_4_node816 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected816 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected816 ((9 : Int),(2 : Int)) hp6_4_branches816 hp6_4_evidence816 hp6_4_check816 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node817 T childKnown
theorem hp6_4_node815 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected815 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected815 ((7 : Int),(2 : Int)) hp6_4_branches815 hp6_4_evidence815 hp6_4_check815 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node816 T childKnown
theorem hp6_4_node814 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected814 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected814 ((8 : Int),(2 : Int)) hp6_4_branches814 hp6_4_evidence814 hp6_4_check814 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node813 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected813 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected813 ((8 : Int),(1 : Int)) hp6_4_branches813 hp6_4_evidence813 hp6_4_check813 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node814 T childKnown
theorem hp6_4_node812 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected812 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected812 ((7 : Int),(1 : Int)) hp6_4_branches812 hp6_4_evidence812 hp6_4_check812 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node813 T childKnown
  · exact hp6_4_node815 T childKnown
  · exact hp6_4_node819 T childKnown
theorem hp6_4_node811 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected811 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected811 ((5 : Int),(1 : Int)) hp6_4_branches811 hp6_4_evidence811 hp6_4_check811 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node812 T childKnown
theorem hp6_4_node810 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected810 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected810 ((6 : Int),(1 : Int)) hp6_4_branches810 hp6_4_evidence810 hp6_4_check810 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node809 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected809 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected809 ((6 : Int),(1 : Int)) hp6_4_branches809 hp6_4_evidence809 hp6_4_check809 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node808 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected808 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected808 ((6 : Int),(0 : Int)) hp6_4_branches808 hp6_4_evidence808 hp6_4_check808 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node809 T childKnown
  · exact hp6_4_node810 T childKnown
theorem hp6_4_node807 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected807 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected807 ((14 : Int),(1 : Int)) hp6_4_branches807 hp6_4_evidence807 hp6_4_check807 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node806 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected806 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected806 ((13 : Int),(1 : Int)) hp6_4_branches806 hp6_4_evidence806 hp6_4_check806 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node807 T childKnown
theorem hp6_4_node805 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected805 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected805 ((14 : Int),(1 : Int)) hp6_4_branches805 hp6_4_evidence805 hp6_4_check805 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node804 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected804 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected804 ((13 : Int),(1 : Int)) hp6_4_branches804 hp6_4_evidence804 hp6_4_check804 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node805 T childKnown
theorem hp6_4_node803 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected803 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected803 ((13 : Int),(1 : Int)) hp6_4_branches803 hp6_4_evidence803 hp6_4_check803 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node802 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected802 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected802 ((14 : Int),(0 : Int)) hp6_4_branches802 hp6_4_evidence802 hp6_4_check802 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node803 T childKnown
  · exact hp6_4_node804 T childKnown
  · exact hp6_4_node806 T childKnown
theorem hp6_4_node801 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected801 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected801 ((11 : Int),(1 : Int)) hp6_4_branches801 hp6_4_evidence801 hp6_4_check801 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node802 T childKnown
theorem hp6_4_node800 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected800 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected800 ((10 : Int),(1 : Int)) hp6_4_branches800 hp6_4_evidence800 hp6_4_check800 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node799 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected799 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected799 ((7 : Int),(2 : Int)) hp6_4_branches799 hp6_4_evidence799 hp6_4_check799 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node800 T childKnown
theorem hp6_4_node798 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected798 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected798 ((10 : Int),(1 : Int)) hp6_4_branches798 hp6_4_evidence798 hp6_4_check798 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node797 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected797 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected797 ((6 : Int),(2 : Int)) hp6_4_branches797 hp6_4_evidence797 hp6_4_check797 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node798 T childKnown
  · exact hp6_4_node799 T childKnown
  · exact hp6_4_node801 T childKnown
theorem hp6_4_node796 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected796 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected796 ((6 : Int),(0 : Int)) hp6_4_branches796 hp6_4_evidence796 hp6_4_check796 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node797 T childKnown
theorem hp6_4_node795 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected795 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected795 ((5 : Int),(0 : Int)) hp6_4_branches795 hp6_4_evidence795 hp6_4_check795 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node796 T childKnown
  · exact hp6_4_node808 T childKnown
  · exact hp6_4_node811 T childKnown
  · exact hp6_4_node821 T childKnown
theorem hp6_4_node794 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected794 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected794 ((0 : Int),(2 : Int)) hp6_4_branches794 hp6_4_evidence794 hp6_4_check794 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node795 T childKnown
theorem hp6_4_node793 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected793 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected793 ((6 : Int),(1 : Int)) hp6_4_branches793 hp6_4_evidence793 hp6_4_check793 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node792 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected792 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected792 ((6 : Int),(1 : Int)) hp6_4_branches792 hp6_4_evidence792 hp6_4_check792 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node791 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected791 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected791 ((5 : Int),(1 : Int)) hp6_4_branches791 hp6_4_evidence791 hp6_4_check791 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node792 T childKnown
  · exact hp6_4_node793 T childKnown
theorem hp6_4_node790 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected790 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected790 ((8 : Int),(2 : Int)) hp6_4_branches790 hp6_4_evidence790 hp6_4_check790 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node789 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected789 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected789 ((7 : Int),(2 : Int)) hp6_4_branches789 hp6_4_evidence789 hp6_4_check789 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node790 T childKnown
theorem hp6_4_node788 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected788 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected788 ((15 : Int),(1 : Int)) hp6_4_branches788 hp6_4_evidence788 hp6_4_check788 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node787 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected787 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected787 ((13 : Int),(0 : Int)) hp6_4_branches787 hp6_4_evidence787 hp6_4_check787 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node788 T childKnown
theorem hp6_4_node786 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected786 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected786 ((9 : Int),(2 : Int)) hp6_4_branches786 hp6_4_evidence786 hp6_4_check786 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node787 T childKnown
theorem hp6_4_node785 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected785 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected785 ((7 : Int),(2 : Int)) hp6_4_branches785 hp6_4_evidence785 hp6_4_check785 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node786 T childKnown
theorem hp6_4_node784 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected784 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected784 ((8 : Int),(2 : Int)) hp6_4_branches784 hp6_4_evidence784 hp6_4_check784 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node783 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected783 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected783 ((8 : Int),(1 : Int)) hp6_4_branches783 hp6_4_evidence783 hp6_4_check783 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node784 T childKnown
theorem hp6_4_node782 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected782 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected782 ((7 : Int),(1 : Int)) hp6_4_branches782 hp6_4_evidence782 hp6_4_check782 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node783 T childKnown
  · exact hp6_4_node785 T childKnown
  · exact hp6_4_node789 T childKnown
theorem hp6_4_node781 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected781 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected781 ((5 : Int),(1 : Int)) hp6_4_branches781 hp6_4_evidence781 hp6_4_check781 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node782 T childKnown
theorem hp6_4_node780 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected780 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected780 ((6 : Int),(1 : Int)) hp6_4_branches780 hp6_4_evidence780 hp6_4_check780 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node779 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected779 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected779 ((6 : Int),(1 : Int)) hp6_4_branches779 hp6_4_evidence779 hp6_4_check779 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node778 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected778 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected778 ((6 : Int),(0 : Int)) hp6_4_branches778 hp6_4_evidence778 hp6_4_check778 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node779 T childKnown
  · exact hp6_4_node780 T childKnown
theorem hp6_4_node777 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected777 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected777 ((14 : Int),(1 : Int)) hp6_4_branches777 hp6_4_evidence777 hp6_4_check777 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node776 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected776 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected776 ((13 : Int),(1 : Int)) hp6_4_branches776 hp6_4_evidence776 hp6_4_check776 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node777 T childKnown
theorem hp6_4_node775 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected775 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected775 ((14 : Int),(1 : Int)) hp6_4_branches775 hp6_4_evidence775 hp6_4_check775 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node774 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected774 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected774 ((13 : Int),(1 : Int)) hp6_4_branches774 hp6_4_evidence774 hp6_4_check774 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node775 T childKnown
theorem hp6_4_node773 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected773 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected773 ((13 : Int),(1 : Int)) hp6_4_branches773 hp6_4_evidence773 hp6_4_check773 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node772 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected772 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected772 ((14 : Int),(0 : Int)) hp6_4_branches772 hp6_4_evidence772 hp6_4_check772 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node773 T childKnown
  · exact hp6_4_node774 T childKnown
  · exact hp6_4_node776 T childKnown
theorem hp6_4_node771 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected771 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected771 ((11 : Int),(1 : Int)) hp6_4_branches771 hp6_4_evidence771 hp6_4_check771 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node772 T childKnown
theorem hp6_4_node770 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected770 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected770 ((10 : Int),(1 : Int)) hp6_4_branches770 hp6_4_evidence770 hp6_4_check770 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node769 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected769 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected769 ((7 : Int),(2 : Int)) hp6_4_branches769 hp6_4_evidence769 hp6_4_check769 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node770 T childKnown
theorem hp6_4_node768 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected768 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected768 ((10 : Int),(1 : Int)) hp6_4_branches768 hp6_4_evidence768 hp6_4_check768 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node767 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected767 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected767 ((7 : Int),(2 : Int)) hp6_4_branches767 hp6_4_evidence767 hp6_4_check767 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node766 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected766 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected766 ((9 : Int),(2 : Int)) hp6_4_branches766 hp6_4_evidence766 hp6_4_check766 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node765 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected765 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected765 ((10 : Int),(1 : Int)) hp6_4_branches765 hp6_4_evidence765 hp6_4_check765 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node766 T childKnown
  · exact hp6_4_node767 T childKnown
theorem hp6_4_node764 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected764 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected764 ((6 : Int),(2 : Int)) hp6_4_branches764 hp6_4_evidence764 hp6_4_check764 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node765 T childKnown
  · exact hp6_4_node768 T childKnown
  · exact hp6_4_node769 T childKnown
  · exact hp6_4_node771 T childKnown
theorem hp6_4_node763 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected763 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected763 ((6 : Int),(0 : Int)) hp6_4_branches763 hp6_4_evidence763 hp6_4_check763 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node764 T childKnown
theorem hp6_4_node762 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected762 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected762 ((5 : Int),(0 : Int)) hp6_4_branches762 hp6_4_evidence762 hp6_4_check762 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node763 T childKnown
  · exact hp6_4_node778 T childKnown
  · exact hp6_4_node781 T childKnown
  · exact hp6_4_node791 T childKnown
theorem hp6_4_node761 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected761 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected761 ((3 : Int),(2 : Int)) hp6_4_branches761 hp6_4_evidence761 hp6_4_check761 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node762 T childKnown
  · exact hp6_4_node794 T childKnown
  · exact hp6_4_node824 T childKnown
  · exact hp6_4_node854 T childKnown
theorem hp6_4_node760 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected760 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected760 ((0 : Int),(1 : Int)) hp6_4_branches760 hp6_4_evidence760 hp6_4_check760 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node759 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected759 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected759 ((4 : Int),(0 : Int)) hp6_4_branches759 hp6_4_evidence759 hp6_4_check759 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node760 T childKnown
  · exact hp6_4_node761 T childKnown
  · exact hp6_4_node872 T childKnown
  · exact hp6_4_node873 T childKnown
  · exact hp6_4_node874 T childKnown
  · exact hp6_4_node878 T childKnown
  · exact hp6_4_node881 T childKnown
  · exact hp6_4_node886 T childKnown
theorem hp6_4_node758 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected758 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected758 ((6 : Int),(1 : Int)) hp6_4_branches758 hp6_4_evidence758 hp6_4_check758 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node757 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected757 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected757 ((4 : Int),(1 : Int)) hp6_4_branches757 hp6_4_evidence757 hp6_4_check757 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node756 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected756 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected756 ((4 : Int),(1 : Int)) hp6_4_branches756 hp6_4_evidence756 hp6_4_check756 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node755 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected755 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected755 ((2 : Int),(1 : Int)) hp6_4_branches755 hp6_4_evidence755 hp6_4_check755 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node754 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected754 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected754 ((5 : Int),(1 : Int)) hp6_4_branches754 hp6_4_evidence754 hp6_4_check754 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node755 T childKnown
  · exact hp6_4_node756 T childKnown
  · exact hp6_4_node757 T childKnown
  · exact hp6_4_node758 T childKnown
theorem hp6_4_node753 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected753 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected753 ((3 : Int),(1 : Int)) hp6_4_branches753 hp6_4_evidence753 hp6_4_check753 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node752 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected752 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected752 ((3 : Int),(1 : Int)) hp6_4_branches752 hp6_4_evidence752 hp6_4_check752 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node751 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected751 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected751 ((6 : Int),(2 : Int)) hp6_4_branches751 hp6_4_evidence751 hp6_4_check751 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node750 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected750 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected750 ((5 : Int),(2 : Int)) hp6_4_branches750 hp6_4_evidence750 hp6_4_check750 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node751 T childKnown
theorem hp6_4_node749 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected749 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected749 ((13 : Int),(1 : Int)) hp6_4_branches749 hp6_4_evidence749 hp6_4_check749 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node748 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected748 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected748 ((11 : Int),(0 : Int)) hp6_4_branches748 hp6_4_evidence748 hp6_4_check748 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node749 T childKnown
theorem hp6_4_node747 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected747 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected747 ((7 : Int),(2 : Int)) hp6_4_branches747 hp6_4_evidence747 hp6_4_check747 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node748 T childKnown
theorem hp6_4_node746 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected746 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected746 ((5 : Int),(2 : Int)) hp6_4_branches746 hp6_4_evidence746 hp6_4_check746 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node747 T childKnown
theorem hp6_4_node745 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected745 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected745 ((6 : Int),(2 : Int)) hp6_4_branches745 hp6_4_evidence745 hp6_4_check745 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node744 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected744 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected744 ((6 : Int),(1 : Int)) hp6_4_branches744 hp6_4_evidence744 hp6_4_check744 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node745 T childKnown
theorem hp6_4_node743 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected743 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected743 ((5 : Int),(1 : Int)) hp6_4_branches743 hp6_4_evidence743 hp6_4_check743 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node744 T childKnown
  · exact hp6_4_node746 T childKnown
  · exact hp6_4_node750 T childKnown
theorem hp6_4_node742 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected742 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected742 ((6 : Int),(2 : Int)) hp6_4_branches742 hp6_4_evidence742 hp6_4_check742 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node741 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected741 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected741 ((5 : Int),(2 : Int)) hp6_4_branches741 hp6_4_evidence741 hp6_4_check741 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node742 T childKnown
theorem hp6_4_node740 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected740 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected740 ((13 : Int),(1 : Int)) hp6_4_branches740 hp6_4_evidence740 hp6_4_check740 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node739 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected739 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected739 ((11 : Int),(0 : Int)) hp6_4_branches739 hp6_4_evidence739 hp6_4_check739 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node740 T childKnown
theorem hp6_4_node738 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected738 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected738 ((7 : Int),(2 : Int)) hp6_4_branches738 hp6_4_evidence738 hp6_4_check738 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node739 T childKnown
theorem hp6_4_node737 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected737 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected737 ((5 : Int),(2 : Int)) hp6_4_branches737 hp6_4_evidence737 hp6_4_check737 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node738 T childKnown
theorem hp6_4_node736 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected736 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected736 ((6 : Int),(2 : Int)) hp6_4_branches736 hp6_4_evidence736 hp6_4_check736 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node735 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected735 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected735 ((6 : Int),(1 : Int)) hp6_4_branches735 hp6_4_evidence735 hp6_4_check735 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node736 T childKnown
theorem hp6_4_node734 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected734 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected734 ((5 : Int),(1 : Int)) hp6_4_branches734 hp6_4_evidence734 hp6_4_check734 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node735 T childKnown
  · exact hp6_4_node737 T childKnown
  · exact hp6_4_node741 T childKnown
theorem hp6_4_node733 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected733 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected733 ((0 : Int),(2 : Int)) hp6_4_branches733 hp6_4_evidence733 hp6_4_check733 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node734 T childKnown
theorem hp6_4_node732 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected732 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected732 ((6 : Int),(2 : Int)) hp6_4_branches732 hp6_4_evidence732 hp6_4_check732 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node731 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected731 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected731 ((5 : Int),(2 : Int)) hp6_4_branches731 hp6_4_evidence731 hp6_4_check731 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node732 T childKnown
theorem hp6_4_node730 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected730 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected730 ((13 : Int),(1 : Int)) hp6_4_branches730 hp6_4_evidence730 hp6_4_check730 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node729 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected729 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected729 ((11 : Int),(0 : Int)) hp6_4_branches729 hp6_4_evidence729 hp6_4_check729 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node730 T childKnown
theorem hp6_4_node728 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected728 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected728 ((7 : Int),(2 : Int)) hp6_4_branches728 hp6_4_evidence728 hp6_4_check728 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node729 T childKnown
theorem hp6_4_node727 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected727 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected727 ((5 : Int),(2 : Int)) hp6_4_branches727 hp6_4_evidence727 hp6_4_check727 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node728 T childKnown
theorem hp6_4_node726 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected726 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected726 ((6 : Int),(2 : Int)) hp6_4_branches726 hp6_4_evidence726 hp6_4_check726 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node725 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected725 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected725 ((6 : Int),(1 : Int)) hp6_4_branches725 hp6_4_evidence725 hp6_4_check725 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node726 T childKnown
theorem hp6_4_node724 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected724 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected724 ((5 : Int),(1 : Int)) hp6_4_branches724 hp6_4_evidence724 hp6_4_check724 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node725 T childKnown
  · exact hp6_4_node727 T childKnown
  · exact hp6_4_node731 T childKnown
theorem hp6_4_node723 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected723 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected723 ((0 : Int),(2 : Int)) hp6_4_branches723 hp6_4_evidence723 hp6_4_check723 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node724 T childKnown
theorem hp6_4_node722 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected722 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected722 ((0 : Int),(1 : Int)) hp6_4_branches722 hp6_4_evidence722 hp6_4_check722 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node723 T childKnown
  · exact hp6_4_node733 T childKnown
  · exact hp6_4_node743 T childKnown
theorem hp6_4_node721 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected721 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected721 ((3 : Int),(1 : Int)) hp6_4_branches721 hp6_4_evidence721 hp6_4_check721 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node722 T childKnown
theorem hp6_4_node720 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected720 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected720 ((3 : Int),(1 : Int)) hp6_4_branches720 hp6_4_evidence720 hp6_4_check720 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node719 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected719 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected719 ((2 : Int),(1 : Int)) hp6_4_branches719 hp6_4_evidence719 hp6_4_check719 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node720 T childKnown
  · exact hp6_4_node721 T childKnown
  · exact hp6_4_node752 T childKnown
  · exact hp6_4_node753 T childKnown
theorem hp6_4_node718 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected718 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected718 ((4 : Int),(1 : Int)) hp6_4_branches718 hp6_4_evidence718 hp6_4_check718 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node717 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected717 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected717 ((4 : Int),(1 : Int)) hp6_4_branches717 hp6_4_evidence717 hp6_4_check717 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node716 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected716 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected716 ((4 : Int),(0 : Int)) hp6_4_branches716 hp6_4_evidence716 hp6_4_check716 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node717 T childKnown
  · exact hp6_4_node718 T childKnown
theorem hp6_4_node715 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected715 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected715 ((2 : Int),(1 : Int)) hp6_4_branches715 hp6_4_evidence715 hp6_4_check715 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node716 T childKnown
theorem hp6_4_node714 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected714 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected714 ((12 : Int),(1 : Int)) hp6_4_branches714 hp6_4_evidence714 hp6_4_check714 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node713 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected713 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected713 ((11 : Int),(1 : Int)) hp6_4_branches713 hp6_4_evidence713 hp6_4_check713 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node714 T childKnown
theorem hp6_4_node712 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected712 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected712 ((12 : Int),(1 : Int)) hp6_4_branches712 hp6_4_evidence712 hp6_4_check712 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node711 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected711 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected711 ((11 : Int),(1 : Int)) hp6_4_branches711 hp6_4_evidence711 hp6_4_check711 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node712 T childKnown
theorem hp6_4_node710 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected710 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected710 ((11 : Int),(1 : Int)) hp6_4_branches710 hp6_4_evidence710 hp6_4_check710 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node709 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected709 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected709 ((12 : Int),(0 : Int)) hp6_4_branches709 hp6_4_evidence709 hp6_4_check709 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node710 T childKnown
  · exact hp6_4_node711 T childKnown
  · exact hp6_4_node713 T childKnown
theorem hp6_4_node708 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected708 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected708 ((9 : Int),(1 : Int)) hp6_4_branches708 hp6_4_evidence708 hp6_4_check708 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node709 T childKnown
theorem hp6_4_node707 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected707 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected707 ((8 : Int),(1 : Int)) hp6_4_branches707 hp6_4_evidence707 hp6_4_check707 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node706 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected706 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected706 ((5 : Int),(2 : Int)) hp6_4_branches706 hp6_4_evidence706 hp6_4_check706 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node707 T childKnown
theorem hp6_4_node705 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected705 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected705 ((8 : Int),(1 : Int)) hp6_4_branches705 hp6_4_evidence705 hp6_4_check705 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node704 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected704 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected704 ((4 : Int),(2 : Int)) hp6_4_branches704 hp6_4_evidence704 hp6_4_check704 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node705 T childKnown
  · exact hp6_4_node706 T childKnown
  · exact hp6_4_node708 T childKnown
theorem hp6_4_node703 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected703 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected703 ((12 : Int),(1 : Int)) hp6_4_branches703 hp6_4_evidence703 hp6_4_check703 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node702 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected702 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected702 ((11 : Int),(1 : Int)) hp6_4_branches702 hp6_4_evidence702 hp6_4_check702 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node703 T childKnown
theorem hp6_4_node701 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected701 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected701 ((12 : Int),(1 : Int)) hp6_4_branches701 hp6_4_evidence701 hp6_4_check701 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node700 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected700 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected700 ((11 : Int),(1 : Int)) hp6_4_branches700 hp6_4_evidence700 hp6_4_check700 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node701 T childKnown
theorem hp6_4_node699 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected699 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected699 ((11 : Int),(1 : Int)) hp6_4_branches699 hp6_4_evidence699 hp6_4_check699 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node698 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected698 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected698 ((12 : Int),(0 : Int)) hp6_4_branches698 hp6_4_evidence698 hp6_4_check698 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node699 T childKnown
  · exact hp6_4_node700 T childKnown
  · exact hp6_4_node702 T childKnown
theorem hp6_4_node697 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected697 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected697 ((9 : Int),(1 : Int)) hp6_4_branches697 hp6_4_evidence697 hp6_4_check697 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node698 T childKnown
theorem hp6_4_node696 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected696 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected696 ((8 : Int),(1 : Int)) hp6_4_branches696 hp6_4_evidence696 hp6_4_check696 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node695 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected695 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected695 ((5 : Int),(2 : Int)) hp6_4_branches695 hp6_4_evidence695 hp6_4_check695 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node696 T childKnown
theorem hp6_4_node694 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected694 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected694 ((8 : Int),(1 : Int)) hp6_4_branches694 hp6_4_evidence694 hp6_4_check694 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node693 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected693 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected693 ((4 : Int),(2 : Int)) hp6_4_branches693 hp6_4_evidence693 hp6_4_check693 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node694 T childKnown
  · exact hp6_4_node695 T childKnown
  · exact hp6_4_node697 T childKnown
theorem hp6_4_node692 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected692 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected692 ((0 : Int),(2 : Int)) hp6_4_branches692 hp6_4_evidence692 hp6_4_check692 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node693 T childKnown
theorem hp6_4_node691 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected691 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected691 ((12 : Int),(1 : Int)) hp6_4_branches691 hp6_4_evidence691 hp6_4_check691 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node690 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected690 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected690 ((11 : Int),(1 : Int)) hp6_4_branches690 hp6_4_evidence690 hp6_4_check690 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node691 T childKnown
theorem hp6_4_node689 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected689 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected689 ((12 : Int),(1 : Int)) hp6_4_branches689 hp6_4_evidence689 hp6_4_check689 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node688 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected688 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected688 ((11 : Int),(1 : Int)) hp6_4_branches688 hp6_4_evidence688 hp6_4_check688 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node689 T childKnown
theorem hp6_4_node687 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected687 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected687 ((11 : Int),(1 : Int)) hp6_4_branches687 hp6_4_evidence687 hp6_4_check687 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node686 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected686 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected686 ((12 : Int),(0 : Int)) hp6_4_branches686 hp6_4_evidence686 hp6_4_check686 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node687 T childKnown
  · exact hp6_4_node688 T childKnown
  · exact hp6_4_node690 T childKnown
theorem hp6_4_node685 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected685 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected685 ((9 : Int),(1 : Int)) hp6_4_branches685 hp6_4_evidence685 hp6_4_check685 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node686 T childKnown
theorem hp6_4_node684 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected684 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected684 ((8 : Int),(1 : Int)) hp6_4_branches684 hp6_4_evidence684 hp6_4_check684 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node683 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected683 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected683 ((5 : Int),(2 : Int)) hp6_4_branches683 hp6_4_evidence683 hp6_4_check683 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node684 T childKnown
theorem hp6_4_node682 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected682 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected682 ((8 : Int),(1 : Int)) hp6_4_branches682 hp6_4_evidence682 hp6_4_check682 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node681 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected681 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected681 ((4 : Int),(2 : Int)) hp6_4_branches681 hp6_4_evidence681 hp6_4_check681 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node682 T childKnown
  · exact hp6_4_node683 T childKnown
  · exact hp6_4_node685 T childKnown
theorem hp6_4_node680 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected680 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected680 ((0 : Int),(2 : Int)) hp6_4_branches680 hp6_4_evidence680 hp6_4_check680 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node681 T childKnown
theorem hp6_4_node679 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected679 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected679 ((0 : Int),(1 : Int)) hp6_4_branches679 hp6_4_evidence679 hp6_4_check679 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node680 T childKnown
  · exact hp6_4_node692 T childKnown
  · exact hp6_4_node704 T childKnown
theorem hp6_4_node678 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected678 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected678 ((4 : Int),(0 : Int)) hp6_4_branches678 hp6_4_evidence678 hp6_4_check678 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node679 T childKnown
theorem hp6_4_node677 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected677 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected677 ((2 : Int),(1 : Int)) hp6_4_branches677 hp6_4_evidence677 hp6_4_check677 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node678 T childKnown
theorem hp6_4_node676 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected676 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected676 ((2 : Int),(1 : Int)) hp6_4_branches676 hp6_4_evidence676 hp6_4_check676 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node675 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected675 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected675 ((2 : Int),(1 : Int)) hp6_4_branches675 hp6_4_evidence675 hp6_4_check675 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node674 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected674 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected674 ((3 : Int),(0 : Int)) hp6_4_branches674 hp6_4_evidence674 hp6_4_check674 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node675 T childKnown
  · exact hp6_4_node676 T childKnown
  · exact hp6_4_node677 T childKnown
  · exact hp6_4_node715 T childKnown
  · exact hp6_4_node719 T childKnown
  · exact hp6_4_node754 T childKnown
theorem hp6_4_node673 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected673 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected673 ((14 : Int),(1 : Int)) hp6_4_branches673 hp6_4_evidence673 hp6_4_check673 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node672 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected672 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected672 ((12 : Int),(1 : Int)) hp6_4_branches672 hp6_4_evidence672 hp6_4_check672 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node671 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected671 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected671 ((12 : Int),(1 : Int)) hp6_4_branches671 hp6_4_evidence671 hp6_4_check671 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node670 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected670 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected670 ((10 : Int),(1 : Int)) hp6_4_branches670 hp6_4_evidence670 hp6_4_check670 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node669 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected669 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected669 ((13 : Int),(1 : Int)) hp6_4_branches669 hp6_4_evidence669 hp6_4_check669 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node670 T childKnown
  · exact hp6_4_node671 T childKnown
  · exact hp6_4_node672 T childKnown
  · exact hp6_4_node673 T childKnown
theorem hp6_4_node668 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected668 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected668 ((11 : Int),(1 : Int)) hp6_4_branches668 hp6_4_evidence668 hp6_4_check668 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node667 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected667 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected667 ((11 : Int),(1 : Int)) hp6_4_branches667 hp6_4_evidence667 hp6_4_check667 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node666 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected666 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected666 ((2 : Int),(2 : Int)) hp6_4_branches666 hp6_4_evidence666 hp6_4_check666 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node665 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected665 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected665 ((7 : Int),(1 : Int)) hp6_4_branches665 hp6_4_evidence665 hp6_4_check665 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node666 T childKnown
theorem hp6_4_node664 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected664 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected664 ((0 : Int),(1 : Int)) hp6_4_branches664 hp6_4_evidence664 hp6_4_check664 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node663 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected663 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected663 ((6 : Int),(2 : Int)) hp6_4_branches663 hp6_4_evidence663 hp6_4_check663 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node664 T childKnown
theorem hp6_4_node662 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected662 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected662 ((8 : Int),(2 : Int)) hp6_4_branches662 hp6_4_evidence662 hp6_4_check662 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node663 T childKnown
theorem hp6_4_node661 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected661 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected661 ((3 : Int),(2 : Int)) hp6_4_branches661 hp6_4_evidence661 hp6_4_check661 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node660 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected660 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected660 ((6 : Int),(2 : Int)) hp6_4_branches660 hp6_4_evidence660 hp6_4_check660 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node661 T childKnown
theorem hp6_4_node659 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected659 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected659 ((8 : Int),(1 : Int)) hp6_4_branches659 hp6_4_evidence659 hp6_4_check659 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node660 T childKnown
  · exact hp6_4_node662 T childKnown
  · exact hp6_4_node665 T childKnown
theorem hp6_4_node658 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected658 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected658 ((11 : Int),(1 : Int)) hp6_4_branches658 hp6_4_evidence658 hp6_4_check658 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node659 T childKnown
theorem hp6_4_node657 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected657 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected657 ((11 : Int),(1 : Int)) hp6_4_branches657 hp6_4_evidence657 hp6_4_check657 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node656 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected656 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected656 ((10 : Int),(1 : Int)) hp6_4_branches656 hp6_4_evidence656 hp6_4_check656 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node657 T childKnown
  · exact hp6_4_node658 T childKnown
  · exact hp6_4_node667 T childKnown
  · exact hp6_4_node668 T childKnown
theorem hp6_4_node655 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected655 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected655 ((12 : Int),(1 : Int)) hp6_4_branches655 hp6_4_evidence655 hp6_4_check655 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node654 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected654 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected654 ((12 : Int),(1 : Int)) hp6_4_branches654 hp6_4_evidence654 hp6_4_check654 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node653 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected653 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected653 ((12 : Int),(0 : Int)) hp6_4_branches653 hp6_4_evidence653 hp6_4_check653 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node654 T childKnown
  · exact hp6_4_node655 T childKnown
theorem hp6_4_node652 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected652 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected652 ((10 : Int),(1 : Int)) hp6_4_branches652 hp6_4_evidence652 hp6_4_check652 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node653 T childKnown
theorem hp6_4_node651 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected651 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected651 ((2 : Int),(2 : Int)) hp6_4_branches651 hp6_4_evidence651 hp6_4_check651 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node650 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected650 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected650 ((7 : Int),(1 : Int)) hp6_4_branches650 hp6_4_evidence650 hp6_4_check650 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node651 T childKnown
theorem hp6_4_node649 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected649 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected649 ((0 : Int),(1 : Int)) hp6_4_branches649 hp6_4_evidence649 hp6_4_check649 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node648 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected648 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected648 ((6 : Int),(2 : Int)) hp6_4_branches648 hp6_4_evidence648 hp6_4_check648 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node649 T childKnown
theorem hp6_4_node647 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected647 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected647 ((8 : Int),(2 : Int)) hp6_4_branches647 hp6_4_evidence647 hp6_4_check647 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node648 T childKnown
theorem hp6_4_node646 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected646 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected646 ((3 : Int),(2 : Int)) hp6_4_branches646 hp6_4_evidence646 hp6_4_check646 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node645 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected645 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected645 ((6 : Int),(2 : Int)) hp6_4_branches645 hp6_4_evidence645 hp6_4_check645 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node646 T childKnown
theorem hp6_4_node644 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected644 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected644 ((8 : Int),(1 : Int)) hp6_4_branches644 hp6_4_evidence644 hp6_4_check644 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node645 T childKnown
  · exact hp6_4_node647 T childKnown
  · exact hp6_4_node650 T childKnown
theorem hp6_4_node643 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected643 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected643 ((12 : Int),(0 : Int)) hp6_4_branches643 hp6_4_evidence643 hp6_4_check643 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node644 T childKnown
theorem hp6_4_node642 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected642 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected642 ((10 : Int),(1 : Int)) hp6_4_branches642 hp6_4_evidence642 hp6_4_check642 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node643 T childKnown
theorem hp6_4_node641 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected641 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected641 ((10 : Int),(1 : Int)) hp6_4_branches641 hp6_4_evidence641 hp6_4_check641 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node640 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected640 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected640 ((10 : Int),(1 : Int)) hp6_4_branches640 hp6_4_evidence640 hp6_4_check640 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node639 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected639 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected639 ((11 : Int),(0 : Int)) hp6_4_branches639 hp6_4_evidence639 hp6_4_check639 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node640 T childKnown
  · exact hp6_4_node641 T childKnown
  · exact hp6_4_node642 T childKnown
  · exact hp6_4_node652 T childKnown
  · exact hp6_4_node656 T childKnown
  · exact hp6_4_node669 T childKnown
theorem hp6_4_node638 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected638 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected638 ((1 : Int),(1 : Int)) hp6_4_branches638 hp6_4_evidence638 hp6_4_check638 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node637 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected637 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected637 ((1 : Int),(1 : Int)) hp6_4_branches637 hp6_4_evidence637 hp6_4_check637 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node636 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected636 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected636 ((2 : Int),(1 : Int)) hp6_4_branches636 hp6_4_evidence636 hp6_4_check636 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node635 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected635 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected635 ((1 : Int),(1 : Int)) hp6_4_branches635 hp6_4_evidence635 hp6_4_check635 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node636 T childKnown
theorem hp6_4_node634 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected634 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected634 ((1 : Int),(1 : Int)) hp6_4_branches634 hp6_4_evidence634 hp6_4_check634 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node633 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected633 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected633 ((0 : Int),(1 : Int)) hp6_4_branches633 hp6_4_evidence633 hp6_4_check633 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node634 T childKnown
  · exact hp6_4_node635 T childKnown
  · exact hp6_4_node637 T childKnown
  · exact hp6_4_node638 T childKnown
theorem hp6_4_node632 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected632 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected632 ((1 : Int),(1 : Int)) hp6_4_branches632 hp6_4_evidence632 hp6_4_check632 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node631 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected631 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected631 ((1 : Int),(1 : Int)) hp6_4_branches631 hp6_4_evidence631 hp6_4_check631 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node630 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected630 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected630 ((0 : Int),(1 : Int)) hp6_4_branches630 hp6_4_evidence630 hp6_4_check630 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node631 T childKnown
  · exact hp6_4_node632 T childKnown
theorem hp6_4_node629 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected629 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected629 ((1 : Int),(1 : Int)) hp6_4_branches629 hp6_4_evidence629 hp6_4_check629 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node628 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected628 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected628 ((1 : Int),(1 : Int)) hp6_4_branches628 hp6_4_evidence628 hp6_4_check628 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node627 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected627 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected627 ((0 : Int),(1 : Int)) hp6_4_branches627 hp6_4_evidence627 hp6_4_check627 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node628 T childKnown
  · exact hp6_4_node629 T childKnown
theorem hp6_4_node626 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected626 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected626 ((4 : Int),(0 : Int)) hp6_4_branches626 hp6_4_evidence626 hp6_4_check626 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node627 T childKnown
theorem hp6_4_node625 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected625 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected625 ((2 : Int),(1 : Int)) hp6_4_branches625 hp6_4_evidence625 hp6_4_check625 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node624 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected624 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected624 ((2 : Int),(1 : Int)) hp6_4_branches624 hp6_4_evidence624 hp6_4_check624 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node623 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected623 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected623 ((4 : Int),(1 : Int)) hp6_4_branches623 hp6_4_evidence623 hp6_4_check623 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node622 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected622 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected622 ((4 : Int),(1 : Int)) hp6_4_branches622 hp6_4_evidence622 hp6_4_check622 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node621 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected621 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected621 ((5 : Int),(1 : Int)) hp6_4_branches621 hp6_4_evidence621 hp6_4_check621 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node620 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected620 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected620 ((5 : Int),(1 : Int)) hp6_4_branches620 hp6_4_evidence620 hp6_4_check620 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node619 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected619 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected619 ((5 : Int),(0 : Int)) hp6_4_branches619 hp6_4_evidence619 hp6_4_check619 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node620 T childKnown
  · exact hp6_4_node621 T childKnown
theorem hp6_4_node618 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected618 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected618 ((13 : Int),(1 : Int)) hp6_4_branches618 hp6_4_evidence618 hp6_4_check618 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node617 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected617 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected617 ((12 : Int),(1 : Int)) hp6_4_branches617 hp6_4_evidence617 hp6_4_check617 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node618 T childKnown
theorem hp6_4_node616 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected616 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected616 ((13 : Int),(1 : Int)) hp6_4_branches616 hp6_4_evidence616 hp6_4_check616 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node615 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected615 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected615 ((12 : Int),(1 : Int)) hp6_4_branches615 hp6_4_evidence615 hp6_4_check615 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node616 T childKnown
theorem hp6_4_node614 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected614 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected614 ((12 : Int),(1 : Int)) hp6_4_branches614 hp6_4_evidence614 hp6_4_check614 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node613 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected613 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected613 ((13 : Int),(0 : Int)) hp6_4_branches613 hp6_4_evidence613 hp6_4_check613 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node614 T childKnown
  · exact hp6_4_node615 T childKnown
  · exact hp6_4_node617 T childKnown
theorem hp6_4_node612 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected612 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected612 ((10 : Int),(1 : Int)) hp6_4_branches612 hp6_4_evidence612 hp6_4_check612 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node613 T childKnown
theorem hp6_4_node611 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected611 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected611 ((5 : Int),(2 : Int)) hp6_4_branches611 hp6_4_evidence611 hp6_4_check611 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node612 T childKnown
theorem hp6_4_node610 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected610 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected610 ((5 : Int),(0 : Int)) hp6_4_branches610 hp6_4_evidence610 hp6_4_check610 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node611 T childKnown
theorem hp6_4_node609 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected609 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected609 ((4 : Int),(0 : Int)) hp6_4_branches609 hp6_4_evidence609 hp6_4_check609 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node610 T childKnown
  · exact hp6_4_node619 T childKnown
  · exact hp6_4_node622 T childKnown
  · exact hp6_4_node623 T childKnown
theorem hp6_4_node608 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected608 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected608 ((1 : Int),(2 : Int)) hp6_4_branches608 hp6_4_evidence608 hp6_4_check608 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node607 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected607 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected607 ((1 : Int),(2 : Int)) hp6_4_branches607 hp6_4_evidence607 hp6_4_check607 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node606 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected606 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected606 ((0 : Int),(2 : Int)) hp6_4_branches606 hp6_4_evidence606 hp6_4_check606 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node607 T childKnown
  · exact hp6_4_node608 T childKnown
  · exact hp6_4_node609 T childKnown
theorem hp6_4_node605 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected605 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected605 ((5 : Int),(1 : Int)) hp6_4_branches605 hp6_4_evidence605 hp6_4_check605 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node604 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected604 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected604 ((5 : Int),(1 : Int)) hp6_4_branches604 hp6_4_evidence604 hp6_4_check604 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node603 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected603 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected603 ((4 : Int),(1 : Int)) hp6_4_branches603 hp6_4_evidence603 hp6_4_check603 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node604 T childKnown
  · exact hp6_4_node605 T childKnown
theorem hp6_4_node602 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected602 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected602 ((7 : Int),(2 : Int)) hp6_4_branches602 hp6_4_evidence602 hp6_4_check602 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node601 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected601 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected601 ((6 : Int),(2 : Int)) hp6_4_branches601 hp6_4_evidence601 hp6_4_check601 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node602 T childKnown
theorem hp6_4_node600 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected600 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected600 ((14 : Int),(1 : Int)) hp6_4_branches600 hp6_4_evidence600 hp6_4_check600 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node599 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected599 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected599 ((12 : Int),(0 : Int)) hp6_4_branches599 hp6_4_evidence599 hp6_4_check599 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node600 T childKnown
theorem hp6_4_node598 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected598 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected598 ((8 : Int),(2 : Int)) hp6_4_branches598 hp6_4_evidence598 hp6_4_check598 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node599 T childKnown
theorem hp6_4_node597 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected597 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected597 ((6 : Int),(2 : Int)) hp6_4_branches597 hp6_4_evidence597 hp6_4_check597 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node598 T childKnown
theorem hp6_4_node596 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected596 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected596 ((7 : Int),(2 : Int)) hp6_4_branches596 hp6_4_evidence596 hp6_4_check596 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node595 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected595 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected595 ((7 : Int),(1 : Int)) hp6_4_branches595 hp6_4_evidence595 hp6_4_check595 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node596 T childKnown
theorem hp6_4_node594 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected594 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected594 ((6 : Int),(1 : Int)) hp6_4_branches594 hp6_4_evidence594 hp6_4_check594 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node595 T childKnown
  · exact hp6_4_node597 T childKnown
  · exact hp6_4_node601 T childKnown
theorem hp6_4_node593 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected593 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected593 ((4 : Int),(1 : Int)) hp6_4_branches593 hp6_4_evidence593 hp6_4_check593 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node594 T childKnown
theorem hp6_4_node592 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected592 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected592 ((5 : Int),(1 : Int)) hp6_4_branches592 hp6_4_evidence592 hp6_4_check592 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node591 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected591 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected591 ((5 : Int),(1 : Int)) hp6_4_branches591 hp6_4_evidence591 hp6_4_check591 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node590 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected590 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected590 ((5 : Int),(0 : Int)) hp6_4_branches590 hp6_4_evidence590 hp6_4_check590 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node591 T childKnown
  · exact hp6_4_node592 T childKnown
theorem hp6_4_node589 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected589 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected589 ((13 : Int),(1 : Int)) hp6_4_branches589 hp6_4_evidence589 hp6_4_check589 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node588 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected588 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected588 ((12 : Int),(1 : Int)) hp6_4_branches588 hp6_4_evidence588 hp6_4_check588 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node589 T childKnown
theorem hp6_4_node587 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected587 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected587 ((13 : Int),(1 : Int)) hp6_4_branches587 hp6_4_evidence587 hp6_4_check587 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node586 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected586 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected586 ((12 : Int),(1 : Int)) hp6_4_branches586 hp6_4_evidence586 hp6_4_check586 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node587 T childKnown
theorem hp6_4_node585 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected585 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected585 ((12 : Int),(1 : Int)) hp6_4_branches585 hp6_4_evidence585 hp6_4_check585 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node584 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected584 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected584 ((13 : Int),(0 : Int)) hp6_4_branches584 hp6_4_evidence584 hp6_4_check584 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node585 T childKnown
  · exact hp6_4_node586 T childKnown
  · exact hp6_4_node588 T childKnown
theorem hp6_4_node583 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected583 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected583 ((10 : Int),(1 : Int)) hp6_4_branches583 hp6_4_evidence583 hp6_4_check583 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node584 T childKnown
theorem hp6_4_node582 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected582 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected582 ((9 : Int),(1 : Int)) hp6_4_branches582 hp6_4_evidence582 hp6_4_check582 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node581 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected581 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected581 ((6 : Int),(2 : Int)) hp6_4_branches581 hp6_4_evidence581 hp6_4_check581 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node582 T childKnown
theorem hp6_4_node580 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected580 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected580 ((9 : Int),(1 : Int)) hp6_4_branches580 hp6_4_evidence580 hp6_4_check580 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node579 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected579 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected579 ((5 : Int),(2 : Int)) hp6_4_branches579 hp6_4_evidence579 hp6_4_check579 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node580 T childKnown
  · exact hp6_4_node581 T childKnown
  · exact hp6_4_node583 T childKnown
theorem hp6_4_node578 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected578 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected578 ((5 : Int),(0 : Int)) hp6_4_branches578 hp6_4_evidence578 hp6_4_check578 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node579 T childKnown
theorem hp6_4_node577 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected577 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected577 ((4 : Int),(0 : Int)) hp6_4_branches577 hp6_4_evidence577 hp6_4_check577 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node578 T childKnown
  · exact hp6_4_node590 T childKnown
  · exact hp6_4_node593 T childKnown
  · exact hp6_4_node603 T childKnown
theorem hp6_4_node576 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected576 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected576 ((1 : Int),(2 : Int)) hp6_4_branches576 hp6_4_evidence576 hp6_4_check576 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node577 T childKnown
theorem hp6_4_node575 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected575 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected575 ((5 : Int),(1 : Int)) hp6_4_branches575 hp6_4_evidence575 hp6_4_check575 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node574 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected574 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected574 ((5 : Int),(1 : Int)) hp6_4_branches574 hp6_4_evidence574 hp6_4_check574 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node573 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected573 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected573 ((4 : Int),(1 : Int)) hp6_4_branches573 hp6_4_evidence573 hp6_4_check573 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node574 T childKnown
  · exact hp6_4_node575 T childKnown
theorem hp6_4_node572 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected572 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected572 ((7 : Int),(2 : Int)) hp6_4_branches572 hp6_4_evidence572 hp6_4_check572 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node571 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected571 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected571 ((6 : Int),(2 : Int)) hp6_4_branches571 hp6_4_evidence571 hp6_4_check571 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node572 T childKnown
theorem hp6_4_node570 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected570 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected570 ((14 : Int),(1 : Int)) hp6_4_branches570 hp6_4_evidence570 hp6_4_check570 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node569 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected569 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected569 ((12 : Int),(0 : Int)) hp6_4_branches569 hp6_4_evidence569 hp6_4_check569 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node570 T childKnown
theorem hp6_4_node568 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected568 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected568 ((8 : Int),(2 : Int)) hp6_4_branches568 hp6_4_evidence568 hp6_4_check568 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node569 T childKnown
theorem hp6_4_node567 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected567 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected567 ((6 : Int),(2 : Int)) hp6_4_branches567 hp6_4_evidence567 hp6_4_check567 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node568 T childKnown
theorem hp6_4_node566 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected566 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected566 ((7 : Int),(2 : Int)) hp6_4_branches566 hp6_4_evidence566 hp6_4_check566 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node565 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected565 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected565 ((7 : Int),(1 : Int)) hp6_4_branches565 hp6_4_evidence565 hp6_4_check565 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node566 T childKnown
theorem hp6_4_node564 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected564 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected564 ((6 : Int),(1 : Int)) hp6_4_branches564 hp6_4_evidence564 hp6_4_check564 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node565 T childKnown
  · exact hp6_4_node567 T childKnown
  · exact hp6_4_node571 T childKnown
theorem hp6_4_node563 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected563 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected563 ((4 : Int),(1 : Int)) hp6_4_branches563 hp6_4_evidence563 hp6_4_check563 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node564 T childKnown
theorem hp6_4_node562 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected562 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected562 ((5 : Int),(1 : Int)) hp6_4_branches562 hp6_4_evidence562 hp6_4_check562 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node561 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected561 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected561 ((5 : Int),(1 : Int)) hp6_4_branches561 hp6_4_evidence561 hp6_4_check561 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node560 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected560 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected560 ((5 : Int),(0 : Int)) hp6_4_branches560 hp6_4_evidence560 hp6_4_check560 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node561 T childKnown
  · exact hp6_4_node562 T childKnown
theorem hp6_4_node559 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected559 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected559 ((13 : Int),(1 : Int)) hp6_4_branches559 hp6_4_evidence559 hp6_4_check559 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node558 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected558 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected558 ((12 : Int),(1 : Int)) hp6_4_branches558 hp6_4_evidence558 hp6_4_check558 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node559 T childKnown
theorem hp6_4_node557 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected557 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected557 ((13 : Int),(1 : Int)) hp6_4_branches557 hp6_4_evidence557 hp6_4_check557 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node556 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected556 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected556 ((12 : Int),(1 : Int)) hp6_4_branches556 hp6_4_evidence556 hp6_4_check556 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node557 T childKnown
theorem hp6_4_node555 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected555 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected555 ((12 : Int),(1 : Int)) hp6_4_branches555 hp6_4_evidence555 hp6_4_check555 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node554 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected554 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected554 ((13 : Int),(0 : Int)) hp6_4_branches554 hp6_4_evidence554 hp6_4_check554 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node555 T childKnown
  · exact hp6_4_node556 T childKnown
  · exact hp6_4_node558 T childKnown
theorem hp6_4_node553 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected553 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected553 ((10 : Int),(1 : Int)) hp6_4_branches553 hp6_4_evidence553 hp6_4_check553 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node554 T childKnown
theorem hp6_4_node552 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected552 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected552 ((9 : Int),(1 : Int)) hp6_4_branches552 hp6_4_evidence552 hp6_4_check552 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node551 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected551 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected551 ((6 : Int),(2 : Int)) hp6_4_branches551 hp6_4_evidence551 hp6_4_check551 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node552 T childKnown
theorem hp6_4_node550 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected550 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected550 ((9 : Int),(1 : Int)) hp6_4_branches550 hp6_4_evidence550 hp6_4_check550 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node549 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected549 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected549 ((5 : Int),(2 : Int)) hp6_4_branches549 hp6_4_evidence549 hp6_4_check549 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node550 T childKnown
  · exact hp6_4_node551 T childKnown
  · exact hp6_4_node553 T childKnown
theorem hp6_4_node548 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected548 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected548 ((5 : Int),(0 : Int)) hp6_4_branches548 hp6_4_evidence548 hp6_4_check548 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node549 T childKnown
theorem hp6_4_node547 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected547 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected547 ((4 : Int),(0 : Int)) hp6_4_branches547 hp6_4_evidence547 hp6_4_check547 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node548 T childKnown
  · exact hp6_4_node560 T childKnown
  · exact hp6_4_node563 T childKnown
  · exact hp6_4_node573 T childKnown
theorem hp6_4_node546 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected546 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected546 ((0 : Int),(2 : Int)) hp6_4_branches546 hp6_4_evidence546 hp6_4_check546 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node547 T childKnown
theorem hp6_4_node545 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected545 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected545 ((5 : Int),(1 : Int)) hp6_4_branches545 hp6_4_evidence545 hp6_4_check545 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node544 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected544 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected544 ((5 : Int),(1 : Int)) hp6_4_branches544 hp6_4_evidence544 hp6_4_check544 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node543 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected543 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected543 ((4 : Int),(1 : Int)) hp6_4_branches543 hp6_4_evidence543 hp6_4_check543 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node544 T childKnown
  · exact hp6_4_node545 T childKnown
theorem hp6_4_node542 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected542 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected542 ((7 : Int),(2 : Int)) hp6_4_branches542 hp6_4_evidence542 hp6_4_check542 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node541 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected541 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected541 ((6 : Int),(2 : Int)) hp6_4_branches541 hp6_4_evidence541 hp6_4_check541 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node542 T childKnown
theorem hp6_4_node540 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected540 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected540 ((14 : Int),(1 : Int)) hp6_4_branches540 hp6_4_evidence540 hp6_4_check540 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node539 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected539 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected539 ((12 : Int),(0 : Int)) hp6_4_branches539 hp6_4_evidence539 hp6_4_check539 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node540 T childKnown
theorem hp6_4_node538 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected538 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected538 ((8 : Int),(2 : Int)) hp6_4_branches538 hp6_4_evidence538 hp6_4_check538 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node539 T childKnown
theorem hp6_4_node537 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected537 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected537 ((6 : Int),(2 : Int)) hp6_4_branches537 hp6_4_evidence537 hp6_4_check537 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node538 T childKnown
theorem hp6_4_node536 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected536 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected536 ((7 : Int),(2 : Int)) hp6_4_branches536 hp6_4_evidence536 hp6_4_check536 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node535 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected535 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected535 ((7 : Int),(1 : Int)) hp6_4_branches535 hp6_4_evidence535 hp6_4_check535 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node536 T childKnown
theorem hp6_4_node534 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected534 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected534 ((6 : Int),(1 : Int)) hp6_4_branches534 hp6_4_evidence534 hp6_4_check534 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node535 T childKnown
  · exact hp6_4_node537 T childKnown
  · exact hp6_4_node541 T childKnown
theorem hp6_4_node533 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected533 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected533 ((4 : Int),(1 : Int)) hp6_4_branches533 hp6_4_evidence533 hp6_4_check533 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node534 T childKnown
theorem hp6_4_node532 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected532 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected532 ((5 : Int),(1 : Int)) hp6_4_branches532 hp6_4_evidence532 hp6_4_check532 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node531 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected531 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected531 ((5 : Int),(1 : Int)) hp6_4_branches531 hp6_4_evidence531 hp6_4_check531 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node530 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected530 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected530 ((5 : Int),(0 : Int)) hp6_4_branches530 hp6_4_evidence530 hp6_4_check530 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node531 T childKnown
  · exact hp6_4_node532 T childKnown
theorem hp6_4_node529 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected529 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected529 ((13 : Int),(1 : Int)) hp6_4_branches529 hp6_4_evidence529 hp6_4_check529 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node528 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected528 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected528 ((12 : Int),(1 : Int)) hp6_4_branches528 hp6_4_evidence528 hp6_4_check528 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node529 T childKnown
theorem hp6_4_node527 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected527 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected527 ((13 : Int),(1 : Int)) hp6_4_branches527 hp6_4_evidence527 hp6_4_check527 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node526 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected526 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected526 ((12 : Int),(1 : Int)) hp6_4_branches526 hp6_4_evidence526 hp6_4_check526 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node527 T childKnown
theorem hp6_4_node525 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected525 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected525 ((12 : Int),(1 : Int)) hp6_4_branches525 hp6_4_evidence525 hp6_4_check525 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node524 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected524 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected524 ((13 : Int),(0 : Int)) hp6_4_branches524 hp6_4_evidence524 hp6_4_check524 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node525 T childKnown
  · exact hp6_4_node526 T childKnown
  · exact hp6_4_node528 T childKnown
theorem hp6_4_node523 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected523 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected523 ((10 : Int),(1 : Int)) hp6_4_branches523 hp6_4_evidence523 hp6_4_check523 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node524 T childKnown
theorem hp6_4_node522 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected522 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected522 ((9 : Int),(1 : Int)) hp6_4_branches522 hp6_4_evidence522 hp6_4_check522 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node521 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected521 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected521 ((6 : Int),(2 : Int)) hp6_4_branches521 hp6_4_evidence521 hp6_4_check521 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node522 T childKnown
theorem hp6_4_node520 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected520 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected520 ((9 : Int),(1 : Int)) hp6_4_branches520 hp6_4_evidence520 hp6_4_check520 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node519 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected519 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected519 ((6 : Int),(2 : Int)) hp6_4_branches519 hp6_4_evidence519 hp6_4_check519 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node518 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected518 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected518 ((8 : Int),(2 : Int)) hp6_4_branches518 hp6_4_evidence518 hp6_4_check518 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node517 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected517 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected517 ((9 : Int),(1 : Int)) hp6_4_branches517 hp6_4_evidence517 hp6_4_check517 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node518 T childKnown
  · exact hp6_4_node519 T childKnown
theorem hp6_4_node516 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected516 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected516 ((5 : Int),(2 : Int)) hp6_4_branches516 hp6_4_evidence516 hp6_4_check516 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node517 T childKnown
  · exact hp6_4_node520 T childKnown
  · exact hp6_4_node521 T childKnown
  · exact hp6_4_node523 T childKnown
theorem hp6_4_node515 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected515 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected515 ((5 : Int),(0 : Int)) hp6_4_branches515 hp6_4_evidence515 hp6_4_check515 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node516 T childKnown
theorem hp6_4_node514 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected514 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected514 ((4 : Int),(0 : Int)) hp6_4_branches514 hp6_4_evidence514 hp6_4_check514 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node515 T childKnown
  · exact hp6_4_node530 T childKnown
  · exact hp6_4_node533 T childKnown
  · exact hp6_4_node543 T childKnown
theorem hp6_4_node513 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected513 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected513 ((2 : Int),(2 : Int)) hp6_4_branches513 hp6_4_evidence513 hp6_4_check513 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node514 T childKnown
  · exact hp6_4_node546 T childKnown
  · exact hp6_4_node576 T childKnown
  · exact hp6_4_node606 T childKnown
theorem hp6_4_node512 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected512 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected512 ((0 : Int),(1 : Int)) hp6_4_branches512 hp6_4_evidence512 hp6_4_check512 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node511 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected511 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected511 ((3 : Int),(0 : Int)) hp6_4_branches511 hp6_4_evidence511 hp6_4_check511 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node512 T childKnown
  · exact hp6_4_node513 T childKnown
  · exact hp6_4_node624 T childKnown
  · exact hp6_4_node625 T childKnown
  · exact hp6_4_node626 T childKnown
  · exact hp6_4_node630 T childKnown
  · exact hp6_4_node633 T childKnown
  · exact hp6_4_node639 T childKnown
theorem hp6_4_node510 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected510 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected510 ((1 : Int),(1 : Int)) hp6_4_branches510 hp6_4_evidence510 hp6_4_check510 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node509 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected509 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected509 ((1 : Int),(1 : Int)) hp6_4_branches509 hp6_4_evidence509 hp6_4_check509 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node508 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected508 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected508 ((1 : Int),(0 : Int)) hp6_4_branches508 hp6_4_evidence508 hp6_4_check508 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node509 T childKnown
  · exact hp6_4_node510 T childKnown
theorem hp6_4_node507 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected507 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected507 ((5 : Int),(1 : Int)) hp6_4_branches507 hp6_4_evidence507 hp6_4_check507 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node506 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected506 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected506 ((3 : Int),(1 : Int)) hp6_4_branches506 hp6_4_evidence506 hp6_4_check506 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node505 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected505 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected505 ((3 : Int),(1 : Int)) hp6_4_branches505 hp6_4_evidence505 hp6_4_check505 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node504 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected504 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected504 ((1 : Int),(1 : Int)) hp6_4_branches504 hp6_4_evidence504 hp6_4_check504 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node503 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected503 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected503 ((4 : Int),(1 : Int)) hp6_4_branches503 hp6_4_evidence503 hp6_4_check503 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node504 T childKnown
  · exact hp6_4_node505 T childKnown
  · exact hp6_4_node506 T childKnown
  · exact hp6_4_node507 T childKnown
theorem hp6_4_node502 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected502 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected502 ((2 : Int),(1 : Int)) hp6_4_branches502 hp6_4_evidence502 hp6_4_check502 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node501 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected501 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected501 ((2 : Int),(1 : Int)) hp6_4_branches501 hp6_4_evidence501 hp6_4_check501 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node500 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected500 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected500 ((5 : Int),(2 : Int)) hp6_4_branches500 hp6_4_evidence500 hp6_4_check500 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node499 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected499 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected499 ((4 : Int),(2 : Int)) hp6_4_branches499 hp6_4_evidence499 hp6_4_check499 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node500 T childKnown
theorem hp6_4_node498 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected498 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected498 ((12 : Int),(1 : Int)) hp6_4_branches498 hp6_4_evidence498 hp6_4_check498 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node497 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected497 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected497 ((10 : Int),(0 : Int)) hp6_4_branches497 hp6_4_evidence497 hp6_4_check497 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node498 T childKnown
theorem hp6_4_node496 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected496 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected496 ((6 : Int),(2 : Int)) hp6_4_branches496 hp6_4_evidence496 hp6_4_check496 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node497 T childKnown
theorem hp6_4_node495 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected495 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected495 ((4 : Int),(2 : Int)) hp6_4_branches495 hp6_4_evidence495 hp6_4_check495 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node496 T childKnown
theorem hp6_4_node494 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected494 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected494 ((5 : Int),(2 : Int)) hp6_4_branches494 hp6_4_evidence494 hp6_4_check494 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node493 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected493 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected493 ((5 : Int),(1 : Int)) hp6_4_branches493 hp6_4_evidence493 hp6_4_check493 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node494 T childKnown
theorem hp6_4_node492 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected492 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected492 ((4 : Int),(1 : Int)) hp6_4_branches492 hp6_4_evidence492 hp6_4_check492 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node493 T childKnown
  · exact hp6_4_node495 T childKnown
  · exact hp6_4_node499 T childKnown
theorem hp6_4_node491 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected491 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected491 ((2 : Int),(1 : Int)) hp6_4_branches491 hp6_4_evidence491 hp6_4_check491 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node492 T childKnown
theorem hp6_4_node490 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected490 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected490 ((2 : Int),(1 : Int)) hp6_4_branches490 hp6_4_evidence490 hp6_4_check490 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node489 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected489 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected489 ((1 : Int),(1 : Int)) hp6_4_branches489 hp6_4_evidence489 hp6_4_check489 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node490 T childKnown
  · exact hp6_4_node491 T childKnown
  · exact hp6_4_node501 T childKnown
  · exact hp6_4_node502 T childKnown
theorem hp6_4_node488 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected488 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected488 ((3 : Int),(1 : Int)) hp6_4_branches488 hp6_4_evidence488 hp6_4_check488 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node487 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected487 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected487 ((3 : Int),(1 : Int)) hp6_4_branches487 hp6_4_evidence487 hp6_4_check487 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node486 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected486 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected486 ((3 : Int),(0 : Int)) hp6_4_branches486 hp6_4_evidence486 hp6_4_check486 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node487 T childKnown
  · exact hp6_4_node488 T childKnown
theorem hp6_4_node485 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected485 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected485 ((1 : Int),(1 : Int)) hp6_4_branches485 hp6_4_evidence485 hp6_4_check485 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node486 T childKnown
theorem hp6_4_node484 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected484 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected484 ((11 : Int),(1 : Int)) hp6_4_branches484 hp6_4_evidence484 hp6_4_check484 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node483 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected483 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected483 ((10 : Int),(1 : Int)) hp6_4_branches483 hp6_4_evidence483 hp6_4_check483 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node484 T childKnown
theorem hp6_4_node482 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected482 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected482 ((11 : Int),(1 : Int)) hp6_4_branches482 hp6_4_evidence482 hp6_4_check482 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node481 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected481 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected481 ((10 : Int),(1 : Int)) hp6_4_branches481 hp6_4_evidence481 hp6_4_check481 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node482 T childKnown
theorem hp6_4_node480 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected480 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected480 ((10 : Int),(1 : Int)) hp6_4_branches480 hp6_4_evidence480 hp6_4_check480 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node479 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected479 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected479 ((11 : Int),(0 : Int)) hp6_4_branches479 hp6_4_evidence479 hp6_4_check479 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node480 T childKnown
  · exact hp6_4_node481 T childKnown
  · exact hp6_4_node483 T childKnown
theorem hp6_4_node478 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected478 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected478 ((8 : Int),(1 : Int)) hp6_4_branches478 hp6_4_evidence478 hp6_4_check478 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node479 T childKnown
theorem hp6_4_node477 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected477 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected477 ((7 : Int),(1 : Int)) hp6_4_branches477 hp6_4_evidence477 hp6_4_check477 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node476 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected476 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected476 ((4 : Int),(2 : Int)) hp6_4_branches476 hp6_4_evidence476 hp6_4_check476 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node477 T childKnown
theorem hp6_4_node475 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected475 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected475 ((7 : Int),(1 : Int)) hp6_4_branches475 hp6_4_evidence475 hp6_4_check475 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node474 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected474 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected474 ((3 : Int),(2 : Int)) hp6_4_branches474 hp6_4_evidence474 hp6_4_check474 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node475 T childKnown
  · exact hp6_4_node476 T childKnown
  · exact hp6_4_node478 T childKnown
theorem hp6_4_node473 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected473 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected473 ((3 : Int),(0 : Int)) hp6_4_branches473 hp6_4_evidence473 hp6_4_check473 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node474 T childKnown
theorem hp6_4_node472 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected472 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected472 ((1 : Int),(1 : Int)) hp6_4_branches472 hp6_4_evidence472 hp6_4_check472 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node473 T childKnown
theorem hp6_4_node471 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected471 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected471 ((1 : Int),(1 : Int)) hp6_4_branches471 hp6_4_evidence471 hp6_4_check471 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node470 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected470 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected470 ((1 : Int),(1 : Int)) hp6_4_branches470 hp6_4_evidence470 hp6_4_check470 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node469 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected469 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected469 ((2 : Int),(0 : Int)) hp6_4_branches469 hp6_4_evidence469 hp6_4_check469 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node470 T childKnown
  · exact hp6_4_node471 T childKnown
  · exact hp6_4_node472 T childKnown
  · exact hp6_4_node485 T childKnown
  · exact hp6_4_node489 T childKnown
  · exact hp6_4_node503 T childKnown
theorem hp6_4_node468 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected468 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected468 ((13 : Int),(1 : Int)) hp6_4_branches468 hp6_4_evidence468 hp6_4_check468 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node467 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected467 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected467 ((11 : Int),(1 : Int)) hp6_4_branches467 hp6_4_evidence467 hp6_4_check467 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node466 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected466 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected466 ((11 : Int),(1 : Int)) hp6_4_branches466 hp6_4_evidence466 hp6_4_check466 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node465 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected465 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected465 ((9 : Int),(1 : Int)) hp6_4_branches465 hp6_4_evidence465 hp6_4_check465 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node464 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected464 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected464 ((12 : Int),(1 : Int)) hp6_4_branches464 hp6_4_evidence464 hp6_4_check464 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node465 T childKnown
  · exact hp6_4_node466 T childKnown
  · exact hp6_4_node467 T childKnown
  · exact hp6_4_node468 T childKnown
theorem hp6_4_node463 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected463 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected463 ((10 : Int),(1 : Int)) hp6_4_branches463 hp6_4_evidence463 hp6_4_check463 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node462 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected462 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected462 ((10 : Int),(1 : Int)) hp6_4_branches462 hp6_4_evidence462 hp6_4_check462 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node461 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected461 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected461 ((1 : Int),(2 : Int)) hp6_4_branches461 hp6_4_evidence461 hp6_4_check461 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node460 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected460 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected460 ((6 : Int),(1 : Int)) hp6_4_branches460 hp6_4_evidence460 hp6_4_check460 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node461 T childKnown
theorem hp6_4_node459 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected459 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected459 ((13 : Int),(2 : Int)) hp6_4_branches459 hp6_4_evidence459 hp6_4_check459 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node458 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected458 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected458 ((12 : Int),(2 : Int)) hp6_4_branches458 hp6_4_evidence458 hp6_4_check458 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node459 T childKnown
theorem hp6_4_node457 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected457 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected457 ((20 : Int),(1 : Int)) hp6_4_branches457 hp6_4_evidence457 hp6_4_check457 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node456 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected456 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected456 ((18 : Int),(0 : Int)) hp6_4_branches456 hp6_4_evidence456 hp6_4_check456 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node457 T childKnown
theorem hp6_4_node455 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected455 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected455 ((14 : Int),(2 : Int)) hp6_4_branches455 hp6_4_evidence455 hp6_4_check455 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node456 T childKnown
theorem hp6_4_node454 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected454 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected454 ((12 : Int),(2 : Int)) hp6_4_branches454 hp6_4_evidence454 hp6_4_check454 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node455 T childKnown
theorem hp6_4_node453 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected453 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected453 ((13 : Int),(2 : Int)) hp6_4_branches453 hp6_4_evidence453 hp6_4_check453 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node452 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected452 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected452 ((13 : Int),(1 : Int)) hp6_4_branches452 hp6_4_evidence452 hp6_4_check452 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node453 T childKnown
theorem hp6_4_node451 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected451 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected451 ((12 : Int),(1 : Int)) hp6_4_branches451 hp6_4_evidence451 hp6_4_check451 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node452 T childKnown
  · exact hp6_4_node454 T childKnown
  · exact hp6_4_node458 T childKnown
theorem hp6_4_node450 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected450 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected450 ((5 : Int),(2 : Int)) hp6_4_branches450 hp6_4_evidence450 hp6_4_check450 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node451 T childKnown
theorem hp6_4_node449 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected449 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected449 ((7 : Int),(2 : Int)) hp6_4_branches449 hp6_4_evidence449 hp6_4_check449 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node450 T childKnown
theorem hp6_4_node448 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected448 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected448 ((2 : Int),(2 : Int)) hp6_4_branches448 hp6_4_evidence448 hp6_4_check448 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node447 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected447 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected447 ((5 : Int),(2 : Int)) hp6_4_branches447 hp6_4_evidence447 hp6_4_check447 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node448 T childKnown
theorem hp6_4_node446 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected446 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected446 ((7 : Int),(1 : Int)) hp6_4_branches446 hp6_4_evidence446 hp6_4_check446 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node447 T childKnown
  · exact hp6_4_node449 T childKnown
  · exact hp6_4_node460 T childKnown
theorem hp6_4_node445 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected445 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected445 ((10 : Int),(1 : Int)) hp6_4_branches445 hp6_4_evidence445 hp6_4_check445 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node446 T childKnown
theorem hp6_4_node444 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected444 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected444 ((10 : Int),(1 : Int)) hp6_4_branches444 hp6_4_evidence444 hp6_4_check444 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node443 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected443 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected443 ((9 : Int),(1 : Int)) hp6_4_branches443 hp6_4_evidence443 hp6_4_check443 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node444 T childKnown
  · exact hp6_4_node445 T childKnown
  · exact hp6_4_node462 T childKnown
  · exact hp6_4_node463 T childKnown
theorem hp6_4_node442 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected442 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected442 ((11 : Int),(1 : Int)) hp6_4_branches442 hp6_4_evidence442 hp6_4_check442 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node441 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected441 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected441 ((11 : Int),(1 : Int)) hp6_4_branches441 hp6_4_evidence441 hp6_4_check441 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node440 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected440 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected440 ((11 : Int),(0 : Int)) hp6_4_branches440 hp6_4_evidence440 hp6_4_check440 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node441 T childKnown
  · exact hp6_4_node442 T childKnown
theorem hp6_4_node439 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected439 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected439 ((9 : Int),(1 : Int)) hp6_4_branches439 hp6_4_evidence439 hp6_4_check439 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node440 T childKnown
theorem hp6_4_node438 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected438 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected438 ((1 : Int),(2 : Int)) hp6_4_branches438 hp6_4_evidence438 hp6_4_check438 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node437 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected437 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected437 ((6 : Int),(1 : Int)) hp6_4_branches437 hp6_4_evidence437 hp6_4_check437 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node438 T childKnown
theorem hp6_4_node436 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected436 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected436 ((19 : Int),(1 : Int)) hp6_4_branches436 hp6_4_evidence436 hp6_4_check436 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node435 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected435 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected435 ((18 : Int),(1 : Int)) hp6_4_branches435 hp6_4_evidence435 hp6_4_check435 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node436 T childKnown
theorem hp6_4_node434 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected434 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected434 ((19 : Int),(1 : Int)) hp6_4_branches434 hp6_4_evidence434 hp6_4_check434 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node433 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected433 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected433 ((18 : Int),(1 : Int)) hp6_4_branches433 hp6_4_evidence433 hp6_4_check433 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node434 T childKnown
theorem hp6_4_node432 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected432 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected432 ((18 : Int),(1 : Int)) hp6_4_branches432 hp6_4_evidence432 hp6_4_check432 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node431 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected431 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected431 ((19 : Int),(0 : Int)) hp6_4_branches431 hp6_4_evidence431 hp6_4_check431 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node432 T childKnown
  · exact hp6_4_node433 T childKnown
  · exact hp6_4_node435 T childKnown
theorem hp6_4_node430 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected430 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected430 ((16 : Int),(1 : Int)) hp6_4_branches430 hp6_4_evidence430 hp6_4_check430 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node431 T childKnown
theorem hp6_4_node429 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected429 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected429 ((15 : Int),(1 : Int)) hp6_4_branches429 hp6_4_evidence429 hp6_4_check429 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node428 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected428 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected428 ((12 : Int),(2 : Int)) hp6_4_branches428 hp6_4_evidence428 hp6_4_check428 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node429 T childKnown
theorem hp6_4_node427 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected427 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected427 ((15 : Int),(1 : Int)) hp6_4_branches427 hp6_4_evidence427 hp6_4_check427 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node426 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected426 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected426 ((11 : Int),(2 : Int)) hp6_4_branches426 hp6_4_evidence426 hp6_4_check426 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node427 T childKnown
  · exact hp6_4_node428 T childKnown
  · exact hp6_4_node430 T childKnown
theorem hp6_4_node425 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected425 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected425 ((5 : Int),(2 : Int)) hp6_4_branches425 hp6_4_evidence425 hp6_4_check425 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node426 T childKnown
theorem hp6_4_node424 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected424 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected424 ((7 : Int),(2 : Int)) hp6_4_branches424 hp6_4_evidence424 hp6_4_check424 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node425 T childKnown
theorem hp6_4_node423 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected423 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected423 ((2 : Int),(2 : Int)) hp6_4_branches423 hp6_4_evidence423 hp6_4_check423 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node422 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected422 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected422 ((5 : Int),(2 : Int)) hp6_4_branches422 hp6_4_evidence422 hp6_4_check422 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node423 T childKnown
theorem hp6_4_node421 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected421 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected421 ((7 : Int),(1 : Int)) hp6_4_branches421 hp6_4_evidence421 hp6_4_check421 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node422 T childKnown
  · exact hp6_4_node424 T childKnown
  · exact hp6_4_node437 T childKnown
theorem hp6_4_node420 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected420 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected420 ((11 : Int),(0 : Int)) hp6_4_branches420 hp6_4_evidence420 hp6_4_check420 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node421 T childKnown
theorem hp6_4_node419 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected419 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected419 ((9 : Int),(1 : Int)) hp6_4_branches419 hp6_4_evidence419 hp6_4_check419 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node420 T childKnown
theorem hp6_4_node418 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected418 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected418 ((9 : Int),(1 : Int)) hp6_4_branches418 hp6_4_evidence418 hp6_4_check418 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node417 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected417 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected417 ((9 : Int),(1 : Int)) hp6_4_branches417 hp6_4_evidence417 hp6_4_check417 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node416 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected416 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected416 ((10 : Int),(0 : Int)) hp6_4_branches416 hp6_4_evidence416 hp6_4_check416 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node417 T childKnown
  · exact hp6_4_node418 T childKnown
  · exact hp6_4_node419 T childKnown
  · exact hp6_4_node439 T childKnown
  · exact hp6_4_node443 T childKnown
  · exact hp6_4_node464 T childKnown
theorem hp6_4_node415 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected415 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected415 ((1 : Int),(1 : Int)) hp6_4_branches415 hp6_4_evidence415 hp6_4_check415 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node414 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected414 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected414 ((1 : Int),(1 : Int)) hp6_4_branches414 hp6_4_evidence414 hp6_4_check414 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node413 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected413 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected413 ((2 : Int),(1 : Int)) hp6_4_branches413 hp6_4_evidence413 hp6_4_check413 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node412 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected412 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected412 ((1 : Int),(1 : Int)) hp6_4_branches412 hp6_4_evidence412 hp6_4_check412 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node413 T childKnown
theorem hp6_4_node411 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected411 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected411 ((2 : Int),(1 : Int)) hp6_4_branches411 hp6_4_evidence411 hp6_4_check411 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node410 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected410 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected410 ((1 : Int),(1 : Int)) hp6_4_branches410 hp6_4_evidence410 hp6_4_check410 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node411 T childKnown
theorem hp6_4_node409 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected409 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected409 ((1 : Int),(1 : Int)) hp6_4_branches409 hp6_4_evidence409 hp6_4_check409 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node408 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected408 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected408 ((0 : Int),(1 : Int)) hp6_4_branches408 hp6_4_evidence408 hp6_4_check408 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node409 T childKnown
  · exact hp6_4_node410 T childKnown
  · exact hp6_4_node412 T childKnown
  · exact hp6_4_node414 T childKnown
  · exact hp6_4_node415 T childKnown
theorem hp6_4_node407 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected407 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected407 ((0 : Int),(1 : Int)) hp6_4_branches407 hp6_4_evidence407 hp6_4_check407 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node406 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected406 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected406 ((0 : Int),(1 : Int)) hp6_4_branches406 hp6_4_evidence406 hp6_4_check406 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node405 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected405 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected405 ((1 : Int),(1 : Int)) hp6_4_branches405 hp6_4_evidence405 hp6_4_check405 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node406 T childKnown
  · exact hp6_4_node407 T childKnown
theorem hp6_4_node404 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected404 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected404 ((0 : Int),(1 : Int)) hp6_4_branches404 hp6_4_evidence404 hp6_4_check404 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node403 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected403 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected403 ((0 : Int),(1 : Int)) hp6_4_branches403 hp6_4_evidence403 hp6_4_check403 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node402 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected402 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected402 ((1 : Int),(1 : Int)) hp6_4_branches402 hp6_4_evidence402 hp6_4_check402 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node403 T childKnown
  · exact hp6_4_node404 T childKnown
theorem hp6_4_node401 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected401 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected401 ((3 : Int),(0 : Int)) hp6_4_branches401 hp6_4_evidence401 hp6_4_check401 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node402 T childKnown
theorem hp6_4_node400 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected400 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected400 ((1 : Int),(1 : Int)) hp6_4_branches400 hp6_4_evidence400 hp6_4_check400 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node399 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected399 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected399 ((1 : Int),(1 : Int)) hp6_4_branches399 hp6_4_evidence399 hp6_4_check399 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node398 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected398 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected398 ((3 : Int),(1 : Int)) hp6_4_branches398 hp6_4_evidence398 hp6_4_check398 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node397 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected397 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected397 ((3 : Int),(1 : Int)) hp6_4_branches397 hp6_4_evidence397 hp6_4_check397 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node396 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected396 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected396 ((4 : Int),(1 : Int)) hp6_4_branches396 hp6_4_evidence396 hp6_4_check396 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node395 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected395 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected395 ((4 : Int),(1 : Int)) hp6_4_branches395 hp6_4_evidence395 hp6_4_check395 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node394 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected394 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected394 ((4 : Int),(0 : Int)) hp6_4_branches394 hp6_4_evidence394 hp6_4_check394 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node395 T childKnown
  · exact hp6_4_node396 T childKnown
theorem hp6_4_node393 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected393 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected393 ((12 : Int),(1 : Int)) hp6_4_branches393 hp6_4_evidence393 hp6_4_check393 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node392 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected392 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected392 ((11 : Int),(1 : Int)) hp6_4_branches392 hp6_4_evidence392 hp6_4_check392 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node393 T childKnown
theorem hp6_4_node391 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected391 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected391 ((12 : Int),(1 : Int)) hp6_4_branches391 hp6_4_evidence391 hp6_4_check391 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node390 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected390 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected390 ((11 : Int),(1 : Int)) hp6_4_branches390 hp6_4_evidence390 hp6_4_check390 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node391 T childKnown
theorem hp6_4_node389 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected389 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected389 ((11 : Int),(1 : Int)) hp6_4_branches389 hp6_4_evidence389 hp6_4_check389 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node388 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected388 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected388 ((12 : Int),(0 : Int)) hp6_4_branches388 hp6_4_evidence388 hp6_4_check388 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node389 T childKnown
  · exact hp6_4_node390 T childKnown
  · exact hp6_4_node392 T childKnown
theorem hp6_4_node387 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected387 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected387 ((9 : Int),(1 : Int)) hp6_4_branches387 hp6_4_evidence387 hp6_4_check387 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node388 T childKnown
theorem hp6_4_node386 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected386 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected386 ((4 : Int),(2 : Int)) hp6_4_branches386 hp6_4_evidence386 hp6_4_check386 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node387 T childKnown
theorem hp6_4_node385 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected385 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected385 ((4 : Int),(0 : Int)) hp6_4_branches385 hp6_4_evidence385 hp6_4_check385 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node386 T childKnown
theorem hp6_4_node384 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected384 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected384 ((3 : Int),(0 : Int)) hp6_4_branches384 hp6_4_evidence384 hp6_4_check384 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node385 T childKnown
  · exact hp6_4_node394 T childKnown
  · exact hp6_4_node397 T childKnown
  · exact hp6_4_node398 T childKnown
theorem hp6_4_node383 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected383 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected383 ((3 : Int),(1 : Int)) hp6_4_branches383 hp6_4_evidence383 hp6_4_check383 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node382 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected382 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected382 ((3 : Int),(1 : Int)) hp6_4_branches382 hp6_4_evidence382 hp6_4_check382 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node381 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected381 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected381 ((4 : Int),(1 : Int)) hp6_4_branches381 hp6_4_evidence381 hp6_4_check381 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node380 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected380 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected380 ((4 : Int),(1 : Int)) hp6_4_branches380 hp6_4_evidence380 hp6_4_check380 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node379 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected379 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected379 ((4 : Int),(0 : Int)) hp6_4_branches379 hp6_4_evidence379 hp6_4_check379 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node380 T childKnown
  · exact hp6_4_node381 T childKnown
theorem hp6_4_node378 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected378 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected378 ((12 : Int),(1 : Int)) hp6_4_branches378 hp6_4_evidence378 hp6_4_check378 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node377 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected377 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected377 ((11 : Int),(1 : Int)) hp6_4_branches377 hp6_4_evidence377 hp6_4_check377 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node378 T childKnown
theorem hp6_4_node376 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected376 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected376 ((12 : Int),(1 : Int)) hp6_4_branches376 hp6_4_evidence376 hp6_4_check376 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node375 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected375 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected375 ((11 : Int),(1 : Int)) hp6_4_branches375 hp6_4_evidence375 hp6_4_check375 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node376 T childKnown
theorem hp6_4_node374 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected374 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected374 ((11 : Int),(1 : Int)) hp6_4_branches374 hp6_4_evidence374 hp6_4_check374 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node373 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected373 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected373 ((12 : Int),(0 : Int)) hp6_4_branches373 hp6_4_evidence373 hp6_4_check373 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node374 T childKnown
  · exact hp6_4_node375 T childKnown
  · exact hp6_4_node377 T childKnown
theorem hp6_4_node372 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected372 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected372 ((9 : Int),(1 : Int)) hp6_4_branches372 hp6_4_evidence372 hp6_4_check372 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node373 T childKnown
theorem hp6_4_node371 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected371 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected371 ((4 : Int),(2 : Int)) hp6_4_branches371 hp6_4_evidence371 hp6_4_check371 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node372 T childKnown
theorem hp6_4_node370 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected370 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected370 ((4 : Int),(0 : Int)) hp6_4_branches370 hp6_4_evidence370 hp6_4_check370 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node371 T childKnown
theorem hp6_4_node369 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected369 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected369 ((3 : Int),(0 : Int)) hp6_4_branches369 hp6_4_evidence369 hp6_4_check369 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node370 T childKnown
  · exact hp6_4_node379 T childKnown
  · exact hp6_4_node382 T childKnown
  · exact hp6_4_node383 T childKnown
theorem hp6_4_node368 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected368 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected368 ((3 : Int),(1 : Int)) hp6_4_branches368 hp6_4_evidence368 hp6_4_check368 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node367 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected367 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected367 ((3 : Int),(1 : Int)) hp6_4_branches367 hp6_4_evidence367 hp6_4_check367 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node366 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected366 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected366 ((4 : Int),(1 : Int)) hp6_4_branches366 hp6_4_evidence366 hp6_4_check366 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node365 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected365 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected365 ((4 : Int),(1 : Int)) hp6_4_branches365 hp6_4_evidence365 hp6_4_check365 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node364 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected364 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected364 ((4 : Int),(0 : Int)) hp6_4_branches364 hp6_4_evidence364 hp6_4_check364 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node365 T childKnown
  · exact hp6_4_node366 T childKnown
theorem hp6_4_node363 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected363 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected363 ((12 : Int),(1 : Int)) hp6_4_branches363 hp6_4_evidence363 hp6_4_check363 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node362 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected362 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected362 ((11 : Int),(1 : Int)) hp6_4_branches362 hp6_4_evidence362 hp6_4_check362 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node363 T childKnown
theorem hp6_4_node361 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected361 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected361 ((12 : Int),(1 : Int)) hp6_4_branches361 hp6_4_evidence361 hp6_4_check361 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node360 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected360 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected360 ((11 : Int),(1 : Int)) hp6_4_branches360 hp6_4_evidence360 hp6_4_check360 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node361 T childKnown
theorem hp6_4_node359 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected359 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected359 ((11 : Int),(1 : Int)) hp6_4_branches359 hp6_4_evidence359 hp6_4_check359 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node358 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected358 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected358 ((12 : Int),(0 : Int)) hp6_4_branches358 hp6_4_evidence358 hp6_4_check358 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node359 T childKnown
  · exact hp6_4_node360 T childKnown
  · exact hp6_4_node362 T childKnown
theorem hp6_4_node357 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected357 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected357 ((9 : Int),(1 : Int)) hp6_4_branches357 hp6_4_evidence357 hp6_4_check357 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node358 T childKnown
theorem hp6_4_node356 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected356 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected356 ((4 : Int),(2 : Int)) hp6_4_branches356 hp6_4_evidence356 hp6_4_check356 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node357 T childKnown
theorem hp6_4_node355 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected355 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected355 ((4 : Int),(0 : Int)) hp6_4_branches355 hp6_4_evidence355 hp6_4_check355 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node356 T childKnown
theorem hp6_4_node354 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected354 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected354 ((3 : Int),(0 : Int)) hp6_4_branches354 hp6_4_evidence354 hp6_4_check354 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node355 T childKnown
  · exact hp6_4_node364 T childKnown
  · exact hp6_4_node367 T childKnown
  · exact hp6_4_node368 T childKnown
theorem hp6_4_node353 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected353 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected353 ((0 : Int),(2 : Int)) hp6_4_branches353 hp6_4_evidence353 hp6_4_check353 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node354 T childKnown
  · exact hp6_4_node369 T childKnown
  · exact hp6_4_node384 T childKnown
theorem hp6_4_node352 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected352 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected352 ((4 : Int),(1 : Int)) hp6_4_branches352 hp6_4_evidence352 hp6_4_check352 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node351 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected351 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected351 ((4 : Int),(1 : Int)) hp6_4_branches351 hp6_4_evidence351 hp6_4_check351 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node350 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected350 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected350 ((3 : Int),(1 : Int)) hp6_4_branches350 hp6_4_evidence350 hp6_4_check350 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node351 T childKnown
  · exact hp6_4_node352 T childKnown
theorem hp6_4_node349 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected349 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected349 ((6 : Int),(2 : Int)) hp6_4_branches349 hp6_4_evidence349 hp6_4_check349 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node348 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected348 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected348 ((5 : Int),(2 : Int)) hp6_4_branches348 hp6_4_evidence348 hp6_4_check348 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node349 T childKnown
theorem hp6_4_node347 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected347 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected347 ((13 : Int),(1 : Int)) hp6_4_branches347 hp6_4_evidence347 hp6_4_check347 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node346 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected346 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected346 ((11 : Int),(0 : Int)) hp6_4_branches346 hp6_4_evidence346 hp6_4_check346 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node347 T childKnown
theorem hp6_4_node345 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected345 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected345 ((7 : Int),(2 : Int)) hp6_4_branches345 hp6_4_evidence345 hp6_4_check345 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node346 T childKnown
theorem hp6_4_node344 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected344 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected344 ((5 : Int),(2 : Int)) hp6_4_branches344 hp6_4_evidence344 hp6_4_check344 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node345 T childKnown
theorem hp6_4_node343 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected343 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected343 ((6 : Int),(2 : Int)) hp6_4_branches343 hp6_4_evidence343 hp6_4_check343 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node342 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected342 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected342 ((6 : Int),(1 : Int)) hp6_4_branches342 hp6_4_evidence342 hp6_4_check342 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node343 T childKnown
theorem hp6_4_node341 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected341 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected341 ((5 : Int),(1 : Int)) hp6_4_branches341 hp6_4_evidence341 hp6_4_check341 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node342 T childKnown
  · exact hp6_4_node344 T childKnown
  · exact hp6_4_node348 T childKnown
theorem hp6_4_node340 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected340 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected340 ((3 : Int),(1 : Int)) hp6_4_branches340 hp6_4_evidence340 hp6_4_check340 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node341 T childKnown
theorem hp6_4_node339 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected339 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected339 ((4 : Int),(1 : Int)) hp6_4_branches339 hp6_4_evidence339 hp6_4_check339 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node338 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected338 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected338 ((4 : Int),(1 : Int)) hp6_4_branches338 hp6_4_evidence338 hp6_4_check338 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node337 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected337 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected337 ((4 : Int),(0 : Int)) hp6_4_branches337 hp6_4_evidence337 hp6_4_check337 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node338 T childKnown
  · exact hp6_4_node339 T childKnown
theorem hp6_4_node336 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected336 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected336 ((12 : Int),(1 : Int)) hp6_4_branches336 hp6_4_evidence336 hp6_4_check336 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node335 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected335 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected335 ((11 : Int),(1 : Int)) hp6_4_branches335 hp6_4_evidence335 hp6_4_check335 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node336 T childKnown
theorem hp6_4_node334 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected334 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected334 ((12 : Int),(1 : Int)) hp6_4_branches334 hp6_4_evidence334 hp6_4_check334 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node333 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected333 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected333 ((11 : Int),(1 : Int)) hp6_4_branches333 hp6_4_evidence333 hp6_4_check333 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node334 T childKnown
theorem hp6_4_node332 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected332 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected332 ((11 : Int),(1 : Int)) hp6_4_branches332 hp6_4_evidence332 hp6_4_check332 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node331 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected331 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected331 ((12 : Int),(0 : Int)) hp6_4_branches331 hp6_4_evidence331 hp6_4_check331 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node332 T childKnown
  · exact hp6_4_node333 T childKnown
  · exact hp6_4_node335 T childKnown
theorem hp6_4_node330 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected330 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected330 ((9 : Int),(1 : Int)) hp6_4_branches330 hp6_4_evidence330 hp6_4_check330 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node331 T childKnown
theorem hp6_4_node329 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected329 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected329 ((8 : Int),(1 : Int)) hp6_4_branches329 hp6_4_evidence329 hp6_4_check329 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node328 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected328 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected328 ((5 : Int),(2 : Int)) hp6_4_branches328 hp6_4_evidence328 hp6_4_check328 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node329 T childKnown
theorem hp6_4_node327 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected327 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected327 ((8 : Int),(1 : Int)) hp6_4_branches327 hp6_4_evidence327 hp6_4_check327 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node326 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected326 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected326 ((4 : Int),(2 : Int)) hp6_4_branches326 hp6_4_evidence326 hp6_4_check326 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node327 T childKnown
  · exact hp6_4_node328 T childKnown
  · exact hp6_4_node330 T childKnown
theorem hp6_4_node325 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected325 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected325 ((4 : Int),(0 : Int)) hp6_4_branches325 hp6_4_evidence325 hp6_4_check325 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node326 T childKnown
theorem hp6_4_node324 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected324 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected324 ((3 : Int),(0 : Int)) hp6_4_branches324 hp6_4_evidence324 hp6_4_check324 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node325 T childKnown
  · exact hp6_4_node337 T childKnown
  · exact hp6_4_node340 T childKnown
  · exact hp6_4_node350 T childKnown
theorem hp6_4_node323 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected323 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected323 ((0 : Int),(2 : Int)) hp6_4_branches323 hp6_4_evidence323 hp6_4_check323 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node324 T childKnown
theorem hp6_4_node322 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected322 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected322 ((4 : Int),(1 : Int)) hp6_4_branches322 hp6_4_evidence322 hp6_4_check322 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node321 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected321 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected321 ((4 : Int),(1 : Int)) hp6_4_branches321 hp6_4_evidence321 hp6_4_check321 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node320 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected320 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected320 ((3 : Int),(1 : Int)) hp6_4_branches320 hp6_4_evidence320 hp6_4_check320 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node321 T childKnown
  · exact hp6_4_node322 T childKnown
theorem hp6_4_node319 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected319 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected319 ((6 : Int),(2 : Int)) hp6_4_branches319 hp6_4_evidence319 hp6_4_check319 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node318 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected318 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected318 ((5 : Int),(2 : Int)) hp6_4_branches318 hp6_4_evidence318 hp6_4_check318 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node319 T childKnown
theorem hp6_4_node317 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected317 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected317 ((13 : Int),(1 : Int)) hp6_4_branches317 hp6_4_evidence317 hp6_4_check317 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node316 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected316 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected316 ((11 : Int),(0 : Int)) hp6_4_branches316 hp6_4_evidence316 hp6_4_check316 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node317 T childKnown
theorem hp6_4_node315 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected315 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected315 ((7 : Int),(2 : Int)) hp6_4_branches315 hp6_4_evidence315 hp6_4_check315 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node316 T childKnown
theorem hp6_4_node314 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected314 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected314 ((5 : Int),(2 : Int)) hp6_4_branches314 hp6_4_evidence314 hp6_4_check314 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node315 T childKnown
theorem hp6_4_node313 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected313 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected313 ((6 : Int),(2 : Int)) hp6_4_branches313 hp6_4_evidence313 hp6_4_check313 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node312 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected312 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected312 ((6 : Int),(1 : Int)) hp6_4_branches312 hp6_4_evidence312 hp6_4_check312 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node313 T childKnown
theorem hp6_4_node311 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected311 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected311 ((5 : Int),(1 : Int)) hp6_4_branches311 hp6_4_evidence311 hp6_4_check311 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node312 T childKnown
  · exact hp6_4_node314 T childKnown
  · exact hp6_4_node318 T childKnown
theorem hp6_4_node310 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected310 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected310 ((3 : Int),(1 : Int)) hp6_4_branches310 hp6_4_evidence310 hp6_4_check310 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node311 T childKnown
theorem hp6_4_node309 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected309 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected309 ((4 : Int),(1 : Int)) hp6_4_branches309 hp6_4_evidence309 hp6_4_check309 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node308 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected308 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected308 ((4 : Int),(1 : Int)) hp6_4_branches308 hp6_4_evidence308 hp6_4_check308 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node307 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected307 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected307 ((4 : Int),(0 : Int)) hp6_4_branches307 hp6_4_evidence307 hp6_4_check307 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node308 T childKnown
  · exact hp6_4_node309 T childKnown
theorem hp6_4_node306 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected306 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected306 ((12 : Int),(1 : Int)) hp6_4_branches306 hp6_4_evidence306 hp6_4_check306 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node305 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected305 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected305 ((11 : Int),(1 : Int)) hp6_4_branches305 hp6_4_evidence305 hp6_4_check305 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node306 T childKnown
theorem hp6_4_node304 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected304 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected304 ((12 : Int),(1 : Int)) hp6_4_branches304 hp6_4_evidence304 hp6_4_check304 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node303 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected303 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected303 ((11 : Int),(1 : Int)) hp6_4_branches303 hp6_4_evidence303 hp6_4_check303 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node304 T childKnown
theorem hp6_4_node302 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected302 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected302 ((11 : Int),(1 : Int)) hp6_4_branches302 hp6_4_evidence302 hp6_4_check302 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node301 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected301 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected301 ((12 : Int),(0 : Int)) hp6_4_branches301 hp6_4_evidence301 hp6_4_check301 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node302 T childKnown
  · exact hp6_4_node303 T childKnown
  · exact hp6_4_node305 T childKnown
theorem hp6_4_node300 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected300 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected300 ((9 : Int),(1 : Int)) hp6_4_branches300 hp6_4_evidence300 hp6_4_check300 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node301 T childKnown
theorem hp6_4_node299 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected299 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected299 ((8 : Int),(1 : Int)) hp6_4_branches299 hp6_4_evidence299 hp6_4_check299 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node298 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected298 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected298 ((5 : Int),(2 : Int)) hp6_4_branches298 hp6_4_evidence298 hp6_4_check298 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node299 T childKnown
theorem hp6_4_node297 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected297 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected297 ((8 : Int),(1 : Int)) hp6_4_branches297 hp6_4_evidence297 hp6_4_check297 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node296 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected296 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected296 ((4 : Int),(2 : Int)) hp6_4_branches296 hp6_4_evidence296 hp6_4_check296 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node297 T childKnown
  · exact hp6_4_node298 T childKnown
  · exact hp6_4_node300 T childKnown
theorem hp6_4_node295 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected295 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected295 ((4 : Int),(0 : Int)) hp6_4_branches295 hp6_4_evidence295 hp6_4_check295 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node296 T childKnown
theorem hp6_4_node294 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected294 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected294 ((3 : Int),(0 : Int)) hp6_4_branches294 hp6_4_evidence294 hp6_4_check294 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node295 T childKnown
  · exact hp6_4_node307 T childKnown
  · exact hp6_4_node310 T childKnown
  · exact hp6_4_node320 T childKnown
theorem hp6_4_node293 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected293 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected293 ((0 : Int),(2 : Int)) hp6_4_branches293 hp6_4_evidence293 hp6_4_check293 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node294 T childKnown
theorem hp6_4_node292 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected292 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected292 ((4 : Int),(1 : Int)) hp6_4_branches292 hp6_4_evidence292 hp6_4_check292 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node291 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected291 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected291 ((4 : Int),(1 : Int)) hp6_4_branches291 hp6_4_evidence291 hp6_4_check291 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node290 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected290 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected290 ((3 : Int),(1 : Int)) hp6_4_branches290 hp6_4_evidence290 hp6_4_check290 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node291 T childKnown
  · exact hp6_4_node292 T childKnown
theorem hp6_4_node289 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected289 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected289 ((6 : Int),(2 : Int)) hp6_4_branches289 hp6_4_evidence289 hp6_4_check289 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node288 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected288 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected288 ((5 : Int),(2 : Int)) hp6_4_branches288 hp6_4_evidence288 hp6_4_check288 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node289 T childKnown
theorem hp6_4_node287 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected287 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected287 ((13 : Int),(1 : Int)) hp6_4_branches287 hp6_4_evidence287 hp6_4_check287 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node286 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected286 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected286 ((11 : Int),(0 : Int)) hp6_4_branches286 hp6_4_evidence286 hp6_4_check286 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node287 T childKnown
theorem hp6_4_node285 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected285 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected285 ((7 : Int),(2 : Int)) hp6_4_branches285 hp6_4_evidence285 hp6_4_check285 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node286 T childKnown
theorem hp6_4_node284 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected284 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected284 ((5 : Int),(2 : Int)) hp6_4_branches284 hp6_4_evidence284 hp6_4_check284 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node285 T childKnown
theorem hp6_4_node283 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected283 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected283 ((6 : Int),(2 : Int)) hp6_4_branches283 hp6_4_evidence283 hp6_4_check283 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node282 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected282 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected282 ((6 : Int),(1 : Int)) hp6_4_branches282 hp6_4_evidence282 hp6_4_check282 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node283 T childKnown
theorem hp6_4_node281 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected281 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected281 ((5 : Int),(1 : Int)) hp6_4_branches281 hp6_4_evidence281 hp6_4_check281 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node282 T childKnown
  · exact hp6_4_node284 T childKnown
  · exact hp6_4_node288 T childKnown
theorem hp6_4_node280 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected280 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected280 ((3 : Int),(1 : Int)) hp6_4_branches280 hp6_4_evidence280 hp6_4_check280 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node281 T childKnown
theorem hp6_4_node279 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected279 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected279 ((4 : Int),(1 : Int)) hp6_4_branches279 hp6_4_evidence279 hp6_4_check279 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node278 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected278 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected278 ((4 : Int),(1 : Int)) hp6_4_branches278 hp6_4_evidence278 hp6_4_check278 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node277 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected277 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected277 ((4 : Int),(0 : Int)) hp6_4_branches277 hp6_4_evidence277 hp6_4_check277 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node278 T childKnown
  · exact hp6_4_node279 T childKnown
theorem hp6_4_node276 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected276 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected276 ((12 : Int),(1 : Int)) hp6_4_branches276 hp6_4_evidence276 hp6_4_check276 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node275 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected275 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected275 ((11 : Int),(1 : Int)) hp6_4_branches275 hp6_4_evidence275 hp6_4_check275 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node276 T childKnown
theorem hp6_4_node274 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected274 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected274 ((12 : Int),(1 : Int)) hp6_4_branches274 hp6_4_evidence274 hp6_4_check274 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node273 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected273 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected273 ((11 : Int),(1 : Int)) hp6_4_branches273 hp6_4_evidence273 hp6_4_check273 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node274 T childKnown
theorem hp6_4_node272 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected272 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected272 ((11 : Int),(1 : Int)) hp6_4_branches272 hp6_4_evidence272 hp6_4_check272 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node271 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected271 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected271 ((12 : Int),(0 : Int)) hp6_4_branches271 hp6_4_evidence271 hp6_4_check271 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node272 T childKnown
  · exact hp6_4_node273 T childKnown
  · exact hp6_4_node275 T childKnown
theorem hp6_4_node270 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected270 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected270 ((9 : Int),(1 : Int)) hp6_4_branches270 hp6_4_evidence270 hp6_4_check270 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node271 T childKnown
theorem hp6_4_node269 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected269 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected269 ((8 : Int),(1 : Int)) hp6_4_branches269 hp6_4_evidence269 hp6_4_check269 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node268 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected268 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected268 ((5 : Int),(2 : Int)) hp6_4_branches268 hp6_4_evidence268 hp6_4_check268 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node269 T childKnown
theorem hp6_4_node267 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected267 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected267 ((8 : Int),(1 : Int)) hp6_4_branches267 hp6_4_evidence267 hp6_4_check267 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node266 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected266 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected266 ((5 : Int),(2 : Int)) hp6_4_branches266 hp6_4_evidence266 hp6_4_check266 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node265 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected265 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected265 ((7 : Int),(2 : Int)) hp6_4_branches265 hp6_4_evidence265 hp6_4_check265 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node264 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected264 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected264 ((8 : Int),(1 : Int)) hp6_4_branches264 hp6_4_evidence264 hp6_4_check264 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node265 T childKnown
  · exact hp6_4_node266 T childKnown
theorem hp6_4_node263 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected263 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected263 ((4 : Int),(2 : Int)) hp6_4_branches263 hp6_4_evidence263 hp6_4_check263 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node264 T childKnown
  · exact hp6_4_node267 T childKnown
  · exact hp6_4_node268 T childKnown
  · exact hp6_4_node270 T childKnown
theorem hp6_4_node262 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected262 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected262 ((4 : Int),(0 : Int)) hp6_4_branches262 hp6_4_evidence262 hp6_4_check262 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node263 T childKnown
theorem hp6_4_node261 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected261 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected261 ((3 : Int),(0 : Int)) hp6_4_branches261 hp6_4_evidence261 hp6_4_check261 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node262 T childKnown
  · exact hp6_4_node277 T childKnown
  · exact hp6_4_node280 T childKnown
  · exact hp6_4_node290 T childKnown
theorem hp6_4_node260 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected260 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected260 ((1 : Int),(2 : Int)) hp6_4_branches260 hp6_4_evidence260 hp6_4_check260 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node261 T childKnown
  · exact hp6_4_node293 T childKnown
  · exact hp6_4_node323 T childKnown
  · exact hp6_4_node353 T childKnown
theorem hp6_4_node259 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected259 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected259 ((0 : Int),(1 : Int)) hp6_4_branches259 hp6_4_evidence259 hp6_4_check259 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node258 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected258 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected258 ((2 : Int),(0 : Int)) hp6_4_branches258 hp6_4_evidence258 hp6_4_check258 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node259 T childKnown
  · exact hp6_4_node260 T childKnown
  · exact hp6_4_node399 T childKnown
  · exact hp6_4_node400 T childKnown
  · exact hp6_4_node401 T childKnown
  · exact hp6_4_node405 T childKnown
  · exact hp6_4_node408 T childKnown
  · exact hp6_4_node416 T childKnown
theorem hp6_4_node257 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected257 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected257 ((4 : Int),(1 : Int)) hp6_4_branches257 hp6_4_evidence257 hp6_4_check257 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node256 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected256 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected256 ((2 : Int),(1 : Int)) hp6_4_branches256 hp6_4_evidence256 hp6_4_check256 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node255 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected255 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected255 ((2 : Int),(1 : Int)) hp6_4_branches255 hp6_4_evidence255 hp6_4_check255 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node254 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected254 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected254 ((0 : Int),(1 : Int)) hp6_4_branches254 hp6_4_evidence254 hp6_4_check254 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node253 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected253 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected253 ((3 : Int),(1 : Int)) hp6_4_branches253 hp6_4_evidence253 hp6_4_check253 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node254 T childKnown
  · exact hp6_4_node255 T childKnown
  · exact hp6_4_node256 T childKnown
  · exact hp6_4_node257 T childKnown
theorem hp6_4_node252 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected252 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected252 ((1 : Int),(1 : Int)) hp6_4_branches252 hp6_4_evidence252 hp6_4_check252 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node251 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected251 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected251 ((1 : Int),(1 : Int)) hp6_4_branches251 hp6_4_evidence251 hp6_4_check251 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node250 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected250 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected250 ((4 : Int),(2 : Int)) hp6_4_branches250 hp6_4_evidence250 hp6_4_check250 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node249 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected249 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected249 ((3 : Int),(2 : Int)) hp6_4_branches249 hp6_4_evidence249 hp6_4_check249 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node250 T childKnown
theorem hp6_4_node248 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected248 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected248 ((11 : Int),(1 : Int)) hp6_4_branches248 hp6_4_evidence248 hp6_4_check248 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node247 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected247 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected247 ((9 : Int),(0 : Int)) hp6_4_branches247 hp6_4_evidence247 hp6_4_check247 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node248 T childKnown
theorem hp6_4_node246 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected246 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected246 ((5 : Int),(2 : Int)) hp6_4_branches246 hp6_4_evidence246 hp6_4_check246 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node247 T childKnown
theorem hp6_4_node245 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected245 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected245 ((3 : Int),(2 : Int)) hp6_4_branches245 hp6_4_evidence245 hp6_4_check245 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node246 T childKnown
theorem hp6_4_node244 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected244 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected244 ((4 : Int),(2 : Int)) hp6_4_branches244 hp6_4_evidence244 hp6_4_check244 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node243 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected243 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected243 ((4 : Int),(1 : Int)) hp6_4_branches243 hp6_4_evidence243 hp6_4_check243 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node244 T childKnown
theorem hp6_4_node242 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected242 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected242 ((3 : Int),(1 : Int)) hp6_4_branches242 hp6_4_evidence242 hp6_4_check242 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node243 T childKnown
  · exact hp6_4_node245 T childKnown
  · exact hp6_4_node249 T childKnown
theorem hp6_4_node241 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected241 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected241 ((1 : Int),(1 : Int)) hp6_4_branches241 hp6_4_evidence241 hp6_4_check241 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node242 T childKnown
theorem hp6_4_node240 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected240 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected240 ((1 : Int),(1 : Int)) hp6_4_branches240 hp6_4_evidence240 hp6_4_check240 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node239 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected239 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected239 ((0 : Int),(1 : Int)) hp6_4_branches239 hp6_4_evidence239 hp6_4_check239 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node240 T childKnown
  · exact hp6_4_node241 T childKnown
  · exact hp6_4_node251 T childKnown
  · exact hp6_4_node252 T childKnown
theorem hp6_4_node238 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected238 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected238 ((2 : Int),(1 : Int)) hp6_4_branches238 hp6_4_evidence238 hp6_4_check238 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node237 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected237 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected237 ((2 : Int),(1 : Int)) hp6_4_branches237 hp6_4_evidence237 hp6_4_check237 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node236 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected236 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected236 ((2 : Int),(0 : Int)) hp6_4_branches236 hp6_4_evidence236 hp6_4_check236 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node237 T childKnown
  · exact hp6_4_node238 T childKnown
theorem hp6_4_node235 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected235 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected235 ((0 : Int),(1 : Int)) hp6_4_branches235 hp6_4_evidence235 hp6_4_check235 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node236 T childKnown
theorem hp6_4_node234 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected234 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected234 ((10 : Int),(1 : Int)) hp6_4_branches234 hp6_4_evidence234 hp6_4_check234 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node233 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected233 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected233 ((9 : Int),(1 : Int)) hp6_4_branches233 hp6_4_evidence233 hp6_4_check233 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node234 T childKnown
theorem hp6_4_node232 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected232 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected232 ((10 : Int),(1 : Int)) hp6_4_branches232 hp6_4_evidence232 hp6_4_check232 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node231 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected231 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected231 ((9 : Int),(1 : Int)) hp6_4_branches231 hp6_4_evidence231 hp6_4_check231 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node232 T childKnown
theorem hp6_4_node230 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected230 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected230 ((9 : Int),(1 : Int)) hp6_4_branches230 hp6_4_evidence230 hp6_4_check230 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node229 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected229 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected229 ((10 : Int),(0 : Int)) hp6_4_branches229 hp6_4_evidence229 hp6_4_check229 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node230 T childKnown
  · exact hp6_4_node231 T childKnown
  · exact hp6_4_node233 T childKnown
theorem hp6_4_node228 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected228 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected228 ((7 : Int),(1 : Int)) hp6_4_branches228 hp6_4_evidence228 hp6_4_check228 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node229 T childKnown
theorem hp6_4_node227 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected227 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected227 ((6 : Int),(1 : Int)) hp6_4_branches227 hp6_4_evidence227 hp6_4_check227 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node226 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected226 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected226 ((3 : Int),(2 : Int)) hp6_4_branches226 hp6_4_evidence226 hp6_4_check226 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node227 T childKnown
theorem hp6_4_node225 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected225 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected225 ((6 : Int),(1 : Int)) hp6_4_branches225 hp6_4_evidence225 hp6_4_check225 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node224 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected224 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected224 ((2 : Int),(2 : Int)) hp6_4_branches224 hp6_4_evidence224 hp6_4_check224 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node225 T childKnown
  · exact hp6_4_node226 T childKnown
  · exact hp6_4_node228 T childKnown
theorem hp6_4_node223 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected223 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected223 ((2 : Int),(0 : Int)) hp6_4_branches223 hp6_4_evidence223 hp6_4_check223 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node224 T childKnown
theorem hp6_4_node222 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected222 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected222 ((0 : Int),(1 : Int)) hp6_4_branches222 hp6_4_evidence222 hp6_4_check222 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node223 T childKnown
theorem hp6_4_node221 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected221 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected221 ((0 : Int),(1 : Int)) hp6_4_branches221 hp6_4_evidence221 hp6_4_check221 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node220 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected220 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected220 ((0 : Int),(1 : Int)) hp6_4_branches220 hp6_4_evidence220 hp6_4_check220 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node219 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected219 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected219 ((1 : Int),(0 : Int)) hp6_4_branches219 hp6_4_evidence219 hp6_4_check219 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node220 T childKnown
  · exact hp6_4_node221 T childKnown
  · exact hp6_4_node222 T childKnown
  · exact hp6_4_node235 T childKnown
  · exact hp6_4_node239 T childKnown
  · exact hp6_4_node253 T childKnown
theorem hp6_4_node218 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected218 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected218 ((12 : Int),(1 : Int)) hp6_4_branches218 hp6_4_evidence218 hp6_4_check218 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node217 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected217 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected217 ((10 : Int),(1 : Int)) hp6_4_branches217 hp6_4_evidence217 hp6_4_check217 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node216 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected216 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected216 ((10 : Int),(1 : Int)) hp6_4_branches216 hp6_4_evidence216 hp6_4_check216 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node215 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected215 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected215 ((8 : Int),(1 : Int)) hp6_4_branches215 hp6_4_evidence215 hp6_4_check215 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node214 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected214 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected214 ((11 : Int),(1 : Int)) hp6_4_branches214 hp6_4_evidence214 hp6_4_check214 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node215 T childKnown
  · exact hp6_4_node216 T childKnown
  · exact hp6_4_node217 T childKnown
  · exact hp6_4_node218 T childKnown
theorem hp6_4_node213 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected213 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected213 ((9 : Int),(1 : Int)) hp6_4_branches213 hp6_4_evidence213 hp6_4_check213 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node212 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected212 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected212 ((9 : Int),(1 : Int)) hp6_4_branches212 hp6_4_evidence212 hp6_4_check212 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node211 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected211 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected211 ((0 : Int),(2 : Int)) hp6_4_branches211 hp6_4_evidence211 hp6_4_check211 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node210 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected210 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected210 ((5 : Int),(1 : Int)) hp6_4_branches210 hp6_4_evidence210 hp6_4_check210 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node211 T childKnown
theorem hp6_4_node209 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected209 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected209 ((12 : Int),(2 : Int)) hp6_4_branches209 hp6_4_evidence209 hp6_4_check209 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node208 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected208 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected208 ((11 : Int),(2 : Int)) hp6_4_branches208 hp6_4_evidence208 hp6_4_check208 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node209 T childKnown
theorem hp6_4_node207 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected207 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected207 ((19 : Int),(1 : Int)) hp6_4_branches207 hp6_4_evidence207 hp6_4_check207 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node206 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected206 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected206 ((17 : Int),(0 : Int)) hp6_4_branches206 hp6_4_evidence206 hp6_4_check206 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node207 T childKnown
theorem hp6_4_node205 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected205 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected205 ((13 : Int),(2 : Int)) hp6_4_branches205 hp6_4_evidence205 hp6_4_check205 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node206 T childKnown
theorem hp6_4_node204 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected204 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected204 ((11 : Int),(2 : Int)) hp6_4_branches204 hp6_4_evidence204 hp6_4_check204 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node205 T childKnown
theorem hp6_4_node203 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected203 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected203 ((12 : Int),(2 : Int)) hp6_4_branches203 hp6_4_evidence203 hp6_4_check203 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node202 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected202 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected202 ((12 : Int),(1 : Int)) hp6_4_branches202 hp6_4_evidence202 hp6_4_check202 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node203 T childKnown
theorem hp6_4_node201 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected201 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected201 ((11 : Int),(1 : Int)) hp6_4_branches201 hp6_4_evidence201 hp6_4_check201 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node202 T childKnown
  · exact hp6_4_node204 T childKnown
  · exact hp6_4_node208 T childKnown
theorem hp6_4_node200 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected200 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected200 ((4 : Int),(2 : Int)) hp6_4_branches200 hp6_4_evidence200 hp6_4_check200 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node201 T childKnown
theorem hp6_4_node199 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected199 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected199 ((6 : Int),(2 : Int)) hp6_4_branches199 hp6_4_evidence199 hp6_4_check199 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node200 T childKnown
theorem hp6_4_node198 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected198 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected198 ((1 : Int),(2 : Int)) hp6_4_branches198 hp6_4_evidence198 hp6_4_check198 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node197 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected197 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected197 ((4 : Int),(2 : Int)) hp6_4_branches197 hp6_4_evidence197 hp6_4_check197 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node198 T childKnown
theorem hp6_4_node196 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected196 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected196 ((6 : Int),(1 : Int)) hp6_4_branches196 hp6_4_evidence196 hp6_4_check196 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node197 T childKnown
  · exact hp6_4_node199 T childKnown
  · exact hp6_4_node210 T childKnown
theorem hp6_4_node195 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected195 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected195 ((9 : Int),(1 : Int)) hp6_4_branches195 hp6_4_evidence195 hp6_4_check195 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node196 T childKnown
theorem hp6_4_node194 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected194 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected194 ((9 : Int),(1 : Int)) hp6_4_branches194 hp6_4_evidence194 hp6_4_check194 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node193 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected193 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected193 ((8 : Int),(1 : Int)) hp6_4_branches193 hp6_4_evidence193 hp6_4_check193 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node194 T childKnown
  · exact hp6_4_node195 T childKnown
  · exact hp6_4_node212 T childKnown
  · exact hp6_4_node213 T childKnown
theorem hp6_4_node192 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected192 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected192 ((10 : Int),(1 : Int)) hp6_4_branches192 hp6_4_evidence192 hp6_4_check192 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node191 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected191 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected191 ((10 : Int),(1 : Int)) hp6_4_branches191 hp6_4_evidence191 hp6_4_check191 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node190 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected190 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected190 ((10 : Int),(0 : Int)) hp6_4_branches190 hp6_4_evidence190 hp6_4_check190 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node191 T childKnown
  · exact hp6_4_node192 T childKnown
theorem hp6_4_node189 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected189 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected189 ((8 : Int),(1 : Int)) hp6_4_branches189 hp6_4_evidence189 hp6_4_check189 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node190 T childKnown
theorem hp6_4_node188 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected188 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected188 ((0 : Int),(2 : Int)) hp6_4_branches188 hp6_4_evidence188 hp6_4_check188 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node187 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected187 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected187 ((5 : Int),(1 : Int)) hp6_4_branches187 hp6_4_evidence187 hp6_4_check187 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node188 T childKnown
theorem hp6_4_node186 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected186 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected186 ((18 : Int),(1 : Int)) hp6_4_branches186 hp6_4_evidence186 hp6_4_check186 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node185 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected185 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected185 ((17 : Int),(1 : Int)) hp6_4_branches185 hp6_4_evidence185 hp6_4_check185 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node186 T childKnown
theorem hp6_4_node184 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected184 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected184 ((18 : Int),(1 : Int)) hp6_4_branches184 hp6_4_evidence184 hp6_4_check184 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node183 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected183 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected183 ((17 : Int),(1 : Int)) hp6_4_branches183 hp6_4_evidence183 hp6_4_check183 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node184 T childKnown
theorem hp6_4_node182 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected182 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected182 ((17 : Int),(1 : Int)) hp6_4_branches182 hp6_4_evidence182 hp6_4_check182 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node181 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected181 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected181 ((18 : Int),(0 : Int)) hp6_4_branches181 hp6_4_evidence181 hp6_4_check181 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node182 T childKnown
  · exact hp6_4_node183 T childKnown
  · exact hp6_4_node185 T childKnown
theorem hp6_4_node180 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected180 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected180 ((15 : Int),(1 : Int)) hp6_4_branches180 hp6_4_evidence180 hp6_4_check180 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node181 T childKnown
theorem hp6_4_node179 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected179 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected179 ((14 : Int),(1 : Int)) hp6_4_branches179 hp6_4_evidence179 hp6_4_check179 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node178 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected178 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected178 ((11 : Int),(2 : Int)) hp6_4_branches178 hp6_4_evidence178 hp6_4_check178 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node179 T childKnown
theorem hp6_4_node177 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected177 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected177 ((14 : Int),(1 : Int)) hp6_4_branches177 hp6_4_evidence177 hp6_4_check177 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node176 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected176 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected176 ((10 : Int),(2 : Int)) hp6_4_branches176 hp6_4_evidence176 hp6_4_check176 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node177 T childKnown
  · exact hp6_4_node178 T childKnown
  · exact hp6_4_node180 T childKnown
theorem hp6_4_node175 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected175 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected175 ((4 : Int),(2 : Int)) hp6_4_branches175 hp6_4_evidence175 hp6_4_check175 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node176 T childKnown
theorem hp6_4_node174 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected174 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected174 ((6 : Int),(2 : Int)) hp6_4_branches174 hp6_4_evidence174 hp6_4_check174 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node175 T childKnown
theorem hp6_4_node173 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected173 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected173 ((1 : Int),(2 : Int)) hp6_4_branches173 hp6_4_evidence173 hp6_4_check173 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node172 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected172 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected172 ((4 : Int),(2 : Int)) hp6_4_branches172 hp6_4_evidence172 hp6_4_check172 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node173 T childKnown
theorem hp6_4_node171 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected171 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected171 ((6 : Int),(1 : Int)) hp6_4_branches171 hp6_4_evidence171 hp6_4_check171 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node172 T childKnown
  · exact hp6_4_node174 T childKnown
  · exact hp6_4_node187 T childKnown
theorem hp6_4_node170 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected170 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected170 ((10 : Int),(0 : Int)) hp6_4_branches170 hp6_4_evidence170 hp6_4_check170 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node171 T childKnown
theorem hp6_4_node169 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected169 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected169 ((8 : Int),(1 : Int)) hp6_4_branches169 hp6_4_evidence169 hp6_4_check169 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node170 T childKnown
theorem hp6_4_node168 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected168 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected168 ((8 : Int),(1 : Int)) hp6_4_branches168 hp6_4_evidence168 hp6_4_check168 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node167 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected167 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected167 ((8 : Int),(1 : Int)) hp6_4_branches167 hp6_4_evidence167 hp6_4_check167 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node166 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected166 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected166 ((9 : Int),(0 : Int)) hp6_4_branches166 hp6_4_evidence166 hp6_4_check166 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node167 T childKnown
  · exact hp6_4_node168 T childKnown
  · exact hp6_4_node169 T childKnown
  · exact hp6_4_node189 T childKnown
  · exact hp6_4_node193 T childKnown
  · exact hp6_4_node214 T childKnown
theorem hp6_4_node165 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected165 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected165 ((1 : Int),(1 : Int)) hp6_4_branches165 hp6_4_evidence165 hp6_4_check165 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node164 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected164 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected164 ((1 : Int),(1 : Int)) hp6_4_branches164 hp6_4_evidence164 hp6_4_check164 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node163 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected163 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected163 ((4 : Int),(2 : Int)) hp6_4_branches163 hp6_4_evidence163 hp6_4_check163 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node162 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected162 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected162 ((3 : Int),(2 : Int)) hp6_4_branches162 hp6_4_evidence162 hp6_4_check162 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node163 T childKnown
theorem hp6_4_node161 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected161 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected161 ((11 : Int),(1 : Int)) hp6_4_branches161 hp6_4_evidence161 hp6_4_check161 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node160 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected160 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected160 ((9 : Int),(0 : Int)) hp6_4_branches160 hp6_4_evidence160 hp6_4_check160 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node161 T childKnown
theorem hp6_4_node159 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected159 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected159 ((5 : Int),(2 : Int)) hp6_4_branches159 hp6_4_evidence159 hp6_4_check159 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node160 T childKnown
theorem hp6_4_node158 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected158 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected158 ((3 : Int),(2 : Int)) hp6_4_branches158 hp6_4_evidence158 hp6_4_check158 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node159 T childKnown
theorem hp6_4_node157 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected157 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected157 ((4 : Int),(2 : Int)) hp6_4_branches157 hp6_4_evidence157 hp6_4_check157 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node156 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected156 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected156 ((4 : Int),(1 : Int)) hp6_4_branches156 hp6_4_evidence156 hp6_4_check156 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node157 T childKnown
theorem hp6_4_node155 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected155 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected155 ((3 : Int),(1 : Int)) hp6_4_branches155 hp6_4_evidence155 hp6_4_check155 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node156 T childKnown
  · exact hp6_4_node158 T childKnown
  · exact hp6_4_node162 T childKnown
theorem hp6_4_node154 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected154 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected154 ((1 : Int),(1 : Int)) hp6_4_branches154 hp6_4_evidence154 hp6_4_check154 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node155 T childKnown
theorem hp6_4_node153 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected153 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected153 ((4 : Int),(2 : Int)) hp6_4_branches153 hp6_4_evidence153 hp6_4_check153 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node152 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected152 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected152 ((3 : Int),(2 : Int)) hp6_4_branches152 hp6_4_evidence152 hp6_4_check152 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node153 T childKnown
theorem hp6_4_node151 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected151 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected151 ((11 : Int),(1 : Int)) hp6_4_branches151 hp6_4_evidence151 hp6_4_check151 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node150 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected150 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected150 ((9 : Int),(0 : Int)) hp6_4_branches150 hp6_4_evidence150 hp6_4_check150 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node151 T childKnown
theorem hp6_4_node149 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected149 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected149 ((5 : Int),(2 : Int)) hp6_4_branches149 hp6_4_evidence149 hp6_4_check149 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node150 T childKnown
theorem hp6_4_node148 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected148 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected148 ((3 : Int),(2 : Int)) hp6_4_branches148 hp6_4_evidence148 hp6_4_check148 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node149 T childKnown
theorem hp6_4_node147 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected147 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected147 ((4 : Int),(2 : Int)) hp6_4_branches147 hp6_4_evidence147 hp6_4_check147 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node146 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected146 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected146 ((4 : Int),(1 : Int)) hp6_4_branches146 hp6_4_evidence146 hp6_4_check146 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node147 T childKnown
theorem hp6_4_node145 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected145 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected145 ((3 : Int),(1 : Int)) hp6_4_branches145 hp6_4_evidence145 hp6_4_check145 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node146 T childKnown
  · exact hp6_4_node148 T childKnown
  · exact hp6_4_node152 T childKnown
theorem hp6_4_node144 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected144 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected144 ((1 : Int),(1 : Int)) hp6_4_branches144 hp6_4_evidence144 hp6_4_check144 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node145 T childKnown
theorem hp6_4_node143 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected143 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected143 ((1 : Int),(1 : Int)) hp6_4_branches143 hp6_4_evidence143 hp6_4_check143 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node142 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected142 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected142 ((0 : Int),(1 : Int)) hp6_4_branches142 hp6_4_evidence142 hp6_4_check142 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node143 T childKnown
  · exact hp6_4_node144 T childKnown
  · exact hp6_4_node154 T childKnown
  · exact hp6_4_node164 T childKnown
  · exact hp6_4_node165 T childKnown
theorem hp6_4_node141 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected141 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected141 ((2 : Int),(1 : Int)) hp6_4_branches141 hp6_4_evidence141 hp6_4_check141 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node140 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected140 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected140 ((2 : Int),(1 : Int)) hp6_4_branches140 hp6_4_evidence140 hp6_4_check140 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node139 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected139 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected139 ((2 : Int),(0 : Int)) hp6_4_branches139 hp6_4_evidence139 hp6_4_check139 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node140 T childKnown
  · exact hp6_4_node141 T childKnown
theorem hp6_4_node138 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected138 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected138 ((2 : Int),(1 : Int)) hp6_4_branches138 hp6_4_evidence138 hp6_4_check138 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node137 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected137 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected137 ((2 : Int),(1 : Int)) hp6_4_branches137 hp6_4_evidence137 hp6_4_check137 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node136 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected136 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected136 ((2 : Int),(0 : Int)) hp6_4_branches136 hp6_4_evidence136 hp6_4_check136 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node137 T childKnown
  · exact hp6_4_node138 T childKnown
theorem hp6_4_node135 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected135 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected135 ((0 : Int),(1 : Int)) hp6_4_branches135 hp6_4_evidence135 hp6_4_check135 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node136 T childKnown
  · exact hp6_4_node139 T childKnown
theorem hp6_4_node134 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected134 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected134 ((10 : Int),(1 : Int)) hp6_4_branches134 hp6_4_evidence134 hp6_4_check134 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node133 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected133 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected133 ((9 : Int),(1 : Int)) hp6_4_branches133 hp6_4_evidence133 hp6_4_check133 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node134 T childKnown
theorem hp6_4_node132 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected132 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected132 ((10 : Int),(1 : Int)) hp6_4_branches132 hp6_4_evidence132 hp6_4_check132 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node131 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected131 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected131 ((9 : Int),(1 : Int)) hp6_4_branches131 hp6_4_evidence131 hp6_4_check131 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node132 T childKnown
theorem hp6_4_node130 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected130 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected130 ((9 : Int),(1 : Int)) hp6_4_branches130 hp6_4_evidence130 hp6_4_check130 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node129 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected129 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected129 ((10 : Int),(0 : Int)) hp6_4_branches129 hp6_4_evidence129 hp6_4_check129 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node130 T childKnown
  · exact hp6_4_node131 T childKnown
  · exact hp6_4_node133 T childKnown
theorem hp6_4_node128 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected128 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected128 ((7 : Int),(1 : Int)) hp6_4_branches128 hp6_4_evidence128 hp6_4_check128 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node129 T childKnown
theorem hp6_4_node127 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected127 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected127 ((6 : Int),(1 : Int)) hp6_4_branches127 hp6_4_evidence127 hp6_4_check127 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node126 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected126 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected126 ((3 : Int),(2 : Int)) hp6_4_branches126 hp6_4_evidence126 hp6_4_check126 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node127 T childKnown
theorem hp6_4_node125 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected125 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected125 ((6 : Int),(1 : Int)) hp6_4_branches125 hp6_4_evidence125 hp6_4_check125 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node124 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected124 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected124 ((2 : Int),(2 : Int)) hp6_4_branches124 hp6_4_evidence124 hp6_4_check124 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node125 T childKnown
  · exact hp6_4_node126 T childKnown
  · exact hp6_4_node128 T childKnown
theorem hp6_4_node123 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected123 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected123 ((10 : Int),(1 : Int)) hp6_4_branches123 hp6_4_evidence123 hp6_4_check123 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node122 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected122 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected122 ((9 : Int),(1 : Int)) hp6_4_branches122 hp6_4_evidence122 hp6_4_check122 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node123 T childKnown
theorem hp6_4_node121 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected121 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected121 ((10 : Int),(1 : Int)) hp6_4_branches121 hp6_4_evidence121 hp6_4_check121 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node120 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected120 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected120 ((9 : Int),(1 : Int)) hp6_4_branches120 hp6_4_evidence120 hp6_4_check120 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node121 T childKnown
theorem hp6_4_node119 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected119 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected119 ((9 : Int),(1 : Int)) hp6_4_branches119 hp6_4_evidence119 hp6_4_check119 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node118 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected118 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected118 ((10 : Int),(0 : Int)) hp6_4_branches118 hp6_4_evidence118 hp6_4_check118 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node119 T childKnown
  · exact hp6_4_node120 T childKnown
  · exact hp6_4_node122 T childKnown
theorem hp6_4_node117 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected117 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected117 ((7 : Int),(1 : Int)) hp6_4_branches117 hp6_4_evidence117 hp6_4_check117 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node118 T childKnown
theorem hp6_4_node116 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected116 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected116 ((6 : Int),(1 : Int)) hp6_4_branches116 hp6_4_evidence116 hp6_4_check116 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node115 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected115 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected115 ((3 : Int),(2 : Int)) hp6_4_branches115 hp6_4_evidence115 hp6_4_check115 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node116 T childKnown
theorem hp6_4_node114 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected114 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected114 ((6 : Int),(1 : Int)) hp6_4_branches114 hp6_4_evidence114 hp6_4_check114 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node113 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected113 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected113 ((2 : Int),(2 : Int)) hp6_4_branches113 hp6_4_evidence113 hp6_4_check113 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node114 T childKnown
  · exact hp6_4_node115 T childKnown
  · exact hp6_4_node117 T childKnown
theorem hp6_4_node112 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected112 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected112 ((0 : Int),(1 : Int)) hp6_4_branches112 hp6_4_evidence112 hp6_4_check112 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node113 T childKnown
  · exact hp6_4_node124 T childKnown
theorem hp6_4_node111 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected111 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected111 ((2 : Int),(0 : Int)) hp6_4_branches111 hp6_4_evidence111 hp6_4_check111 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node112 T childKnown
theorem hp6_4_node110 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected110 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected110 ((0 : Int),(1 : Int)) hp6_4_branches110 hp6_4_evidence110 hp6_4_check110 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node109 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected109 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected109 ((0 : Int),(1 : Int)) hp6_4_branches109 hp6_4_evidence109 hp6_4_check109 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node108 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected108 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected108 ((2 : Int),(1 : Int)) hp6_4_branches108 hp6_4_evidence108 hp6_4_check108 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node107 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected107 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected107 ((2 : Int),(1 : Int)) hp6_4_branches107 hp6_4_evidence107 hp6_4_check107 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node106 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected106 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected106 ((3 : Int),(1 : Int)) hp6_4_branches106 hp6_4_evidence106 hp6_4_check106 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node105 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected105 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected105 ((3 : Int),(1 : Int)) hp6_4_branches105 hp6_4_evidence105 hp6_4_check105 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node104 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected104 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected104 ((3 : Int),(0 : Int)) hp6_4_branches104 hp6_4_evidence104 hp6_4_check104 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node105 T childKnown
  · exact hp6_4_node106 T childKnown
theorem hp6_4_node103 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected103 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected103 ((11 : Int),(1 : Int)) hp6_4_branches103 hp6_4_evidence103 hp6_4_check103 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node102 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected102 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected102 ((10 : Int),(1 : Int)) hp6_4_branches102 hp6_4_evidence102 hp6_4_check102 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node103 T childKnown
theorem hp6_4_node101 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected101 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected101 ((11 : Int),(1 : Int)) hp6_4_branches101 hp6_4_evidence101 hp6_4_check101 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node100 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected100 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected100 ((10 : Int),(1 : Int)) hp6_4_branches100 hp6_4_evidence100 hp6_4_check100 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node101 T childKnown
theorem hp6_4_node99 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected99 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected99 ((10 : Int),(1 : Int)) hp6_4_branches99 hp6_4_evidence99 hp6_4_check99 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node98 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected98 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected98 ((11 : Int),(0 : Int)) hp6_4_branches98 hp6_4_evidence98 hp6_4_check98 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node99 T childKnown
  · exact hp6_4_node100 T childKnown
  · exact hp6_4_node102 T childKnown
theorem hp6_4_node97 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected97 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected97 ((8 : Int),(1 : Int)) hp6_4_branches97 hp6_4_evidence97 hp6_4_check97 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node98 T childKnown
theorem hp6_4_node96 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected96 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected96 ((3 : Int),(2 : Int)) hp6_4_branches96 hp6_4_evidence96 hp6_4_check96 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node97 T childKnown
theorem hp6_4_node95 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected95 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected95 ((3 : Int),(0 : Int)) hp6_4_branches95 hp6_4_evidence95 hp6_4_check95 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node96 T childKnown
theorem hp6_4_node94 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected94 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected94 ((2 : Int),(0 : Int)) hp6_4_branches94 hp6_4_evidence94 hp6_4_check94 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node95 T childKnown
  · exact hp6_4_node104 T childKnown
  · exact hp6_4_node107 T childKnown
  · exact hp6_4_node108 T childKnown
theorem hp6_4_node93 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected93 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected93 ((3 : Int),(1 : Int)) hp6_4_branches93 hp6_4_evidence93 hp6_4_check93 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node92 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected92 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected92 ((3 : Int),(1 : Int)) hp6_4_branches92 hp6_4_evidence92 hp6_4_check92 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node91 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected91 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected91 ((2 : Int),(1 : Int)) hp6_4_branches91 hp6_4_evidence91 hp6_4_check91 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node92 T childKnown
  · exact hp6_4_node93 T childKnown
theorem hp6_4_node90 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected90 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected90 ((5 : Int),(2 : Int)) hp6_4_branches90 hp6_4_evidence90 hp6_4_check90 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node89 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected89 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected89 ((4 : Int),(2 : Int)) hp6_4_branches89 hp6_4_evidence89 hp6_4_check89 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node90 T childKnown
theorem hp6_4_node88 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected88 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected88 ((12 : Int),(1 : Int)) hp6_4_branches88 hp6_4_evidence88 hp6_4_check88 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node87 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected87 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected87 ((10 : Int),(0 : Int)) hp6_4_branches87 hp6_4_evidence87 hp6_4_check87 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node88 T childKnown
theorem hp6_4_node86 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected86 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected86 ((6 : Int),(2 : Int)) hp6_4_branches86 hp6_4_evidence86 hp6_4_check86 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node87 T childKnown
theorem hp6_4_node85 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected85 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected85 ((4 : Int),(2 : Int)) hp6_4_branches85 hp6_4_evidence85 hp6_4_check85 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node86 T childKnown
theorem hp6_4_node84 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected84 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected84 ((5 : Int),(2 : Int)) hp6_4_branches84 hp6_4_evidence84 hp6_4_check84 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node83 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected83 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected83 ((5 : Int),(1 : Int)) hp6_4_branches83 hp6_4_evidence83 hp6_4_check83 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node84 T childKnown
theorem hp6_4_node82 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected82 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected82 ((4 : Int),(1 : Int)) hp6_4_branches82 hp6_4_evidence82 hp6_4_check82 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node83 T childKnown
  · exact hp6_4_node85 T childKnown
  · exact hp6_4_node89 T childKnown
theorem hp6_4_node81 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected81 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected81 ((2 : Int),(1 : Int)) hp6_4_branches81 hp6_4_evidence81 hp6_4_check81 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node82 T childKnown
theorem hp6_4_node80 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected80 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected80 ((3 : Int),(1 : Int)) hp6_4_branches80 hp6_4_evidence80 hp6_4_check80 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node79 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected79 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected79 ((3 : Int),(1 : Int)) hp6_4_branches79 hp6_4_evidence79 hp6_4_check79 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node78 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected78 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected78 ((3 : Int),(0 : Int)) hp6_4_branches78 hp6_4_evidence78 hp6_4_check78 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node79 T childKnown
  · exact hp6_4_node80 T childKnown
theorem hp6_4_node77 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected77 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected77 ((11 : Int),(1 : Int)) hp6_4_branches77 hp6_4_evidence77 hp6_4_check77 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node76 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected76 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected76 ((10 : Int),(1 : Int)) hp6_4_branches76 hp6_4_evidence76 hp6_4_check76 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node77 T childKnown
theorem hp6_4_node75 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected75 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected75 ((11 : Int),(1 : Int)) hp6_4_branches75 hp6_4_evidence75 hp6_4_check75 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node74 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected74 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected74 ((10 : Int),(1 : Int)) hp6_4_branches74 hp6_4_evidence74 hp6_4_check74 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node75 T childKnown
theorem hp6_4_node73 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected73 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected73 ((10 : Int),(1 : Int)) hp6_4_branches73 hp6_4_evidence73 hp6_4_check73 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node72 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected72 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected72 ((11 : Int),(0 : Int)) hp6_4_branches72 hp6_4_evidence72 hp6_4_check72 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node73 T childKnown
  · exact hp6_4_node74 T childKnown
  · exact hp6_4_node76 T childKnown
theorem hp6_4_node71 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected71 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected71 ((8 : Int),(1 : Int)) hp6_4_branches71 hp6_4_evidence71 hp6_4_check71 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node72 T childKnown
theorem hp6_4_node70 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected70 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected70 ((7 : Int),(1 : Int)) hp6_4_branches70 hp6_4_evidence70 hp6_4_check70 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node69 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected69 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected69 ((4 : Int),(2 : Int)) hp6_4_branches69 hp6_4_evidence69 hp6_4_check69 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node70 T childKnown
theorem hp6_4_node68 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected68 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected68 ((7 : Int),(1 : Int)) hp6_4_branches68 hp6_4_evidence68 hp6_4_check68 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node67 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected67 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected67 ((3 : Int),(2 : Int)) hp6_4_branches67 hp6_4_evidence67 hp6_4_check67 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node68 T childKnown
  · exact hp6_4_node69 T childKnown
  · exact hp6_4_node71 T childKnown
theorem hp6_4_node66 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected66 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected66 ((3 : Int),(0 : Int)) hp6_4_branches66 hp6_4_evidence66 hp6_4_check66 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node67 T childKnown
theorem hp6_4_node65 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected65 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected65 ((2 : Int),(0 : Int)) hp6_4_branches65 hp6_4_evidence65 hp6_4_check65 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node66 T childKnown
  · exact hp6_4_node78 T childKnown
  · exact hp6_4_node81 T childKnown
  · exact hp6_4_node91 T childKnown
theorem hp6_4_node64 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected64 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected64 ((3 : Int),(1 : Int)) hp6_4_branches64 hp6_4_evidence64 hp6_4_check64 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node63 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected63 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected63 ((3 : Int),(1 : Int)) hp6_4_branches63 hp6_4_evidence63 hp6_4_check63 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node62 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected62 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected62 ((2 : Int),(1 : Int)) hp6_4_branches62 hp6_4_evidence62 hp6_4_check62 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node63 T childKnown
  · exact hp6_4_node64 T childKnown
theorem hp6_4_node61 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected61 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected61 ((5 : Int),(2 : Int)) hp6_4_branches61 hp6_4_evidence61 hp6_4_check61 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node60 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected60 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected60 ((4 : Int),(2 : Int)) hp6_4_branches60 hp6_4_evidence60 hp6_4_check60 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node61 T childKnown
theorem hp6_4_node59 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected59 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected59 ((12 : Int),(1 : Int)) hp6_4_branches59 hp6_4_evidence59 hp6_4_check59 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node58 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected58 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected58 ((10 : Int),(0 : Int)) hp6_4_branches58 hp6_4_evidence58 hp6_4_check58 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node59 T childKnown
theorem hp6_4_node57 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected57 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected57 ((6 : Int),(2 : Int)) hp6_4_branches57 hp6_4_evidence57 hp6_4_check57 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node58 T childKnown
theorem hp6_4_node56 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected56 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected56 ((4 : Int),(2 : Int)) hp6_4_branches56 hp6_4_evidence56 hp6_4_check56 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node57 T childKnown
theorem hp6_4_node55 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected55 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected55 ((5 : Int),(2 : Int)) hp6_4_branches55 hp6_4_evidence55 hp6_4_check55 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node54 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected54 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected54 ((5 : Int),(1 : Int)) hp6_4_branches54 hp6_4_evidence54 hp6_4_check54 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node55 T childKnown
theorem hp6_4_node53 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected53 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected53 ((4 : Int),(1 : Int)) hp6_4_branches53 hp6_4_evidence53 hp6_4_check53 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node54 T childKnown
  · exact hp6_4_node56 T childKnown
  · exact hp6_4_node60 T childKnown
theorem hp6_4_node52 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected52 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected52 ((2 : Int),(1 : Int)) hp6_4_branches52 hp6_4_evidence52 hp6_4_check52 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node53 T childKnown
theorem hp6_4_node51 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected51 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected51 ((3 : Int),(1 : Int)) hp6_4_branches51 hp6_4_evidence51 hp6_4_check51 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node50 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected50 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected50 ((3 : Int),(1 : Int)) hp6_4_branches50 hp6_4_evidence50 hp6_4_check50 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node49 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected49 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected49 ((3 : Int),(0 : Int)) hp6_4_branches49 hp6_4_evidence49 hp6_4_check49 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node50 T childKnown
  · exact hp6_4_node51 T childKnown
theorem hp6_4_node48 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected48 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected48 ((11 : Int),(1 : Int)) hp6_4_branches48 hp6_4_evidence48 hp6_4_check48 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node47 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected47 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected47 ((10 : Int),(1 : Int)) hp6_4_branches47 hp6_4_evidence47 hp6_4_check47 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node48 T childKnown
theorem hp6_4_node46 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected46 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected46 ((11 : Int),(1 : Int)) hp6_4_branches46 hp6_4_evidence46 hp6_4_check46 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node45 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected45 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected45 ((10 : Int),(1 : Int)) hp6_4_branches45 hp6_4_evidence45 hp6_4_check45 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node46 T childKnown
theorem hp6_4_node44 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected44 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected44 ((10 : Int),(1 : Int)) hp6_4_branches44 hp6_4_evidence44 hp6_4_check44 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node43 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected43 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected43 ((11 : Int),(0 : Int)) hp6_4_branches43 hp6_4_evidence43 hp6_4_check43 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node44 T childKnown
  · exact hp6_4_node45 T childKnown
  · exact hp6_4_node47 T childKnown
theorem hp6_4_node42 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected42 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected42 ((8 : Int),(1 : Int)) hp6_4_branches42 hp6_4_evidence42 hp6_4_check42 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node43 T childKnown
theorem hp6_4_node41 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected41 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected41 ((7 : Int),(1 : Int)) hp6_4_branches41 hp6_4_evidence41 hp6_4_check41 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node40 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected40 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected40 ((4 : Int),(2 : Int)) hp6_4_branches40 hp6_4_evidence40 hp6_4_check40 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node41 T childKnown
theorem hp6_4_node39 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected39 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected39 ((7 : Int),(1 : Int)) hp6_4_branches39 hp6_4_evidence39 hp6_4_check39 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node38 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected38 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected38 ((3 : Int),(2 : Int)) hp6_4_branches38 hp6_4_evidence38 hp6_4_check38 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node39 T childKnown
  · exact hp6_4_node40 T childKnown
  · exact hp6_4_node42 T childKnown
theorem hp6_4_node37 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected37 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected37 ((3 : Int),(0 : Int)) hp6_4_branches37 hp6_4_evidence37 hp6_4_check37 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node38 T childKnown
theorem hp6_4_node36 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected36 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected36 ((2 : Int),(0 : Int)) hp6_4_branches36 hp6_4_evidence36 hp6_4_check36 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node37 T childKnown
  · exact hp6_4_node49 T childKnown
  · exact hp6_4_node52 T childKnown
  · exact hp6_4_node62 T childKnown
theorem hp6_4_node35 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected35 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected35 ((3 : Int),(1 : Int)) hp6_4_branches35 hp6_4_evidence35 hp6_4_check35 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node34 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected34 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected34 ((3 : Int),(1 : Int)) hp6_4_branches34 hp6_4_evidence34 hp6_4_check34 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node33 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected33 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected33 ((2 : Int),(1 : Int)) hp6_4_branches33 hp6_4_evidence33 hp6_4_check33 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node34 T childKnown
  · exact hp6_4_node35 T childKnown
theorem hp6_4_node32 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected32 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected32 ((5 : Int),(2 : Int)) hp6_4_branches32 hp6_4_evidence32 hp6_4_check32 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node31 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected31 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected31 ((4 : Int),(2 : Int)) hp6_4_branches31 hp6_4_evidence31 hp6_4_check31 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node32 T childKnown
theorem hp6_4_node30 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected30 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected30 ((12 : Int),(1 : Int)) hp6_4_branches30 hp6_4_evidence30 hp6_4_check30 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node29 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected29 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected29 ((10 : Int),(0 : Int)) hp6_4_branches29 hp6_4_evidence29 hp6_4_check29 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node30 T childKnown
theorem hp6_4_node28 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected28 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected28 ((6 : Int),(2 : Int)) hp6_4_branches28 hp6_4_evidence28 hp6_4_check28 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node29 T childKnown
theorem hp6_4_node27 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected27 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected27 ((4 : Int),(2 : Int)) hp6_4_branches27 hp6_4_evidence27 hp6_4_check27 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node28 T childKnown
theorem hp6_4_node26 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected26 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected26 ((5 : Int),(2 : Int)) hp6_4_branches26 hp6_4_evidence26 hp6_4_check26 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node25 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected25 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected25 ((5 : Int),(1 : Int)) hp6_4_branches25 hp6_4_evidence25 hp6_4_check25 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node26 T childKnown
theorem hp6_4_node24 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected24 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected24 ((4 : Int),(1 : Int)) hp6_4_branches24 hp6_4_evidence24 hp6_4_check24 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node25 T childKnown
  · exact hp6_4_node27 T childKnown
  · exact hp6_4_node31 T childKnown
theorem hp6_4_node23 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected23 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected23 ((2 : Int),(1 : Int)) hp6_4_branches23 hp6_4_evidence23 hp6_4_check23 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node24 T childKnown
theorem hp6_4_node22 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected22 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected22 ((3 : Int),(1 : Int)) hp6_4_branches22 hp6_4_evidence22 hp6_4_check22 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node21 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected21 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected21 ((3 : Int),(1 : Int)) hp6_4_branches21 hp6_4_evidence21 hp6_4_check21 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node20 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected20 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected20 ((3 : Int),(0 : Int)) hp6_4_branches20 hp6_4_evidence20 hp6_4_check20 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node21 T childKnown
  · exact hp6_4_node22 T childKnown
theorem hp6_4_node19 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected19 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected19 ((11 : Int),(1 : Int)) hp6_4_branches19 hp6_4_evidence19 hp6_4_check19 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node18 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected18 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected18 ((10 : Int),(1 : Int)) hp6_4_branches18 hp6_4_evidence18 hp6_4_check18 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node19 T childKnown
theorem hp6_4_node17 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected17 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected17 ((11 : Int),(1 : Int)) hp6_4_branches17 hp6_4_evidence17 hp6_4_check17 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node16 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected16 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected16 ((10 : Int),(1 : Int)) hp6_4_branches16 hp6_4_evidence16 hp6_4_check16 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node17 T childKnown
theorem hp6_4_node15 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected15 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected15 ((10 : Int),(1 : Int)) hp6_4_branches15 hp6_4_evidence15 hp6_4_check15 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node14 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected14 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected14 ((11 : Int),(0 : Int)) hp6_4_branches14 hp6_4_evidence14 hp6_4_check14 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_4_node15 T childKnown
  · exact hp6_4_node16 T childKnown
  · exact hp6_4_node18 T childKnown
theorem hp6_4_node13 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected13 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected13 ((8 : Int),(1 : Int)) hp6_4_branches13 hp6_4_evidence13 hp6_4_check13 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node14 T childKnown
theorem hp6_4_node12 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected12 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected12 ((7 : Int),(1 : Int)) hp6_4_branches12 hp6_4_evidence12 hp6_4_check12 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node11 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected11 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected11 ((4 : Int),(2 : Int)) hp6_4_branches11 hp6_4_evidence11 hp6_4_check11 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node12 T childKnown
theorem hp6_4_node10 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected10 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected10 ((7 : Int),(1 : Int)) hp6_4_branches10 hp6_4_evidence10 hp6_4_check10 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node9 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected9 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected9 ((4 : Int),(2 : Int)) hp6_4_branches9 hp6_4_evidence9 hp6_4_check9 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node8 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected8 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected8 ((6 : Int),(2 : Int)) hp6_4_branches8 hp6_4_evidence8 hp6_4_check8 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node7 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected7 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected7 ((7 : Int),(1 : Int)) hp6_4_branches7 hp6_4_evidence7 hp6_4_check7 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_4_node8 T childKnown
  · exact hp6_4_node9 T childKnown
theorem hp6_4_node6 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected6 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected6 ((3 : Int),(2 : Int)) hp6_4_branches6 hp6_4_evidence6 hp6_4_check6 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node7 T childKnown
  · exact hp6_4_node10 T childKnown
  · exact hp6_4_node11 T childKnown
  · exact hp6_4_node13 T childKnown
theorem hp6_4_node5 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected5 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected5 ((3 : Int),(0 : Int)) hp6_4_branches5 hp6_4_evidence5 hp6_4_check5 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_4_node6 T childKnown
theorem hp6_4_node4 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected4 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected4 ((2 : Int),(0 : Int)) hp6_4_branches4 hp6_4_evidence4 hp6_4_check4 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node5 T childKnown
  · exact hp6_4_node20 T childKnown
  · exact hp6_4_node23 T childKnown
  · exact hp6_4_node33 T childKnown
theorem hp6_4_node3 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected3 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected3 ((0 : Int),(2 : Int)) hp6_4_branches3 hp6_4_evidence3 hp6_4_check3 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_4_node4 T childKnown
  · exact hp6_4_node36 T childKnown
  · exact hp6_4_node65 T childKnown
  · exact hp6_4_node94 T childKnown
theorem hp6_4_node2 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected2 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected2 ((0 : Int),(1 : Int)) hp6_4_branches2 hp6_4_evidence2 hp6_4_check2 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_4_node1 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected1 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected1 ((1 : Int),(0 : Int)) hp6_4_branches1 hp6_4_evidence1 hp6_4_check1 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node2 T childKnown
  · exact hp6_4_node3 T childKnown
  · exact hp6_4_node109 T childKnown
  · exact hp6_4_node110 T childKnown
  · exact hp6_4_node111 T childKnown
  · exact hp6_4_node135 T childKnown
  · exact hp6_4_node142 T childKnown
  · exact hp6_4_node166 T childKnown
theorem hp6_4_node0 (T : Tiling (6 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_4_selected0 → T.world s) : False := by
  apply replay_step (6 : Int) (4 : Int) (by decide) (by decide) T hp6_4_selected0 ((0 : Int),(0 : Int)) hp6_4_branches0 hp6_4_evidence0 hp6_4_check0 ?_ known
  intro t member childKnown
  simp only [hp6_4_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_4_node1 T childKnown
  · exact hp6_4_node219 T childKnown
  · exact hp6_4_node258 T childKnown
  · exact hp6_4_node469 T childKnown
  · exact hp6_4_node508 T childKnown
  · exact hp6_4_node511 T childKnown
  · exact hp6_4_node674 T childKnown
  · exact hp6_4_node759 T childKnown
  · exact hp6_4_node921 T childKnown
  · exact hp6_4_node972 T childKnown
  · exact hp6_4_node1004 T childKnown
  · exact hp6_4_node1036 T childKnown
  · exact hp6_4_node1124 T childKnown
  · exact hp6_4_node1177 T childKnown
  · exact hp6_4_node1290 T childKnown
  · exact hp6_4_node1343 T childKnown
  · exact hp6_4_node1456 T childKnown
  · exact hp6_4_node1509 T childKnown
  · exact hp6_4_node1511 T childKnown
  · exact hp6_4_node1526 T childKnown
  · exact hp6_4_node1529 T childKnown
  · exact hp6_4_node1779 T childKnown

theorem hp6_4_no_half_plane : ¬Tiles (6 : Int) (4 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp6_4_node0 T (by simp [hp6_4_selected0])
#print axioms hp6_4_no_half_plane

end THalfPlaneFinite

import ProfileAssembly
import LQuadrantSmall
import LQuadrantShortLong
import LHalfPlaneEqual
import PositiveLPlane
import PositiveLStrip
import PositiveLSpecial

namespace PolyominoFormal

theorem exact_strip_of_no_quadrant {a b c : Int}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (positive : StripTileable a b c 0) (noQ : ¬Tiles a b c 0 Quadrant) : ExactStrip a b c 0 := by
  have noHS : ¬HalfStripTileable a b c 0 := fun h => noQ (half_strip_implies_quadrant h)
  exact ⟨(fun h => noHS (rectangle_implies_half_strip h)),noHS,
    (fun h => noQ (PositiveHierarchy.bent_tiles_quadrant h)),noQ,positive,
    PositiveHierarchy.strip_tiles_halfplane positive,PositiveHierarchy.strip_tiles_plane positive,
    (fun h => noQ (rep_zero_south_implies_quadrant ha hb hc h))⟩

/-- The final L assembly isolates the two remaining unbounded obstruction
inputs explicitly; the surrounding hierarchy implications are all proved. -/
theorem sorted_L_classified_of_obstructions
    (two : ∀ a : Int,5≤a→¬Tiles a 2 0 0 Quadrant)
    (unequal : ∀ a b : Int,b<a→3≤b→5≤a→¬Tiles a b 0 0 HalfPlane) :
    ∀ a b : Nat,b≤a→Classified a b 0 0 (classifyL a b) := by
  intro a b hab
  by_cases zero : b=0
  · subst b
    simpa [classifyL] using (bar_exact_rectangle a 0 (by omega) (by omega)).classified
  · by_cases unit : b=1
    · subst b
      have ha : 1≤a := by omega
      simpa [classifyL,Nat.min_eq_right ha,Nat.max_eq_left ha] using
        (unit_l_exact_rectangle a (by omega)).classified
    · have b2 : 2≤b := by omega
      by_cases small : b=2
      · subst b
        have noQ : ¬Tiles a 2 0 0 Quadrant := by
          by_cases short : a≤4
          · exact LRegion.b_two_small_no_quadrant a (by omega) (by omega)
          · exact two a (by omega)
        have h := (exact_strip_of_no_quadrant (by omega) (by omega) (by omega)
          (PositiveLStrip.strip_tileable a (by omega)) noQ).classified
        simpa [classifyL,Nat.min_eq_right hab,Nat.max_eq_left hab] using h
      · have b3 : 3≤b := by omega
        by_cases special : a=4∧b=3
        · rcases special with ⟨rfl,rfl⟩
          have h := (exact_strip_of_no_quadrant (by omega) (by omega) (by omega)
            PositiveLSpecial.strip_tileable LRegion.no_quadrant_4_3).classified
          simpa [classifyL] using h
        · have noHP : ¬Tiles a b 0 0 HalfPlane := by
            by_cases equal : a=b
            · subst a
              exact LHalfPlaneEqual.no_halfplane (by omega)
            · exact unequal a b (by omega) (by omega) (by omega)
          have positive : Tiles a b 0 0 Plane := PositiveLPlane.tiles_plane a b (by omega) (by omega)
          have h := no_halfplane_zero_south_profile (by omega : 0≤(a : Int))
            (by omega : 0≤(b : Int)) (by omega : (0 : Int)≤0) noHP
            (show Tiles a b 0 0 Plane↔True from ⟨fun _ => True.intro,fun _ => positive⟩)
          have nb : ¬b≤1 := by omega
          have ne : ¬(b=2∨(a=4∧b=3)) := by omega
          simpa only [classifyL,Nat.min_eq_right hab,Nat.max_eq_left hab,if_neg nb,if_neg ne,if_pos] using h

#print axioms sorted_L_classified_of_obstructions

/-- Only the unequal long-arm half-plane obstruction remains as an input. -/
theorem sorted_L_classified_of_unequal
    (unequal : ∀ a b : Int,b<a→3≤b→5≤a→¬Tiles a b 0 0 HalfPlane) :
    ∀ a b : Nat,b≤a→Classified a b 0 0 (classifyL a b) :=
  sorted_L_classified_of_obstructions LRegion.shortlong_no_quadrant unequal

#print axioms sorted_L_classified_of_unequal
end PolyominoFormal

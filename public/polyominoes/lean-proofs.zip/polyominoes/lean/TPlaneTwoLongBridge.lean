import TPlaneDeep
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
namespace PolyominoFormal.TPlaneTwoLongBridge
open CrossUnits TBoundary THalfPlane THalfPlaneStarters THalfPlaneGaps THalfPlaneDeepGaps TPlaneDeep

theorem no_s_neighbor {a b p : Int} (ha : 2≤a) (hb : a+4≤b)
    (T : Tiling a b 2 0 Plane) (ht : T.world ⟨p,b,a,0,2,b⟩)
    {u : Cross} (hu : T.world u)
    (form : (∃q s,(s=a ∨ s=2) ∧ u=⟨q+s,0,a+2-s,b,s,0⟩ ∧ q≤p+1 ∧ p+1≤q+a+2) ∨
      u=⟨p+1,b,a,0,2,b⟩ ∨ u=⟨p+1,b,2,0,a,b⟩) : False := by
  rcases form with ⟨q,s,hs,rfl,hq0,hq1⟩ | eq | eq
  · have hit : Contains ⟨q+s,0,a+2-s,b,s,0⟩ (p+1) 0 := by left; dsimp; omega
    have sep := separate (by omega) (by omega) (by omega) T hu ht hit
      (by dsimp [Contains]; omega)
    have hq : q=p+1 := by dsimp [Apart] at sep; omega
    have hsa : s=a := by dsimp [Apart] at sep; omega
    subst q; subst s
    apply blocked_deep_run (L:=p+1) (R:=p+a) (h:=1) ha (by omega) (by omega)
      (by omega) (by omega) T _ (pair_closed T ht hu)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · subst u
    have eq := T.disjoint _ _ (p+1) b ht hu
      (by left; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega
  · subst u
    have eq := T.disjoint _ _ (p+1) b ht hu
      (by left; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega

theorem finite_bridge_impossible {a b r w : Int} (ha : 2≤a) (hb : a+4≤b)
    (hr : r=a ∨ r=2) (hw : w=a ∨ w=2) (T : Tiling a b 2 0 Plane)
    (hU : T.world ⟨1,-2,b,2,0,a⟩)
    (hW : T.world ⟨b+2,-1,0,w,b,a+2-w⟩)
    (hR : T.world ⟨2+r,0,a+2-r,b,r,0⟩)
    (hZ : T.world ⟨b-1,0,2,b,a,0⟩) : False := by
  let B : Region := fun x y => Contains ⟨1,-2,b,2,0,a⟩ x y ∨
    Contains ⟨b+2,-1,0,w,b,a+2-w⟩ x y
  have closed : CornerCertificate.TileClosed T.world B := pair_closed T hU hW
  have choose : ∀p,2≤p → p≤b+1 → ∃t,T.world t ∧ Contains t p 0 ∧
      ((∃q s,(s=a ∨ s=2) ∧ t=⟨q+s,0,a+2-s,b,s,0⟩ ∧
        2≤q ∧ q≤p ∧ p≤q+a+2 ∧ q+a+2≤b+1) ∨ Starter a b 2 p 0 t) := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p 0 True.intro
    have empty : ¬B p 0 := by dsimp [B,Contains]; omega
    have avoid : ∀{x y},B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit empty blocked
    refine ⟨t,ht,hit,THalfPlaneUnit.run_forms (L:=2) (R:=b+1)
      (by omega) (by omega) (by omega) hp0 hp1 (T.copies t ht) hit ?_ ?_ ?_ ?_⟩
    · apply avoid; left; right; dsimp; omega
    · apply avoid; right; right; dsimp; omega
    · apply avoid; right; left; dsimp; omega
    · intro h0 h1; apply avoid; right; left; dsimp; omega
  have chooseBound : ∀p,2≤p → p≤b+1 → ∃t,T.world t ∧ Contains t p 0 ∧ 0≤t.y-t.south := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit,form⟩ := choose p hp0 hp1
    refine ⟨t,ht,hit,?_⟩
    rcases form with ⟨q,s,hs,rfl,rest⟩ | st
    · dsimp; omega
    · rcases st with rfl | rfl | rfl | rfl | rfl | rfl <;> dsimp <;> omega
  have interior : ∀{t p}, T.world t → Contains t p 0 → 0<t.y → 2≤p → p≤b+1 →
      3≤p ∧ p≤b := by
    intro t p ht hit ypos hp0 hp1
    have neL : p≠2 := by
      intro eq; subst p
      have same := T.disjoint _ _ 2 0 ht hR hit (by left; dsimp; omega)
      have y := congrArg Cross.y same; dsimp at y; omega
    have neR : p≠b+1 := by
      intro eq; subst p
      have same := T.disjoint _ _ (b+1) 0 ht hZ hit (by left; dsimp; omega)
      have y := congrArg Cross.y same; dsimp at y; omega
    omega
  have noVR : ∀p s,2≤p → p≤b+1 → (s=a ∨ s=2) →
      T.world ⟨p,s,b,a+2-s,0,s⟩ → False := by
    intro p s hp0 hp1 hs ht
    have bounds := interior ht (by right; dsimp; omega) (by dsimp; omega) hp0 hp1
    obtain ⟨u,hu,hit,bound⟩ := chooseBound (p+1) (by omega) (by omega)
    have sep := separate (by omega) (by omega) (by omega) T hu ht hit (by dsimp [Contains]; omega)
    exact right_v_neighbor_long (by omega) (by omega) (by omega) hs (T.copies u hu) bound hit sep
  have noVL : ∀p s,2≤p → p≤b+1 → (s=a ∨ s=2) →
      T.world ⟨p,s,0,a+2-s,b,s⟩ → False := by
    intro p s hp0 hp1 hs ht
    have bounds := interior ht (by right; dsimp; omega) (by dsimp; omega) hp0 hp1
    obtain ⟨u,hu,hit,bound⟩ := chooseBound (p-1) (by omega) (by omega)
    let V : Tiling a b 2 0 Plane := T.mirrorX
    have ht' : V.world ⟨-p,s,b,a+2-s,0,s⟩ := ⟨_,ht,rfl⟩
    have hu' : V.world (mirrorX u) := ⟨_,hu,rfl⟩
    have hit' : Contains (mirrorX u) (-p+1) 0 := by
      apply (mirrorX_hit u _ _).2
      simpa only [show -(-p+1)=p-1 by omega] using hit
    have sep := separate (by omega) (by omega) (by omega) V hu' ht' hit'
      (by dsimp [Contains]; omega)
    exact right_v_neighbor_long (by omega) (by omega) (by omega) hs (V.copies _ hu')
      (by simpa only [mirrorX] using bound) hit' sep
  have chooseHS : ∀p,2≤p → p≤b+1 → ∃t,T.world t ∧ Contains t p 0 ∧
      ((∃q s,(s=a ∨ s=2) ∧ t=⟨q+s,0,a+2-s,b,s,0⟩ ∧
        2≤q ∧ q≤p ∧ p≤q+a+2 ∧ q+a+2≤b+1) ∨
       t=⟨p,b,a,0,2,b⟩ ∨ t=⟨p,b,2,0,a,b⟩) := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit,form⟩ := choose p hp0 hp1
    refine ⟨t,ht,hit,?_⟩
    rcases form with h | st
    · exact Or.inl h
    · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
      · exact False.elim (noVR p a hp0 hp1 (Or.inl rfl) (by simpa only [Int.zero_add,show a+2-a=2 by omega] using ht))
      · exact False.elim (noVR p 2 hp0 hp1 (Or.inr rfl) (by simpa using ht))
      · exact False.elim (noVL p a hp0 hp1 (Or.inl rfl) (by simpa only [Int.zero_add,show a+2-a=2 by omega] using ht))
      · exact False.elim (noVL p 2 hp0 hp1 (Or.inr rfl) (by simpa using ht))
      · exact Or.inr (Or.inl (by apply same_eq; dsimp [Same]; omega))
      · exact Or.inr (Or.inr (by apply same_eq; dsimp [Same]; omega))
  have noSR : ∀p,2≤p → p≤b+1 → T.world ⟨p,b,a,0,2,b⟩ → False := by
    intro p hp0 hp1 ht
    have bounds := interior ht (by right; dsimp; omega) (by dsimp; omega) hp0 hp1
    obtain ⟨u,hu,_,form⟩ := chooseHS (p+1) (by omega) (by omega)
    apply no_s_neighbor ha hb T ht hu
    rcases form with ⟨q,s,hs,eq,hq0,hq1,hq2,hq3⟩ | eq | eq
    · exact Or.inl ⟨q,s,hs,eq,hq1,hq2⟩
    · exact Or.inr (Or.inl eq)
    · exact Or.inr (Or.inr eq)
  have noSL : ∀p,2≤p → p≤b+1 → T.world ⟨p,b,2,0,a,b⟩ → False := by
    intro p hp0 hp1 ht
    have bounds := interior ht (by right; dsimp; omega) (by dsimp; omega) hp0 hp1
    obtain ⟨u,hu,_,form⟩ := chooseHS (p-1) (by omega) (by omega)
    let V : Tiling a b 2 0 Plane := T.mirrorX
    have ht' : V.world ⟨-p,b,a,0,2,b⟩ := ⟨_,ht,rfl⟩
    have hu' : V.world (mirrorX u) := ⟨_,hu,rfl⟩
    apply no_s_neighbor ha hb V ht' hu'
    rcases form with ⟨q,s,hs,rfl,hq0,hq1,hq2,hq3⟩ | eq | eq
    · left; refine ⟨-q-a-2,a+2-s,by omega,?_,by omega,by omega⟩
      apply same_eq; dsimp [Same,mirrorX]; omega
    · subst u; right; right
      apply same_eq; dsimp [Same,mirrorX]; omega
    · subst u; right; left
      apply same_eq; dsimp [Same,mirrorX]; omega
  have allH : ∀p,2≤p → p≤b+1 → ∃q s,(s=a ∨ s=2) ∧
      T.world ⟨q+s,0,a+2-s,b,s,0⟩ ∧ 2≤q ∧ q≤p ∧ p≤q+a+2 ∧ q+a+2≤b+1 := by
    intro p hp0 hp1
    obtain ⟨t,ht,_,form⟩ := chooseHS p hp0 hp1
    rcases form with ⟨q,s,hs,rfl,hq0,hq1,hq2,hq3⟩ | eq | eq
    · exact ⟨q,s,hs,ht,hq0,hq1,hq2,hq3⟩
    · subst t; exact False.elim (noSR p hp0 hp1 ht)
    · subst t; exact False.elim (noSL p hp0 hp1 ht)
  obtain ⟨q,s,hs,ht,hq0,hq1,hq2,hq3⟩ := allH (a+5) (by omega) (by omega)
  have hit : Contains ⟨q+s,0,a+2-s,b,s,0⟩ (a+5) 0 := by left; dsimp; omega
  have sep := separate (by omega) (by omega) (by omega) T ht hR hit
    (by dsimp [Contains]; omega)
  have hq : q=a+5 := by dsimp [Apart] at sep; omega
  subst q
  apply deep_left_run (L:=3+r) (R:=a+4+s) (h:=1) ha (by omega) (by omega) (by omega)
    T _ (Contains _) (pair_closed T hR ht) (single_closed T hR) (fun _ _ h => Or.inl h)
  · intros; trivial
  · intros; trivial
  · intro x h0 h1; dsimp [Contains]; omega
  · intro x h0 h1; dsimp [Contains]; omega
  · intro y h0 h1; right; dsimp; omega
  · intro x h0 h1; dsimp [Contains]; omega
  · right; right; dsimp; omega

#print axioms no_s_neighbor
#print axioms finite_bridge_impossible
end PolyominoFormal.TPlaneTwoLongBridge

import TilingSymmetry
import TPlaneGeometry

set_option maxHeartbeats 3000000
namespace PolyominoFormal.TilingCompactness
open CrossUnits

def Unbounded (S : Nat → Prop) : Prop := ∀ N, ∃ n, N≤n ∧ S n

theorem unbounded_partition {S : Nat→Prop} (hS : Unbounded S) (p : Nat→Prop) :
    Unbounded (fun n => S n ∧ p n) ∨ Unbounded (fun n => S n ∧ ¬p n) := by
  classical
  by_cases hp : Unbounded (fun n => S n ∧ p n)
  · exact Or.inl hp
  · right
    have bound : ∃ N, ∀ n, N≤n → S n → ¬p n := by
      apply Classical.byContradiction
      intro noBound
      apply hp
      intro N
      apply Classical.byContradiction
      intro noWitness
      apply noBound
      exact ⟨N,by intro n hn hs h; exact noWitness ⟨n,hn,hs,h⟩⟩
    obtain ⟨N,hN⟩ := bound
    intro M
    obtain ⟨n,hn,hs⟩ := hS (N+M)
    exact ⟨n,by omega,hs,hN n (by omega) hs⟩

theorem stabilize_list (world : Nat→Cross→Prop) (L : List Cross)
    (S : Nat→Prop) (hS : Unbounded S) :
    ∃ U : Nat→Prop, Unbounded U ∧ (∀ n,U n→S n) ∧
      ∀ t, t∈L → ∀ i j,U i→U j→(world i t↔world j t) := by
  classical
  induction L generalizing S with
  | nil => exact ⟨S,hS,by intro n h; exact h,by simp⟩
  | cons t ts ih =>
    rcases unbounded_partition hS (fun n => world n t) with hp | hn
    · obtain ⟨U,hU,sub,agree⟩ := ih (fun n => S n∧world n t) hp
      refine ⟨U,hU,by intro n h; exact (sub n h).1,?_⟩
      intro u hu i j hi hj
      rcases List.mem_cons.mp hu with rfl | hu
      · exact ⟨by intro _; exact (sub j hj).2,by intro _; exact (sub i hi).2⟩
      · exact agree u hu i j hi hj
    · obtain ⟨U,hU,sub,agree⟩ := ih (fun n => S n∧¬world n t) hn
      refine ⟨U,hU,by intro n h; exact (sub n h).1,?_⟩
      intro u hu i j hi hj
      rcases List.mem_cons.mp hu with rfl | hu
      · exact ⟨by intro h; exact False.elim ((sub i hi).2 h),
               by intro h; exact False.elim ((sub j hj).2 h)⟩
      · exact agree u hu i j hi hj

structure Stage where
  indices : Nat→Prop
  unbounded : Unbounded indices

noncomputable def next (world : Nat→Cross→Prop) (L : List Cross) (s : Stage) : Stage :=
  ⟨Classical.choose (stabilize_list world L s.indices s.unbounded),
   (Classical.choose_spec (stabilize_list world L s.indices s.unbounded)).1⟩

theorem next_sub (world : Nat→Cross→Prop) (L : List Cross) (s : Stage) :
    ∀ n,(next world L s).indices n→s.indices n :=
  (Classical.choose_spec (stabilize_list world L s.indices s.unbounded)).2.1

theorem next_agree (world : Nat→Cross→Prop) (L : List Cross) (s : Stage) :
    ∀ t,t∈L→∀ i j,(next world L s).indices i→(next world L s).indices j→
      (world i t↔world j t) :=
  (Classical.choose_spec (stabilize_list world L s.indices s.unbounded)).2.2

noncomputable def stages (world : Nat→Cross→Prop) (candidates : Nat→List Cross) : Nat→Stage
  | 0 => ⟨fun _ => True,by intro N; exact ⟨N,by omega,True.intro⟩⟩
  | n+1 => next world (candidates n) (stages world candidates n)

theorem stages_sub (world : Nat→Cross→Prop) (candidates : Nat→List Cross)
    {i j : Nat} (h : i≤j) :
    ∀ n,(stages world candidates j).indices n→(stages world candidates i).indices n := by
  induction j with
  | zero =>
    have hi : i=0 := by omega
    subst i
    exact fun _ h => h
  | succ j ih =>
    by_cases eq : i=j+1
    · subst i; exact fun _ h => h
    · intro n hn
      exact ih (by omega) n (next_sub world (candidates j) (stages world candidates j) n hn)

noncomputable def sample (world : Nat→Cross→Prop) (candidates : Nat→List Cross) (n : Nat) : Nat :=
  Classical.choose ((stages world candidates n).unbounded n)

theorem sample_mem (world : Nat→Cross→Prop) (candidates : Nat→List Cross) (n : Nat) :
    (stages world candidates n).indices (sample world candidates n) :=
  (Classical.choose_spec ((stages world candidates n).unbounded n)).2

def Eventually (p : Nat→Prop) : Prop := ∃ N,∀ n,N≤n→p n

/-- A countable compactness argument with an explicitly finite candidate list
for every cell. No external compactness principle is assumed. -/
theorem compact {a b c d : Int} {R : Region}
    (world : Nat→Cross→Prop) (candidates : Nat→List Cross)
    (finite_cover : ∀ x y, R x y→∃ N,∀ t,Copy a b c d t→Contains t x y→t∈candidates N)
    (copies : ∀ n t,world n t→Copy a b c d t)
    (inside : ∀ n t,world n t→∀ x y,Contains t x y→R x y)
    (disjoint : ∀ n t u x y,world n t→world n u→Contains t x y→Contains u x y→t=u)
    (cover : ∀ x y,R x y→Eventually (fun n => ∃ t,world n t∧Contains t x y)) :
    Tiles a b c d R := by
  classical
  let limit := fun t => Eventually (fun n => world (sample world candidates n) t)
  refine ⟨{
    world := limit
    copies := ?_
    inside := ?_
    disjoint := ?_
    cover := ?_ }⟩
  · rintro t ⟨N,hN⟩
    exact copies _ t (hN N (by omega))
  · rintro t ⟨N,hN⟩ x y hit
    exact inside _ t (hN N (by omega)) x y hit
  · intro x y hxy
    obtain ⟨N,hN⟩ := finite_cover x y hxy
    obtain ⟨M,hM⟩ := cover x y hxy
    obtain ⟨j,hj,hstage⟩ := (stages world candidates (N+1)).unbounded M
    obtain ⟨t,ht,hit⟩ := hM j hj
    have member := hN t (copies j t ht) hit
    refine ⟨t,⟨N+1,?_⟩,hit⟩
    intro n hn
    have hs := stages_sub world candidates hn (sample world candidates n) (sample_mem world candidates n)
    exact (next_agree world (candidates N) (stages world candidates N) t member
      j (sample world candidates n) hstage hs).1 ht

  · rintro t u x y ⟨N,hN⟩ ⟨M,hM⟩ hit hit'
    exact disjoint _ t u x y (hN (N+M) (by omega)) (hM (N+M) (by omega)) hit hit'

#print axioms compact
end PolyominoFormal.TilingCompactness

import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_6096 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7786 a b) ∨ (fact_366edf150095_7785 a b))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7786 a b) ∧ (fact_366edf150095_7785 a b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7786 a b) ∧ (fact_366edf150095_7785 a b) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6088 a b) ∨ (fact_366edf150095_6604 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6082 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6100 a b) ∨ (fact_366edf150095_7180 a b)))) ∨ ((fact_366edf150095_7786 a b) ∧ (fact_366edf150095_7785 a b) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6088 a b) ∨ (fact_366edf150095_6604 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6082 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6100 a b) ∨ (fact_366edf150095_7180 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3005 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n084_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h3 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3587 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ (((2 : Int) + b) ≥ (0 : Int)) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ (((2 : Int) + b) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_empty (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ ((3 : Int) < (((3 : Int) + b) - b)) ∨ ((3 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : ((((((-1 : Int) - a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-1 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((0 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((1 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ ((((2 : Int) * a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + b))) ∨ (((3 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((((4 : Int) + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + b))) ∨ (((5 : Int) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h4 : (a > b))
    (h5 : (((4 : Int) < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((4 : Int) > (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (((4 : Int) + a) - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h8 : (((2 : Int) < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((2 : Int) > (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((2 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o0 (a b jx jy : Int)
    (h0 : (((5 : Int) > jx) ∨ ((5 : Int) < jx) ∨ ((jy + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((((jx - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h4 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h7 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2953 a b jy))
    (h1 : ((((jx - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h3 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - b))))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((((jx - a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o3 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((jx - b) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h3 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((jx - b) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (fact_366edf150095_2952 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o5 (a b jx jy : Int)
    (h0 : ((((jx - a) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h6 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((jx - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h4 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n085_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((jx - (0 : Int)) ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ ((jx ≤ ((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a))) ∧ (((2 : Int) + ((2 : Int) * b) + ((-1 : Int) * a)) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - b))))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h10 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_empty (a b : Int)
    (h0 : ((fact_366edf150095_2909 a b) ∨ (fact_366edf150095_2589 a b) ∨ (fact_366edf150095_4082 a b) ∨ (fact_366edf150095_4087 a b) ∨ (fact_366edf150095_2592 a b) ∨ (fact_366edf150095_3194 a b) ∨ (fact_366edf150095_2594 a b) ∨ (fact_366edf150095_4089 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + b)))) ∨ ((((6 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((6 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o0 (a b jx jy : Int)
    (h0 : (¬ ((((6 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h4 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o1 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o3 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h3 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h4 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h5 : ((jx < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h6 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n086_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((((5 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ (5 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_short (a b : Int)
    (h0 : (¬ (((5 : Int) - (5 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_nonnegative (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : (¬ (((-3 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((5 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((5 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((5 : Int) ≥ ((5 : Int) + (3 : Int))) ∧ (((fact_366edf150095_6593 a b) ∨ (fact_366edf150095_6235 a b) ∨ (fact_366edf150095_7090 a b) ∨ (fact_366edf150095_7124 a b) ∨ (fact_366edf150095_6265 a b) ∨ (fact_366edf150095_6779 a b) ∨ (fact_366edf150095_6279 a b) ∨ (fact_366edf150095_7139 a b) ∨ (fact_366edf150095_6293 a b) ∨ (fact_366edf150095_6847 a b) ∨ (fact_366edf150095_6329 a b) ∨ (fact_366edf150095_7247 a b) ∨ (fact_366edf150095_6335 a b)) ∨ ((fact_366edf150095_6588 a b) ∨ (fact_366edf150095_6230 a b) ∨ (fact_366edf150095_7085 a b) ∨ (fact_366edf150095_7119 a b) ∨ (fact_366edf150095_6260 a b) ∨ (fact_366edf150095_6774 a b) ∨ (fact_366edf150095_6276 a b) ∨ (fact_366edf150095_7136 a b) ∨ (fact_366edf150095_6292 a b) ∨ (fact_366edf150095_6842 a b) ∨ (fact_366edf150095_6324 a b) ∨ (fact_366edf150095_7246 a b) ∨ (fact_366edf150095_6332 a b)))) ∨ (((5 : Int) ≥ ((5 : Int) + (2 : Int))) ∧ ((fact_366edf150095_6593 a b) ∨ (fact_366edf150095_6235 a b) ∨ (fact_366edf150095_7090 a b) ∨ (fact_366edf150095_7124 a b) ∨ (fact_366edf150095_6265 a b) ∨ (fact_366edf150095_6779 a b) ∨ (fact_366edf150095_6279 a b) ∨ (fact_366edf150095_7139 a b) ∨ (fact_366edf150095_6293 a b) ∨ (fact_366edf150095_6847 a b) ∨ (fact_366edf150095_6329 a b) ∨ (fact_366edf150095_7247 a b) ∨ (fact_366edf150095_6335 a b)) ∧ ((fact_366edf150095_6588 a b) ∨ (fact_366edf150095_6230 a b) ∨ (fact_366edf150095_7085 a b) ∨ (fact_366edf150095_7119 a b) ∨ (fact_366edf150095_6260 a b) ∨ (fact_366edf150095_6774 a b) ∨ (fact_366edf150095_6276 a b) ∨ (fact_366edf150095_7136 a b) ∨ (fact_366edf150095_6292 a b) ∨ (fact_366edf150095_6842 a b) ∨ (fact_366edf150095_6324 a b) ∨ (fact_366edf150095_7246 a b) ∨ (fact_366edf150095_6332 a b))) ∨ ((5 : Int) ≥ ((5 : Int) + (4 : Int))) ∨ (((5 : Int) = ((5 : Int) + (1 : Int))) ∧ ((fact_366edf150095_6593 a b) ∨ (fact_366edf150095_6235 a b) ∨ (fact_366edf150095_7090 a b) ∨ (fact_366edf150095_7124 a b) ∨ (fact_366edf150095_6265 a b) ∨ (fact_366edf150095_6779 a b) ∨ (fact_366edf150095_6279 a b) ∨ (fact_366edf150095_7139 a b) ∨ (fact_366edf150095_6293 a b) ∨ (fact_366edf150095_6847 a b) ∨ (fact_366edf150095_6329 a b) ∨ (fact_366edf150095_7247 a b) ∨ (fact_366edf150095_6335 a b)) ∧ ((fact_366edf150095_6588 a b) ∨ (fact_366edf150095_6230 a b) ∨ (fact_366edf150095_7085 a b) ∨ (fact_366edf150095_7119 a b) ∨ (fact_366edf150095_6260 a b) ∨ (fact_366edf150095_6774 a b) ∨ (fact_366edf150095_6276 a b) ∨ (fact_366edf150095_7136 a b) ∨ (fact_366edf150095_6292 a b) ∨ (fact_366edf150095_6842 a b) ∨ (fact_366edf150095_6324 a b) ∨ (fact_366edf150095_7246 a b) ∨ (fact_366edf150095_6332 a b)) ∧ (((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((5 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + b))))) ∨ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((5 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + b))))))) ∨ (((fact_366edf150095_6593 a b) ∨ (fact_366edf150095_6235 a b) ∨ (fact_366edf150095_7090 a b) ∨ (fact_366edf150095_7124 a b) ∨ (fact_366edf150095_6265 a b) ∨ (fact_366edf150095_6779 a b) ∨ (fact_366edf150095_6279 a b) ∨ (fact_366edf150095_7139 a b) ∨ (fact_366edf150095_6293 a b) ∨ (fact_366edf150095_6847 a b) ∨ (fact_366edf150095_6329 a b) ∨ (fact_366edf150095_7247 a b) ∨ (fact_366edf150095_6335 a b)) ∧ ((fact_366edf150095_6588 a b) ∨ (fact_366edf150095_6230 a b) ∨ (fact_366edf150095_7085 a b) ∨ (fact_366edf150095_7119 a b) ∨ (fact_366edf150095_6260 a b) ∨ (fact_366edf150095_6774 a b) ∨ (fact_366edf150095_6276 a b) ∨ (fact_366edf150095_7136 a b) ∨ (fact_366edf150095_6292 a b) ∨ (fact_366edf150095_6842 a b) ∨ (fact_366edf150095_6324 a b) ∨ (fact_366edf150095_7246 a b) ∨ (fact_366edf150095_6332 a b)) ∧ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((5 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + b))))) ∧ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((5 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + b)))))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((5 : Int) ≥ (-((-3 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ (-((-3 : Int) + ((-1 : Int) * a)))) ∧ ((-((-3 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + b))))))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : ((((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h8 : ((5 : Int) ≥ run_x))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n087_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((5 : Int) ≥ run_x))
    (h3 : ((((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (¬ ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((1 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((4 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((5 : Int) ≥ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ (-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((5 : Int) + b)))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3504 a b) ∨ (fact_366edf150095_3453 a b) ∨ (fact_366edf150095_5780 a b) ∨ (fact_366edf150095_5788 a b) ∨ (fact_366edf150095_3461 a b) ∨ (fact_366edf150095_3699 a b) ∨ (fact_366edf150095_3467 a b) ∨ (fact_366edf150095_5794 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3708 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4119 a b) ∨ (fact_366edf150095_3714 a b) ∨ (fact_366edf150095_5865 a b) ∨ (fact_366edf150095_5948 a b) ∨ (fact_366edf150095_3795 a b) ∨ (fact_366edf150095_4228 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7501 a b) ∨ (fact_366edf150095_7570 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7501 a b) ∧ (fact_366edf150095_7570 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7501 a b) ∧ (fact_366edf150095_7570 a b) ∧ (((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4894 a b) ∨ (fact_366edf150095_4390 a b)) ∨ ((fact_366edf150095_5122 a b) ∨ (fact_366edf150095_4416 a b) ∨ (fact_366edf150095_6341 a b) ∨ (fact_366edf150095_6429 a b) ∨ (fact_366edf150095_4500 a b) ∨ (fact_366edf150095_5250 a b) ∨ (fact_366edf150095_4582 a b) ∨ (fact_366edf150095_6511 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))))))) ∨ ((fact_366edf150095_7501 a b) ∧ (fact_366edf150095_7570 a b) ∧ ((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4894 a b) ∨ (fact_366edf150095_4390 a b)) ∧ ((fact_366edf150095_5122 a b) ∨ (fact_366edf150095_4416 a b) ∨ (fact_366edf150095_6341 a b) ∨ (fact_366edf150095_6429 a b) ∨ (fact_366edf150095_4500 a b) ∨ (fact_366edf150095_5250 a b) ∨ (fact_366edf150095_4582 a b) ∨ (fact_366edf150095_6511 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)))))))))
    (h1 : (a > b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2973 a b run_x)))
    (h4 : ((5 : Int) ≤ run_x))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n088_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3553 a b run_x))))
    (h3 : (run_x ≤ ((2 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_2138 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_empty (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_4132 a b) ∨ (fact_366edf150095_3727 a b) ∨ (fact_366edf150095_5878 a b) ∨ (fact_366edf150095_5961 a b) ∨ (fact_366edf150095_3808 a b) ∨ (fact_366edf150095_4241 a b) ∨ (fact_366edf150095_3878 a b) ∨ (fact_366edf150095_6031 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (fact_366edf150095_3210 a b jx jy))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_3213 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (fact_366edf150095_3215 a b jx jy))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (fact_366edf150095_3216 a b jx jy))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (fact_366edf150095_3217 a b jx jy))
    (h3 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_366edf150095_3214 a b jx jy))
    (h8 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (fact_366edf150095_3212 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n089_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_3211 a b jx jy))
    (h1 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + ((2 : Int) * b))) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_6096 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7788 a b) ∨ (fact_366edf150095_7787 a b))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7788 a b) ∧ (fact_366edf150095_7787 a b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7788 a b) ∧ (fact_366edf150095_7787 a b) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6088 a b) ∨ (fact_366edf150095_6604 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6082 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6555 a b) ∨ (fact_366edf150095_7180 a b)))) ∨ ((fact_366edf150095_7788 a b) ∧ (fact_366edf150095_7787 a b) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6088 a b) ∨ (fact_366edf150095_6604 a b) ∨ ((((((5 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((5 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6082 a b) ∨ (fact_366edf150095_6601 a b) ∨ (fact_366edf150095_6555 a b) ∨ (fact_366edf150095_7180 a b))))))
    (h1 : (a ≥ b))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h1 : (((((5 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3005 a b run_x) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n090_run_floor (a b run_x : Int)
    (h0 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h1 : (((((5 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3587 a b run_x) ∨ ((((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7814 a b) ∨ (fact_366edf150095_7846 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7814 a b) ∧ (fact_366edf150095_7846 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7814 a b) ∧ (fact_366edf150095_7846 a b) ∧ (((((((-1 : Int) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int)))))) ∨ ((((((-1 : Int) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int)))))))) ∨ ((fact_366edf150095_7814 a b) ∧ (fact_366edf150095_7846 a b) ∧ ((((((-1 : Int) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int)))))) ∧ ((((((-1 : Int) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((2 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((3 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ ((((5 : Int) + a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))))))))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (((((5 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((4 : Int) < (((3 : Int) + a) - a)) ∨ ((4 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h7 : ((((((-1 : Int) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) * a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ ((((5 : Int) + a) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-((-4 : Int) + ((-1 : Int) * a)))) ∧ ((-((-4 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h8 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n091_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((0 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((1 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) * a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((4 : Int) ≥ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((5 : Int) + a) - a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ ((((5 : Int) + a) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((5 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-4 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3512 a b) ∨ (fact_366edf150095_3482 a b) ∨ (fact_366edf150095_5817 a b) ∨ (fact_366edf150095_5819 a b) ∨ (fact_366edf150095_3484 a b) ∨ (fact_366edf150095_4084 a b) ∨ (fact_366edf150095_3485 a b) ∨ (fact_366edf150095_5820 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4095 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((fact_366edf150095_4209 a b) ∨ (fact_366edf150095_4090 a b) ∨ (fact_366edf150095_6120 a b) ∨ (fact_366edf150095_6121 a b) ∨ (fact_366edf150095_4091 a b) ∨ (fact_366edf150095_5103 a b) ∨ (fact_366edf150095_4092 a b) ∨ (fact_366edf150095_6122 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5105 a b))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7507 a b) ∨ (fact_366edf150095_7581 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7507 a b) ∧ (fact_366edf150095_7581 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7507 a b) ∧ (fact_366edf150095_7581 a b) ∧ (((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4995 a b)) ∨ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5677 a b)))) ∨ ((fact_366edf150095_7507 a b) ∧ (fact_366edf150095_7581 a b) ∧ ((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4995 a b)) ∧ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5677 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_2349 a b run_x) ∨ (fact_366edf150095_3624 a b run_x) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3051 a b run_x)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n092_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3313 a b run_x) ∨ (fact_366edf150095_5228 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3596 a b run_x))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3501 a b) ∨ (fact_366edf150095_3450 a b) ∨ (fact_366edf150095_5777 a b) ∨ (fact_366edf150095_5785 a b) ∨ (fact_366edf150095_3458 a b) ∨ (fact_366edf150095_3696 a b) ∨ (fact_366edf150095_3465 a b) ∨ (fact_366edf150095_5792 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3706 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6963 a b) ∨ (fact_366edf150095_6951 a b) ∨ (fact_366edf150095_7268 a b) ∨ (fact_366edf150095_7270 a b) ∨ (fact_366edf150095_6953 a b) ∨ (fact_366edf150095_7009 a b) ∨ (fact_366edf150095_6954 a b) ∨ (fact_366edf150095_7275 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_7020 a b))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7418 a b) ∨ (fact_366edf150095_7758 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7418 a b) ∧ (fact_366edf150095_7758 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7418 a b) ∧ (fact_366edf150095_7758 a b) ∧ (((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4378 a b)) ∨ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_7202 a b)))) ∨ ((fact_366edf150095_7418 a b) ∧ (fact_366edf150095_7758 a b) ∧ ((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4378 a b)) ∧ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_7202 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_2970 a b run_x)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n093_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h3 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3550 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_point (a b : Int)
    (h0 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_11 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_empty (a b : Int)
    (h0 : ((fact_366edf150095_3233 a b) ∨ (fact_366edf150095_3167 a b) ∨ (fact_366edf150095_5093 a b) ∨ (fact_366edf150095_5095 a b) ∨ (fact_366edf150095_3169 a b) ∨ (fact_366edf150095_3424 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((3 : Int) ≥ ((4 : Int) - b)) ∧ ((3 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (fact_366edf150095_1800 a b jx jy))
    (h7 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1805 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1809 a b jx jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_366edf150095_2954 a b jy))
    (h7 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - b))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o3 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1812 a b jx jy))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o4 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (fact_366edf150095_1813 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o5 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (fact_366edf150095_1808 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_366edf150095_1804 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n094_o7 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : (fact_366edf150095_1801 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((4 : Int) + a) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ (((4 : Int) + a) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((((-1 : Int) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((4 : Int) + a)) ∧ ((-1 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ ((((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((jx - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o1 (a b jx jy : Int)
    (h0 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((jx - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((jx - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jx < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jx) ∨ ((jy + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((((jx - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (a = (b + (2 : Int))))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o4 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((jx - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((jx - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h9 : ((jx < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jx) ∨ ((jy + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h11 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h12 : (a = (b + (2 : Int))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((((jx - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n095_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((jx - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2906 a b) ∨ (fact_366edf150095_2578 a b) ∨ (fact_366edf150095_4067 a b) ∨ (fact_366edf150095_4072 a b) ∨ (fact_366edf150095_2581 a b) ∨ (fact_366edf150095_3181 a b) ∨ (fact_366edf150095_2583 a b) ∨ (fact_366edf150095_4074 a b) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o0 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((5 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_366edf150095_2953 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h10 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o3 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h2 : (¬ (((jx = ((5 : Int) + b)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : (fact_366edf150095_2952 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o5 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h5 : (¬ (((jx = ((5 : Int) + a)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h2 : (¬ ((((5 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n096_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((5 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (fact_366edf150095_2955 a b jy))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_366edf150095_5 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_empty (a b : Int)
    (h0 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((fact_366edf150095_3227 a b) ∨ (fact_366edf150095_3133 a b) ∨ (fact_366edf150095_4223 a b) ∨ (fact_366edf150095_4312 a b) ∨ (fact_366edf150095_3141 a b) ∨ (fact_366edf150095_3358 a b) ∨ (fact_366edf150095_3146 a b) ∨ (fact_366edf150095_4318 a b) ∨ (fact_366edf150095_3150 a b) ∨ (fact_366edf150095_3155 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b))))))
    (h5 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_1830 a b jx jy))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1837 a b jx jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o2 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (fact_366edf150095_1857 a b jx jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o3 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1872 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1873 a b jx jy))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1856 a b jx jy))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (fact_366edf150095_1836 a b jx jy))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n097_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_1831 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2909 a b) ∨ (fact_366edf150095_2589 a b) ∨ (fact_366edf150095_4082 a b) ∨ (fact_366edf150095_4087 a b) ∨ (fact_366edf150095_2592 a b) ∨ (fact_366edf150095_3194 a b) ∨ (fact_366edf150095_2594 a b) ∨ (fact_366edf150095_4089 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o0 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (¬ ((((6 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) + a)) ∨ (((5 : Int) + a) < jy)))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_366edf150095_2953 a b jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((6 : Int) + b)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_2952 a b jy))
    (h2 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jx = ((6 : Int) + a)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n098_o7 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (¬ ((((6 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_point (a b : Int)
    (h0 : (fact_366edf150095_5 a b))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_3227 a b) ∨ (fact_366edf150095_3133 a b) ∨ (fact_366edf150095_4223 a b) ∨ (fact_366edf150095_4312 a b) ∨ (fact_366edf150095_3141 a b) ∨ (fact_366edf150095_3358 a b) ∨ (fact_366edf150095_3146 a b) ∨ (fact_366edf150095_4318 a b) ∨ (fact_366edf150095_3150 a b) ∨ (fact_366edf150095_3155 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((4 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b))))))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1830 a b jx jy))
    (h1 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o1 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_1837 a b jx jy))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_366edf150095_1857 a b jx jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o3 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_366edf150095_1872 a b jx jy))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_1873 a b jx jy))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_1856 a b jx jy))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1836 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n099_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1831 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_tall (a b : Int)
    (h0 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7596 a b) ∨ (fact_366edf150095_7658 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7596 a b) ∧ (fact_366edf150095_7658 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7596 a b) ∧ (fact_366edf150095_7658 a b) ∧ (((fact_366edf150095_4177 a b) ∨ (fact_366edf150095_3772 a b) ∨ (fact_366edf150095_5923 a b) ∨ (fact_366edf150095_6006 a b) ∨ (fact_366edf150095_3853 a b) ∨ (fact_366edf150095_4286 a b) ∨ (fact_366edf150095_3906 a b) ∨ (fact_366edf150095_6058 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4008 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4400 a b)) ∨ ((((((-1 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((6 : Int) + b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7596 a b) ∧ (fact_366edf150095_7658 a b) ∧ ((fact_366edf150095_4177 a b) ∨ (fact_366edf150095_3772 a b) ∨ (fact_366edf150095_5923 a b) ∨ (fact_366edf150095_6006 a b) ∨ (fact_366edf150095_3853 a b) ∨ (fact_366edf150095_4286 a b) ∨ (fact_366edf150095_3906 a b) ∨ (fact_366edf150095_6058 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4008 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4400 a b)) ∧ ((((((-1 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((6 : Int) + b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_2336 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n100_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3336 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((6 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_point (a b : Int)
    (h0 : (fact_366edf150095_5 a b))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_empty (a b : Int)
    (h0 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : ((fact_366edf150095_3227 a b) ∨ (fact_366edf150095_3133 a b) ∨ (fact_366edf150095_4223 a b) ∨ (fact_366edf150095_4312 a b) ∨ (fact_366edf150095_3141 a b) ∨ (fact_366edf150095_3358 a b) ∨ (fact_366edf150095_3146 a b) ∨ (fact_366edf150095_4318 a b) ∨ (fact_366edf150095_3150 a b) ∨ (fact_366edf150095_3155 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) + a)) ∧ ((4 : Int) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((4 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o0 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1830 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o1 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1837 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o2 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1857 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o3 (a b jx jy : Int)
    (h0 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h7 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (fact_366edf150095_1872 a b jx jy))
    (h11 : (a = (b + (2 : Int))))
    (h12 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_366edf150095_1873 a b jx jy))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h3 : (fact_366edf150095_1856 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_1836 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n101_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_366edf150095_1831 a b jx jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3515 a b) ∨ (fact_366edf150095_3490 a b) ∨ (fact_366edf150095_5823 a b) ∨ (fact_366edf150095_5826 a b) ∨ (fact_366edf150095_3493 a b) ∨ (fact_366edf150095_4099 a b) ∨ (fact_366edf150095_3494 a b) ∨ (fact_366edf150095_5827 a b) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4108 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((7 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((7 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a > b))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7599 a b) ∨ (fact_366edf150095_7660 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7599 a b) ∧ (fact_366edf150095_7660 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7599 a b) ∧ (fact_366edf150095_7660 a b) ∧ (((fact_366edf150095_4181 a b) ∨ (fact_366edf150095_3776 a b) ∨ (fact_366edf150095_5927 a b) ∨ (fact_366edf150095_6010 a b) ∨ (fact_366edf150095_3857 a b) ∨ (fact_366edf150095_4290 a b) ∨ (fact_366edf150095_3908 a b) ∨ (fact_366edf150095_6060 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4011 a b) ∨ (fact_366edf150095_5014 a b) ∨ (fact_366edf150095_5047 a b)) ∨ ((((((-1 : Int) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((7 : Int) + a)) ∧ ((-1 : Int) ≥ ((7 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((7 : Int) + a)) ∧ ((0 : Int) ≥ ((7 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((7 : Int) + a)) ∧ ((1 : Int) ≥ ((7 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ ((7 : Int) + a)) ∧ ((6 : Int) ≥ ((7 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7599 a b) ∧ (fact_366edf150095_7660 a b) ∧ ((fact_366edf150095_4181 a b) ∨ (fact_366edf150095_3776 a b) ∨ (fact_366edf150095_5927 a b) ∨ (fact_366edf150095_6010 a b) ∨ (fact_366edf150095_3857 a b) ∨ (fact_366edf150095_4290 a b) ∨ (fact_366edf150095_3908 a b) ∨ (fact_366edf150095_6060 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4011 a b) ∨ (fact_366edf150095_5014 a b) ∨ (fact_366edf150095_5047 a b)) ∧ ((((((-1 : Int) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((7 : Int) + a)) ∧ ((-1 : Int) ≥ ((7 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((7 : Int) + a)) ∧ ((0 : Int) ≥ ((7 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((7 : Int) + a)) ∧ ((1 : Int) ≥ ((7 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((5 : Int) + a) - a) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ ((7 : Int) + a)) ∧ ((6 : Int) ≥ ((7 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ (fact_366edf150095_2354 a b run_x) ∨ (fact_366edf150095_3627 a b run_x) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3057 a b run_x)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n102_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((4 : Int) + b)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (fact_366edf150095_3314 a b run_x) ∨ (fact_366edf150095_5229 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3606 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((-1 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7489 a b) ∨ (fact_366edf150095_7559 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7489 a b) ∧ (fact_366edf150095_7559 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7489 a b) ∧ (fact_366edf150095_7559 a b) ∧ (((fact_366edf150095_4162 a b) ∨ (fact_366edf150095_3757 a b) ∨ (fact_366edf150095_5908 a b) ∨ (fact_366edf150095_5991 a b) ∨ (fact_366edf150095_3838 a b) ∨ (fact_366edf150095_4271 a b) ∨ (fact_366edf150095_3895 a b) ∨ (fact_366edf150095_6047 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3990 a b) ∨ (fact_366edf150095_4392 a b)) ∨ ((fact_366edf150095_5124 a b) ∨ (fact_366edf150095_4418 a b) ∨ (fact_366edf150095_6343 a b) ∨ (fact_366edf150095_6431 a b) ∨ (fact_366edf150095_4502 a b) ∨ (fact_366edf150095_5252 a b) ∨ (fact_366edf150095_4584 a b) ∨ (fact_366edf150095_6513 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7489 a b) ∧ (fact_366edf150095_7559 a b) ∧ ((fact_366edf150095_4162 a b) ∨ (fact_366edf150095_3757 a b) ∨ (fact_366edf150095_5908 a b) ∨ (fact_366edf150095_5991 a b) ∨ (fact_366edf150095_3838 a b) ∨ (fact_366edf150095_4271 a b) ∨ (fact_366edf150095_3895 a b) ∨ (fact_366edf150095_6047 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3990 a b) ∨ (fact_366edf150095_4392 a b)) ∧ ((fact_366edf150095_5124 a b) ∨ (fact_366edf150095_4418 a b) ∨ (fact_366edf150095_6343 a b) ∨ (fact_366edf150095_6431 a b) ∨ (fact_366edf150095_4502 a b) ∨ (fact_366edf150095_5252 a b) ∨ (fact_366edf150095_4584 a b) ∨ (fact_366edf150095_6513 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_2336 a b run_x) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((5 : Int) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n103_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3336 a b run_x) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_point (a b : Int)
    (h0 : (fact_366edf150095_11 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_366edf150095_3233 a b) ∨ (fact_366edf150095_3167 a b) ∨ (fact_366edf150095_5093 a b) ∨ (fact_366edf150095_5095 a b) ∨ (fact_366edf150095_3169 a b) ∨ (fact_366edf150095_3424 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a)))) ∨ ((((3 : Int) ≥ ((5 : Int) - b)) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_366edf150095_1800 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h8 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h9 : (((jx + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h10 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    (h15 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1805 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - a))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o2 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - b))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_1809 a b jx jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - b))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o3 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_366edf150095_1812 a b jx jy))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o4 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - a))))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jy - a))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (fact_366edf150095_1813 a b jx jy))
    (h8 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - a))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1808 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1804 a b jx jy))
    (h1 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h2 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n104_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1801 a b jx jy))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h6 : (fact_366edf150095_2955 a b jy))
    (h7 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - b))))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_5 a b))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_empty (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((fact_366edf150095_3227 a b) ∨ (fact_366edf150095_3133 a b) ∨ (fact_366edf150095_4223 a b) ∨ (fact_366edf150095_4312 a b) ∨ (fact_366edf150095_3141 a b) ∨ (fact_366edf150095_3358 a b) ∨ (fact_366edf150095_3146 a b) ∨ (fact_366edf150095_4318 a b) ∨ (fact_366edf150095_3150 a b) ∨ (fact_366edf150095_3155 a b) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b))))))
    (h2 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1830 a b jx jy))
    (h2 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_1837 a b jx jy))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1857 a b jx jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o3 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1872 a b jx jy))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (a ≥ (5 : Int)))
    (h12 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1873 a b jx jy))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_1856 a b jx jy))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h10 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h11 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h12 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h13 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1836 a b jx jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n105_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1831 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_point (a b : Int)
    (h0 : (fact_366edf150095_5 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_empty (a b : Int)
    (h0 : ((fact_366edf150095_3227 a b) ∨ (fact_366edf150095_3133 a b) ∨ (fact_366edf150095_4223 a b) ∨ (fact_366edf150095_4312 a b) ∨ (fact_366edf150095_3141 a b) ∨ (fact_366edf150095_3358 a b) ∨ (fact_366edf150095_3146 a b) ∨ (fact_366edf150095_4318 a b) ∨ (fact_366edf150095_3150 a b) ∨ (fact_366edf150095_3155 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a))))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o0 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_1830 a b jx jy))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1837 a b jx jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1857 a b jx jy))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (fact_366edf150095_1872 a b jx jy))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h4 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1873 a b jx jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (fact_366edf150095_1856 a b jx jy))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ (5 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_1836 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n106_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h6 : (fact_366edf150095_1831 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_left (a b : Int)
    (h0 : (¬ (((((6 : Int) ≥ ((-1 : Int) - a)) ∧ ((6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((6 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((6 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) * a)) ∧ ((6 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((6 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((6 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((6 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_right (a b : Int)
    (h0 : (¬ (((((6 : Int) ≥ ((-1 : Int) - a)) ∧ ((6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((6 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((6 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((6 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((2 : Int) * a)) ∧ ((6 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((6 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((6 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((6 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7490 a b) ∨ (fact_366edf150095_7562 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7490 a b) ∧ (fact_366edf150095_7562 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7490 a b) ∧ (fact_366edf150095_7562 a b) ∧ (((fact_366edf150095_4166 a b) ∨ (fact_366edf150095_3761 a b) ∨ (fact_366edf150095_5912 a b) ∨ (fact_366edf150095_5995 a b) ∨ (fact_366edf150095_3842 a b) ∨ (fact_366edf150095_4275 a b) ∨ (fact_366edf150095_3898 a b) ∨ (fact_366edf150095_6050 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3994 a b) ∨ (fact_366edf150095_4996 a b)) ∨ ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7490 a b) ∧ (fact_366edf150095_7562 a b) ∧ ((fact_366edf150095_4166 a b) ∨ (fact_366edf150095_3761 a b) ∨ (fact_366edf150095_5912 a b) ∨ (fact_366edf150095_5995 a b) ∨ (fact_366edf150095_3842 a b) ∨ (fact_366edf150095_4275 a b) ∨ (fact_366edf150095_3898 a b) ∨ (fact_366edf150095_6050 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3994 a b) ∨ (fact_366edf150095_4996 a b)) ∧ ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((((5 : Int) + b) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ ((4 : Int) + b)))
    (h4 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_2349 a b run_x) ∨ (fact_366edf150095_3624 a b run_x) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n107_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3313 a b run_x) ∨ (fact_366edf150095_5228 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3510 a b) ∨ (fact_366edf150095_3477 a b) ∨ (fact_366edf150095_5812 a b) ∨ (fact_366edf150095_5814 a b) ∨ (fact_366edf150095_3479 a b) ∨ (fact_366edf150095_4069 a b) ∨ (fact_366edf150095_3480 a b) ∨ (fact_366edf150095_5815 a b) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4079 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4208 a b) ∨ (fact_366edf150095_4075 a b) ∨ (fact_366edf150095_6117 a b) ∨ (fact_366edf150095_6118 a b) ∨ (fact_366edf150095_4076 a b) ∨ (fact_366edf150095_5099 a b) ∨ (fact_366edf150095_4077 a b) ∨ (fact_366edf150095_6119 a b) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5101 a b))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7420 a b) ∨ (fact_366edf150095_7458 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7420 a b) ∧ (fact_366edf150095_7458 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7420 a b) ∧ (fact_366edf150095_7458 a b) ∧ (((fact_366edf150095_4151 a b) ∨ (fact_366edf150095_3746 a b) ∨ (fact_366edf150095_5897 a b) ∨ (fact_366edf150095_5980 a b) ∨ (fact_366edf150095_3827 a b) ∨ (fact_366edf150095_4260 a b) ∨ (fact_366edf150095_3887 a b) ∨ (fact_366edf150095_6039 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4878 a b)) ∨ ((fact_366edf150095_5175 a b) ∨ (fact_366edf150095_4469 a b) ∨ (fact_366edf150095_6394 a b) ∨ (fact_366edf150095_6482 a b) ∨ (fact_366edf150095_4553 a b) ∨ (fact_366edf150095_5303 a b) ∨ (fact_366edf150095_4618 a b) ∨ (fact_366edf150095_6537 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5598 a b)))) ∨ ((fact_366edf150095_7420 a b) ∧ (fact_366edf150095_7458 a b) ∧ ((fact_366edf150095_4151 a b) ∨ (fact_366edf150095_3746 a b) ∨ (fact_366edf150095_5897 a b) ∨ (fact_366edf150095_5980 a b) ∨ (fact_366edf150095_3827 a b) ∨ (fact_366edf150095_4260 a b) ∨ (fact_366edf150095_3887 a b) ∨ (fact_366edf150095_6039 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4878 a b)) ∧ ((fact_366edf150095_5175 a b) ∨ (fact_366edf150095_4469 a b) ∨ (fact_366edf150095_6394 a b) ∨ (fact_366edf150095_6482 a b) ∨ (fact_366edf150095_4553 a b) ∨ (fact_366edf150095_5303 a b) ∨ (fact_366edf150095_4618 a b) ∨ (fact_366edf150095_6537 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5598 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ (fact_366edf150095_2346 a b run_x) ∨ (fact_366edf150095_3621 a b run_x) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3044 a b run_x)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n108_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (fact_366edf150095_3312 a b run_x) ∨ (fact_366edf150095_5227 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3583 a b run_x))))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_empty (a b : Int)
    (h0 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o0 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o3 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o4 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o5 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jx = ((4 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o6 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n109_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2905 a b) ∨ (fact_366edf150095_2577 a b) ∨ (fact_366edf150095_4066 a b) ∨ (fact_366edf150095_4071 a b) ∨ (fact_366edf150095_2580 a b) ∨ (fact_366edf150095_3180 a b) ∨ (fact_366edf150095_2582 a b) ∨ (fact_366edf150095_4073 a b) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o1 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o3 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (¬ (((jx = ((5 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (¬ (((jx = ((5 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n110_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_366edf150095_2955 a b jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ (4 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_short (a b : Int)
    (h0 : (¬ (((4 : Int) - (4 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((4 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((4 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n111_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((4 : Int) ≥ ((4 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7734 a b) ∨ (fact_366edf150095_7733 a b))) ∨ (((4 : Int) ≥ ((4 : Int) + (2 : Int))) ∧ (fact_366edf150095_7734 a b) ∧ (fact_366edf150095_7733 a b)) ∨ ((4 : Int) ≥ ((4 : Int) + (4 : Int))) ∨ (((4 : Int) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7734 a b) ∧ (fact_366edf150095_7733 a b) ∧ (((fact_366edf150095_6581 a b) ∨ (fact_366edf150095_6223 a b) ∨ (fact_366edf150095_7078 a b) ∨ (fact_366edf150095_7112 a b) ∨ (fact_366edf150095_6253 a b) ∨ (fact_366edf150095_6767 a b) ∨ (fact_366edf150095_6271 a b) ∨ (fact_366edf150095_7131 a b) ∨ (fact_366edf150095_6820 a b) ∨ (fact_366edf150095_6306 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6576 a b) ∨ (fact_366edf150095_6218 a b) ∨ (fact_366edf150095_7073 a b) ∨ (fact_366edf150095_7107 a b) ∨ (fact_366edf150095_6248 a b) ∨ (fact_366edf150095_6762 a b) ∨ (fact_366edf150095_6268 a b) ∨ (fact_366edf150095_7128 a b) ∨ (fact_366edf150095_6816 a b) ∨ (fact_366edf150095_6300 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))))) ∨ ((fact_366edf150095_7734 a b) ∧ (fact_366edf150095_7733 a b) ∧ ((fact_366edf150095_6581 a b) ∨ (fact_366edf150095_6223 a b) ∨ (fact_366edf150095_7078 a b) ∨ (fact_366edf150095_7112 a b) ∨ (fact_366edf150095_6253 a b) ∨ (fact_366edf150095_6767 a b) ∨ (fact_366edf150095_6271 a b) ∨ (fact_366edf150095_7131 a b) ∨ (fact_366edf150095_6820 a b) ∨ (fact_366edf150095_6306 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6576 a b) ∨ (fact_366edf150095_6218 a b) ∨ (fact_366edf150095_7073 a b) ∨ (fact_366edf150095_7107 a b) ∨ (fact_366edf150095_6248 a b) ∨ (fact_366edf150095_6762 a b) ∨ (fact_366edf150095_6268 a b) ∨ (fact_366edf150095_7128 a b) ∨ (fact_366edf150095_6816 a b) ∨ (fact_366edf150095_6300 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

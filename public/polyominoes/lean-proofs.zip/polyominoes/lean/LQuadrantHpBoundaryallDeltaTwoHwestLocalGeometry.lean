import LQuadrantHpBoundaryallDeltaTwoHwestLocalArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_delta_two_hwest_local_M (a b : Int) : Int := 6*(a+b+1)
def HP_boundaryall_delta_two_hwest_local_Box (a b x y : Int) : Prop := -HP_boundaryall_delta_two_hwest_local_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_delta_two_hwest_local_M a b ∧ y≤HP_boundaryall_delta_two_hwest_local_M a b
def HP_boundaryall_delta_two_hwest_local_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_boundaryall_delta_two_hwest_local_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o0 a b jx jy (hb) (hit) (hlong) (sep1).2.1 (sep2).2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o1 a b jx jy (hit) (hb) (sep2).2.2.1 (sep1).2.2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o2 a b jx jy (sep2).2.1 (insideT) (hlong) (hexception) (hit) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o3 a b jx jy (insideT) (hlong) (sep3).2.2.2 (sep2).2.1 (sep0).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o4 a b jx jy (hlong) (hit) (sep2).2.2.1 (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o5 a b jx jy (sep0).2.1 (ap1_3).2.2.1 (sep3).2.1 (hlong) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o6 a b jx jy (hb) (hit) (hlong) (sep2).2.2.1 (sep3).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n002_o7 a b jx jy (hb) (ap1_3).2.2.1 (sep0).2.1 (hlong) (sep3).2.1 (hit)

theorem HP_boundaryall_delta_two_hwest_local_node036 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o0 a b jx jy (hb) (hlong) (sep0).2.2.1 (sep1).2.1 (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o1 a b jx jy (sep2).2.2.1 (insideT) (sep1).2.2.1 (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o2 a b jx jy (hb) (hit) (insideT) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o3 a b jx jy (sep3).2.2.1 (sep0).2.2.1 (hit) (hlong) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o4 a b jx jy (insideT) (hlong) (hit) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o5 a b jx jy (sep1).1 (hlong) (hb) (hit) (insideT) (sep3).2.1 (sep1).2.1 (sep0).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o6 a b jx jy (insideT) (hdelta_two) (hb) (sep3).2.2.1 (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n036_o7 a b jx jy (insideT) (hit) (hlong) (sep1).2.1 (hb) (sep3).1

theorem HP_boundaryall_delta_two_hwest_local_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_point a b (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o0 a b jx jy (hdelta_two) (sep1).2.2.1 (hit) (hlong) (sep2).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o1 a b jx jy (insideT) (hb) (sep2).1 (hit) (sep1).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o2 a b jx jy (insideT) (sep2).2.1 (sep2).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o3 a b jx jy (insideT) (sep0).2.1 (hit) (hlong) (sep2).2.1 (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node002 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o4 a b jx jy (hb) (sep2).2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o5 a b jx jy (sep0).2.1 (hit) (sep1).2.1 (hb) (insideT) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o6 a b jx jy (hlong) (hb) (hit) (sep1).2.2.1 (sep0).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n001_o7 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb) (insideT) (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node036 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_boundaryall_delta_two_hwest_local_node072 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o0 a b jx jy (hb) (hit) (sep1).2.1 (hlong) (sep0).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o1 a b jx jy (hb) (sep3).2.2.1 (hit) (insideT) (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o2 a b jx jy (hit) (hdelta_two) (hlong) (insideT) (hexception) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o3 a b jx jy (hit) (hb) (sep3).2.1 (sep2).2.1 (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o4 a b jx jy (hb) (sep3).2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o5 a b jx jy (hdelta_two) (hb) (sep3).2.1 (sep2).2.2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o6 a b jx jy (hb) (sep0).2.1 (sep2).2.1 (sep2).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n072_o7 a b jx jy (sep2).2.1 (hdelta_two) (hit) (sep0).2.1 (hlong)

theorem HP_boundaryall_delta_two_hwest_local_node074 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o0 a b jx jy (hb) (sep1).2.1 (hlong) (sep0).1 (insideT) (hit) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o1 a b jx jy (hit) (sep4).1 (insideT) (hlong) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o2 a b jx jy (sep4).2.1 (sep1).2.1 (hit) (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o3 a b jx jy (sep2).2.1 (sep2).1 (insideT) (hb) (hlong) (sep4).2.1 (hit) (sep1).1 (sep0).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o4 a b jx jy (hit) (sep4).2.1 (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o5 a b jx jy (hlong) (insideT) (hb) (sep1).2.1 (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o6 a b jx jy (hlong) (sep2).2.1 (hit) (sep2).2.2.1 (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n074_o7 a b jx jy (sep0).2.1 (hb) (sep4).2.2.1 (sep2).2.1 (hlong) (hit) (sep2).2.2.1

theorem HP_boundaryall_delta_two_hwest_local_node076 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_empty a b ((by simpa only [Contains] using occupied)) (ap0_3).2.2.1 (hlong) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o0 a b jx jy (hlong) (hit) (hb) (sep1).2.1 (sep2).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o1 a b jx jy (sep2).2.1 (hit) (sep5).1 (hlong) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o2 a b jx jy (insideT) (hdelta_two) (hexception) (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o3 a b jx jy (sep1).1 (sep0).1 (hb) (sep2).1 (sep2).2.1 (insideT) (hlong) (hit) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o4 a b jx jy (hit) (sep5).2.1 (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o5 a b jx jy (sep1).2.2.1 (hdelta_two) (sep5).2.1 (hb) (sep2).1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o6 a b jx jy (sep2).2.2.1 (hlong) (hit) (sep5).2.2.1 (sep5).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n076_o7 a b jx jy (hit) (hdelta_two) (sep2).2.1 (sep5).2.1 (hb)

theorem HP_boundaryall_delta_two_hwest_local_node075 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o0 a b jx jy (insideT) (hb) (hlong) (hit) (sep1).2.1 (sep0).1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o1 a b jx jy (hit) (insideT) (hb) (sep2).2.1 (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node076 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o2 a b jx jy (hb) (ap0_3).2.2.1 (hexception) (hlong) (insideT) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o3 a b jx jy (hlong) (sep2).2.1 (hb) (sep0).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o4 a b jx jy (hit) (hlong) (sep4).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o5 a b jx jy (sep1).2.1 (hit) (hlong) (sep0).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o6 a b jx jy (hlong) (hit) (sep4).2.1 (sep2).2.1 (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n075_o7 a b jx jy (sep2).2.1 (hdelta_two) (hb) (sep3).2.1 (hit)

theorem HP_boundaryall_delta_two_hwest_local_node073 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o0 a b jx jy (hit) (sep0).2.2.1 (hlong) (hb) (sep1).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o1 a b jx jy (hb) (insideT) (hit) (hlong) (sep2).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node074 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o2 a b jx jy (hlong) (insideT) (sep3).2.1 (hb) (ap0_3).2.2.1 (hexception) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o3 a b jx jy (hb) (sep3).2.1 (sep2).2.1 (sep2).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep2).2.2.1 (hlong) (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node075 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o5 a b jx jy (hlong) (sep0).2.1 (sep1).2.1 (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o6 a b jx jy (hit) (sep0).2.1 (sep2).2.2.1 (hlong) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n073_o7 a b jx jy (hb) (sep0).2.1 (hit) (hdelta_two) (sep2).2.1

theorem HP_boundaryall_delta_two_hwest_local_node078 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o0 a b jx jy (insideT) (sep0).1 (sep4).2.1 (hlong) (hit) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o1 a b jx jy (sep2).2.1 (hit) (hb) (sep4).1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o2 a b jx jy (hexception) (hdelta_two) (sep3).2.1 (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o3 a b jx jy (sep2).2.1 (hit) (sep4).2.1 (hlong) (sep1).1 (hb) (sep2).1 (sep0).1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o4 a b jx jy (hlong) (hit) (hb) (sep4).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o5 a b jx jy (hit) (sep2).2.1 (hdelta_two) (insideT) (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o6 a b jx jy (sep2).2.1 (sep4).2.1 (sep2).2.2.1 (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n078_o7 a b jx jy (hit) (hlong) (sep4).2.2.1 (sep4).2.1 (hb) (sep0).2.2.1 (sep2).2.1

theorem HP_boundaryall_delta_two_hwest_local_node077 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o0 a b jx jy (sep2).2.2.1 (hit) (sep0).2.1 (hb) (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (sep2).2.1 (hlong) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node078 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o2 a b jx jy (insideT) (hexception) (hdelta_two) (sep3).2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o3 a b jx jy (sep0).2.1 (sep2).2.1 (hlong) (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o4 a b jx jy (hit) (insideT) (hlong) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o5 a b jx jy (hb) (hlong) (sep1).2.1 (insideT) (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o6 a b jx jy (sep2).2.2.1 (sep2).2.1 (sep3).2.1 (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n077_o7 a b jx jy (hdelta_two) (hit) (sep0).2.1 (sep2).2.1 (hb)

theorem HP_boundaryall_delta_two_hwest_local_node059 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (1 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (1 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (1 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (1 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o0 a b jx jy (sep0).2.1 (hlong) (hb) (sep0).1 (sep1).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o1 a b jx jy (hb) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hlong) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node072 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o2 a b jx jy (sep2).2.2.1 (hit) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node073 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o3 a b jx jy (sep2).2.2.2 (sep0).2.1 (sep2).2.2.1 (hlong) (hdelta_two) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hb) (sep2).2.2.1 (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node077 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o5 a b jx jy (hlong) (sep0).2.1 (sep1).2.2.2 (hit) (hb) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o6 a b jx jy (hb) (sep2).2.1 (hlong) (hit) (sep0).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n059_o7 a b jx jy (sep2).2.1 (hlong) (hit) (hdelta_two) (hexception) (insideT)

theorem HP_boundaryall_delta_two_hwest_local_node092 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_point a b (hdelta_two) (ap1_4).2.2.1 (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o0 a b jx jy (hdelta_two) (ap1_4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o1 a b jx jy (ap1_4).2.2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o2 a b jx jy (hdelta_two) (ap1_4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o3 a b jx jy (hb) (hdelta_two) (ap1_4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o4 a b jx jy (ap1_4).2.2.1 (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o5 a b jx jy (hdelta_two) (ap1_4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o6 a b jx jy (hb) (ap1_4).2.2.1 (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n092_o7 a b jx jy (ap1_4).2.2.1 (hlong) (hdelta_two)

theorem HP_boundaryall_delta_two_hwest_local_node093 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o0 a b jx jy (hit) (sep1).2.1 (sep0).2.1 (hlong) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o1 a b jx jy (sep1).2.2.1 (hlong) (hb) (insideT) (sep3).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o2 a b jx jy (hit) (insideT) (hlong) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o3 a b jx jy (hdelta_two) (hlong) (sep4).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o4 a b jx jy (hit) (hlong) (sep3).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o5 a b jx jy (sep1).1 (sep0).1 (sep4).2.1 (hlong) (sep1).2.1 (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o6 a b jx jy (hlong) (hb) (hit) (sep4).2.1 (sep3).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n093_o7 a b jx jy (hit) (hlong) (insideT) (sep1).2.1 (hb) (sep4).2.2.1

theorem HP_boundaryall_delta_two_hwest_local_node080 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o0 a b jx jy (hlong) (hdelta_two) (sep1).2.2.1 (hit) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o1 a b jx jy (sep1).2.2.1 (hlong) (hb) (insideT) (sep3).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o2 a b jx jy (hit) (sep2).2.1 (sep3).2.2.1 (hlong) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o3 a b jx jy (hlong) (sep1).2.2.1 (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node092 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o4 a b jx jy (sep3).2.1 (hlong) (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o5 a b jx jy (hit) (sep0).2.1 (sep1).2.1 (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o6 a b jx jy (hb) (sep3).2.1 (sep3).2.2.1 (hlong) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n080_o7 a b jx jy (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node093 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_boundaryall_delta_two_hwest_local_node095 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o0 a b jx jy (hb) (sep1).2.1 (hit) (hlong) (sep0).2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o1 a b jx jy (hit) (sep4).2.2.1 (hlong) (sep3).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o2 a b jx jy (insideT) (hexception) (hdelta_two) (sep2).2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o3 a b jx jy (sep2).2.1 (insideT) (hlong) (hit) (sep0).2.1 (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o4 a b jx jy (sep4).2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o5 a b jx jy (hlong) (hit) (sep1).2.1 (hb) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o6 a b jx jy (hlong) (hb) (sep4).2.2.1 (hit) (sep3).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n095_o7 a b jx jy (hit) (sep3).2.1 (hb) (sep0).2.1 (hdelta_two)

theorem HP_boundaryall_delta_two_hwest_local_node097 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o0 a b jx jy (hb) (hit) (hlong) (sep1).2.1 (sep3).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o1 a b jx jy (hlong) (hit) (sep5).1 (hb) (insideT) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o2 a b jx jy (sep2).2.1 (hdelta_two) (hexception) (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o3 a b jx jy (hit) (sep3).1 (sep5).2.1 (insideT) (sep1).1 (sep0).1 (hlong) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o4 a b jx jy (sep5).2.1 (hlong) (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o5 a b jx jy (hlong) (ap1_3).2.2.1 (hit) (sep1).2.2.1 (sep3).2.1 (sep5).2.1 (sep3).1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o6 a b jx jy (sep5).2.2.1 (sep3).2.2.1 (hb) (hit) (sep5).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n097_o7 a b jx jy (hlong) (sep3).2.1 (hit) (hb) (sep0).2.1 (sep1).2.1 (sep5).2.2.1

theorem HP_boundaryall_delta_two_hwest_local_node096 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_point a b (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o0 a b jx jy (hlong) (sep1).2.1 (hb) (hit) (sep3).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o1 a b jx jy (sep3).2.1 (hlong) (insideT) (hit) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node097 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o2 a b jx jy (hexception) (insideT) (hdelta_two) (hit) (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o3 a b jx jy (insideT) (sep2).2.1 (hit) (sep0).2.1 (hlong) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o4 a b jx jy (hit) (hb) (insideT) (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o5 a b jx jy (sep1).2.1 (hb) (hlong) (hit) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o6 a b jx jy (hlong) (sep3).2.2.1 (sep2).2.1 (sep3).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n096_o7 a b jx jy (hit) (hb) (sep3).2.1 (hlong) (ap1_3).2.2.1 (sep0).2.1

theorem HP_boundaryall_delta_two_hwest_local_node094 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o0 a b jx jy (hit) (sep0).2.1 (sep1).2.1 (sep3).2.2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o1 a b jx jy (sep3).2.1 (hb) (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node095 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o2 a b jx jy (hit) (insideT) (sep2).2.1 (hexception) (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o3 a b jx jy (sep3).2.2.2 (hb) (sep2).2.1 (hlong) (insideT) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o4 a b jx jy (hlong) (hit) ((by simpa only [Same,eq_comm] using absent)) (hb) (sep3).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node096 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o5 a b jx jy (hlong) (hb) (sep0).2.1 (sep3).2.1 (insideT) (hit) (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o6 a b jx jy (hlong) (hit) (sep2).2.1 (sep3).2.1 (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n094_o7 a b jx jy (sep0).2.1 (ap1_3).2.2.1 (hit) (sep3).2.1 (hb) (hlong)

theorem HP_boundaryall_delta_two_hwest_local_node153 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_point a b (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o0 a b jx jy (hit) (hlong) (hb) (sep3).2.2.1 (sep4).2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o1 a b jx jy (hit) (insideT) (sep3).2.2.1 (sep4).1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o2 a b jx jy (hit) (hexception) (hlong) (hdelta_two) (insideT) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o3 a b jx jy (sep1).2.2.1 (sep3).2.1 (hlong) (sep1).2.1 (hdelta_two) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o4 a b jx jy (hb) (sep4).2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o5 a b jx jy (insideT) (hdelta_two) (hit) (sep0).2.1 (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o6 a b jx jy (hit) (hlong) (sep4).2.1 (sep4).2.2.1 (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n153_o7 a b jx jy (hlong) (sep1).2.1 (hit) (sep3).2.2.1 (sep0).2.1 (sep5).1 (hb)

theorem HP_boundaryall_delta_two_hwest_local_node152 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o0 a b jx jy (sep3).2.2.1 (hit) (hlong) (hb) (sep1).2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o1 a b jx jy (sep3).2.2.1 (insideT) (hit) (hb) (hlong) (sep4).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o2 a b jx jy (hit) (hdelta_two) (insideT) (hexception) (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o3 a b jx jy (sep4).2.1 (hlong) (sep1).2.2.1 (sep1).2.1 (hdelta_two) (sep3).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o4 a b jx jy (hb) (sep4).2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o5 a b jx jy (insideT) (hlong) (hit) (hb) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o6 a b jx jy (sep4).2.2.1 (sep3).2.2.1 (hb) (hlong) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n152_o7 a b jx jy (sep3).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (sep4).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node153 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_boundaryall_delta_two_hwest_local_node156 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (6 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (6 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_empty a b (hlong) (ap1_3).2.2.1 (hexception) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o0 a b jx jy (hlong) (hb) (hit) (sep1).2.1 (sep1).2.2.1 (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o1 a b jx jy (hdelta_two) (insideT) (sep5).1 (sep3).2.2.1 (sep1).2.2.2 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o2 a b jx jy (hexception) (insideT) (hit) (hdelta_two) (hlong) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o3 a b jx jy (sep6).2.2.1 (hit) (hlong) (hb) (sep1).2.2.1 (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o4 a b jx jy (hit) (hb) (hlong) (sep5).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o5 a b jx jy (hit) (sep1).2.1 (hb) (sep3).1 (hlong) (sep6).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o6 a b jx jy (hlong) (hdelta_two) (sep5).2.1 (hit) (hexception) (sep5).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n156_o7 a b jx jy (hexception) (hdelta_two) (sep6).1 (hit) (insideT) (sep3).2.2.1 (hb)

theorem HP_boundaryall_delta_two_hwest_local_node155 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o0 a b jx jy (hlong) (sep1).2.1 (hb) (hit) (sep3).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o1 a b jx jy (hlong) (hit) (hb) (sep3).2.2.1 (sep5).1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o2 a b jx jy (hit) (hb) (hlong) (sep1).2.1 (ap1_3).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o3 a b jx jy (sep1).2.2.1 (hdelta_two) (sep3).1 (hit) (sep1).2.1 (hb) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o4 a b jx jy (hit) (insideT) (hlong) (hb) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o5 a b jx jy (sep0).2.1 (sep1).2.1 (insideT) (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o6 a b jx jy (hlong) (sep5).2.2.1 (hit) (hb) (sep3).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n155_o7 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hdelta_two) (hit) (hb) (hexception) (sep3).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_boundaryall_delta_two_hwest_local_node156 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_boundaryall_delta_two_hwest_local_node157 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o0 a b jx jy (hlong) (sep3).2.2.1 (sep5).2.2.1 (hb) (hit) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o1 a b jx jy (insideT) (sep3).2.2.1 (ap1_3).2.2.1 (hb) (sep5).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o2 a b jx jy (hdelta_two) (hlong) (hexception) (sep5).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o3 a b jx jy (sep1).2.1 (sep3).2.1 (hdelta_two) (hit) (hlong) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o4 a b jx jy (hb) (hlong) (hit) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o5 a b jx jy (sep1).2.1 (sep5).2.1 (hlong) (sep3).1 (hb) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o6 a b jx jy (sep1).2.1 (sep4).2.1 (sep3).2.2.1 (hit) (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n157_o7 a b jx jy (sep3).2.2.1 (hb) (sep0).2.1 (sep1).2.1 (sep5).2.2.1 (hit) (hlong)

theorem HP_boundaryall_delta_two_hwest_local_node154 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o0 a b jx jy (hb) (sep1).2.1 (hit) (hlong) (sep3).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o1 a b jx jy (hlong) (hit) (insideT) (sep3).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node155 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o2 a b jx jy (insideT) (hexception) (hit) (sep4).2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o3 a b jx jy (sep3).2.2.1 (sep1).2.1 (hit) (hdelta_two) (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o4 a b jx jy (hlong) (insideT) (sep4).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o5 a b jx jy (sep4).2.1 (hit) (sep1).1 (hlong) (hb) (insideT) (sep3).1 (sep1).2.1 (sep0).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o6 a b jx jy (sep1).2.1 (hit) (sep3).2.2.1 (sep4).2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n154_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hdelta_two) (hb) (hit) (insideT) (sep3).2.2.1 (hexception)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node157 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_boundaryall_delta_two_hwest_local_node158 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o0 a b jx jy (sep3).2.1 (hlong) (sep1).2.1 (hb) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o1 a b jx jy (sep4).2.2.1 (sep3).2.2.1 (insideT) (hlong) (ap1_3).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o2 a b jx jy (hdelta_two) (hit) (sep4).2.1 (insideT) (hb) (hexception)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o3 a b jx jy (sep1).2.1 (sep3).2.1 (hlong) (hit) (hdelta_two) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o4 a b jx jy (sep4).2.1 (sep4).2.2.1 (insideT) (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o5 a b jx jy (insideT) (sep1).2.1 (sep0).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o6 a b jx jy (sep3).2.1 (sep1).2.1 (hdelta_two) (hb) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n158_o7 a b jx jy (hit) (sep3).2.2.1 (hlong) (sep4).1 (hb) (sep4).2.1

theorem HP_boundaryall_delta_two_hwest_local_node098 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o0 a b jx jy (sep3).2.1 (insideT) (sep1).2.1 (hb) (sep0).1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o1 a b jx jy (hlong) ((by simpa only [Same,eq_comm] using absent)) (hit) (sep3).2.2.1 (hb) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node152 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o2 a b jx jy (sep2).2.1 (hit) (hexception) (hlong) (hdelta_two) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o3 a b jx jy (sep1).2.2.2 (hit) (hlong) (sep3).2.1 (hdelta_two) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o4 a b jx jy (hb) (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node154 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o5 a b jx jy (hb) (sep0).2.1 (sep1).2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o6 a b jx jy (hit) (sep1).2.1 (hdelta_two) (sep3).2.1 (sep0).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n098_o7 a b jx jy (hb) (hit) (sep3).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node158 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_boundaryall_delta_two_hwest_local_node159 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o0 a b jx jy (hit) (sep0).2.1 (hlong) (hb) (sep1).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o1 a b jx jy (sep3).2.2.1 (hdelta_two) (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o2 a b jx jy (sep3).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o3 a b jx jy (hlong) (hdelta_two) (sep3).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o4 a b jx jy (hlong) (hb) (hit) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o5 a b jx jy (hlong) (sep1).2.1 (hit) (hb) (sep0).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o6 a b jx jy (sep3).2.1 (hdelta_two) (hit) (hlong) (sep0).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n159_o7 a b jx jy (sep3).2.2.1 (sep1).2.1 (hlong) (insideT) (hit) (hb)

theorem HP_boundaryall_delta_two_hwest_local_node079 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o0 a b jx jy (hb) (sep0).2.1 (hit) (hlong) (sep0).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o1 a b jx jy (sep1).2.2.1 (insideT) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node080 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o2 a b jx jy (hdelta_two) (sep2).2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o3 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hb) (sep0).2.1 (insideT) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node094 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o4 a b jx jy (insideT) (sep2).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o5 a b jx jy (hb) (hdelta_two) (hit) (insideT) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (sep2).2.1 (hlong) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node098 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n079_o7 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (sep1).2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node159 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_boundaryall_delta_two_hwest_local_node170 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o0 a b jx jy (hb) (sep0).2.2.1 (sep4).2.1 (sep1).2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o1 a b jx jy (sep4).2.2.1 (sep2).2.2.1 (hb) (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o2 a b jx jy (insideT) (hb) (sep4).2.1 (hdelta_two) (hexception) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o3 a b jx jy (hdelta_two) (hit) (sep1).2.2.1 (sep4).2.1 (hlong) (sep3).2.1 (sep2).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o4 a b jx jy (hit) (hb) (sep4).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o5 a b jx jy (hit) (sep0).2.1 (hb) (sep1).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o6 a b jx jy (hit) (hb) (sep2).2.2.1 (hlong) (sep4).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n170_o7 a b jx jy (sep3).2.1 (hit) (sep4).2.1 (sep4).2.2.1 (hlong)

theorem HP_boundaryall_delta_two_hwest_local_node172 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o0 a b jx jy (hb) (hit) (hlong) (sep2).2.2.1 (sep3).2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o1 a b jx jy (hlong) (hit) (sep5).1 (hb) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o2 a b jx jy (hdelta_two) (sep2).2.1 (insideT) (hexception) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o3 a b jx jy (sep1).2.2.1 (hlong) (hit) (sep2).1 (sep5).2.1 (hdelta_two) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o4 a b jx jy (sep5).2.1 (hlong) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o5 a b jx jy (sep0).2.1 (sep1).2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o6 a b jx jy (hlong) (hb) (sep5).2.2.1 (sep2).2.2.1 (sep5).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n172_o7 a b jx jy (sep5).2.1 (sep5).2.2.1 (hlong) (sep3).2.1 (hit)

theorem HP_boundaryall_delta_two_hwest_local_node171 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_point a b (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o0 a b jx jy (hit) (sep3).2.1 (sep2).2.2.1 (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o1 a b jx jy (hit) (hlong) (insideT) (sep2).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node172 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o2 a b jx jy (hexception) (hit) (sep4).2.1 (insideT) (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o3 a b jx jy (hit) (sep0).2.1 (hdelta_two) (sep1).2.2.2 (hb) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o4 a b jx jy (insideT) (sep4).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o5 a b jx jy (hb) (hit) (hlong) (sep0).2.1 (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o6 a b jx jy (sep3).2.1 (hit) (hdelta_two) (sep4).2.1 (hb) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n171_o7 a b jx jy (sep4).2.1 (hlong) (sep3).2.1 (hit) (ap2_3).2.1

theorem HP_boundaryall_delta_two_hwest_local_node169 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o0 a b jx jy (sep2).2.1 (hit) (hlong) (sep3).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hb) (hit) (hlong) (sep2).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node170 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o2 a b jx jy (hit) (sep2).2.1 (ap2_3).2.1 (hb) (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o3 a b jx jy (hit) (sep2).2.1 (hdelta_two) (sep3).2.2.2 (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o4 a b jx jy (sep2).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit) (insideT) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node171 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o5 a b jx jy (hb) (hlong) (hit) (insideT) (sep1).2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o6 a b jx jy (hdelta_two) (sep2).2.2.1 (sep3).2.1 (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n169_o7 a b jx jy (hlong) (sep2).2.1 (hdelta_two) (sep3).2.1 (hit)

theorem HP_boundaryall_delta_two_hwest_local_node173 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o0 a b jx jy (hit) (sep2).2.2.1 (hlong) (sep2).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o1 a b jx jy (sep3).2.2.1 (hdelta_two) (insideT) (hlong) (hit) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o2 a b jx jy (hit) (hexception) (hdelta_two) (insideT) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o3 a b jx jy (hit) (hdelta_two) (sep2).2.2.1 (sep3).2.2.2 (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o4 a b jx jy (sep3).2.2.1 (hdelta_two) (hit) (hlong) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o5 a b jx jy (hit) (hb) (hlong) (sep1).2.1 (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o6 a b jx jy (sep3).2.1 (hlong) (sep2).2.2.1 (hit) (sep2).2.1 (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n173_o7 a b jx jy (insideT) (hit) (hb) (hexception) (hdelta_two) (sep3).2.1

theorem HP_boundaryall_delta_two_hwest_local_node176 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o0 a b jx jy (hlong) (hb) (hit) (sep2).2.2.1 (sep4).2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o1 a b jx jy (sep4).2.2.1 (sep2).2.2.1 (hlong) (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o2 a b jx jy (hdelta_two) (hexception) (hit) (sep5).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o3 a b jx jy (sep5).2.2.1 (hb) (hit) (hdelta_two) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o4 a b jx jy (hb) (hit) (hlong) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o5 a b jx jy (sep0).1 (sep5).2.1 (insideT) (hit) (hlong) (sep1).2.1 (sep1).1 (hb) (sep2).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o6 a b jx jy (hb) (hit) (sep4).2.2.1 (hlong) (sep2).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n176_o7 a b jx jy (hit) (hlong) (hb) (sep5).2.2.1 (sep2).2.2.1 (sep5).2.1

theorem HP_boundaryall_delta_two_hwest_local_node175 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o0 a b jx jy (hit) (hlong) (sep2).2.2.1 (sep1).2.1 (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o1 a b jx jy (sep2).2.2.1 (sep4).2.2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o2 a b jx jy (insideT) (hdelta_two) (sep2).2.1 (hlong) (hexception) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o3 a b jx jy (hdelta_two) (hit) (sep3).2.1 (sep4).2.1 (hb) (sep0).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o4 a b jx jy (hlong) (hit) (hb) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o5 a b jx jy (hit) (hlong) (hb) (insideT) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o6 a b jx jy (sep4).2.2.1 (sep4).2.1 (sep2).2.2.1 (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n175_o7 a b jx jy (hit) (sep4).2.1 (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node176 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_boundaryall_delta_two_hwest_local_node179 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_point a b (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_empty a b (hb) (ap2_3).2.1 ((by simpa only [Contains] using occupied)) (hlong) (hexception)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o0 a b jx jy (hlong) (hb) (hit) (sep1).2.1 (sep1).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o1 a b jx jy (sep5).1 (hdelta_two) (sep3).2.2.2 (sep2).2.2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o2 a b jx jy (hexception) (insideT) (hit) (sep6).2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o3 a b jx jy (sep1).2.2.1 (hdelta_two) (sep6).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o4 a b jx jy (insideT) (sep5).2.1 (hlong) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o5 a b jx jy (hdelta_two) (sep0).2.1 (hb) (hit) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o6 a b jx jy (hexception) (hdelta_two) (sep5).2.2.1 (sep5).2.1 (hb) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n179_o7 a b jx jy (sep6).1 (hit) (sep6).2.1 (sep3).2.1 (hlong) (hb)

theorem HP_boundaryall_delta_two_hwest_local_node178 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o0 a b jx jy (hlong) (sep5).2.1 (sep2).2.2.1 (hit) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o1 a b jx jy (hit) (sep2).2.2.1 (sep5).1 (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o2 a b jx jy (insideT) (hit) (hexception) (hb) (sep2).2.1 (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o3 a b jx jy (sep5).2.1 (hit) (sep3).2.1 (hdelta_two) (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o4 a b jx jy (sep5).2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o5 a b jx jy (hit) (sep0).2.1 (sep1).2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o6 a b jx jy (hit) (sep5).2.1 (hlong) (sep2).2.2.1 (hb) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n178_o7 a b jx jy (sep5).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (hb) (sep2).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_boundaryall_delta_two_hwest_local_node179 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_boundaryall_delta_two_hwest_local_node180 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o0 a b jx jy (hlong) (hit) (sep1).2.1 (hb) (sep4).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o1 a b jx jy (hit) (sep5).2.2.1 (insideT) (hlong) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o2 a b jx jy (hexception) (hdelta_two) (sep5).2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o3 a b jx jy (hit) (hb) (sep5).2.2.1 (hdelta_two) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o4 a b jx jy (sep4).2.1 (hit) (hb) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o5 a b jx jy (sep1).2.1 (sep2).1 (sep1).1 (hlong) (hit) (sep5).2.1 (insideT) (hb) (sep0).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o6 a b jx jy (hdelta_two) (sep2).2.2.1 (sep4).2.1 (hb) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n180_o7 a b jx jy (hit) (hlong) (sep5).2.1 (hb) (sep2).2.2.1 (sep5).2.2.1

theorem HP_boundaryall_delta_two_hwest_local_node177 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o0 a b jx jy (hlong) (hit) (sep0).2.2.1 (sep4).2.1 (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (sep2).2.2.1 (hb) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node178 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o2 a b jx jy (hit) (hdelta_two) (hlong) (sep4).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o3 a b jx jy (hit) (sep4).2.1 (hdelta_two) (hlong) (sep2).1 (sep1).2.2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o4 a b jx jy (hit) (hlong) (sep4).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o5 a b jx jy (hlong) (insideT) (hit) (sep1).2.1 (hdelta_two) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o6 a b jx jy (sep3).2.1 (hdelta_two) (hit) (hb) (sep2).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n177_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hit) (sep2).2.2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_delta_two_hwest_local_node180 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_boundaryall_delta_two_hwest_local_node181 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_point a b (hb) ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o0 a b jx jy (hb) (hlong) (sep2).2.2.1 (hit) (sep1).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o1 a b jx jy (ap2_3).2.1 (sep4).2.2.1 (insideT) (hlong) (hit) (hb) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o2 a b jx jy (sep4).2.1 (hdelta_two) (hit) (hexception) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o3 a b jx jy (sep0).2.1 (hdelta_two) (hlong) (hit) (insideT) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o4 a b jx jy (hlong) (hb) (hit) (sep4).2.2.1 (sep4).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o5 a b jx jy (hlong) (sep0).2.1 (hit) (insideT) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o6 a b jx jy (hdelta_two) (sep3).2.1 (hit) (sep2).2.2.1 (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n181_o7 a b jx jy (hlong) (sep4).2.2.1 (sep0).2.1 (hit) (hb) (sep2).2.2.1

theorem HP_boundaryall_delta_two_hwest_local_node174 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o0 a b jx jy (sep2).2.1 (sep2).2.2.1 (hlong) (hb) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (hlong) (sep2).2.2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node175 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o2 a b jx jy (hit) (hb) (hdelta_two) (sep1).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o3 a b jx jy (sep2).2.2.1 (sep2).2.1 (hit) (sep3).2.2.1 (hb) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o4 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb) (sep2).2.1 (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node177 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o5 a b jx jy (hlong) (sep3).2.1 (insideT) (sep0).2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o6 a b jx jy (sep1).2.2.1 (sep2).2.1 (hit) (sep3).2.1 (hlong) (hdelta_two)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n174_o7 a b jx jy (hit) (sep2).2.1 (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_delta_two_hwest_local_node181 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_boundaryall_delta_two_hwest_local_node160 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2
  have support : HP_boundaryall_delta_two_hwest_local_Box a b a (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) a (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) a (2 : Int) ∨ Contains (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) a (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hdelta_two)
  obtain ⟨t,ht,hit⟩ := cover a (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o0 a b jx jy (sep1).2.2.1 (sep0).2.2.2 (hb) (hlong) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk a ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o1 a b jx jy (insideT) (sep1).2.2.1 (hit) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node169 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o2 a b jx jy (hdelta_two) (insideT) (hit) (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o3 a b jx jy (hdelta_two) (sep1).2.1 (hit) (sep1).2.2.1 (sep2).1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk a ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o4 a b jx jy (insideT) (hlong) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node173 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o5 a b jx jy (insideT) (sep1).2.1 (hb) (hit) (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o6 a b jx jy (hdelta_two) (sep2).1 (sep1).2.1 (hb) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk a ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n160_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (sep1).2.1 (hb) (hlong) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_delta_two_hwest_local_node174 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_boundaryall_delta_two_hwest_local_node182 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o0 a b jx jy (sep1).2.2.1 (hit) (hb) (sep0).2.1 (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o1 a b jx jy (hdelta_two) (insideT) (hit) (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o2 a b jx jy (sep2).2.1 (hlong) (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o3 a b jx jy (hlong) (insideT) (hdelta_two) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o4 a b jx jy (insideT) (hit) (sep2).2.1 (hb) (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o5 a b jx jy (insideT) (sep0).2.1 (hlong) (hb) (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o6 a b jx jy (hdelta_two) (insideT) (hit) (sep2).2.1 (hb) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n182_o7 a b jx jy (sep2).1 (insideT) (hb) (sep1).2.1 (hlong) (hit)

theorem HP_boundaryall_delta_two_hwest_local_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have support : HP_boundaryall_delta_two_hwest_local_Box a b (1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_point a b ((by simpa only [HP_boundaryall_delta_two_hwest_local_Box,HP_boundaryall_delta_two_hwest_local_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (2 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o0 a b jx jy (sep0).2.1 (hb) (hlong) (hit) (sep1).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (hit) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_delta_two_hwest_local_node001 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o2 a b jx jy (insideT) (hit) (sep0).2.1 (hdelta_two) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((1 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o3 a b jx jy (hit) (insideT) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_delta_two_hwest_local_node059 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep1).2.2.1 (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_delta_two_hwest_local_node079 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o5 a b jx jy (sep1).2.2.2 (hit) (sep0).2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o6 a b jx jy (sep0).2.1 (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_delta_two_hwest_local_node160 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (1 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_delta_two_hwest_local_n000_o7 a b jx jy (hb) (sep1).2.1 (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_delta_two_hwest_local_node182 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover separate ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)

theorem HP_boundaryall_delta_two_hwest_local_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_delta_two_hwest_local_Inside t)
    (cover : ∀ x y, HP_boundaryall_delta_two_hwest_local_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_delta_two_hwest_local_node000 a b ha hb hstrict hlong hdelta_two hexception world copies inside cover sep anchor0 anchor1 rootap0_1

theorem HP_boundaryall_delta_two_hwest_local_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  apply HP_boundaryall_delta_two_hwest_local_bounded_obstruction a b ha hb hstrict hlong hdelta_two hexception T.world T.copies ?_ ?_ T.disjoint anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_delta_two_hwest_local_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hdelta_two : (a = (b + (2 : Int))))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_delta_two_hwest_local_anchored_obstruction a b ha hb hstrict hlong hdelta_two hexception U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_delta_two_hwest_local_no_shifted_anchor
#print axioms HP_boundaryall_delta_two_hwest_local_bounded_obstruction
end PolyominoFormal.LRegion

import LQuadrantHpEqualTipLongGeometry
import LQuadrantHpUnequalTipShortGeometry
import LQuadrantHpShortlongTipShortGeometry
import TilingSymmetry
import PositiveHierarchy

namespace PolyominoFormal.LRegion
open CrossUnits

private theorem hp_inside {a b : Int} (ha : 0≤a) (hb : 0≤b)
    (T : Tiling a b 0 0 HalfPlane) (t : Cross) (ht : T.world t) :
    0≤t.y-t.south := by
  have nn := TPlane.copy_nonnegative ha hb (by omega) (by omega) (T.copies t ht)
  rcases nn with ⟨he,hn,hw,hs⟩
  apply T.inside t ht t.x (t.y-t.south)
  right
  exact ⟨by omega, by omega, by omega, by omega⟩

theorem equal_no_right_tip (a p : Int) (ha : 3≤a)
    (T : Tiling a a 0 0 HalfPlane) : ¬T.world ⟨p,a,a,0,0,a⟩ := by
  intro anchor
  let U : Tiling a a 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have shifted : U.world ⟨0,a,a,0,0,a⟩ := by
    refine ⟨_,anchor,?_⟩
    have cancel : p + -p = 0 := by omega
    simp only [shift,cancel,Int.add_zero]
  exact HP_equal_tip_long_bounded_obstruction a a (by omega) ha rfl
    U.world U.copies (fun t ht => hp_inside (by omega) (by omega) U t ht)
    (fun x y h => U.cover x y h.2.1) U.disjoint shifted

theorem equal_no_left_tip (a p : Int) (ha : 3≤a)
    (T : Tiling a a 0 0 HalfPlane) : ¬T.world ⟨p,a,0,0,a,a⟩ := by
  intro anchor
  apply equal_no_right_tip a (-p) ha T.mirrorX
  exact ⟨_,anchor,rfl⟩

theorem unequal_no_right_short_tip (a b p : Int)
    (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) : ¬T.world ⟨p,b,a,0,0,b⟩ := by
  intro anchor
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have shifted : U.world ⟨0,b,a,0,0,b⟩ := by
    refine ⟨_,anchor,?_⟩
    have cancel : p + -p = 0 := by omega
    simp only [shift,cancel,Int.add_zero]
  exact HP_unequal_tip_short_bounded_obstruction a b (by omega) hb hab ha
    U.world U.copies (fun t ht => hp_inside (by omega) (by omega) U t ht)
    (fun x y h => U.cover x y h.2.1) U.disjoint shifted

theorem unequal_no_left_short_tip (a b p : Int)
    (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) : ¬T.world ⟨p,b,0,0,a,b⟩ := by
  intro anchor
  apply unequal_no_right_short_tip a b (-p) hb hab ha T.mirrorX
  exact ⟨_,anchor,rfl⟩

/-- Either horizontal orientation of a tile whose short vertical leg ends on
    the boundary. For equal arms this excludes every boundary-tip tile. -/
def ForbiddenShortTip (a b : Int) (t : Cross) : Prop :=
  t.y=b ∧ t.north=0 ∧ t.south=b ∧
  ((t.east=a ∧ t.west=0) ∨ (t.east=0 ∧ t.west=a))

theorem equal_avoid_tips (a : Int) (ha : 3≤a)
    (T : Tiling a a 0 0 HalfPlane) :
    ∀ t, T.world t → ¬ForbiddenShortTip a a t := by
  rintro ⟨p,y,e,n,w,s⟩ ht ⟨hy,hn,hs,arms⟩
  dsimp only at hy hn hs arms
  subst y; subst n; subst s
  rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
  · subst e; subst w; exact equal_no_right_tip a p ha T ht
  · subst e; subst w; exact equal_no_left_tip a p ha T ht

theorem unequal_avoid_short_tips (a b : Int)
    (hb : 3≤b) (hab : b<a) (ha : 5≤a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀ t, T.world t → ¬ForbiddenShortTip a b t := by
  rintro ⟨p,y,e,n,w,s⟩ ht ⟨hy,hn,hs,arms⟩
  dsimp only at hy hn hs arms
  subst y; subst n; subst s
  rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
  · subst e; subst w; exact unequal_no_right_short_tip a b p hb hab ha T ht
  · subst e; subst w; exact unequal_no_left_short_tip a b p hb hab ha T ht

theorem shortlong_no_right_short_tip (a p : Int) (ha : 5≤a)
    (T : Tiling a 2 0 0 HalfPlane) : ¬T.world ⟨p,2,a,0,0,2⟩ := by
  intro anchor
  apply HP_shortlong_tip_short_no_shifted_anchor a 2 p (by omega) (by omega) rfl ha T
  simpa only [shift,Int.zero_add,Int.add_zero] using anchor

theorem shortlong_no_left_short_tip (a p : Int) (ha : 5≤a)
    (T : Tiling a 2 0 0 HalfPlane) : ¬T.world ⟨p,2,0,0,a,2⟩ := by
  intro anchor
  apply shortlong_no_right_short_tip a (-p) ha T.mirrorX
  exact ⟨_,anchor,rfl⟩

theorem shortlong_avoid_short_tips (a : Int) (ha : 5≤a)
    (T : Tiling a 2 0 0 HalfPlane) :
    ∀ t, T.world t → ¬ForbiddenShortTip a 2 t := by
  rintro ⟨p,y,e,n,w,s⟩ ht ⟨hy,hn,hs,arms⟩
  dsimp only at hy hn hs arms
  subst y; subst n; subst s
  rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
  · subst e; subst w; exact shortlong_no_right_short_tip a p ha T ht
  · subst e; subst w; exact shortlong_no_left_short_tip a p ha T ht

def ForbiddenShortTipBoth (a b : Int) (t : Cross) : Prop :=
  ForbiddenShortTip a b t ∨ ForbiddenShortTip a b (transpose t)

theorem shortlong_quadrant_avoid_short_tips (a : Int) (ha : 5≤a)
    (T : Tiling a 2 0 0 Quadrant) :
    ∀ t, T.world t → ¬ForbiddenShortTipBoth a 2 t := by
  intro t ht bad
  rcases bad with horizontal | vertical
  · exact shortlong_avoid_short_tips a ha (PositiveHierarchy.quadrantToHalfPlane T)
      t (Or.inl ht) horizontal
  · let U : Tiling a 2 0 0 Quadrant := T.transpose.congr (by
      intro x y; unfold Quadrant; omega)
    have member : U.world (transpose t) := ⟨t,ht,rfl⟩
    exact shortlong_avoid_short_tips a ha (PositiveHierarchy.quadrantToHalfPlane U)
      (transpose t) (Or.inl member) vertical

#print axioms equal_avoid_tips
#print axioms unequal_avoid_short_tips
#print axioms shortlong_avoid_short_tips
#print axioms shortlong_quadrant_avoid_short_tips
end PolyominoFormal.LRegion

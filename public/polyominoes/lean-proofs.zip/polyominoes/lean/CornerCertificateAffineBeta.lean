import CornerCertificateAffineBetaGeometry

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

section AffineBeta
variable (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include ha copies separate cover ceiling in
theorem affine_beta_node149 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known149 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known149 a) ((1 : Int),(2 : Int)) (affine_beta_branches149 a) copies separate cover ceiling
    (affine_beta_nonnegative149 a ha) (affine_beta_window149 a ha world h B state)
    (affine_beta_empty149 a ha) (affine_beta_complete149 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node148 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known148 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known148 a) ((1 : Int),(2 : Int)) (affine_beta_branches148 a) copies separate cover ceiling
    (affine_beta_nonnegative148 a ha) (affine_beta_window148 a ha world h B state)
    (affine_beta_empty148 a ha) (affine_beta_complete148 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node147 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known147 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known147 a) ((2 : Int),(2 : Int)) (affine_beta_branches147 a) copies separate cover ceiling
    (affine_beta_nonnegative147 a ha) (affine_beta_window147 a ha world h B state)
    (affine_beta_empty147 a ha) (affine_beta_complete147 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node146 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known146 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known146 a) ((2 : Int),(2 : Int)) (affine_beta_branches146 a) copies separate cover ceiling
    (affine_beta_nonnegative146 a ha) (affine_beta_window146 a ha world h B state)
    (affine_beta_empty146 a ha) (affine_beta_complete146 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node145 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known145 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known145 a) ((1 : Int),(2 : Int)) (affine_beta_branches145 a) copies separate cover ceiling
    (affine_beta_nonnegative145 a ha) (affine_beta_window145 a ha world h B state)
    (affine_beta_empty145 a ha) (affine_beta_complete145 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known145,affine_beta_known146,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known145,affine_beta_known147,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node146 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node147 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node144 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known144 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known144 a) ((0 : Int),(2 : Int)) (affine_beta_branches144 a) copies separate cover ceiling
    (affine_beta_nonnegative144 a ha) (affine_beta_window144 a ha world h B state)
    (affine_beta_empty144 a ha) (affine_beta_complete144 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known144,affine_beta_known145,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known144,affine_beta_known148,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known144,affine_beta_known149,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node145 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node148 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node149 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node143 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known143 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known143 a) ((1 : Int),(0 : Int)) (affine_beta_branches143 a) copies separate cover ceiling
    (affine_beta_nonnegative143 a ha) (affine_beta_window143 a ha world h B state)
    (affine_beta_empty143 a ha) (affine_beta_complete143 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known143,affine_beta_known144,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node144 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node142 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known142 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known142 a) ((1 : Int),(0 : Int)) (affine_beta_branches142 a) copies separate cover ceiling
    (affine_beta_nonnegative142 a ha) (affine_beta_window142 a ha world h B state)
    (affine_beta_empty142 a ha) (affine_beta_complete142 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node141 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known141 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known141 a) ((1 : Int),(4 : Int)) (affine_beta_branches141 a) copies separate cover ceiling
    (affine_beta_nonnegative141 a ha) (affine_beta_window141 a ha world h B state)
    (affine_beta_empty141 a ha) (affine_beta_complete141 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node140 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known140 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known140 a) ((2 : Int),(2 : Int)) (affine_beta_branches140 a) copies separate cover ceiling
    (affine_beta_nonnegative140 a ha) (affine_beta_window140 a ha world h B state)
    (affine_beta_empty140 a ha) (affine_beta_complete140 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known140,affine_beta_known141,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node141 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node139 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known139 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known139 a) ((2 : Int),(2 : Int)) (affine_beta_branches139 a) copies separate cover ceiling
    (affine_beta_nonnegative139 a ha) (affine_beta_window139 a ha world h B state)
    (affine_beta_empty139 a ha) (affine_beta_complete139 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node138 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known138 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known138 a) ((1 : Int),(4 : Int)) (affine_beta_branches138 a) copies separate cover ceiling
    (affine_beta_nonnegative138 a ha) (affine_beta_window138 a ha world h B state)
    (affine_beta_empty138 a ha) (affine_beta_complete138 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node137 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known137 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known137 a) ((2 : Int),(2 : Int)) (affine_beta_branches137 a) copies separate cover ceiling
    (affine_beta_nonnegative137 a ha) (affine_beta_window137 a ha world h B state)
    (affine_beta_empty137 a ha) (affine_beta_complete137 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known137,affine_beta_known138,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node138 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node136 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known136 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known136 a) ((1 : Int),(5 : Int)) (affine_beta_branches136 a) copies separate cover ceiling
    (affine_beta_nonnegative136 a ha) (affine_beta_window136 a ha world h B state)
    (affine_beta_empty136 a ha) (affine_beta_complete136 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node135 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known135 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known135 a) ((1 : Int),(5 : Int)) (affine_beta_branches135 a) copies separate cover ceiling
    (affine_beta_nonnegative135 a ha) (affine_beta_window135 a ha world h B state)
    (affine_beta_empty135 a ha) (affine_beta_complete135 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node134 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known134 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known134 a) ((3 : Int),(2 : Int)) (affine_beta_branches134 a) copies separate cover ceiling
    (affine_beta_nonnegative134 a ha) (affine_beta_window134 a ha world h B state)
    (affine_beta_empty134 a ha) (affine_beta_complete134 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known134,affine_beta_known135,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known134,affine_beta_known136,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node135 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node136 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node133 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known133 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known133 a) ((1 : Int),(5 : Int)) (affine_beta_branches133 a) copies separate cover ceiling
    (affine_beta_nonnegative133 a ha) (affine_beta_window133 a ha world h B state)
    (affine_beta_empty133 a ha) (affine_beta_complete133 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node132 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known132 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known132 a) ((1 : Int),(5 : Int)) (affine_beta_branches132 a) copies separate cover ceiling
    (affine_beta_nonnegative132 a ha) (affine_beta_window132 a ha world h B state)
    (affine_beta_empty132 a ha) (affine_beta_complete132 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node131 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known131 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known131 a) ((3 : Int),(2 : Int)) (affine_beta_branches131 a) copies separate cover ceiling
    (affine_beta_nonnegative131 a ha) (affine_beta_window131 a ha world h B state)
    (affine_beta_empty131 a ha) (affine_beta_complete131 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known131,affine_beta_known132,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known131,affine_beta_known133,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node132 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node133 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node130 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known130 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known130 a) ((1 : Int),(4 : Int)) (affine_beta_branches130 a) copies separate cover ceiling
    (affine_beta_nonnegative130 a ha) (affine_beta_window130 a ha world h B state)
    (affine_beta_empty130 a ha) (affine_beta_complete130 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known130,affine_beta_known131,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known130,affine_beta_known134,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node131 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node134 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node129 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known129 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf129 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node128 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known128 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known128 a) ((1 : Int),(3 : Int)) (affine_beta_branches128 a) copies separate cover ceiling
    (affine_beta_nonnegative128 a ha) (affine_beta_window128 a ha world h B state)
    (affine_beta_empty128 a ha) (affine_beta_complete128 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known128,affine_beta_known129,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known128,affine_beta_known130,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known128,affine_beta_known137,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known128,affine_beta_known139,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known128,affine_beta_known140,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node129 a ha world h nextB nextState
    · exact affine_beta_node130 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node137 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node139 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node140 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node127 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known127 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf127 a ha world h B state
include ha in
theorem affine_beta_node126 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known126 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf126 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node125 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known125 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known125 a) ((0 : Int),(2 : Int)) (affine_beta_branches125 a) copies separate cover ceiling
    (affine_beta_nonnegative125 a ha) (affine_beta_window125 a ha world h B state)
    (affine_beta_empty125 a ha) (affine_beta_complete125 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known125,affine_beta_known126,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known125,affine_beta_known127,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known125,affine_beta_known128,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node126 a ha world h nextB nextState
    · exact affine_beta_node127 a ha world h nextB nextState
    · exact affine_beta_node128 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node124 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known124 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known124 a) ((1 : Int),(0 : Int)) (affine_beta_branches124 a) copies separate cover ceiling
    (affine_beta_nonnegative124 a ha) (affine_beta_window124 a ha world h B state)
    (affine_beta_empty124 a ha) (affine_beta_complete124 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known124,affine_beta_known125,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node125 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node123 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known123 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known123 a) ((1 : Int),(3 : Int)) (affine_beta_branches123 a) copies separate cover ceiling
    (affine_beta_nonnegative123 a ha) (affine_beta_window123 a ha world h B state)
    (affine_beta_empty123 a ha) (affine_beta_complete123 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node122 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known122 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known122 a) ((1 : Int),(3 : Int)) (affine_beta_branches122 a) copies separate cover ceiling
    (affine_beta_nonnegative122 a ha) (affine_beta_window122 a ha world h B state)
    (affine_beta_empty122 a ha) (affine_beta_complete122 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node121 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known121 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known121 a) ((2 : Int),(3 : Int)) (affine_beta_branches121 a) copies separate cover ceiling
    (affine_beta_nonnegative121 a ha) (affine_beta_window121 a ha world h B state)
    (affine_beta_empty121 a ha) (affine_beta_complete121 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node120 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known120 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known120 a) ((2 : Int),(3 : Int)) (affine_beta_branches120 a) copies separate cover ceiling
    (affine_beta_nonnegative120 a ha) (affine_beta_window120 a ha world h B state)
    (affine_beta_empty120 a ha) (affine_beta_complete120 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node119 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known119 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known119 a) ((1 : Int),(3 : Int)) (affine_beta_branches119 a) copies separate cover ceiling
    (affine_beta_nonnegative119 a ha) (affine_beta_window119 a ha world h B state)
    (affine_beta_empty119 a ha) (affine_beta_complete119 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known119,affine_beta_known120,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known119,affine_beta_known121,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node120 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node121 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node118 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known118 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known118 a) ((0 : Int),(3 : Int)) (affine_beta_branches118 a) copies separate cover ceiling
    (affine_beta_nonnegative118 a ha) (affine_beta_window118 a ha world h B state)
    (affine_beta_empty118 a ha) (affine_beta_complete118 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known118,affine_beta_known119,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known118,affine_beta_known122,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known118,affine_beta_known123,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node119 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node122 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node123 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node117 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known117 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known117 a) ((1 : Int),(3 : Int)) (affine_beta_branches117 a) copies separate cover ceiling
    (affine_beta_nonnegative117 a ha) (affine_beta_window117 a ha world h B state)
    (affine_beta_empty117 a ha) (affine_beta_complete117 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node116 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known116 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known116 a) ((1 : Int),(3 : Int)) (affine_beta_branches116 a) copies separate cover ceiling
    (affine_beta_nonnegative116 a ha) (affine_beta_window116 a ha world h B state)
    (affine_beta_empty116 a ha) (affine_beta_complete116 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node115 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known115 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known115 a) ((2 : Int),(3 : Int)) (affine_beta_branches115 a) copies separate cover ceiling
    (affine_beta_nonnegative115 a ha) (affine_beta_window115 a ha world h B state)
    (affine_beta_empty115 a ha) (affine_beta_complete115 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node114 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known114 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known114 a) ((2 : Int),(3 : Int)) (affine_beta_branches114 a) copies separate cover ceiling
    (affine_beta_nonnegative114 a ha) (affine_beta_window114 a ha world h B state)
    (affine_beta_empty114 a ha) (affine_beta_complete114 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node113 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known113 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known113 a) ((1 : Int),(3 : Int)) (affine_beta_branches113 a) copies separate cover ceiling
    (affine_beta_nonnegative113 a ha) (affine_beta_window113 a ha world h B state)
    (affine_beta_empty113 a ha) (affine_beta_complete113 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known113,affine_beta_known114,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known113,affine_beta_known115,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node114 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node115 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node112 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known112 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known112 a) ((0 : Int),(3 : Int)) (affine_beta_branches112 a) copies separate cover ceiling
    (affine_beta_nonnegative112 a ha) (affine_beta_window112 a ha world h B state)
    (affine_beta_empty112 a ha) (affine_beta_complete112 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known112,affine_beta_known113,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known112,affine_beta_known116,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known112,affine_beta_known117,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node113 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node116 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node117 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node111 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known111 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known111 a) ((2 : Int),(0 : Int)) (affine_beta_branches111 a) copies separate cover ceiling
    (affine_beta_nonnegative111 a ha) (affine_beta_window111 a ha world h B state)
    (affine_beta_empty111 a ha) (affine_beta_complete111 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known111,affine_beta_known112,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known111,affine_beta_known118,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node112 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node118 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node110 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known110 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known110 a) ((1 : Int),(5 : Int)) (affine_beta_branches110 a) copies separate cover ceiling
    (affine_beta_nonnegative110 a ha) (affine_beta_window110 a ha world h B state)
    (affine_beta_empty110 a ha) (affine_beta_complete110 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node109 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known109 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known109 a) ((2 : Int),(3 : Int)) (affine_beta_branches109 a) copies separate cover ceiling
    (affine_beta_nonnegative109 a ha) (affine_beta_window109 a ha world h B state)
    (affine_beta_empty109 a ha) (affine_beta_complete109 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known109,affine_beta_known110,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node110 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node108 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known108 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known108 a) ((2 : Int),(3 : Int)) (affine_beta_branches108 a) copies separate cover ceiling
    (affine_beta_nonnegative108 a ha) (affine_beta_window108 a ha world h B state)
    (affine_beta_empty108 a ha) (affine_beta_complete108 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node107 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known107 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known107 a) ((1 : Int),(5 : Int)) (affine_beta_branches107 a) copies separate cover ceiling
    (affine_beta_nonnegative107 a ha) (affine_beta_window107 a ha world h B state)
    (affine_beta_empty107 a ha) (affine_beta_complete107 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node106 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known106 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known106 a) ((2 : Int),(3 : Int)) (affine_beta_branches106 a) copies separate cover ceiling
    (affine_beta_nonnegative106 a ha) (affine_beta_window106 a ha world h B state)
    (affine_beta_empty106 a ha) (affine_beta_complete106 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known106,affine_beta_known107,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node107 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node105 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known105 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known105 a) ((1 : Int),(6 : Int)) (affine_beta_branches105 a) copies separate cover ceiling
    (affine_beta_nonnegative105 a ha) (affine_beta_window105 a ha world h B state)
    (affine_beta_empty105 a ha) (affine_beta_complete105 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node104 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known104 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known104 a) ((1 : Int),(6 : Int)) (affine_beta_branches104 a) copies separate cover ceiling
    (affine_beta_nonnegative104 a ha) (affine_beta_window104 a ha world h B state)
    (affine_beta_empty104 a ha) (affine_beta_complete104 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node103 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known103 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known103 a) ((3 : Int),(3 : Int)) (affine_beta_branches103 a) copies separate cover ceiling
    (affine_beta_nonnegative103 a ha) (affine_beta_window103 a ha world h B state)
    (affine_beta_empty103 a ha) (affine_beta_complete103 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known103,affine_beta_known104,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known103,affine_beta_known105,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node104 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node105 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node102 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known102 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known102 a) ((1 : Int),(6 : Int)) (affine_beta_branches102 a) copies separate cover ceiling
    (affine_beta_nonnegative102 a ha) (affine_beta_window102 a ha world h B state)
    (affine_beta_empty102 a ha) (affine_beta_complete102 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node101 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known101 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known101 a) ((1 : Int),(6 : Int)) (affine_beta_branches101 a) copies separate cover ceiling
    (affine_beta_nonnegative101 a ha) (affine_beta_window101 a ha world h B state)
    (affine_beta_empty101 a ha) (affine_beta_complete101 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node100 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known100 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known100 a) ((3 : Int),(3 : Int)) (affine_beta_branches100 a) copies separate cover ceiling
    (affine_beta_nonnegative100 a ha) (affine_beta_window100 a ha world h B state)
    (affine_beta_empty100 a ha) (affine_beta_complete100 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known100,affine_beta_known101,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known100,affine_beta_known102,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node101 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node102 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node099 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known099 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known099 a) ((1 : Int),(5 : Int)) (affine_beta_branches099 a) copies separate cover ceiling
    (affine_beta_nonnegative099 a ha) (affine_beta_window099 a ha world h B state)
    (affine_beta_empty099 a ha) (affine_beta_complete099 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known099,affine_beta_known100,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known099,affine_beta_known103,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node100 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node103 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node098 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known098 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf098 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node097 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known097 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known097 a) ((1 : Int),(4 : Int)) (affine_beta_branches097 a) copies separate cover ceiling
    (affine_beta_nonnegative097 a ha) (affine_beta_window097 a ha world h B state)
    (affine_beta_empty097 a ha) (affine_beta_complete097 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known097,affine_beta_known098,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known097,affine_beta_known099,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known097,affine_beta_known106,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known097,affine_beta_known108,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known097,affine_beta_known109,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node098 a ha world h nextB nextState
    · exact affine_beta_node099 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node106 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node108 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node109 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node096 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known096 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf096 a ha world h B state
include ha in
theorem affine_beta_node095 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known095 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf095 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node094 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known094 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known094 a) ((0 : Int),(3 : Int)) (affine_beta_branches094 a) copies separate cover ceiling
    (affine_beta_nonnegative094 a ha) (affine_beta_window094 a ha world h B state)
    (affine_beta_empty094 a ha) (affine_beta_complete094 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known094,affine_beta_known095,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known094,affine_beta_known096,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known094,affine_beta_known097,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node095 a ha world h nextB nextState
    · exact affine_beta_node096 a ha world h nextB nextState
    · exact affine_beta_node097 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node093 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known093 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known093 a) ((1 : Int),(5 : Int)) (affine_beta_branches093 a) copies separate cover ceiling
    (affine_beta_nonnegative093 a ha) (affine_beta_window093 a ha world h B state)
    (affine_beta_empty093 a ha) (affine_beta_complete093 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node092 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known092 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known092 a) ((2 : Int),(3 : Int)) (affine_beta_branches092 a) copies separate cover ceiling
    (affine_beta_nonnegative092 a ha) (affine_beta_window092 a ha world h B state)
    (affine_beta_empty092 a ha) (affine_beta_complete092 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known092,affine_beta_known093,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node093 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node091 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known091 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known091 a) ((2 : Int),(3 : Int)) (affine_beta_branches091 a) copies separate cover ceiling
    (affine_beta_nonnegative091 a ha) (affine_beta_window091 a ha world h B state)
    (affine_beta_empty091 a ha) (affine_beta_complete091 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node090 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known090 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known090 a) ((1 : Int),(5 : Int)) (affine_beta_branches090 a) copies separate cover ceiling
    (affine_beta_nonnegative090 a ha) (affine_beta_window090 a ha world h B state)
    (affine_beta_empty090 a ha) (affine_beta_complete090 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node089 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known089 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known089 a) ((2 : Int),(3 : Int)) (affine_beta_branches089 a) copies separate cover ceiling
    (affine_beta_nonnegative089 a ha) (affine_beta_window089 a ha world h B state)
    (affine_beta_empty089 a ha) (affine_beta_complete089 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known089,affine_beta_known090,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_beta_node090 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node088 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known088 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known088 a) ((1 : Int),(6 : Int)) (affine_beta_branches088 a) copies separate cover ceiling
    (affine_beta_nonnegative088 a ha) (affine_beta_window088 a ha world h B state)
    (affine_beta_empty088 a ha) (affine_beta_complete088 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node087 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known087 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known087 a) ((1 : Int),(6 : Int)) (affine_beta_branches087 a) copies separate cover ceiling
    (affine_beta_nonnegative087 a ha) (affine_beta_window087 a ha world h B state)
    (affine_beta_empty087 a ha) (affine_beta_complete087 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node086 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known086 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known086 a) ((3 : Int),(3 : Int)) (affine_beta_branches086 a) copies separate cover ceiling
    (affine_beta_nonnegative086 a ha) (affine_beta_window086 a ha world h B state)
    (affine_beta_empty086 a ha) (affine_beta_complete086 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known086,affine_beta_known087,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known086,affine_beta_known088,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node087 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node088 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node085 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known085 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known085 a) ((1 : Int),(6 : Int)) (affine_beta_branches085 a) copies separate cover ceiling
    (affine_beta_nonnegative085 a ha) (affine_beta_window085 a ha world h B state)
    (affine_beta_empty085 a ha) (affine_beta_complete085 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node084 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known084 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known084 a) ((1 : Int),(6 : Int)) (affine_beta_branches084 a) copies separate cover ceiling
    (affine_beta_nonnegative084 a ha) (affine_beta_window084 a ha world h B state)
    (affine_beta_empty084 a ha) (affine_beta_complete084 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node083 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known083 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known083 a) ((3 : Int),(3 : Int)) (affine_beta_branches083 a) copies separate cover ceiling
    (affine_beta_nonnegative083 a ha) (affine_beta_window083 a ha world h B state)
    (affine_beta_empty083 a ha) (affine_beta_complete083 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known083,affine_beta_known084,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known083,affine_beta_known085,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node084 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node085 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node082 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known082 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known082 a) ((1 : Int),(5 : Int)) (affine_beta_branches082 a) copies separate cover ceiling
    (affine_beta_nonnegative082 a ha) (affine_beta_window082 a ha world h B state)
    (affine_beta_empty082 a ha) (affine_beta_complete082 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known082,affine_beta_known083,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known082,affine_beta_known086,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node083 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node086 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node081 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known081 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf081 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node080 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known080 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known080 a) ((1 : Int),(4 : Int)) (affine_beta_branches080 a) copies separate cover ceiling
    (affine_beta_nonnegative080 a ha) (affine_beta_window080 a ha world h B state)
    (affine_beta_empty080 a ha) (affine_beta_complete080 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known080,affine_beta_known081,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known080,affine_beta_known082,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known080,affine_beta_known089,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known080,affine_beta_known091,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known080,affine_beta_known092,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node081 a ha world h nextB nextState
    · exact affine_beta_node082 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node089 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node091 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node092 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node079 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known079 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf079 a ha world h B state
include ha in
theorem affine_beta_node078 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known078 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf078 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node077 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known077 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known077 a) ((0 : Int),(3 : Int)) (affine_beta_branches077 a) copies separate cover ceiling
    (affine_beta_nonnegative077 a ha) (affine_beta_window077 a ha world h B state)
    (affine_beta_empty077 a ha) (affine_beta_complete077 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known077,affine_beta_known078,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known077,affine_beta_known079,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known077,affine_beta_known080,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node078 a ha world h nextB nextState
    · exact affine_beta_node079 a ha world h nextB nextState
    · exact affine_beta_node080 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node076 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known076 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known076 a) ((2 : Int),(0 : Int)) (affine_beta_branches076 a) copies separate cover ceiling
    (affine_beta_nonnegative076 a ha) (affine_beta_window076 a ha world h B state)
    (affine_beta_empty076 a ha) (affine_beta_complete076 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known076,affine_beta_known077,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known076,affine_beta_known094,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node077 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node094 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node075 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known075 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known075 a) ((1 : Int),(3 : Int)) (affine_beta_branches075 a) copies separate cover ceiling
    (affine_beta_nonnegative075 a ha) (affine_beta_window075 a ha world h B state)
    (affine_beta_empty075 a ha) (affine_beta_complete075 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node074 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known074 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known074 a) ((1 : Int),(3 : Int)) (affine_beta_branches074 a) copies separate cover ceiling
    (affine_beta_nonnegative074 a ha) (affine_beta_window074 a ha world h B state)
    (affine_beta_empty074 a ha) (affine_beta_complete074 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches074,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches074,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node073 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known073 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known073 a) ((1 : Int),(2 : Int)) (affine_beta_branches073 a) copies separate cover ceiling
    (affine_beta_nonnegative073 a ha) (affine_beta_window073 a ha world h B state)
    (affine_beta_empty073 a ha) (affine_beta_complete073 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known073,affine_beta_known074,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known073,affine_beta_known075,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node074 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node075 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node072 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known072 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known072 a) ((1 : Int),(3 : Int)) (affine_beta_branches072 a) copies separate cover ceiling
    (affine_beta_nonnegative072 a ha) (affine_beta_window072 a ha world h B state)
    (affine_beta_empty072 a ha) (affine_beta_complete072 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node071 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known071 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known071 a) ((1 : Int),(3 : Int)) (affine_beta_branches071 a) copies separate cover ceiling
    (affine_beta_nonnegative071 a ha) (affine_beta_window071 a ha world h B state)
    (affine_beta_empty071 a ha) (affine_beta_complete071 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node070 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known070 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known070 a) ((1 : Int),(2 : Int)) (affine_beta_branches070 a) copies separate cover ceiling
    (affine_beta_nonnegative070 a ha) (affine_beta_window070 a ha world h B state)
    (affine_beta_empty070 a ha) (affine_beta_complete070 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known070,affine_beta_known071,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known070,affine_beta_known072,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node071 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node072 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node069 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known069 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known069 a) ((2 : Int),(0 : Int)) (affine_beta_branches069 a) copies separate cover ceiling
    (affine_beta_nonnegative069 a ha) (affine_beta_window069 a ha world h B state)
    (affine_beta_empty069 a ha) (affine_beta_complete069 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known069,affine_beta_known070,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known069,affine_beta_known073,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node070 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node073 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node068 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known068 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known068 a) ((2 : Int),(3 : Int)) (affine_beta_branches068 a) copies separate cover ceiling
    (affine_beta_nonnegative068 a ha) (affine_beta_window068 a ha world h B state)
    (affine_beta_empty068 a ha) (affine_beta_complete068 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node067 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known067 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known067 a) ((2 : Int),(3 : Int)) (affine_beta_branches067 a) copies separate cover ceiling
    (affine_beta_nonnegative067 a ha) (affine_beta_window067 a ha world h B state)
    (affine_beta_empty067 a ha) (affine_beta_complete067 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_beta_node066 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known066 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf066 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node065 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known065 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known065 a) ((4 : Int),(3 : Int)) (affine_beta_branches065 a) copies separate cover ceiling
    (affine_beta_nonnegative065 a ha) (affine_beta_window065 a ha world h B state)
    (affine_beta_empty065 a ha) (affine_beta_complete065 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node064 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known064 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known064 a) ((4 : Int),(3 : Int)) (affine_beta_branches064 a) copies separate cover ceiling
    (affine_beta_nonnegative064 a ha) (affine_beta_window064 a ha world h B state)
    (affine_beta_empty064 a ha) (affine_beta_complete064 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node063 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known063 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known063 a) ((3 : Int),(3 : Int)) (affine_beta_branches063 a) copies separate cover ceiling
    (affine_beta_nonnegative063 a ha) (affine_beta_window063 a ha world h B state)
    (affine_beta_empty063 a ha) (affine_beta_complete063 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known063,affine_beta_known064,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known063,affine_beta_known065,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node064 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node065 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node062 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known062 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known062 a) ((4 : Int),(3 : Int)) (affine_beta_branches062 a) copies separate cover ceiling
    (affine_beta_nonnegative062 a ha) (affine_beta_window062 a ha world h B state)
    (affine_beta_empty062 a ha) (affine_beta_complete062 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node061 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known061 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known061 a) ((4 : Int),(3 : Int)) (affine_beta_branches061 a) copies separate cover ceiling
    (affine_beta_nonnegative061 a ha) (affine_beta_window061 a ha world h B state)
    (affine_beta_empty061 a ha) (affine_beta_complete061 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node060 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known060 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known060 a) ((3 : Int),(3 : Int)) (affine_beta_branches060 a) copies separate cover ceiling
    (affine_beta_nonnegative060 a ha) (affine_beta_window060 a ha world h B state)
    (affine_beta_empty060 a ha) (affine_beta_complete060 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known060,affine_beta_known061,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known060,affine_beta_known062,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node061 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node062 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node059 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known059 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known059 a) ((1 : Int),(5 : Int)) (affine_beta_branches059 a) copies separate cover ceiling
    (affine_beta_nonnegative059 a ha) (affine_beta_window059 a ha world h B state)
    (affine_beta_empty059 a ha) (affine_beta_complete059 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known059,affine_beta_known060,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known059,affine_beta_known063,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node060 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node063 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node058 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known058 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known058 a) ((2 : Int),(3 : Int)) (affine_beta_branches058 a) copies separate cover ceiling
    (affine_beta_nonnegative058 a ha) (affine_beta_window058 a ha world h B state)
    (affine_beta_empty058 a ha) (affine_beta_complete058 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node057 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known057 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known057 a) ((2 : Int),(3 : Int)) (affine_beta_branches057 a) copies separate cover ceiling
    (affine_beta_nonnegative057 a ha) (affine_beta_window057 a ha world h B state)
    (affine_beta_empty057 a ha) (affine_beta_complete057 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node056 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known056 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known056 a) ((3 : Int),(3 : Int)) (affine_beta_branches056 a) copies separate cover ceiling
    (affine_beta_nonnegative056 a ha) (affine_beta_window056 a ha world h B state)
    (affine_beta_empty056 a ha) (affine_beta_complete056 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node055 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known055 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known055 a) ((3 : Int),(3 : Int)) (affine_beta_branches055 a) copies separate cover ceiling
    (affine_beta_nonnegative055 a ha) (affine_beta_window055 a ha world h B state)
    (affine_beta_empty055 a ha) (affine_beta_complete055 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node054 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known054 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known054 a) ((2 : Int),(3 : Int)) (affine_beta_branches054 a) copies separate cover ceiling
    (affine_beta_nonnegative054 a ha) (affine_beta_window054 a ha world h B state)
    (affine_beta_empty054 a ha) (affine_beta_complete054 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known054,affine_beta_known055,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known054,affine_beta_known056,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node055 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node056 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node053 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known053 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known053 a) ((1 : Int),(4 : Int)) (affine_beta_branches053 a) copies separate cover ceiling
    (affine_beta_nonnegative053 a ha) (affine_beta_window053 a ha world h B state)
    (affine_beta_empty053 a ha) (affine_beta_complete053 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known054,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known057,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known058,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known059,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known066,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known067,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known053,affine_beta_known068,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node054 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node057 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node058 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node059 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node066 a ha world h nextB nextState
    · exact affine_beta_node067 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node068 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node052 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known052 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf052 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node051 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known051 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known051 a) ((1 : Int),(2 : Int)) (affine_beta_branches051 a) copies separate cover ceiling
    (affine_beta_nonnegative051 a ha) (affine_beta_window051 a ha world h B state)
    (affine_beta_empty051 a ha) (affine_beta_complete051 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known051,affine_beta_known052,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known051,affine_beta_known053,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node052 a ha world h nextB nextState
    · exact affine_beta_node053 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node050 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known050 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known050 a) ((2 : Int),(3 : Int)) (affine_beta_branches050 a) copies separate cover ceiling
    (affine_beta_nonnegative050 a ha) (affine_beta_window050 a ha world h B state)
    (affine_beta_empty050 a ha) (affine_beta_complete050 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node049 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known049 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known049 a) ((2 : Int),(3 : Int)) (affine_beta_branches049 a) copies separate cover ceiling
    (affine_beta_nonnegative049 a ha) (affine_beta_window049 a ha world h B state)
    (affine_beta_empty049 a ha) (affine_beta_complete049 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_beta_node048 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known048 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf048 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node047 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known047 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known047 a) ((4 : Int),(3 : Int)) (affine_beta_branches047 a) copies separate cover ceiling
    (affine_beta_nonnegative047 a ha) (affine_beta_window047 a ha world h B state)
    (affine_beta_empty047 a ha) (affine_beta_complete047 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node046 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known046 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known046 a) ((4 : Int),(3 : Int)) (affine_beta_branches046 a) copies separate cover ceiling
    (affine_beta_nonnegative046 a ha) (affine_beta_window046 a ha world h B state)
    (affine_beta_empty046 a ha) (affine_beta_complete046 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node045 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known045 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known045 a) ((3 : Int),(3 : Int)) (affine_beta_branches045 a) copies separate cover ceiling
    (affine_beta_nonnegative045 a ha) (affine_beta_window045 a ha world h B state)
    (affine_beta_empty045 a ha) (affine_beta_complete045 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known045,affine_beta_known046,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known045,affine_beta_known047,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node046 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node047 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node044 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known044 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known044 a) ((4 : Int),(3 : Int)) (affine_beta_branches044 a) copies separate cover ceiling
    (affine_beta_nonnegative044 a ha) (affine_beta_window044 a ha world h B state)
    (affine_beta_empty044 a ha) (affine_beta_complete044 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node043 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known043 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known043 a) ((4 : Int),(3 : Int)) (affine_beta_branches043 a) copies separate cover ceiling
    (affine_beta_nonnegative043 a ha) (affine_beta_window043 a ha world h B state)
    (affine_beta_empty043 a ha) (affine_beta_complete043 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node042 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known042 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known042 a) ((3 : Int),(3 : Int)) (affine_beta_branches042 a) copies separate cover ceiling
    (affine_beta_nonnegative042 a ha) (affine_beta_window042 a ha world h B state)
    (affine_beta_empty042 a ha) (affine_beta_complete042 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known042,affine_beta_known043,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known042,affine_beta_known044,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node043 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node044 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node041 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known041 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known041 a) ((1 : Int),(5 : Int)) (affine_beta_branches041 a) copies separate cover ceiling
    (affine_beta_nonnegative041 a ha) (affine_beta_window041 a ha world h B state)
    (affine_beta_empty041 a ha) (affine_beta_complete041 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known041,affine_beta_known042,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known041,affine_beta_known045,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node042 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node045 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node040 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known040 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known040 a) ((2 : Int),(3 : Int)) (affine_beta_branches040 a) copies separate cover ceiling
    (affine_beta_nonnegative040 a ha) (affine_beta_window040 a ha world h B state)
    (affine_beta_empty040 a ha) (affine_beta_complete040 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node039 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known039 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known039 a) ((2 : Int),(3 : Int)) (affine_beta_branches039 a) copies separate cover ceiling
    (affine_beta_nonnegative039 a ha) (affine_beta_window039 a ha world h B state)
    (affine_beta_empty039 a ha) (affine_beta_complete039 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node038 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known038 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known038 a) ((3 : Int),(3 : Int)) (affine_beta_branches038 a) copies separate cover ceiling
    (affine_beta_nonnegative038 a ha) (affine_beta_window038 a ha world h B state)
    (affine_beta_empty038 a ha) (affine_beta_complete038 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node037 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known037 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known037 a) ((3 : Int),(3 : Int)) (affine_beta_branches037 a) copies separate cover ceiling
    (affine_beta_nonnegative037 a ha) (affine_beta_window037 a ha world h B state)
    (affine_beta_empty037 a ha) (affine_beta_complete037 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node036 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known036 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known036 a) ((2 : Int),(3 : Int)) (affine_beta_branches036 a) copies separate cover ceiling
    (affine_beta_nonnegative036 a ha) (affine_beta_window036 a ha world h B state)
    (affine_beta_empty036 a ha) (affine_beta_complete036 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known036,affine_beta_known037,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known036,affine_beta_known038,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node037 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node038 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node035 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known035 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known035 a) ((1 : Int),(4 : Int)) (affine_beta_branches035 a) copies separate cover ceiling
    (affine_beta_nonnegative035 a ha) (affine_beta_window035 a ha world h B state)
    (affine_beta_empty035 a ha) (affine_beta_complete035 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known036,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known039,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known040,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known041,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known048,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known049,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known035,affine_beta_known050,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node036 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node039 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node040 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node041 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node048 a ha world h nextB nextState
    · exact affine_beta_node049 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node050 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node034 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known034 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf034 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node033 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known033 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known033 a) ((1 : Int),(2 : Int)) (affine_beta_branches033 a) copies separate cover ceiling
    (affine_beta_nonnegative033 a ha) (affine_beta_window033 a ha world h B state)
    (affine_beta_empty033 a ha) (affine_beta_complete033 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known033,affine_beta_known034,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known033,affine_beta_known035,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node034 a ha world h nextB nextState
    · exact affine_beta_node035 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node032 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known032 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known032 a) ((2 : Int),(0 : Int)) (affine_beta_branches032 a) copies separate cover ceiling
    (affine_beta_nonnegative032 a ha) (affine_beta_window032 a ha world h B state)
    (affine_beta_empty032 a ha) (affine_beta_complete032 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known032,affine_beta_known033,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known032,affine_beta_known051,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node033 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node051 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node031 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known031 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf031 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node030 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known030 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known030 a) ((0 : Int),(2 : Int)) (affine_beta_branches030 a) copies separate cover ceiling
    (affine_beta_nonnegative030 a ha) (affine_beta_window030 a ha world h B state)
    (affine_beta_empty030 a ha) (affine_beta_complete030 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known030,affine_beta_known031,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known030,affine_beta_known032,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known030,affine_beta_known069,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known030,affine_beta_known076,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known030,affine_beta_known111,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node031 a ha world h nextB nextState
    · exact affine_beta_node032 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node069 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node076 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node111 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node029 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known029 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf029 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node028 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known028 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known028 a) ((1 : Int),(1 : Int)) (affine_beta_branches028 a) copies separate cover ceiling
    (affine_beta_nonnegative028 a ha) (affine_beta_window028 a ha world h B state)
    (affine_beta_empty028 a ha) (affine_beta_complete028 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node027 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known027 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known027 a) ((1 : Int),(2 : Int)) (affine_beta_branches027 a) copies separate cover ceiling
    (affine_beta_nonnegative027 a ha) (affine_beta_window027 a ha world h B state)
    (affine_beta_empty027 a ha) (affine_beta_complete027 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node026 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known026 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known026 a) ((1 : Int),(2 : Int)) (affine_beta_branches026 a) copies separate cover ceiling
    (affine_beta_nonnegative026 a ha) (affine_beta_window026 a ha world h B state)
    (affine_beta_empty026 a ha) (affine_beta_complete026 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node025 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known025 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known025 a) ((1 : Int),(1 : Int)) (affine_beta_branches025 a) copies separate cover ceiling
    (affine_beta_nonnegative025 a ha) (affine_beta_window025 a ha world h B state)
    (affine_beta_empty025 a ha) (affine_beta_complete025 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known025,affine_beta_known026,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known025,affine_beta_known027,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node026 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node027 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node024 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known024 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known024 a) ((1 : Int),(1 : Int)) (affine_beta_branches024 a) copies separate cover ceiling
    (affine_beta_nonnegative024 a ha) (affine_beta_window024 a ha world h B state)
    (affine_beta_empty024 a ha) (affine_beta_complete024 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node023 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known023 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known023 a) ((1 : Int),(0 : Int)) (affine_beta_branches023 a) copies separate cover ceiling
    (affine_beta_nonnegative023 a ha) (affine_beta_window023 a ha world h B state)
    (affine_beta_empty023 a ha) (affine_beta_complete023 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known023,affine_beta_known024,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known023,affine_beta_known025,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known023,affine_beta_known028,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node024 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node025 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node028 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node022 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known022 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known022 a) ((1 : Int),(1 : Int)) (affine_beta_branches022 a) copies separate cover ceiling
    (affine_beta_nonnegative022 a ha) (affine_beta_window022 a ha world h B state)
    (affine_beta_empty022 a ha) (affine_beta_complete022 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node021 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known021 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known021 a) ((2 : Int),(2 : Int)) (affine_beta_branches021 a) copies separate cover ceiling
    (affine_beta_nonnegative021 a ha) (affine_beta_window021 a ha world h B state)
    (affine_beta_empty021 a ha) (affine_beta_complete021 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node020 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known020 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known020 a) ((2 : Int),(2 : Int)) (affine_beta_branches020 a) copies separate cover ceiling
    (affine_beta_nonnegative020 a ha) (affine_beta_window020 a ha world h B state)
    (affine_beta_empty020 a ha) (affine_beta_complete020 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_beta_node019 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known019 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf019 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node018 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known018 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known018 a) ((4 : Int),(2 : Int)) (affine_beta_branches018 a) copies separate cover ceiling
    (affine_beta_nonnegative018 a ha) (affine_beta_window018 a ha world h B state)
    (affine_beta_empty018 a ha) (affine_beta_complete018 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node017 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known017 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known017 a) ((4 : Int),(2 : Int)) (affine_beta_branches017 a) copies separate cover ceiling
    (affine_beta_nonnegative017 a ha) (affine_beta_window017 a ha world h B state)
    (affine_beta_empty017 a ha) (affine_beta_complete017 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node016 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known016 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known016 a) ((3 : Int),(2 : Int)) (affine_beta_branches016 a) copies separate cover ceiling
    (affine_beta_nonnegative016 a ha) (affine_beta_window016 a ha world h B state)
    (affine_beta_empty016 a ha) (affine_beta_complete016 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known016,affine_beta_known017,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known016,affine_beta_known018,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node017 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node018 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node015 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known015 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known015 a) ((4 : Int),(2 : Int)) (affine_beta_branches015 a) copies separate cover ceiling
    (affine_beta_nonnegative015 a ha) (affine_beta_window015 a ha world h B state)
    (affine_beta_empty015 a ha) (affine_beta_complete015 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node014 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known014 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known014 a) ((4 : Int),(2 : Int)) (affine_beta_branches014 a) copies separate cover ceiling
    (affine_beta_nonnegative014 a ha) (affine_beta_window014 a ha world h B state)
    (affine_beta_empty014 a ha) (affine_beta_complete014 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node013 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known013 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known013 a) ((3 : Int),(2 : Int)) (affine_beta_branches013 a) copies separate cover ceiling
    (affine_beta_nonnegative013 a ha) (affine_beta_window013 a ha world h B state)
    (affine_beta_empty013 a ha) (affine_beta_complete013 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known013,affine_beta_known014,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known013,affine_beta_known015,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node014 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node015 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node012 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known012 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known012 a) ((1 : Int),(4 : Int)) (affine_beta_branches012 a) copies separate cover ceiling
    (affine_beta_nonnegative012 a ha) (affine_beta_window012 a ha world h B state)
    (affine_beta_empty012 a ha) (affine_beta_complete012 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known012,affine_beta_known013,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known012,affine_beta_known016,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node013 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node016 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node011 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known011 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known011 a) ((2 : Int),(2 : Int)) (affine_beta_branches011 a) copies separate cover ceiling
    (affine_beta_nonnegative011 a ha) (affine_beta_window011 a ha world h B state)
    (affine_beta_empty011 a ha) (affine_beta_complete011 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node010 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known010 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known010 a) ((2 : Int),(2 : Int)) (affine_beta_branches010 a) copies separate cover ceiling
    (affine_beta_nonnegative010 a ha) (affine_beta_window010 a ha world h B state)
    (affine_beta_empty010 a ha) (affine_beta_complete010 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node009 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known009 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known009 a) ((3 : Int),(2 : Int)) (affine_beta_branches009 a) copies separate cover ceiling
    (affine_beta_nonnegative009 a ha) (affine_beta_window009 a ha world h B state)
    (affine_beta_empty009 a ha) (affine_beta_complete009 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node008 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known008 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known008 a) ((3 : Int),(2 : Int)) (affine_beta_branches008 a) copies separate cover ceiling
    (affine_beta_nonnegative008 a ha) (affine_beta_window008 a ha world h B state)
    (affine_beta_empty008 a ha) (affine_beta_complete008 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node007 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known007 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known007 a) ((2 : Int),(2 : Int)) (affine_beta_branches007 a) copies separate cover ceiling
    (affine_beta_nonnegative007 a ha) (affine_beta_window007 a ha world h B state)
    (affine_beta_empty007 a ha) (affine_beta_complete007 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known007,affine_beta_known008,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known007,affine_beta_known009,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node008 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node009 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node006 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known006 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known006 a) ((1 : Int),(3 : Int)) (affine_beta_branches006 a) copies separate cover ceiling
    (affine_beta_nonnegative006 a ha) (affine_beta_window006 a ha world h B state)
    (affine_beta_empty006 a ha) (affine_beta_complete006 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known007,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known010,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known011,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known012,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known019,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known020,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known006,affine_beta_known021,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node007 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node010 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node011 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node012 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node019 a ha world h nextB nextState
    · exact affine_beta_node020 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node021 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node005 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known005 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf005 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node004 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known004 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known004 a) ((1 : Int),(1 : Int)) (affine_beta_branches004 a) copies separate cover ceiling
    (affine_beta_nonnegative004 a ha) (affine_beta_window004 a ha world h B state)
    (affine_beta_empty004 a ha) (affine_beta_complete004 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known004,affine_beta_known005,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known004,affine_beta_known006,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_beta_node005 a ha world h nextB nextState
    · exact affine_beta_node006 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_beta_node003 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known003 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known003 a) ((1 : Int),(1 : Int)) (affine_beta_branches003 a) copies separate cover ceiling
    (affine_beta_nonnegative003 a ha) (affine_beta_window003 a ha world h B state)
    (affine_beta_empty003 a ha) (affine_beta_complete003 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_beta_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_beta_node002 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known002 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known002 a) ((1 : Int),(0 : Int)) (affine_beta_branches002 a) copies separate cover ceiling
    (affine_beta_nonnegative002 a ha) (affine_beta_window002 a ha world h B state)
    (affine_beta_empty002 a ha) (affine_beta_complete002 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known002,affine_beta_known003,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known002,affine_beta_known004,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known002,affine_beta_known022,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_beta_node003 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node004 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node022 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_beta_node001 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known001 a)) B) : Transition world h .beta B := by
  exact affine_beta_leaf001 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_beta_node000 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_beta_known000 a)) B) : Transition world h .beta B := by
  apply replay_affine_step a (by omega) world h .beta (affine_beta_known000 a) ((0 : Int),(1 : Int)) (affine_beta_branches000 a) copies separate cover ceiling
    (affine_beta_nonnegative000 a ha) (affine_beta_window000 a ha world h B state)
    (affine_beta_empty000 a ha) (affine_beta_complete000 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_beta_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known001,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known002,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known023,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known029,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known030,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known124,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known142,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_beta_known000,affine_beta_known143,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_beta_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_beta_node001 a ha world h nextB nextState
    · exact affine_beta_node002 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node023 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node029 a ha world h nextB nextState
    · exact affine_beta_node030 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node124 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node142 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_beta_node143 a ha world h copies separate cover ceiling nextB nextState
end AffineBeta

theorem affine_beta_seed_eq (a : Int) : SameCells (seed .beta) (knownCells (affine_beta_known000 a)) := by
  change SameCells (seed .beta) (knownCells (affine_beta_known000 (0 : Int)))
  decide

theorem affine_beta_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .beta 0 0 B) : Transition world h .beta B := by
  exact affine_beta_node000 a ha world h copies separate cover ceiling B
    (state_congr (affine_beta_seed_eq a) (seed_state world h .beta B closed bounded clean))
#print axioms affine_beta_local

end CornerCertificate

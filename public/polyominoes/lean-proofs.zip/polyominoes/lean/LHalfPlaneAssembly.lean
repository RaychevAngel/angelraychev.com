import LHalfPlaneBoundaryTips
import LHalfPlaneSameBars
import THalfPlane
set_option maxHeartbeats 100000
set_option maxRecDepth 10000
namespace PolyominoFormal.LHalfPlaneAssembly
open CrossUnits TBoundary

def LongCover {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Prop :=
  ∀z,∃p r,(r=0 ∨ r=a) ∧ T.world ⟨p+r,0,a-r,b,r,0⟩ ∧ p≤z ∧ z≤p+a

def NoShortBars (a b : Int) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane, ∀p, ¬T.world ⟨p,0,b,a,0,0⟩
def NoSameBars (a b : Int) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane,
    T.world ⟨0,0,a,b,0,0⟩ → T.world ⟨a+1,0,a,b,0,0⟩ → False
def NoAlternatingBars (a b : Int) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane,
    T.world ⟨-1,0,0,b,a,0⟩ → T.world ⟨0,0,a,b,0,0⟩ →
    T.world ⟨2*a+1,0,0,b,a,0⟩ → T.world ⟨2*a+2,0,a,b,0,0⟩ → False

theorem same_bars {a b : Int} (ha : 5≤a) (hb : 3≤b) (hlt : b<a) :
    NoSameBars a b := by
  intro T ht hu
  apply LRegion.same_long_bars_impossible a b 0 ha hb hlt T ht
  simpa only [Int.zero_add] using hu

theorem long_cover {a b : Int} (ha : 5≤a) (hb : 3≤b) (hlt : b<a)
    (short : NoShortBars a b) (T : Tiling a b 0 0 HalfPlane) : LongCover T := by
  intro z
  obtain ⟨⟨x,y,e,n,w,s⟩,ht,hit⟩ := T.cover z 0 (by unfold HalfPlane; omega)
  have bound := THalfPlane.hp_bound (by omega) (by omega) (by omega) T ht
  have cp := T.copies _ ht
  rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
  all_goals rcases cp with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp [Contains] at hit
  · have hy : y=0 := by omega
    subst y; refine ⟨x,0,Or.inl rfl,?_,by omega,by omega⟩
    simpa only [Int.add_zero,Int.sub_zero] using ht
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.unequal_no_right_long_tip a b x hb hlt ha T ht)
  · have hy : y=b := by omega
    subst y; exact False.elim (LRegion.unequal_no_left_short_tip a b x hb hlt ha T ht)
  · have hy : y=0 := by omega
    subst y
    exact False.elim (short T.mirrorX (-x) ⟨_,ht,rfl⟩)
  · have hy : y=a := by omega
    subst y; exact False.elim (LRegion.unequal_no_left_long_tip a b x hb hlt ha T ht)
  · have hy : y=0 := by omega
    subst y; refine ⟨x-a,a,Or.inr rfl,?_,by omega,by omega⟩
    simpa only [Int.sub_add_cancel,Int.sub_self] using ht
  · have hy : y=0 := by omega
    subst y; exact False.elim (short T x ht)
  · have hy : y=b := by omega
    subst y; exact False.elim (LRegion.unequal_no_right_short_tip a b x hb hlt ha T ht)

theorem next_long {a b p r : Int} (ha : 1≤a) (hb : 1≤b) (hr : r=0 ∨ r=a)
    (T : Tiling a b 0 0 HalfPlane) (cover : LongCover T)
    (ht : T.world ⟨p+r,0,a-r,b,r,0⟩) :
    ∃s,(s=0 ∨ s=a) ∧ T.world ⟨p+(a+1)+s,0,a-s,b,s,0⟩ := by
  obtain ⟨q,s,hs,hu,hq0,hq1⟩ := cover (p+(a+1))
  have hit : Contains ⟨q+s,0,a-s,b,s,0⟩ (p+(a+1)) 0 := by left; dsimp; omega
  have ap := separate (by omega) (by omega) (by omega) T hu ht hit
    (by dsimp [Contains]; omega)
  have hq : q=p+(a+1) := by dsimp [Apart] at ap; omega
  subst q; exact ⟨s,hs,hu⟩

theorem no_same_translated {a b p r : Int} (hr : r=0 ∨ r=a)
    (same : NoSameBars a b) (T : Tiling a b 0 0 HalfPlane)
    (ht : T.world ⟨p+r,0,a-r,b,r,0⟩)
    (hu : T.world ⟨p+(a+1)+r,0,a-r,b,r,0⟩) : False := by
  rcases hr with hr | hr
  · subst r
    let U : Tiling a b 0 0 HalfPlane := (T.translate (-p) 0).congr (by
      intro x y; simp only [HalfPlane,Int.sub_zero])
    apply same U
    · refine ⟨_,ht,?_⟩; apply same_eq; dsimp [Same,shift]; omega
    · refine ⟨_,hu,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · subst r
    let U : Tiling a b 0 0 HalfPlane := (T.mirrorX.translate (p+2*a+1) 0).congr (by
      intro x y; simp only [HalfPlane,Int.sub_zero])
    apply same U
    · refine ⟨_,⟨_,hu,rfl⟩,?_⟩; apply same_eq; dsimp [Same,shift,mirrorX]; omega
    · refine ⟨_,⟨_,ht,rfl⟩,?_⟩; apply same_eq; dsimp [Same,shift,mirrorX]; omega

theorem next_opposite {a b p r : Int} (ha : 1≤a) (hb : 1≤b) (hr : r=0 ∨ r=a)
    (same : NoSameBars a b) (T : Tiling a b 0 0 HalfPlane) (cover : LongCover T)
    (ht : T.world ⟨p+r,0,a-r,b,r,0⟩) :
    T.world ⟨p+(a+1)+(a-r),0,r,b,a-r,0⟩ := by
  obtain ⟨s,hs,hu⟩ := next_long ha hb hr T cover ht
  have neq : s≠r := by intro eq; subst s; exact no_same_translated hr same T ht hu
  have hs' : s=a-r := by omega
  subst s
  simpa only [show a-(a-r)=r by omega] using hu

theorem no_halfplane_from_boundary {a b : Int} (ha : 5≤a) (hb : 3≤b) (hlt : b<a)
    (short : NoShortBars a b) (same : NoSameBars a b) (alt : NoAlternatingBars a b) :
    ¬Tiles a b 0 0 HalfPlane := by
  rintro ⟨T⟩
  have cover := long_cover ha hb hlt short T
  have start : ∃p,T.world ⟨p+a,0,0,b,a,0⟩ := by
    obtain ⟨p,r,hr,ht,_,_⟩ := cover 0
    rcases hr with hr | hr
    · subst r
      exact ⟨p+(a+1),by simpa only [Int.sub_zero,Int.add_zero] using
        (next_opposite (by omega) (by omega) (Or.inl rfl) same T cover ht)⟩
    · subst r
      exact ⟨p,by simpa only [Int.sub_self] using ht⟩
  obtain ⟨p,h0⟩ := start
  have h1 := next_opposite (p:=p) (r:=a) (by omega) (by omega) (Or.inr rfl) same T cover
    (by simpa only [Int.sub_self] using h0)
  have h1' : T.world ⟨p+a+1,0,a,b,0,0⟩ := by
    simpa only [Int.sub_self,Int.add_zero,show p+(a+1)=p+a+1 by omega] using h1
  have h2 := next_opposite (p:=p+a+1) (r:=0) (by omega) (by omega) (Or.inl rfl) same T cover
    (by simpa only [Int.add_zero,Int.sub_zero] using h1')
  have h2' : T.world ⟨p+3*a+2,0,0,b,a,0⟩ := by
    simpa only [Int.sub_zero,show p+a+1+(a+1)+a=p+3*a+2 by omega] using h2
  have h3 := next_opposite (p:=p+2*a+2) (r:=a) (by omega) (by omega) (Or.inr rfl) same T cover
    (by simpa only [Int.sub_self,show p+2*a+2+a=p+3*a+2 by omega] using h2')
  let U : Tiling a b 0 0 HalfPlane := (T.translate (-(p+a+1)) 0).congr (by
    intro x y; simp only [HalfPlane,Int.sub_zero])
  apply alt U
  · refine ⟨_,h0,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h1',?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h2',?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h3,?_⟩; apply same_eq; dsimp [Same,shift]; omega

#print axioms no_halfplane_from_boundary

def NoEightAlternatingBars (a b : Int) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane,
    T.world ⟨-2*a-3,0,0,b,a,0⟩ → T.world ⟨-2*a-2,0,a,b,0,0⟩ →
    T.world ⟨-1,0,0,b,a,0⟩ → T.world ⟨0,0,a,b,0,0⟩ →
    T.world ⟨2*a+1,0,0,b,a,0⟩ → T.world ⟨2*a+2,0,a,b,0,0⟩ →
    T.world ⟨4*a+3,0,0,b,a,0⟩ → T.world ⟨4*a+4,0,a,b,0,0⟩ → False

/-- Eight successive bars follow from the same ordinary boundary covering
    argument. This permits local obstructions to use neighboring pairs. -/
theorem no_halfplane_from_eight {a b : Int} (ha : 5≤a) (hb : 3≤b) (hlt : b<a)
    (short : NoShortBars a b) (same : NoSameBars a b) (alt : NoEightAlternatingBars a b) :
    ¬Tiles a b 0 0 HalfPlane := by
  apply no_halfplane_from_boundary ha hb hlt short same
  intro T h0 h1 h2 h3
  have cover := long_cover ha hb hlt short T
  have h4 : T.world ⟨4*a+3,0,0,b,a,0⟩ := by
    have h := next_opposite (p:=2*a+2) (r:=0) (by omega) (by omega)
      (Or.inl rfl) same T cover
      (by simpa only [Int.add_zero,Int.sub_zero] using h3)
    simpa only [Int.sub_zero,show 2*a+2+(a+1)+a=4*a+3 by omega] using h
  have h5 : T.world ⟨4*a+4,0,a,b,0,0⟩ := by
    have h := next_opposite (p:=3*a+3) (r:=a) (by omega) (by omega)
      (Or.inr rfl) same T cover
      (by simpa only [Int.sub_self,show 3*a+3+a=4*a+3 by omega] using h4)
    simpa only [Int.sub_self,Int.add_zero,show 3*a+3+(a+1)=4*a+4 by omega] using h
  have h6 : T.world ⟨6*a+5,0,0,b,a,0⟩ := by
    have h := next_opposite (p:=4*a+4) (r:=0) (by omega) (by omega)
      (Or.inl rfl) same T cover
      (by simpa only [Int.add_zero,Int.sub_zero] using h5)
    simpa only [Int.sub_zero,show 4*a+4+(a+1)+a=6*a+5 by omega] using h
  have h7 : T.world ⟨6*a+6,0,a,b,0,0⟩ := by
    have h := next_opposite (p:=5*a+5) (r:=a) (by omega) (by omega)
      (Or.inr rfl) same T cover
      (by simpa only [Int.sub_self,show 5*a+5+a=6*a+5 by omega] using h6)
    simpa only [Int.sub_self,Int.add_zero,show 5*a+5+(a+1)=6*a+6 by omega] using h
  let U : Tiling a b 0 0 HalfPlane := (T.translate (-(2*a+2)) 0).congr (by
    intro x y; simp only [HalfPlane,Int.sub_zero])
  apply alt U
  · refine ⟨_,h0,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h1,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h2,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h3,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h4,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h5,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h6,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h7,?_⟩; apply same_eq; dsimp [Same,shift]; omega

#print axioms no_halfplane_from_eight
end PolyominoFormal.LHalfPlaneAssembly

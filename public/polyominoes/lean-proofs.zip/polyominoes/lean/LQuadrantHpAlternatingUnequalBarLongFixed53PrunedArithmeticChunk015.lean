import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((0 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((0 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_empty (a b : Int)
    (h0 : (((((0 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((0 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((0 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o1 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (¬ ((((0 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (¬ ((((0 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o4 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (¬ ((((0 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h4 : (b = (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o5 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o6 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n375_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b = (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (¬ ((((0 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h7 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-1 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-1 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-1 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-1 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-1 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o1 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jx - (0 : Int))) ∨ ((9 : Int) > jy) ∨ ((9 : Int) < jy)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : (a = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((-1 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o4 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h4 : (a = (5 : Int)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n376_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b = (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h7 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_empty (a b : Int)
    (h0 : (((((-3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((-8 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h7 : (b = (3 : Int)))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((-3 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ ((((-3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (b = (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n377_o7 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_empty (a b : Int)
    (h0 : (((((-3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-8 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((-8 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-8 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-8 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (((-8 : Int) > (jx + a)) ∨ ((-8 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o1 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : (b = (3 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((-3 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (5 : Int)))
    (h7 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h8 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((-8 : Int) > (jx + (0 : Int))) ∨ ((-8 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n378_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-8 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-8 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-8 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-8 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-8 : Int) > (jx + a)) ∨ ((-8 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-8 : Int) > (jx + b)) ∨ ((-8 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n379_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : (a = (5 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (¬ ((((-9 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (b = (3 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n380_o7 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-6 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_empty (a b : Int)
    (h0 : (((((-6 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-6 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-6 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-6 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-6 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (5 : Int))) ∨ (((-3 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-3 : Int)) ∧ ((1 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((-6 : Int) ≥ ((-9 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((-9 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((-9 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-9 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-12 : Int) > (jx + a)) ∨ ((-12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h7 : (((jx + a) < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h8 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (¬ ((((-11 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-6 : Int) ≥ (jx - a)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-6 : Int) ≥ (jx - b)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-6 : Int) ≥ (jx - b)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o5 (a b jx jy : Int)
    (h0 : ((((-6 : Int) ≥ (jx - a)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h4 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n381_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-9 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-9 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-9 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-11 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-11 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-11 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h5 : (((-9 : Int) > (jx + a)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((-9 : Int) > (jx + (0 : Int))) ∨ ((-9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o6 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (((-9 : Int) > (jx + b)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n382_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-6 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_empty (a b : Int)
    (h0 : (((((-6 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-6 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-6 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-6 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-6 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-6 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-6 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-6 : Int)) ∧ ((-6 : Int) ≤ (-3 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : (¬ ((((-11 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (((-12 : Int) > (jx + a)) ∨ ((-12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h9 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-6 : Int) ≥ (jx - a)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-6 : Int) ≥ (jx - b)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-6 : Int) ≥ (jx - b)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-6 : Int) ≥ (jx - a)) ∧ ((-6 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) - (3 : Int))) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o6 (a b jx jy : Int)
    (h0 : (¬ ((((-9 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (a = (5 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n383_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : ((((-6 : Int) ≥ (jx - (0 : Int))) ∧ ((-6 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-6 : Int) ≥ jx) ∧ ((-6 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((6 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_empty (a b : Int)
    (h0 : (((((-3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-13 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (23 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (24 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((6 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-3 : Int) ≥ ((-11 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((-11 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((-11 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-11 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o0 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((-8 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h9 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    (h1 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o4 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h2 : (b = (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n384_o7 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (¬ ((((-8 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h7 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-11 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-11 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-11 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-8 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-8 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((-8 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-8 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o0 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h7 : (¬ ((((-9 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o3 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (b = (3 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n385_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_point (a b : Int)
    (h0 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-11 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-11 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-11 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-8 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-8 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int))) ∨ (((-8 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-8 : Int)) ∧ ((4 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-9 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-9 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-9 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-9 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : (((-9 : Int) > (jx + a)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o1 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o3 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-9 : Int) > (jx + (0 : Int))) ∨ ((-9 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (((-9 : Int) > (jx + b)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n386_o7 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : (((-9 : Int) > (jx + a)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((-9 : Int) - (0 : Int))) ∨ (((-9 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-11 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-11 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-11 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-8 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-8 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((-8 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-8 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o0 (a b jx jy : Int)
    (h0 : (((-8 : Int) > (jx + a)) ∨ ((-8 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-8 : Int) > (jx + b)) ∨ ((-8 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n387_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jx < ((-8 : Int) - (0 : Int))) ∨ (((-8 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-9 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-9 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-9 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-9 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o0 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-9 : Int) > (jx + a)) ∨ ((-9 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((-9 : Int) > (jx + (0 : Int))) ∨ ((-9 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-9 : Int) > (jx + (0 : Int))) ∨ ((-9 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o6 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ ((((-7 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((-3 : Int) - (5 : Int))) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n388_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_empty (a b : Int)
    (h0 : (((((-4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (7 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - (5 : Int))) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((-4 : Int) ≥ ((-9 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-9 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-9 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-9 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-4 : Int) ≥ ((-7 : Int) - (0 : Int))) ∧ ((-4 : Int) ≤ ((-7 : Int) + (3 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-7 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-7 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((-7 : Int) > (jx + a)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o1 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h6 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o3 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o5 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (((-7 : Int) > (jx + (0 : Int))) ∨ ((-7 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (((-7 : Int) > (jx + b)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n389_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (3 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-7 : Int) > (jx + a)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((7 : Int) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((7 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-13 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-12 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (11 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (12 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (23 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (24 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ ((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((7 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((7 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o1 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - a)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jx - (0 : Int))) ∨ ((9 : Int) > jy) ∨ ((9 : Int) < jy)))
    (h7 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o2 (a b jx jy : Int)
    (h0 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - b)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (¬ ((((6 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : (¬ ((((4 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h5 : (b = (3 : Int)))
    (h6 : (a = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - a)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((4 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h8 : (a = (5 : Int)))
    (h9 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o5 (a b jx jy : Int)
    (h0 : (¬ ((((6 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h7 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h8 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + b)))))
    (h9 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n390_o7 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jx - (0 : Int))) ∨ ((9 : Int) > jy) ∨ ((9 : Int) < jy)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - b)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o0 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (a = (5 : Int)))
    (h7 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (¬ ((((2 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o3 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o4 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o5 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (¬ ((((7 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o6 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n391_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((4 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h8 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h9 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h10 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h8 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o3 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o6 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n392_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o1 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o2 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o3 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : (¬ ((((10 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (b = (3 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n393_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((6 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((6 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((10 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (10 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (((6 : Int) > jx) ∨ ((6 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h7 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h8 : (b = (3 : Int)))
    (h9 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o5 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o6 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < jy)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n394_o7 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_point (a b : Int)
    (h0 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o0 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((7 : Int) > (jx + a)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o4 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o5 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n395_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o1 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h6 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o3 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h6 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o5 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h1 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n396_o7 (a b jx jy : Int)
    (h0 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o0 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o6 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n397_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h3 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_point (a b : Int)
    (h0 : (¬ (((1 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o0 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o2 (a b jx jy : Int)
    (h0 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h5 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (3 : Int)))
    (h4 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h5 : (a = (5 : Int)))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (¬ ((((4 : Int) = jx) ∧ ((8 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o4 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o6 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n398_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < (jy - b))))
    (h3 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((-2 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-2 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (8 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((8 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((8 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o0 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h1 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + a) < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((5 : Int) = jx) ∧ ((13 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h3 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (b = (3 : Int)))
    (h5 : (a = (5 : Int)))
    (h6 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o2 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h5 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o3 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h5 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o5 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o6 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h1 : (((jx + b) < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n399_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (a = (5 : Int)))
    (h7 : (b = (3 : Int)))
    (h8 : (¬ ((((5 : Int) = jx) ∧ ((11 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

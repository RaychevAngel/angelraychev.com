import HPFiniteA6B6Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp6_6_node922 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected922 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected922 ((9 : Int),(1 : Int)) hp6_6_branches922 hp6_6_evidence922 hp6_6_check922 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node921 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected921 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected921 ((7 : Int),(1 : Int)) hp6_6_branches921 hp6_6_evidence921 hp6_6_check921 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node920 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected920 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected920 ((7 : Int),(1 : Int)) hp6_6_branches920 hp6_6_evidence920 hp6_6_check920 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node919 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected919 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected919 ((7 : Int),(1 : Int)) hp6_6_branches919 hp6_6_evidence919 hp6_6_check919 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node918 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected918 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected918 ((8 : Int),(1 : Int)) hp6_6_branches918 hp6_6_evidence918 hp6_6_check918 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node919 T childKnown
  · exact hp6_6_node920 T childKnown
  · exact hp6_6_node921 T childKnown
  · exact hp6_6_node922 T childKnown
theorem hp6_6_node917 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected917 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected917 ((8 : Int),(1 : Int)) hp6_6_branches917 hp6_6_evidence917 hp6_6_check917 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node916 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected916 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected916 ((8 : Int),(1 : Int)) hp6_6_branches916 hp6_6_evidence916 hp6_6_check916 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node915 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected915 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected915 ((8 : Int),(1 : Int)) hp6_6_branches915 hp6_6_evidence915 hp6_6_check915 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node914 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected914 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected914 ((1 : Int),(2 : Int)) hp6_6_branches914 hp6_6_evidence914 hp6_6_check914 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node913 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected913 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected913 ((1 : Int),(2 : Int)) hp6_6_branches913 hp6_6_evidence913 hp6_6_check913 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node912 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected912 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected912 ((5 : Int),(1 : Int)) hp6_6_branches912 hp6_6_evidence912 hp6_6_check912 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node913 T childKnown
  · exact hp6_6_node914 T childKnown
theorem hp6_6_node911 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected911 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected911 ((8 : Int),(1 : Int)) hp6_6_branches911 hp6_6_evidence911 hp6_6_check911 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node912 T childKnown
theorem hp6_6_node910 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected910 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected910 ((7 : Int),(1 : Int)) hp6_6_branches910 hp6_6_evidence910 hp6_6_check910 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node911 T childKnown
  · exact hp6_6_node915 T childKnown
  · exact hp6_6_node916 T childKnown
  · exact hp6_6_node917 T childKnown
theorem hp6_6_node909 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected909 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected909 ((9 : Int),(1 : Int)) hp6_6_branches909 hp6_6_evidence909 hp6_6_check909 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node908 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected908 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected908 ((9 : Int),(0 : Int)) hp6_6_branches908 hp6_6_evidence908 hp6_6_check908 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node909 T childKnown
theorem hp6_6_node907 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected907 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected907 ((7 : Int),(1 : Int)) hp6_6_branches907 hp6_6_evidence907 hp6_6_check907 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node908 T childKnown
theorem hp6_6_node906 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected906 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected906 ((1 : Int),(2 : Int)) hp6_6_branches906 hp6_6_evidence906 hp6_6_check906 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node905 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected905 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected905 ((1 : Int),(2 : Int)) hp6_6_branches905 hp6_6_evidence905 hp6_6_check905 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node904 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected904 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected904 ((5 : Int),(1 : Int)) hp6_6_branches904 hp6_6_evidence904 hp6_6_check904 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node905 T childKnown
  · exact hp6_6_node906 T childKnown
theorem hp6_6_node903 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected903 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected903 ((9 : Int),(0 : Int)) hp6_6_branches903 hp6_6_evidence903 hp6_6_check903 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node904 T childKnown
theorem hp6_6_node902 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected902 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected902 ((7 : Int),(1 : Int)) hp6_6_branches902 hp6_6_evidence902 hp6_6_check902 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node903 T childKnown
theorem hp6_6_node901 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected901 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected901 ((7 : Int),(1 : Int)) hp6_6_branches901 hp6_6_evidence901 hp6_6_check901 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node900 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected900 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected900 ((8 : Int),(0 : Int)) hp6_6_branches900 hp6_6_evidence900 hp6_6_check900 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node901 T childKnown
  · exact hp6_6_node902 T childKnown
  · exact hp6_6_node907 T childKnown
  · exact hp6_6_node910 T childKnown
  · exact hp6_6_node918 T childKnown
theorem hp6_6_node899 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected899 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected899 ((2 : Int),(2 : Int)) hp6_6_branches899 hp6_6_evidence899 hp6_6_check899 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node898 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected898 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected898 ((2 : Int),(2 : Int)) hp6_6_branches898 hp6_6_evidence898 hp6_6_check898 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node897 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected897 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected897 ((2 : Int),(1 : Int)) hp6_6_branches897 hp6_6_evidence897 hp6_6_check897 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node898 T childKnown
  · exact hp6_6_node899 T childKnown
theorem hp6_6_node896 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected896 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected896 ((2 : Int),(2 : Int)) hp6_6_branches896 hp6_6_evidence896 hp6_6_check896 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node895 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected895 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected895 ((2 : Int),(2 : Int)) hp6_6_branches895 hp6_6_evidence895 hp6_6_check895 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node894 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected894 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected894 ((2 : Int),(1 : Int)) hp6_6_branches894 hp6_6_evidence894 hp6_6_check894 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node895 T childKnown
  · exact hp6_6_node896 T childKnown
theorem hp6_6_node893 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected893 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected893 ((11 : Int),(1 : Int)) hp6_6_branches893 hp6_6_evidence893 hp6_6_check893 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node892 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected892 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected892 ((9 : Int),(2 : Int)) hp6_6_branches892 hp6_6_evidence892 hp6_6_check892 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node891 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected891 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected891 ((10 : Int),(1 : Int)) hp6_6_branches891 hp6_6_evidence891 hp6_6_check891 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node892 T childKnown
  · exact hp6_6_node893 T childKnown
theorem hp6_6_node890 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected890 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected890 ((8 : Int),(0 : Int)) hp6_6_branches890 hp6_6_evidence890 hp6_6_check890 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node891 T childKnown
theorem hp6_6_node889 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected889 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected889 ((3 : Int),(2 : Int)) hp6_6_branches889 hp6_6_evidence889 hp6_6_check889 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node888 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected888 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected888 ((3 : Int),(2 : Int)) hp6_6_branches888 hp6_6_evidence888 hp6_6_check888 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node887 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected887 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected887 ((3 : Int),(2 : Int)) hp6_6_branches887 hp6_6_evidence887 hp6_6_check887 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node886 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected886 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected886 ((4 : Int),(2 : Int)) hp6_6_branches886 hp6_6_evidence886 hp6_6_check886 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node885 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected885 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected885 ((3 : Int),(2 : Int)) hp6_6_branches885 hp6_6_evidence885 hp6_6_check885 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node886 T childKnown
theorem hp6_6_node884 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected884 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected884 ((2 : Int),(2 : Int)) hp6_6_branches884 hp6_6_evidence884 hp6_6_check884 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node885 T childKnown
  · exact hp6_6_node887 T childKnown
  · exact hp6_6_node888 T childKnown
  · exact hp6_6_node889 T childKnown
theorem hp6_6_node883 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected883 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected883 ((10 : Int),(1 : Int)) hp6_6_branches883 hp6_6_evidence883 hp6_6_check883 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node882 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected882 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected882 ((12 : Int),(1 : Int)) hp6_6_branches882 hp6_6_evidence882 hp6_6_check882 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node881 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected881 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected881 ((11 : Int),(1 : Int)) hp6_6_branches881 hp6_6_evidence881 hp6_6_check881 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node882 T childKnown
theorem hp6_6_node880 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected880 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected880 ((4 : Int),(2 : Int)) hp6_6_branches880 hp6_6_evidence880 hp6_6_check880 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node881 T childKnown
  · exact hp6_6_node883 T childKnown
theorem hp6_6_node879 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected879 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected879 ((10 : Int),(1 : Int)) hp6_6_branches879 hp6_6_evidence879 hp6_6_check879 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node878 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected878 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected878 ((12 : Int),(1 : Int)) hp6_6_branches878 hp6_6_evidence878 hp6_6_check878 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node877 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected877 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected877 ((11 : Int),(1 : Int)) hp6_6_branches877 hp6_6_evidence877 hp6_6_check877 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node878 T childKnown
theorem hp6_6_node876 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected876 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected876 ((4 : Int),(2 : Int)) hp6_6_branches876 hp6_6_evidence876 hp6_6_check876 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node877 T childKnown
  · exact hp6_6_node879 T childKnown
theorem hp6_6_node875 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected875 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected875 ((10 : Int),(1 : Int)) hp6_6_branches875 hp6_6_evidence875 hp6_6_check875 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node874 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected874 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected874 ((12 : Int),(1 : Int)) hp6_6_branches874 hp6_6_evidence874 hp6_6_check874 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node873 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected873 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected873 ((11 : Int),(1 : Int)) hp6_6_branches873 hp6_6_evidence873 hp6_6_check873 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node874 T childKnown
theorem hp6_6_node872 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected872 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected872 ((10 : Int),(1 : Int)) hp6_6_branches872 hp6_6_evidence872 hp6_6_check872 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node871 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected871 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected871 ((5 : Int),(2 : Int)) hp6_6_branches871 hp6_6_evidence871 hp6_6_check871 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node870 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected870 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected870 ((10 : Int),(1 : Int)) hp6_6_branches870 hp6_6_evidence870 hp6_6_check870 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node871 T childKnown
theorem hp6_6_node869 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected869 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected869 ((10 : Int),(1 : Int)) hp6_6_branches869 hp6_6_evidence869 hp6_6_check869 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node868 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected868 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected868 ((4 : Int),(2 : Int)) hp6_6_branches868 hp6_6_evidence868 hp6_6_check868 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node869 T childKnown
  · exact hp6_6_node870 T childKnown
  · exact hp6_6_node872 T childKnown
  · exact hp6_6_node873 T childKnown
  · exact hp6_6_node875 T childKnown
theorem hp6_6_node867 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected867 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected867 ((4 : Int),(2 : Int)) hp6_6_branches867 hp6_6_evidence867 hp6_6_check867 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node866 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected866 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected866 ((9 : Int),(2 : Int)) hp6_6_branches866 hp6_6_evidence866 hp6_6_check866 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node865 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected865 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected865 ((4 : Int),(2 : Int)) hp6_6_branches865 hp6_6_evidence865 hp6_6_check865 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node864 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected864 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected864 ((4 : Int),(2 : Int)) hp6_6_branches864 hp6_6_evidence864 hp6_6_check864 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node863 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected863 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected863 ((12 : Int),(1 : Int)) hp6_6_branches863 hp6_6_evidence863 hp6_6_check863 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node862 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected862 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected862 ((11 : Int),(1 : Int)) hp6_6_branches862 hp6_6_evidence862 hp6_6_check862 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node863 T childKnown
theorem hp6_6_node861 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected861 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected861 ((10 : Int),(1 : Int)) hp6_6_branches861 hp6_6_evidence861 hp6_6_check861 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node862 T childKnown
  · exact hp6_6_node864 T childKnown
  · exact hp6_6_node865 T childKnown
  · exact hp6_6_node866 T childKnown
  · exact hp6_6_node867 T childKnown
theorem hp6_6_node860 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected860 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected860 ((2 : Int),(2 : Int)) hp6_6_branches860 hp6_6_evidence860 hp6_6_check860 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node861 T childKnown
  · exact hp6_6_node868 T childKnown
  · exact hp6_6_node876 T childKnown
  · exact hp6_6_node880 T childKnown
theorem hp6_6_node859 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected859 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected859 ((8 : Int),(0 : Int)) hp6_6_branches859 hp6_6_evidence859 hp6_6_check859 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node860 T childKnown
theorem hp6_6_node858 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected858 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected858 ((3 : Int),(2 : Int)) hp6_6_branches858 hp6_6_evidence858 hp6_6_check858 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node857 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected857 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected857 ((3 : Int),(2 : Int)) hp6_6_branches857 hp6_6_evidence857 hp6_6_check857 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node856 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected856 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected856 ((3 : Int),(1 : Int)) hp6_6_branches856 hp6_6_evidence856 hp6_6_check856 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node857 T childKnown
  · exact hp6_6_node858 T childKnown
theorem hp6_6_node855 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected855 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected855 ((12 : Int),(1 : Int)) hp6_6_branches855 hp6_6_evidence855 hp6_6_check855 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node854 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected854 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected854 ((10 : Int),(2 : Int)) hp6_6_branches854 hp6_6_evidence854 hp6_6_check854 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node853 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected853 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected853 ((11 : Int),(1 : Int)) hp6_6_branches853 hp6_6_evidence853 hp6_6_check853 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node854 T childKnown
  · exact hp6_6_node855 T childKnown
theorem hp6_6_node852 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected852 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected852 ((8 : Int),(0 : Int)) hp6_6_branches852 hp6_6_evidence852 hp6_6_check852 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node853 T childKnown
theorem hp6_6_node851 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected851 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected851 ((8 : Int),(0 : Int)) hp6_6_branches851 hp6_6_evidence851 hp6_6_check851 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node850 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected850 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected850 ((3 : Int),(1 : Int)) hp6_6_branches850 hp6_6_evidence850 hp6_6_check850 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node851 T childKnown
  · exact hp6_6_node852 T childKnown
theorem hp6_6_node849 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected849 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected849 ((2 : Int),(1 : Int)) hp6_6_branches849 hp6_6_evidence849 hp6_6_check849 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node850 T childKnown
  · exact hp6_6_node856 T childKnown
  · exact hp6_6_node859 T childKnown
  · exact hp6_6_node884 T childKnown
  · exact hp6_6_node890 T childKnown
theorem hp6_6_node848 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected848 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected848 ((3 : Int),(2 : Int)) hp6_6_branches848 hp6_6_evidence848 hp6_6_check848 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node847 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected847 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected847 ((3 : Int),(2 : Int)) hp6_6_branches847 hp6_6_evidence847 hp6_6_check847 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node846 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected846 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected846 ((2 : Int),(2 : Int)) hp6_6_branches846 hp6_6_evidence846 hp6_6_check846 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node847 T childKnown
  · exact hp6_6_node848 T childKnown
theorem hp6_6_node845 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected845 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected845 ((8 : Int),(0 : Int)) hp6_6_branches845 hp6_6_evidence845 hp6_6_check845 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node846 T childKnown
theorem hp6_6_node844 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected844 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected844 ((3 : Int),(2 : Int)) hp6_6_branches844 hp6_6_evidence844 hp6_6_check844 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node843 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected843 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected843 ((3 : Int),(2 : Int)) hp6_6_branches843 hp6_6_evidence843 hp6_6_check843 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node842 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected842 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected842 ((2 : Int),(2 : Int)) hp6_6_branches842 hp6_6_evidence842 hp6_6_check842 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node843 T childKnown
  · exact hp6_6_node844 T childKnown
theorem hp6_6_node841 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected841 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected841 ((10 : Int),(1 : Int)) hp6_6_branches841 hp6_6_evidence841 hp6_6_check841 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node840 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected840 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected840 ((12 : Int),(1 : Int)) hp6_6_branches840 hp6_6_evidence840 hp6_6_check840 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node839 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected839 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected839 ((11 : Int),(1 : Int)) hp6_6_branches839 hp6_6_evidence839 hp6_6_check839 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node840 T childKnown
theorem hp6_6_node838 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected838 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected838 ((4 : Int),(2 : Int)) hp6_6_branches838 hp6_6_evidence838 hp6_6_check838 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node839 T childKnown
  · exact hp6_6_node841 T childKnown
theorem hp6_6_node837 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected837 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected837 ((10 : Int),(1 : Int)) hp6_6_branches837 hp6_6_evidence837 hp6_6_check837 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node836 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected836 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected836 ((12 : Int),(1 : Int)) hp6_6_branches836 hp6_6_evidence836 hp6_6_check836 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node835 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected835 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected835 ((11 : Int),(1 : Int)) hp6_6_branches835 hp6_6_evidence835 hp6_6_check835 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node836 T childKnown
theorem hp6_6_node834 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected834 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected834 ((4 : Int),(2 : Int)) hp6_6_branches834 hp6_6_evidence834 hp6_6_check834 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node835 T childKnown
  · exact hp6_6_node837 T childKnown
theorem hp6_6_node833 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected833 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected833 ((2 : Int),(2 : Int)) hp6_6_branches833 hp6_6_evidence833 hp6_6_check833 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node834 T childKnown
  · exact hp6_6_node838 T childKnown
theorem hp6_6_node832 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected832 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected832 ((8 : Int),(0 : Int)) hp6_6_branches832 hp6_6_evidence832 hp6_6_check832 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node833 T childKnown
theorem hp6_6_node831 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected831 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected831 ((3 : Int),(2 : Int)) hp6_6_branches831 hp6_6_evidence831 hp6_6_check831 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node830 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected830 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected830 ((3 : Int),(2 : Int)) hp6_6_branches830 hp6_6_evidence830 hp6_6_check830 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node829 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected829 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected829 ((3 : Int),(1 : Int)) hp6_6_branches829 hp6_6_evidence829 hp6_6_check829 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node830 T childKnown
  · exact hp6_6_node831 T childKnown
theorem hp6_6_node828 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected828 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected828 ((12 : Int),(1 : Int)) hp6_6_branches828 hp6_6_evidence828 hp6_6_check828 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node827 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected827 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected827 ((10 : Int),(2 : Int)) hp6_6_branches827 hp6_6_evidence827 hp6_6_check827 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node826 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected826 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected826 ((11 : Int),(1 : Int)) hp6_6_branches826 hp6_6_evidence826 hp6_6_check826 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node827 T childKnown
  · exact hp6_6_node828 T childKnown
theorem hp6_6_node825 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected825 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected825 ((8 : Int),(0 : Int)) hp6_6_branches825 hp6_6_evidence825 hp6_6_check825 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node826 T childKnown
theorem hp6_6_node824 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected824 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected824 ((8 : Int),(0 : Int)) hp6_6_branches824 hp6_6_evidence824 hp6_6_check824 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node823 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected823 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected823 ((3 : Int),(1 : Int)) hp6_6_branches823 hp6_6_evidence823 hp6_6_check823 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node824 T childKnown
  · exact hp6_6_node825 T childKnown
theorem hp6_6_node822 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected822 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected822 ((3 : Int),(2 : Int)) hp6_6_branches822 hp6_6_evidence822 hp6_6_check822 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node821 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected821 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected821 ((3 : Int),(2 : Int)) hp6_6_branches821 hp6_6_evidence821 hp6_6_check821 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node820 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected820 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected820 ((3 : Int),(1 : Int)) hp6_6_branches820 hp6_6_evidence820 hp6_6_check820 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node821 T childKnown
  · exact hp6_6_node822 T childKnown
theorem hp6_6_node819 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected819 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected819 ((2 : Int),(1 : Int)) hp6_6_branches819 hp6_6_evidence819 hp6_6_check819 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node820 T childKnown
  · exact hp6_6_node823 T childKnown
  · exact hp6_6_node829 T childKnown
  · exact hp6_6_node832 T childKnown
  · exact hp6_6_node842 T childKnown
  · exact hp6_6_node845 T childKnown
theorem hp6_6_node818 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected818 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected818 ((3 : Int),(2 : Int)) hp6_6_branches818 hp6_6_evidence818 hp6_6_check818 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node817 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected817 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected817 ((3 : Int),(2 : Int)) hp6_6_branches817 hp6_6_evidence817 hp6_6_check817 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node816 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected816 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected816 ((2 : Int),(2 : Int)) hp6_6_branches816 hp6_6_evidence816 hp6_6_check816 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node817 T childKnown
  · exact hp6_6_node818 T childKnown
theorem hp6_6_node815 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected815 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected815 ((8 : Int),(0 : Int)) hp6_6_branches815 hp6_6_evidence815 hp6_6_check815 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node816 T childKnown
theorem hp6_6_node814 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected814 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected814 ((3 : Int),(2 : Int)) hp6_6_branches814 hp6_6_evidence814 hp6_6_check814 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node813 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected813 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected813 ((3 : Int),(2 : Int)) hp6_6_branches813 hp6_6_evidence813 hp6_6_check813 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node812 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected812 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected812 ((2 : Int),(2 : Int)) hp6_6_branches812 hp6_6_evidence812 hp6_6_check812 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node813 T childKnown
  · exact hp6_6_node814 T childKnown
theorem hp6_6_node811 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected811 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected811 ((10 : Int),(1 : Int)) hp6_6_branches811 hp6_6_evidence811 hp6_6_check811 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node810 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected810 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected810 ((12 : Int),(1 : Int)) hp6_6_branches810 hp6_6_evidence810 hp6_6_check810 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node809 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected809 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected809 ((11 : Int),(1 : Int)) hp6_6_branches809 hp6_6_evidence809 hp6_6_check809 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node810 T childKnown
theorem hp6_6_node808 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected808 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected808 ((4 : Int),(2 : Int)) hp6_6_branches808 hp6_6_evidence808 hp6_6_check808 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node809 T childKnown
  · exact hp6_6_node811 T childKnown
theorem hp6_6_node807 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected807 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected807 ((10 : Int),(1 : Int)) hp6_6_branches807 hp6_6_evidence807 hp6_6_check807 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node806 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected806 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected806 ((12 : Int),(1 : Int)) hp6_6_branches806 hp6_6_evidence806 hp6_6_check806 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node805 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected805 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected805 ((11 : Int),(1 : Int)) hp6_6_branches805 hp6_6_evidence805 hp6_6_check805 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node806 T childKnown
theorem hp6_6_node804 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected804 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected804 ((4 : Int),(2 : Int)) hp6_6_branches804 hp6_6_evidence804 hp6_6_check804 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node805 T childKnown
  · exact hp6_6_node807 T childKnown
theorem hp6_6_node803 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected803 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected803 ((2 : Int),(2 : Int)) hp6_6_branches803 hp6_6_evidence803 hp6_6_check803 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node804 T childKnown
  · exact hp6_6_node808 T childKnown
theorem hp6_6_node802 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected802 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected802 ((8 : Int),(0 : Int)) hp6_6_branches802 hp6_6_evidence802 hp6_6_check802 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node803 T childKnown
theorem hp6_6_node801 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected801 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected801 ((3 : Int),(2 : Int)) hp6_6_branches801 hp6_6_evidence801 hp6_6_check801 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node800 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected800 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected800 ((3 : Int),(2 : Int)) hp6_6_branches800 hp6_6_evidence800 hp6_6_check800 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node799 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected799 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected799 ((3 : Int),(1 : Int)) hp6_6_branches799 hp6_6_evidence799 hp6_6_check799 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node800 T childKnown
  · exact hp6_6_node801 T childKnown
theorem hp6_6_node798 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected798 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected798 ((12 : Int),(1 : Int)) hp6_6_branches798 hp6_6_evidence798 hp6_6_check798 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node797 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected797 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected797 ((10 : Int),(2 : Int)) hp6_6_branches797 hp6_6_evidence797 hp6_6_check797 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node796 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected796 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected796 ((11 : Int),(1 : Int)) hp6_6_branches796 hp6_6_evidence796 hp6_6_check796 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node797 T childKnown
  · exact hp6_6_node798 T childKnown
theorem hp6_6_node795 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected795 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected795 ((8 : Int),(0 : Int)) hp6_6_branches795 hp6_6_evidence795 hp6_6_check795 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node796 T childKnown
theorem hp6_6_node794 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected794 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected794 ((8 : Int),(0 : Int)) hp6_6_branches794 hp6_6_evidence794 hp6_6_check794 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node793 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected793 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected793 ((3 : Int),(1 : Int)) hp6_6_branches793 hp6_6_evidence793 hp6_6_check793 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node794 T childKnown
  · exact hp6_6_node795 T childKnown
theorem hp6_6_node792 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected792 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected792 ((3 : Int),(2 : Int)) hp6_6_branches792 hp6_6_evidence792 hp6_6_check792 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node791 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected791 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected791 ((3 : Int),(2 : Int)) hp6_6_branches791 hp6_6_evidence791 hp6_6_check791 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node790 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected790 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected790 ((3 : Int),(1 : Int)) hp6_6_branches790 hp6_6_evidence790 hp6_6_check790 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node791 T childKnown
  · exact hp6_6_node792 T childKnown
theorem hp6_6_node789 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected789 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected789 ((2 : Int),(1 : Int)) hp6_6_branches789 hp6_6_evidence789 hp6_6_check789 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node790 T childKnown
  · exact hp6_6_node793 T childKnown
  · exact hp6_6_node799 T childKnown
  · exact hp6_6_node802 T childKnown
  · exact hp6_6_node812 T childKnown
  · exact hp6_6_node815 T childKnown
theorem hp6_6_node788 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected788 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected788 ((2 : Int),(1 : Int)) hp6_6_branches788 hp6_6_evidence788 hp6_6_check788 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node787 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected787 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected787 ((2 : Int),(1 : Int)) hp6_6_branches787 hp6_6_evidence787 hp6_6_check787 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node786 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected786 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected786 ((3 : Int),(2 : Int)) hp6_6_branches786 hp6_6_evidence786 hp6_6_check786 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node785 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected785 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected785 ((3 : Int),(2 : Int)) hp6_6_branches785 hp6_6_evidence785 hp6_6_check785 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node784 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected784 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected784 ((3 : Int),(1 : Int)) hp6_6_branches784 hp6_6_evidence784 hp6_6_check784 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node785 T childKnown
  · exact hp6_6_node786 T childKnown
theorem hp6_6_node783 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected783 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected783 ((2 : Int),(2 : Int)) hp6_6_branches783 hp6_6_evidence783 hp6_6_check783 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node784 T childKnown
  · exact hp6_6_node787 T childKnown
  · exact hp6_6_node788 T childKnown
theorem hp6_6_node782 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected782 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected782 ((2 : Int),(1 : Int)) hp6_6_branches782 hp6_6_evidence782 hp6_6_check782 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node781 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected781 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected781 ((2 : Int),(1 : Int)) hp6_6_branches781 hp6_6_evidence781 hp6_6_check781 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node780 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected780 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected780 ((3 : Int),(2 : Int)) hp6_6_branches780 hp6_6_evidence780 hp6_6_check780 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node779 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected779 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected779 ((3 : Int),(2 : Int)) hp6_6_branches779 hp6_6_evidence779 hp6_6_check779 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node778 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected778 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected778 ((3 : Int),(1 : Int)) hp6_6_branches778 hp6_6_evidence778 hp6_6_check778 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node779 T childKnown
  · exact hp6_6_node780 T childKnown
theorem hp6_6_node777 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected777 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected777 ((2 : Int),(2 : Int)) hp6_6_branches777 hp6_6_evidence777 hp6_6_check777 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node778 T childKnown
  · exact hp6_6_node781 T childKnown
  · exact hp6_6_node782 T childKnown
theorem hp6_6_node776 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected776 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected776 ((3 : Int),(2 : Int)) hp6_6_branches776 hp6_6_evidence776 hp6_6_check776 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node775 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected775 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected775 ((2 : Int),(2 : Int)) hp6_6_branches775 hp6_6_evidence775 hp6_6_check775 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node776 T childKnown
theorem hp6_6_node774 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected774 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected774 ((3 : Int),(2 : Int)) hp6_6_branches774 hp6_6_evidence774 hp6_6_check774 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node773 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected773 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected773 ((2 : Int),(2 : Int)) hp6_6_branches773 hp6_6_evidence773 hp6_6_check773 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node774 T childKnown
theorem hp6_6_node772 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected772 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected772 ((10 : Int),(1 : Int)) hp6_6_branches772 hp6_6_evidence772 hp6_6_check772 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node771 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected771 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected771 ((12 : Int),(1 : Int)) hp6_6_branches771 hp6_6_evidence771 hp6_6_check771 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node770 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected770 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected770 ((11 : Int),(1 : Int)) hp6_6_branches770 hp6_6_evidence770 hp6_6_check770 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node771 T childKnown
theorem hp6_6_node769 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected769 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected769 ((4 : Int),(2 : Int)) hp6_6_branches769 hp6_6_evidence769 hp6_6_check769 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node770 T childKnown
  · exact hp6_6_node772 T childKnown
theorem hp6_6_node768 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected768 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected768 ((8 : Int),(0 : Int)) hp6_6_branches768 hp6_6_evidence768 hp6_6_check768 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node769 T childKnown
theorem hp6_6_node767 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected767 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected767 ((2 : Int),(2 : Int)) hp6_6_branches767 hp6_6_evidence767 hp6_6_check767 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node768 T childKnown
theorem hp6_6_node766 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected766 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected766 ((3 : Int),(2 : Int)) hp6_6_branches766 hp6_6_evidence766 hp6_6_check766 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node765 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected765 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected765 ((3 : Int),(2 : Int)) hp6_6_branches765 hp6_6_evidence765 hp6_6_check765 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node764 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected764 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected764 ((3 : Int),(1 : Int)) hp6_6_branches764 hp6_6_evidence764 hp6_6_check764 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node765 T childKnown
  · exact hp6_6_node766 T childKnown
theorem hp6_6_node763 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected763 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected763 ((12 : Int),(1 : Int)) hp6_6_branches763 hp6_6_evidence763 hp6_6_check763 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node762 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected762 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected762 ((10 : Int),(2 : Int)) hp6_6_branches762 hp6_6_evidence762 hp6_6_check762 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node761 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected761 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected761 ((11 : Int),(1 : Int)) hp6_6_branches761 hp6_6_evidence761 hp6_6_check761 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node762 T childKnown
  · exact hp6_6_node763 T childKnown
theorem hp6_6_node760 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected760 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected760 ((8 : Int),(0 : Int)) hp6_6_branches760 hp6_6_evidence760 hp6_6_check760 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node761 T childKnown
theorem hp6_6_node759 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected759 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected759 ((8 : Int),(0 : Int)) hp6_6_branches759 hp6_6_evidence759 hp6_6_check759 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node758 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected758 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected758 ((3 : Int),(1 : Int)) hp6_6_branches758 hp6_6_evidence758 hp6_6_check758 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node759 T childKnown
  · exact hp6_6_node760 T childKnown
theorem hp6_6_node757 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected757 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected757 ((3 : Int),(2 : Int)) hp6_6_branches757 hp6_6_evidence757 hp6_6_check757 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node756 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected756 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected756 ((3 : Int),(2 : Int)) hp6_6_branches756 hp6_6_evidence756 hp6_6_check756 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node755 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected755 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected755 ((3 : Int),(1 : Int)) hp6_6_branches755 hp6_6_evidence755 hp6_6_check755 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node756 T childKnown
  · exact hp6_6_node757 T childKnown
theorem hp6_6_node754 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected754 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected754 ((2 : Int),(1 : Int)) hp6_6_branches754 hp6_6_evidence754 hp6_6_check754 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node755 T childKnown
  · exact hp6_6_node758 T childKnown
  · exact hp6_6_node764 T childKnown
  · exact hp6_6_node767 T childKnown
  · exact hp6_6_node773 T childKnown
  · exact hp6_6_node775 T childKnown
theorem hp6_6_node753 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected753 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected753 ((3 : Int),(2 : Int)) hp6_6_branches753 hp6_6_evidence753 hp6_6_check753 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node752 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected752 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected752 ((3 : Int),(2 : Int)) hp6_6_branches752 hp6_6_evidence752 hp6_6_check752 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node751 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected751 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected751 ((2 : Int),(2 : Int)) hp6_6_branches751 hp6_6_evidence751 hp6_6_check751 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node752 T childKnown
  · exact hp6_6_node753 T childKnown
theorem hp6_6_node750 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected750 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected750 ((8 : Int),(0 : Int)) hp6_6_branches750 hp6_6_evidence750 hp6_6_check750 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node751 T childKnown
theorem hp6_6_node749 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected749 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected749 ((3 : Int),(2 : Int)) hp6_6_branches749 hp6_6_evidence749 hp6_6_check749 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node748 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected748 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected748 ((3 : Int),(2 : Int)) hp6_6_branches748 hp6_6_evidence748 hp6_6_check748 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node747 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected747 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected747 ((2 : Int),(2 : Int)) hp6_6_branches747 hp6_6_evidence747 hp6_6_check747 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node748 T childKnown
  · exact hp6_6_node749 T childKnown
theorem hp6_6_node746 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected746 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected746 ((10 : Int),(1 : Int)) hp6_6_branches746 hp6_6_evidence746 hp6_6_check746 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node745 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected745 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected745 ((12 : Int),(1 : Int)) hp6_6_branches745 hp6_6_evidence745 hp6_6_check745 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node744 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected744 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected744 ((11 : Int),(1 : Int)) hp6_6_branches744 hp6_6_evidence744 hp6_6_check744 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node745 T childKnown
theorem hp6_6_node743 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected743 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected743 ((4 : Int),(2 : Int)) hp6_6_branches743 hp6_6_evidence743 hp6_6_check743 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node744 T childKnown
  · exact hp6_6_node746 T childKnown
theorem hp6_6_node742 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected742 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected742 ((10 : Int),(1 : Int)) hp6_6_branches742 hp6_6_evidence742 hp6_6_check742 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node741 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected741 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected741 ((12 : Int),(1 : Int)) hp6_6_branches741 hp6_6_evidence741 hp6_6_check741 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node740 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected740 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected740 ((11 : Int),(1 : Int)) hp6_6_branches740 hp6_6_evidence740 hp6_6_check740 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node741 T childKnown
theorem hp6_6_node739 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected739 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected739 ((4 : Int),(2 : Int)) hp6_6_branches739 hp6_6_evidence739 hp6_6_check739 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node740 T childKnown
  · exact hp6_6_node742 T childKnown
theorem hp6_6_node738 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected738 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected738 ((2 : Int),(2 : Int)) hp6_6_branches738 hp6_6_evidence738 hp6_6_check738 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node739 T childKnown
  · exact hp6_6_node743 T childKnown
theorem hp6_6_node737 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected737 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected737 ((8 : Int),(0 : Int)) hp6_6_branches737 hp6_6_evidence737 hp6_6_check737 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node738 T childKnown
theorem hp6_6_node736 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected736 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected736 ((3 : Int),(2 : Int)) hp6_6_branches736 hp6_6_evidence736 hp6_6_check736 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node735 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected735 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected735 ((3 : Int),(2 : Int)) hp6_6_branches735 hp6_6_evidence735 hp6_6_check735 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node734 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected734 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected734 ((3 : Int),(1 : Int)) hp6_6_branches734 hp6_6_evidence734 hp6_6_check734 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node735 T childKnown
  · exact hp6_6_node736 T childKnown
theorem hp6_6_node733 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected733 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected733 ((12 : Int),(1 : Int)) hp6_6_branches733 hp6_6_evidence733 hp6_6_check733 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node732 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected732 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected732 ((10 : Int),(2 : Int)) hp6_6_branches732 hp6_6_evidence732 hp6_6_check732 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node731 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected731 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected731 ((11 : Int),(1 : Int)) hp6_6_branches731 hp6_6_evidence731 hp6_6_check731 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node732 T childKnown
  · exact hp6_6_node733 T childKnown
theorem hp6_6_node730 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected730 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected730 ((8 : Int),(0 : Int)) hp6_6_branches730 hp6_6_evidence730 hp6_6_check730 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node731 T childKnown
theorem hp6_6_node729 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected729 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected729 ((8 : Int),(0 : Int)) hp6_6_branches729 hp6_6_evidence729 hp6_6_check729 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node728 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected728 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected728 ((3 : Int),(1 : Int)) hp6_6_branches728 hp6_6_evidence728 hp6_6_check728 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node729 T childKnown
  · exact hp6_6_node730 T childKnown
theorem hp6_6_node727 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected727 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected727 ((3 : Int),(2 : Int)) hp6_6_branches727 hp6_6_evidence727 hp6_6_check727 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node726 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected726 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected726 ((3 : Int),(2 : Int)) hp6_6_branches726 hp6_6_evidence726 hp6_6_check726 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node725 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected725 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected725 ((3 : Int),(1 : Int)) hp6_6_branches725 hp6_6_evidence725 hp6_6_check725 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node726 T childKnown
  · exact hp6_6_node727 T childKnown
theorem hp6_6_node724 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected724 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected724 ((2 : Int),(1 : Int)) hp6_6_branches724 hp6_6_evidence724 hp6_6_check724 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node725 T childKnown
  · exact hp6_6_node728 T childKnown
  · exact hp6_6_node734 T childKnown
  · exact hp6_6_node737 T childKnown
  · exact hp6_6_node747 T childKnown
  · exact hp6_6_node750 T childKnown
theorem hp6_6_node723 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected723 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected723 ((0 : Int),(2 : Int)) hp6_6_branches723 hp6_6_evidence723 hp6_6_check723 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node724 T childKnown
  · exact hp6_6_node754 T childKnown
  · exact hp6_6_node777 T childKnown
  · exact hp6_6_node783 T childKnown
theorem hp6_6_node722 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected722 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected722 ((2 : Int),(1 : Int)) hp6_6_branches722 hp6_6_evidence722 hp6_6_check722 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node721 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected721 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected721 ((2 : Int),(1 : Int)) hp6_6_branches721 hp6_6_evidence721 hp6_6_check721 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node720 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected720 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected720 ((3 : Int),(2 : Int)) hp6_6_branches720 hp6_6_evidence720 hp6_6_check720 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node719 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected719 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected719 ((3 : Int),(2 : Int)) hp6_6_branches719 hp6_6_evidence719 hp6_6_check719 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node718 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected718 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected718 ((3 : Int),(1 : Int)) hp6_6_branches718 hp6_6_evidence718 hp6_6_check718 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node719 T childKnown
  · exact hp6_6_node720 T childKnown
theorem hp6_6_node717 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected717 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected717 ((2 : Int),(2 : Int)) hp6_6_branches717 hp6_6_evidence717 hp6_6_check717 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node718 T childKnown
  · exact hp6_6_node721 T childKnown
  · exact hp6_6_node722 T childKnown
theorem hp6_6_node716 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected716 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected716 ((2 : Int),(1 : Int)) hp6_6_branches716 hp6_6_evidence716 hp6_6_check716 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node715 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected715 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected715 ((2 : Int),(1 : Int)) hp6_6_branches715 hp6_6_evidence715 hp6_6_check715 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node714 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected714 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected714 ((3 : Int),(2 : Int)) hp6_6_branches714 hp6_6_evidence714 hp6_6_check714 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node713 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected713 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected713 ((3 : Int),(2 : Int)) hp6_6_branches713 hp6_6_evidence713 hp6_6_check713 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node712 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected712 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected712 ((3 : Int),(1 : Int)) hp6_6_branches712 hp6_6_evidence712 hp6_6_check712 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node713 T childKnown
  · exact hp6_6_node714 T childKnown
theorem hp6_6_node711 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected711 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected711 ((2 : Int),(2 : Int)) hp6_6_branches711 hp6_6_evidence711 hp6_6_check711 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node712 T childKnown
  · exact hp6_6_node715 T childKnown
  · exact hp6_6_node716 T childKnown
theorem hp6_6_node710 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected710 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected710 ((3 : Int),(2 : Int)) hp6_6_branches710 hp6_6_evidence710 hp6_6_check710 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node709 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected709 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected709 ((2 : Int),(2 : Int)) hp6_6_branches709 hp6_6_evidence709 hp6_6_check709 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node710 T childKnown
theorem hp6_6_node708 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected708 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected708 ((3 : Int),(2 : Int)) hp6_6_branches708 hp6_6_evidence708 hp6_6_check708 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node707 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected707 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected707 ((2 : Int),(2 : Int)) hp6_6_branches707 hp6_6_evidence707 hp6_6_check707 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node708 T childKnown
theorem hp6_6_node706 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected706 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected706 ((10 : Int),(1 : Int)) hp6_6_branches706 hp6_6_evidence706 hp6_6_check706 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node705 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected705 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected705 ((12 : Int),(1 : Int)) hp6_6_branches705 hp6_6_evidence705 hp6_6_check705 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node704 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected704 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected704 ((11 : Int),(1 : Int)) hp6_6_branches704 hp6_6_evidence704 hp6_6_check704 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node705 T childKnown
theorem hp6_6_node703 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected703 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected703 ((4 : Int),(2 : Int)) hp6_6_branches703 hp6_6_evidence703 hp6_6_check703 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node704 T childKnown
  · exact hp6_6_node706 T childKnown
theorem hp6_6_node702 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected702 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected702 ((8 : Int),(0 : Int)) hp6_6_branches702 hp6_6_evidence702 hp6_6_check702 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node703 T childKnown
theorem hp6_6_node701 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected701 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected701 ((2 : Int),(2 : Int)) hp6_6_branches701 hp6_6_evidence701 hp6_6_check701 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node702 T childKnown
theorem hp6_6_node700 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected700 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected700 ((3 : Int),(2 : Int)) hp6_6_branches700 hp6_6_evidence700 hp6_6_check700 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node699 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected699 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected699 ((3 : Int),(2 : Int)) hp6_6_branches699 hp6_6_evidence699 hp6_6_check699 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node698 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected698 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected698 ((3 : Int),(1 : Int)) hp6_6_branches698 hp6_6_evidence698 hp6_6_check698 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node699 T childKnown
  · exact hp6_6_node700 T childKnown
theorem hp6_6_node697 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected697 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected697 ((12 : Int),(1 : Int)) hp6_6_branches697 hp6_6_evidence697 hp6_6_check697 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node696 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected696 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected696 ((10 : Int),(2 : Int)) hp6_6_branches696 hp6_6_evidence696 hp6_6_check696 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node695 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected695 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected695 ((11 : Int),(1 : Int)) hp6_6_branches695 hp6_6_evidence695 hp6_6_check695 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node696 T childKnown
  · exact hp6_6_node697 T childKnown
theorem hp6_6_node694 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected694 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected694 ((8 : Int),(0 : Int)) hp6_6_branches694 hp6_6_evidence694 hp6_6_check694 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node695 T childKnown
theorem hp6_6_node693 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected693 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected693 ((8 : Int),(0 : Int)) hp6_6_branches693 hp6_6_evidence693 hp6_6_check693 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node692 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected692 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected692 ((3 : Int),(1 : Int)) hp6_6_branches692 hp6_6_evidence692 hp6_6_check692 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node693 T childKnown
  · exact hp6_6_node694 T childKnown
theorem hp6_6_node691 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected691 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected691 ((3 : Int),(2 : Int)) hp6_6_branches691 hp6_6_evidence691 hp6_6_check691 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node690 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected690 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected690 ((3 : Int),(2 : Int)) hp6_6_branches690 hp6_6_evidence690 hp6_6_check690 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node689 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected689 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected689 ((3 : Int),(1 : Int)) hp6_6_branches689 hp6_6_evidence689 hp6_6_check689 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node690 T childKnown
  · exact hp6_6_node691 T childKnown
theorem hp6_6_node688 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected688 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected688 ((2 : Int),(1 : Int)) hp6_6_branches688 hp6_6_evidence688 hp6_6_check688 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node689 T childKnown
  · exact hp6_6_node692 T childKnown
  · exact hp6_6_node698 T childKnown
  · exact hp6_6_node701 T childKnown
  · exact hp6_6_node707 T childKnown
  · exact hp6_6_node709 T childKnown
theorem hp6_6_node687 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected687 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected687 ((3 : Int),(2 : Int)) hp6_6_branches687 hp6_6_evidence687 hp6_6_check687 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node686 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected686 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected686 ((3 : Int),(2 : Int)) hp6_6_branches686 hp6_6_evidence686 hp6_6_check686 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node685 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected685 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected685 ((2 : Int),(2 : Int)) hp6_6_branches685 hp6_6_evidence685 hp6_6_check685 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node686 T childKnown
  · exact hp6_6_node687 T childKnown
theorem hp6_6_node684 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected684 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected684 ((8 : Int),(0 : Int)) hp6_6_branches684 hp6_6_evidence684 hp6_6_check684 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node685 T childKnown
theorem hp6_6_node683 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected683 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected683 ((3 : Int),(2 : Int)) hp6_6_branches683 hp6_6_evidence683 hp6_6_check683 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node682 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected682 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected682 ((3 : Int),(2 : Int)) hp6_6_branches682 hp6_6_evidence682 hp6_6_check682 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node681 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected681 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected681 ((2 : Int),(2 : Int)) hp6_6_branches681 hp6_6_evidence681 hp6_6_check681 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node682 T childKnown
  · exact hp6_6_node683 T childKnown
theorem hp6_6_node680 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected680 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected680 ((10 : Int),(1 : Int)) hp6_6_branches680 hp6_6_evidence680 hp6_6_check680 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node679 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected679 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected679 ((12 : Int),(1 : Int)) hp6_6_branches679 hp6_6_evidence679 hp6_6_check679 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node678 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected678 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected678 ((11 : Int),(1 : Int)) hp6_6_branches678 hp6_6_evidence678 hp6_6_check678 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node679 T childKnown
theorem hp6_6_node677 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected677 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected677 ((4 : Int),(2 : Int)) hp6_6_branches677 hp6_6_evidence677 hp6_6_check677 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node678 T childKnown
  · exact hp6_6_node680 T childKnown
theorem hp6_6_node676 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected676 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected676 ((10 : Int),(1 : Int)) hp6_6_branches676 hp6_6_evidence676 hp6_6_check676 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node675 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected675 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected675 ((12 : Int),(1 : Int)) hp6_6_branches675 hp6_6_evidence675 hp6_6_check675 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node674 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected674 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected674 ((11 : Int),(1 : Int)) hp6_6_branches674 hp6_6_evidence674 hp6_6_check674 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node675 T childKnown
theorem hp6_6_node673 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected673 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected673 ((4 : Int),(2 : Int)) hp6_6_branches673 hp6_6_evidence673 hp6_6_check673 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node674 T childKnown
  · exact hp6_6_node676 T childKnown
theorem hp6_6_node672 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected672 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected672 ((2 : Int),(2 : Int)) hp6_6_branches672 hp6_6_evidence672 hp6_6_check672 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node673 T childKnown
  · exact hp6_6_node677 T childKnown
theorem hp6_6_node671 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected671 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected671 ((8 : Int),(0 : Int)) hp6_6_branches671 hp6_6_evidence671 hp6_6_check671 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node672 T childKnown
theorem hp6_6_node670 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected670 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected670 ((3 : Int),(2 : Int)) hp6_6_branches670 hp6_6_evidence670 hp6_6_check670 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node669 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected669 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected669 ((3 : Int),(2 : Int)) hp6_6_branches669 hp6_6_evidence669 hp6_6_check669 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node668 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected668 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected668 ((3 : Int),(1 : Int)) hp6_6_branches668 hp6_6_evidence668 hp6_6_check668 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node669 T childKnown
  · exact hp6_6_node670 T childKnown
theorem hp6_6_node667 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected667 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected667 ((12 : Int),(1 : Int)) hp6_6_branches667 hp6_6_evidence667 hp6_6_check667 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node666 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected666 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected666 ((10 : Int),(2 : Int)) hp6_6_branches666 hp6_6_evidence666 hp6_6_check666 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node665 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected665 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected665 ((11 : Int),(1 : Int)) hp6_6_branches665 hp6_6_evidence665 hp6_6_check665 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node666 T childKnown
  · exact hp6_6_node667 T childKnown
theorem hp6_6_node664 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected664 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected664 ((8 : Int),(0 : Int)) hp6_6_branches664 hp6_6_evidence664 hp6_6_check664 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node665 T childKnown
theorem hp6_6_node663 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected663 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected663 ((8 : Int),(0 : Int)) hp6_6_branches663 hp6_6_evidence663 hp6_6_check663 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node662 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected662 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected662 ((3 : Int),(1 : Int)) hp6_6_branches662 hp6_6_evidence662 hp6_6_check662 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node663 T childKnown
  · exact hp6_6_node664 T childKnown
theorem hp6_6_node661 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected661 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected661 ((3 : Int),(2 : Int)) hp6_6_branches661 hp6_6_evidence661 hp6_6_check661 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node660 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected660 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected660 ((3 : Int),(2 : Int)) hp6_6_branches660 hp6_6_evidence660 hp6_6_check660 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node659 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected659 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected659 ((3 : Int),(1 : Int)) hp6_6_branches659 hp6_6_evidence659 hp6_6_check659 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node660 T childKnown
  · exact hp6_6_node661 T childKnown
theorem hp6_6_node658 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected658 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected658 ((2 : Int),(1 : Int)) hp6_6_branches658 hp6_6_evidence658 hp6_6_check658 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node659 T childKnown
  · exact hp6_6_node662 T childKnown
  · exact hp6_6_node668 T childKnown
  · exact hp6_6_node671 T childKnown
  · exact hp6_6_node681 T childKnown
  · exact hp6_6_node684 T childKnown
theorem hp6_6_node657 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected657 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected657 ((0 : Int),(2 : Int)) hp6_6_branches657 hp6_6_evidence657 hp6_6_check657 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node658 T childKnown
  · exact hp6_6_node688 T childKnown
  · exact hp6_6_node711 T childKnown
  · exact hp6_6_node717 T childKnown
theorem hp6_6_node656 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected656 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected656 ((2 : Int),(1 : Int)) hp6_6_branches656 hp6_6_evidence656 hp6_6_check656 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node655 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected655 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected655 ((2 : Int),(1 : Int)) hp6_6_branches655 hp6_6_evidence655 hp6_6_check655 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node654 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected654 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected654 ((3 : Int),(2 : Int)) hp6_6_branches654 hp6_6_evidence654 hp6_6_check654 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node653 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected653 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected653 ((3 : Int),(2 : Int)) hp6_6_branches653 hp6_6_evidence653 hp6_6_check653 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node652 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected652 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected652 ((3 : Int),(1 : Int)) hp6_6_branches652 hp6_6_evidence652 hp6_6_check652 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node653 T childKnown
  · exact hp6_6_node654 T childKnown
theorem hp6_6_node651 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected651 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected651 ((2 : Int),(2 : Int)) hp6_6_branches651 hp6_6_evidence651 hp6_6_check651 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node652 T childKnown
  · exact hp6_6_node655 T childKnown
  · exact hp6_6_node656 T childKnown
theorem hp6_6_node650 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected650 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected650 ((2 : Int),(1 : Int)) hp6_6_branches650 hp6_6_evidence650 hp6_6_check650 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node649 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected649 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected649 ((2 : Int),(1 : Int)) hp6_6_branches649 hp6_6_evidence649 hp6_6_check649 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node648 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected648 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected648 ((3 : Int),(2 : Int)) hp6_6_branches648 hp6_6_evidence648 hp6_6_check648 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node647 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected647 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected647 ((3 : Int),(2 : Int)) hp6_6_branches647 hp6_6_evidence647 hp6_6_check647 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node646 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected646 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected646 ((3 : Int),(1 : Int)) hp6_6_branches646 hp6_6_evidence646 hp6_6_check646 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node647 T childKnown
  · exact hp6_6_node648 T childKnown
theorem hp6_6_node645 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected645 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected645 ((2 : Int),(2 : Int)) hp6_6_branches645 hp6_6_evidence645 hp6_6_check645 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node646 T childKnown
  · exact hp6_6_node649 T childKnown
  · exact hp6_6_node650 T childKnown
theorem hp6_6_node644 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected644 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected644 ((3 : Int),(2 : Int)) hp6_6_branches644 hp6_6_evidence644 hp6_6_check644 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node643 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected643 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected643 ((2 : Int),(2 : Int)) hp6_6_branches643 hp6_6_evidence643 hp6_6_check643 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node644 T childKnown
theorem hp6_6_node642 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected642 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected642 ((3 : Int),(2 : Int)) hp6_6_branches642 hp6_6_evidence642 hp6_6_check642 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node641 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected641 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected641 ((2 : Int),(2 : Int)) hp6_6_branches641 hp6_6_evidence641 hp6_6_check641 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node642 T childKnown
theorem hp6_6_node640 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected640 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected640 ((10 : Int),(1 : Int)) hp6_6_branches640 hp6_6_evidence640 hp6_6_check640 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node639 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected639 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected639 ((12 : Int),(1 : Int)) hp6_6_branches639 hp6_6_evidence639 hp6_6_check639 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node638 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected638 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected638 ((11 : Int),(1 : Int)) hp6_6_branches638 hp6_6_evidence638 hp6_6_check638 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node639 T childKnown
theorem hp6_6_node637 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected637 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected637 ((4 : Int),(2 : Int)) hp6_6_branches637 hp6_6_evidence637 hp6_6_check637 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node638 T childKnown
  · exact hp6_6_node640 T childKnown
theorem hp6_6_node636 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected636 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected636 ((8 : Int),(0 : Int)) hp6_6_branches636 hp6_6_evidence636 hp6_6_check636 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node637 T childKnown
theorem hp6_6_node635 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected635 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected635 ((2 : Int),(2 : Int)) hp6_6_branches635 hp6_6_evidence635 hp6_6_check635 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node636 T childKnown
theorem hp6_6_node634 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected634 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected634 ((3 : Int),(2 : Int)) hp6_6_branches634 hp6_6_evidence634 hp6_6_check634 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node633 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected633 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected633 ((3 : Int),(2 : Int)) hp6_6_branches633 hp6_6_evidence633 hp6_6_check633 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node632 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected632 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected632 ((3 : Int),(1 : Int)) hp6_6_branches632 hp6_6_evidence632 hp6_6_check632 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node633 T childKnown
  · exact hp6_6_node634 T childKnown
theorem hp6_6_node631 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected631 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected631 ((12 : Int),(1 : Int)) hp6_6_branches631 hp6_6_evidence631 hp6_6_check631 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node630 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected630 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected630 ((10 : Int),(2 : Int)) hp6_6_branches630 hp6_6_evidence630 hp6_6_check630 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node629 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected629 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected629 ((11 : Int),(1 : Int)) hp6_6_branches629 hp6_6_evidence629 hp6_6_check629 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node630 T childKnown
  · exact hp6_6_node631 T childKnown
theorem hp6_6_node628 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected628 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected628 ((8 : Int),(0 : Int)) hp6_6_branches628 hp6_6_evidence628 hp6_6_check628 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node629 T childKnown
theorem hp6_6_node627 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected627 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected627 ((8 : Int),(0 : Int)) hp6_6_branches627 hp6_6_evidence627 hp6_6_check627 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node626 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected626 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected626 ((3 : Int),(1 : Int)) hp6_6_branches626 hp6_6_evidence626 hp6_6_check626 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node627 T childKnown
  · exact hp6_6_node628 T childKnown
theorem hp6_6_node625 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected625 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected625 ((3 : Int),(2 : Int)) hp6_6_branches625 hp6_6_evidence625 hp6_6_check625 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node624 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected624 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected624 ((3 : Int),(2 : Int)) hp6_6_branches624 hp6_6_evidence624 hp6_6_check624 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node623 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected623 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected623 ((3 : Int),(1 : Int)) hp6_6_branches623 hp6_6_evidence623 hp6_6_check623 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node624 T childKnown
  · exact hp6_6_node625 T childKnown
theorem hp6_6_node622 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected622 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected622 ((2 : Int),(1 : Int)) hp6_6_branches622 hp6_6_evidence622 hp6_6_check622 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node623 T childKnown
  · exact hp6_6_node626 T childKnown
  · exact hp6_6_node632 T childKnown
  · exact hp6_6_node635 T childKnown
  · exact hp6_6_node641 T childKnown
  · exact hp6_6_node643 T childKnown
theorem hp6_6_node621 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected621 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected621 ((3 : Int),(2 : Int)) hp6_6_branches621 hp6_6_evidence621 hp6_6_check621 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node620 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected620 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected620 ((3 : Int),(2 : Int)) hp6_6_branches620 hp6_6_evidence620 hp6_6_check620 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node619 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected619 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected619 ((2 : Int),(2 : Int)) hp6_6_branches619 hp6_6_evidence619 hp6_6_check619 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node620 T childKnown
  · exact hp6_6_node621 T childKnown
theorem hp6_6_node618 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected618 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected618 ((8 : Int),(0 : Int)) hp6_6_branches618 hp6_6_evidence618 hp6_6_check618 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node619 T childKnown
theorem hp6_6_node617 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected617 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected617 ((3 : Int),(2 : Int)) hp6_6_branches617 hp6_6_evidence617 hp6_6_check617 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node616 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected616 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected616 ((3 : Int),(2 : Int)) hp6_6_branches616 hp6_6_evidence616 hp6_6_check616 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node615 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected615 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected615 ((2 : Int),(2 : Int)) hp6_6_branches615 hp6_6_evidence615 hp6_6_check615 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node616 T childKnown
  · exact hp6_6_node617 T childKnown
theorem hp6_6_node614 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected614 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected614 ((10 : Int),(1 : Int)) hp6_6_branches614 hp6_6_evidence614 hp6_6_check614 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node613 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected613 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected613 ((12 : Int),(1 : Int)) hp6_6_branches613 hp6_6_evidence613 hp6_6_check613 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node612 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected612 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected612 ((11 : Int),(1 : Int)) hp6_6_branches612 hp6_6_evidence612 hp6_6_check612 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node613 T childKnown
theorem hp6_6_node611 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected611 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected611 ((4 : Int),(2 : Int)) hp6_6_branches611 hp6_6_evidence611 hp6_6_check611 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node612 T childKnown
  · exact hp6_6_node614 T childKnown
theorem hp6_6_node610 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected610 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected610 ((10 : Int),(1 : Int)) hp6_6_branches610 hp6_6_evidence610 hp6_6_check610 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node609 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected609 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected609 ((12 : Int),(1 : Int)) hp6_6_branches609 hp6_6_evidence609 hp6_6_check609 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node608 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected608 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected608 ((11 : Int),(1 : Int)) hp6_6_branches608 hp6_6_evidence608 hp6_6_check608 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node609 T childKnown
theorem hp6_6_node607 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected607 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected607 ((4 : Int),(2 : Int)) hp6_6_branches607 hp6_6_evidence607 hp6_6_check607 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node608 T childKnown
  · exact hp6_6_node610 T childKnown
theorem hp6_6_node606 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected606 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected606 ((2 : Int),(2 : Int)) hp6_6_branches606 hp6_6_evidence606 hp6_6_check606 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node607 T childKnown
  · exact hp6_6_node611 T childKnown
theorem hp6_6_node605 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected605 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected605 ((8 : Int),(0 : Int)) hp6_6_branches605 hp6_6_evidence605 hp6_6_check605 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node606 T childKnown
theorem hp6_6_node604 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected604 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected604 ((3 : Int),(2 : Int)) hp6_6_branches604 hp6_6_evidence604 hp6_6_check604 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node603 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected603 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected603 ((3 : Int),(2 : Int)) hp6_6_branches603 hp6_6_evidence603 hp6_6_check603 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node602 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected602 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected602 ((3 : Int),(1 : Int)) hp6_6_branches602 hp6_6_evidence602 hp6_6_check602 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node603 T childKnown
  · exact hp6_6_node604 T childKnown
theorem hp6_6_node601 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected601 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected601 ((12 : Int),(1 : Int)) hp6_6_branches601 hp6_6_evidence601 hp6_6_check601 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node600 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected600 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected600 ((10 : Int),(2 : Int)) hp6_6_branches600 hp6_6_evidence600 hp6_6_check600 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node599 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected599 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected599 ((11 : Int),(1 : Int)) hp6_6_branches599 hp6_6_evidence599 hp6_6_check599 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node600 T childKnown
  · exact hp6_6_node601 T childKnown
theorem hp6_6_node598 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected598 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected598 ((8 : Int),(0 : Int)) hp6_6_branches598 hp6_6_evidence598 hp6_6_check598 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node599 T childKnown
theorem hp6_6_node597 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected597 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected597 ((8 : Int),(0 : Int)) hp6_6_branches597 hp6_6_evidence597 hp6_6_check597 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node596 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected596 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected596 ((3 : Int),(1 : Int)) hp6_6_branches596 hp6_6_evidence596 hp6_6_check596 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node597 T childKnown
  · exact hp6_6_node598 T childKnown
theorem hp6_6_node595 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected595 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected595 ((3 : Int),(2 : Int)) hp6_6_branches595 hp6_6_evidence595 hp6_6_check595 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node594 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected594 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected594 ((3 : Int),(2 : Int)) hp6_6_branches594 hp6_6_evidence594 hp6_6_check594 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node593 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected593 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected593 ((3 : Int),(1 : Int)) hp6_6_branches593 hp6_6_evidence593 hp6_6_check593 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node594 T childKnown
  · exact hp6_6_node595 T childKnown
theorem hp6_6_node592 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected592 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected592 ((2 : Int),(1 : Int)) hp6_6_branches592 hp6_6_evidence592 hp6_6_check592 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node593 T childKnown
  · exact hp6_6_node596 T childKnown
  · exact hp6_6_node602 T childKnown
  · exact hp6_6_node605 T childKnown
  · exact hp6_6_node615 T childKnown
  · exact hp6_6_node618 T childKnown
theorem hp6_6_node591 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected591 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected591 ((0 : Int),(2 : Int)) hp6_6_branches591 hp6_6_evidence591 hp6_6_check591 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node592 T childKnown
  · exact hp6_6_node622 T childKnown
  · exact hp6_6_node645 T childKnown
  · exact hp6_6_node651 T childKnown
theorem hp6_6_node590 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected590 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected590 ((0 : Int),(1 : Int)) hp6_6_branches590 hp6_6_evidence590 hp6_6_check590 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node591 T childKnown
  · exact hp6_6_node657 T childKnown
  · exact hp6_6_node723 T childKnown
  · exact hp6_6_node789 T childKnown
  · exact hp6_6_node819 T childKnown
  · exact hp6_6_node849 T childKnown
  · exact hp6_6_node894 T childKnown
  · exact hp6_6_node897 T childKnown
theorem hp6_6_node589 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected589 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected589 ((1 : Int),(1 : Int)) hp6_6_branches589 hp6_6_evidence589 hp6_6_check589 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node588 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected588 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected588 ((1 : Int),(0 : Int)) hp6_6_branches588 hp6_6_evidence588 hp6_6_check588 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node589 T childKnown
theorem hp6_6_node587 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected587 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected587 ((2 : Int),(2 : Int)) hp6_6_branches587 hp6_6_evidence587 hp6_6_check587 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node586 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected586 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected586 ((2 : Int),(2 : Int)) hp6_6_branches586 hp6_6_evidence586 hp6_6_check586 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node585 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected585 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected585 ((2 : Int),(2 : Int)) hp6_6_branches585 hp6_6_evidence585 hp6_6_check585 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node584 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected584 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected584 ((3 : Int),(2 : Int)) hp6_6_branches584 hp6_6_evidence584 hp6_6_check584 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node583 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected583 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected583 ((2 : Int),(2 : Int)) hp6_6_branches583 hp6_6_evidence583 hp6_6_check583 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node584 T childKnown
theorem hp6_6_node582 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected582 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected582 ((1 : Int),(2 : Int)) hp6_6_branches582 hp6_6_evidence582 hp6_6_check582 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node583 T childKnown
  · exact hp6_6_node585 T childKnown
  · exact hp6_6_node586 T childKnown
  · exact hp6_6_node587 T childKnown
theorem hp6_6_node581 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected581 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected581 ((1 : Int),(0 : Int)) hp6_6_branches581 hp6_6_evidence581 hp6_6_check581 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node582 T childKnown
theorem hp6_6_node580 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected580 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected580 ((1 : Int),(1 : Int)) hp6_6_branches580 hp6_6_evidence580 hp6_6_check580 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node579 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected579 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected579 ((1 : Int),(0 : Int)) hp6_6_branches579 hp6_6_evidence579 hp6_6_check579 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node580 T childKnown
theorem hp6_6_node578 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected578 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected578 ((8 : Int),(1 : Int)) hp6_6_branches578 hp6_6_evidence578 hp6_6_check578 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node577 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected577 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected577 ((6 : Int),(1 : Int)) hp6_6_branches577 hp6_6_evidence577 hp6_6_check577 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node576 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected576 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected576 ((6 : Int),(1 : Int)) hp6_6_branches576 hp6_6_evidence576 hp6_6_check576 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node575 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected575 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected575 ((6 : Int),(1 : Int)) hp6_6_branches575 hp6_6_evidence575 hp6_6_check575 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node574 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected574 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected574 ((7 : Int),(1 : Int)) hp6_6_branches574 hp6_6_evidence574 hp6_6_check574 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node575 T childKnown
  · exact hp6_6_node576 T childKnown
  · exact hp6_6_node577 T childKnown
  · exact hp6_6_node578 T childKnown
theorem hp6_6_node573 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected573 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected573 ((7 : Int),(1 : Int)) hp6_6_branches573 hp6_6_evidence573 hp6_6_check573 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node572 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected572 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected572 ((7 : Int),(1 : Int)) hp6_6_branches572 hp6_6_evidence572 hp6_6_check572 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node571 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected571 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected571 ((7 : Int),(1 : Int)) hp6_6_branches571 hp6_6_evidence571 hp6_6_check571 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node570 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected570 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected570 ((0 : Int),(2 : Int)) hp6_6_branches570 hp6_6_evidence570 hp6_6_check570 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node569 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected569 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected569 ((0 : Int),(2 : Int)) hp6_6_branches569 hp6_6_evidence569 hp6_6_check569 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node568 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected568 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected568 ((4 : Int),(1 : Int)) hp6_6_branches568 hp6_6_evidence568 hp6_6_check568 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node569 T childKnown
  · exact hp6_6_node570 T childKnown
theorem hp6_6_node567 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected567 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected567 ((7 : Int),(1 : Int)) hp6_6_branches567 hp6_6_evidence567 hp6_6_check567 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node568 T childKnown
theorem hp6_6_node566 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected566 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected566 ((6 : Int),(1 : Int)) hp6_6_branches566 hp6_6_evidence566 hp6_6_check566 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node567 T childKnown
  · exact hp6_6_node571 T childKnown
  · exact hp6_6_node572 T childKnown
  · exact hp6_6_node573 T childKnown
theorem hp6_6_node565 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected565 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected565 ((8 : Int),(1 : Int)) hp6_6_branches565 hp6_6_evidence565 hp6_6_check565 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node564 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected564 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected564 ((8 : Int),(0 : Int)) hp6_6_branches564 hp6_6_evidence564 hp6_6_check564 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node565 T childKnown
theorem hp6_6_node563 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected563 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected563 ((6 : Int),(1 : Int)) hp6_6_branches563 hp6_6_evidence563 hp6_6_check563 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node564 T childKnown
theorem hp6_6_node562 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected562 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected562 ((0 : Int),(2 : Int)) hp6_6_branches562 hp6_6_evidence562 hp6_6_check562 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node561 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected561 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected561 ((0 : Int),(2 : Int)) hp6_6_branches561 hp6_6_evidence561 hp6_6_check561 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node560 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected560 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected560 ((4 : Int),(1 : Int)) hp6_6_branches560 hp6_6_evidence560 hp6_6_check560 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node561 T childKnown
  · exact hp6_6_node562 T childKnown
theorem hp6_6_node559 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected559 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected559 ((8 : Int),(0 : Int)) hp6_6_branches559 hp6_6_evidence559 hp6_6_check559 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node560 T childKnown
theorem hp6_6_node558 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected558 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected558 ((6 : Int),(1 : Int)) hp6_6_branches558 hp6_6_evidence558 hp6_6_check558 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node559 T childKnown
theorem hp6_6_node557 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected557 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected557 ((6 : Int),(1 : Int)) hp6_6_branches557 hp6_6_evidence557 hp6_6_check557 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node556 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected556 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected556 ((7 : Int),(0 : Int)) hp6_6_branches556 hp6_6_evidence556 hp6_6_check556 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node557 T childKnown
  · exact hp6_6_node558 T childKnown
  · exact hp6_6_node563 T childKnown
  · exact hp6_6_node566 T childKnown
  · exact hp6_6_node574 T childKnown
theorem hp6_6_node555 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected555 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected555 ((10 : Int),(1 : Int)) hp6_6_branches555 hp6_6_evidence555 hp6_6_check555 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node554 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected554 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected554 ((8 : Int),(2 : Int)) hp6_6_branches554 hp6_6_evidence554 hp6_6_check554 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node553 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected553 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected553 ((9 : Int),(1 : Int)) hp6_6_branches553 hp6_6_evidence553 hp6_6_check553 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node554 T childKnown
  · exact hp6_6_node555 T childKnown
theorem hp6_6_node552 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected552 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected552 ((7 : Int),(0 : Int)) hp6_6_branches552 hp6_6_evidence552 hp6_6_check552 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node553 T childKnown
theorem hp6_6_node551 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected551 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected551 ((2 : Int),(2 : Int)) hp6_6_branches551 hp6_6_evidence551 hp6_6_check551 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node550 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected550 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected550 ((2 : Int),(2 : Int)) hp6_6_branches550 hp6_6_evidence550 hp6_6_check550 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node549 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected549 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected549 ((2 : Int),(2 : Int)) hp6_6_branches549 hp6_6_evidence549 hp6_6_check549 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node548 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected548 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected548 ((3 : Int),(2 : Int)) hp6_6_branches548 hp6_6_evidence548 hp6_6_check548 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node547 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected547 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected547 ((2 : Int),(2 : Int)) hp6_6_branches547 hp6_6_evidence547 hp6_6_check547 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node548 T childKnown
theorem hp6_6_node546 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected546 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected546 ((1 : Int),(2 : Int)) hp6_6_branches546 hp6_6_evidence546 hp6_6_check546 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node547 T childKnown
  · exact hp6_6_node549 T childKnown
  · exact hp6_6_node550 T childKnown
  · exact hp6_6_node551 T childKnown
theorem hp6_6_node545 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected545 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected545 ((9 : Int),(1 : Int)) hp6_6_branches545 hp6_6_evidence545 hp6_6_check545 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node544 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected544 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected544 ((11 : Int),(1 : Int)) hp6_6_branches544 hp6_6_evidence544 hp6_6_check544 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node543 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected543 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected543 ((10 : Int),(1 : Int)) hp6_6_branches543 hp6_6_evidence543 hp6_6_check543 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node544 T childKnown
theorem hp6_6_node542 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected542 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected542 ((3 : Int),(2 : Int)) hp6_6_branches542 hp6_6_evidence542 hp6_6_check542 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node543 T childKnown
  · exact hp6_6_node545 T childKnown
theorem hp6_6_node541 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected541 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected541 ((9 : Int),(1 : Int)) hp6_6_branches541 hp6_6_evidence541 hp6_6_check541 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node540 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected540 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected540 ((11 : Int),(1 : Int)) hp6_6_branches540 hp6_6_evidence540 hp6_6_check540 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node539 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected539 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected539 ((10 : Int),(1 : Int)) hp6_6_branches539 hp6_6_evidence539 hp6_6_check539 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node540 T childKnown
theorem hp6_6_node538 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected538 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected538 ((3 : Int),(2 : Int)) hp6_6_branches538 hp6_6_evidence538 hp6_6_check538 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node539 T childKnown
  · exact hp6_6_node541 T childKnown
theorem hp6_6_node537 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected537 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected537 ((9 : Int),(1 : Int)) hp6_6_branches537 hp6_6_evidence537 hp6_6_check537 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node536 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected536 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected536 ((11 : Int),(1 : Int)) hp6_6_branches536 hp6_6_evidence536 hp6_6_check536 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node535 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected535 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected535 ((10 : Int),(1 : Int)) hp6_6_branches535 hp6_6_evidence535 hp6_6_check535 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node536 T childKnown
theorem hp6_6_node534 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected534 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected534 ((9 : Int),(1 : Int)) hp6_6_branches534 hp6_6_evidence534 hp6_6_check534 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node533 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected533 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected533 ((4 : Int),(2 : Int)) hp6_6_branches533 hp6_6_evidence533 hp6_6_check533 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node532 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected532 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected532 ((9 : Int),(1 : Int)) hp6_6_branches532 hp6_6_evidence532 hp6_6_check532 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node533 T childKnown
theorem hp6_6_node531 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected531 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected531 ((9 : Int),(1 : Int)) hp6_6_branches531 hp6_6_evidence531 hp6_6_check531 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node530 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected530 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected530 ((3 : Int),(2 : Int)) hp6_6_branches530 hp6_6_evidence530 hp6_6_check530 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node531 T childKnown
  · exact hp6_6_node532 T childKnown
  · exact hp6_6_node534 T childKnown
  · exact hp6_6_node535 T childKnown
  · exact hp6_6_node537 T childKnown
theorem hp6_6_node529 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected529 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected529 ((3 : Int),(2 : Int)) hp6_6_branches529 hp6_6_evidence529 hp6_6_check529 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node528 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected528 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected528 ((8 : Int),(2 : Int)) hp6_6_branches528 hp6_6_evidence528 hp6_6_check528 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node527 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected527 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected527 ((3 : Int),(2 : Int)) hp6_6_branches527 hp6_6_evidence527 hp6_6_check527 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node526 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected526 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected526 ((3 : Int),(2 : Int)) hp6_6_branches526 hp6_6_evidence526 hp6_6_check526 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node525 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected525 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected525 ((11 : Int),(1 : Int)) hp6_6_branches525 hp6_6_evidence525 hp6_6_check525 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node524 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected524 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected524 ((10 : Int),(1 : Int)) hp6_6_branches524 hp6_6_evidence524 hp6_6_check524 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node525 T childKnown
theorem hp6_6_node523 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected523 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected523 ((9 : Int),(1 : Int)) hp6_6_branches523 hp6_6_evidence523 hp6_6_check523 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node524 T childKnown
  · exact hp6_6_node526 T childKnown
  · exact hp6_6_node527 T childKnown
  · exact hp6_6_node528 T childKnown
  · exact hp6_6_node529 T childKnown
theorem hp6_6_node522 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected522 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected522 ((1 : Int),(2 : Int)) hp6_6_branches522 hp6_6_evidence522 hp6_6_check522 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node523 T childKnown
  · exact hp6_6_node530 T childKnown
  · exact hp6_6_node538 T childKnown
  · exact hp6_6_node542 T childKnown
theorem hp6_6_node521 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected521 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected521 ((7 : Int),(0 : Int)) hp6_6_branches521 hp6_6_evidence521 hp6_6_check521 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node522 T childKnown
theorem hp6_6_node520 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected520 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected520 ((2 : Int),(2 : Int)) hp6_6_branches520 hp6_6_evidence520 hp6_6_check520 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node519 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected519 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected519 ((2 : Int),(2 : Int)) hp6_6_branches519 hp6_6_evidence519 hp6_6_check519 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node518 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected518 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected518 ((2 : Int),(1 : Int)) hp6_6_branches518 hp6_6_evidence518 hp6_6_check518 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node519 T childKnown
  · exact hp6_6_node520 T childKnown
theorem hp6_6_node517 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected517 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected517 ((11 : Int),(1 : Int)) hp6_6_branches517 hp6_6_evidence517 hp6_6_check517 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node516 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected516 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected516 ((9 : Int),(2 : Int)) hp6_6_branches516 hp6_6_evidence516 hp6_6_check516 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node515 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected515 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected515 ((10 : Int),(1 : Int)) hp6_6_branches515 hp6_6_evidence515 hp6_6_check515 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node516 T childKnown
  · exact hp6_6_node517 T childKnown
theorem hp6_6_node514 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected514 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected514 ((7 : Int),(0 : Int)) hp6_6_branches514 hp6_6_evidence514 hp6_6_check514 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node515 T childKnown
theorem hp6_6_node513 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected513 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected513 ((7 : Int),(0 : Int)) hp6_6_branches513 hp6_6_evidence513 hp6_6_check513 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node512 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected512 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected512 ((2 : Int),(1 : Int)) hp6_6_branches512 hp6_6_evidence512 hp6_6_check512 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node513 T childKnown
  · exact hp6_6_node514 T childKnown
theorem hp6_6_node511 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected511 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected511 ((2 : Int),(2 : Int)) hp6_6_branches511 hp6_6_evidence511 hp6_6_check511 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node510 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected510 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected510 ((2 : Int),(2 : Int)) hp6_6_branches510 hp6_6_evidence510 hp6_6_check510 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node509 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected509 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected509 ((2 : Int),(1 : Int)) hp6_6_branches509 hp6_6_evidence509 hp6_6_check509 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node510 T childKnown
  · exact hp6_6_node511 T childKnown
theorem hp6_6_node508 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected508 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected508 ((2 : Int),(2 : Int)) hp6_6_branches508 hp6_6_evidence508 hp6_6_check508 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node507 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected507 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected507 ((2 : Int),(2 : Int)) hp6_6_branches507 hp6_6_evidence507 hp6_6_check507 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node506 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected506 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected506 ((2 : Int),(2 : Int)) hp6_6_branches506 hp6_6_evidence506 hp6_6_check506 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node505 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected505 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected505 ((2 : Int),(1 : Int)) hp6_6_branches505 hp6_6_evidence505 hp6_6_check505 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node506 T childKnown
  · exact hp6_6_node507 T childKnown
  · exact hp6_6_node508 T childKnown
theorem hp6_6_node504 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected504 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected504 ((3 : Int),(2 : Int)) hp6_6_branches504 hp6_6_evidence504 hp6_6_check504 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node503 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected503 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected503 ((2 : Int),(2 : Int)) hp6_6_branches503 hp6_6_evidence503 hp6_6_check503 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node504 T childKnown
theorem hp6_6_node502 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected502 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected502 ((7 : Int),(0 : Int)) hp6_6_branches502 hp6_6_evidence502 hp6_6_check502 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node501 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected501 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected501 ((10 : Int),(1 : Int)) hp6_6_branches501 hp6_6_evidence501 hp6_6_check501 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node500 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected500 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected500 ((12 : Int),(1 : Int)) hp6_6_branches500 hp6_6_evidence500 hp6_6_check500 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node499 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected499 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected499 ((11 : Int),(1 : Int)) hp6_6_branches499 hp6_6_evidence499 hp6_6_check499 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node500 T childKnown
theorem hp6_6_node498 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected498 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected498 ((4 : Int),(2 : Int)) hp6_6_branches498 hp6_6_evidence498 hp6_6_check498 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node499 T childKnown
  · exact hp6_6_node501 T childKnown
theorem hp6_6_node497 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected497 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected497 ((7 : Int),(0 : Int)) hp6_6_branches497 hp6_6_evidence497 hp6_6_check497 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node498 T childKnown
theorem hp6_6_node496 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected496 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected496 ((2 : Int),(2 : Int)) hp6_6_branches496 hp6_6_evidence496 hp6_6_check496 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node497 T childKnown
theorem hp6_6_node495 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected495 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected495 ((3 : Int),(2 : Int)) hp6_6_branches495 hp6_6_evidence495 hp6_6_check495 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node494 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected494 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected494 ((3 : Int),(2 : Int)) hp6_6_branches494 hp6_6_evidence494 hp6_6_check494 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node493 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected493 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected493 ((3 : Int),(1 : Int)) hp6_6_branches493 hp6_6_evidence493 hp6_6_check493 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node494 T childKnown
  · exact hp6_6_node495 T childKnown
theorem hp6_6_node492 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected492 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected492 ((12 : Int),(1 : Int)) hp6_6_branches492 hp6_6_evidence492 hp6_6_check492 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node491 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected491 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected491 ((10 : Int),(2 : Int)) hp6_6_branches491 hp6_6_evidence491 hp6_6_check491 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node490 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected490 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected490 ((11 : Int),(1 : Int)) hp6_6_branches490 hp6_6_evidence490 hp6_6_check490 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node491 T childKnown
  · exact hp6_6_node492 T childKnown
theorem hp6_6_node489 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected489 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected489 ((3 : Int),(1 : Int)) hp6_6_branches489 hp6_6_evidence489 hp6_6_check489 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node490 T childKnown
theorem hp6_6_node488 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected488 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected488 ((7 : Int),(0 : Int)) hp6_6_branches488 hp6_6_evidence488 hp6_6_check488 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node489 T childKnown
theorem hp6_6_node487 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected487 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected487 ((2 : Int),(1 : Int)) hp6_6_branches487 hp6_6_evidence487 hp6_6_check487 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node488 T childKnown
  · exact hp6_6_node493 T childKnown
  · exact hp6_6_node496 T childKnown
  · exact hp6_6_node502 T childKnown
  · exact hp6_6_node503 T childKnown
theorem hp6_6_node486 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected486 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected486 ((1 : Int),(1 : Int)) hp6_6_branches486 hp6_6_evidence486 hp6_6_check486 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node487 T childKnown
  · exact hp6_6_node505 T childKnown
  · exact hp6_6_node509 T childKnown
  · exact hp6_6_node512 T childKnown
  · exact hp6_6_node518 T childKnown
  · exact hp6_6_node521 T childKnown
  · exact hp6_6_node546 T childKnown
  · exact hp6_6_node552 T childKnown
theorem hp6_6_node485 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected485 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected485 ((7 : Int),(1 : Int)) hp6_6_branches485 hp6_6_evidence485 hp6_6_check485 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node484 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected484 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected484 ((5 : Int),(1 : Int)) hp6_6_branches484 hp6_6_evidence484 hp6_6_check484 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node483 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected483 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected483 ((5 : Int),(1 : Int)) hp6_6_branches483 hp6_6_evidence483 hp6_6_check483 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node482 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected482 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected482 ((5 : Int),(1 : Int)) hp6_6_branches482 hp6_6_evidence482 hp6_6_check482 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node481 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected481 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected481 ((6 : Int),(1 : Int)) hp6_6_branches481 hp6_6_evidence481 hp6_6_check481 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node482 T childKnown
  · exact hp6_6_node483 T childKnown
  · exact hp6_6_node484 T childKnown
  · exact hp6_6_node485 T childKnown
theorem hp6_6_node480 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected480 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected480 ((6 : Int),(1 : Int)) hp6_6_branches480 hp6_6_evidence480 hp6_6_check480 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node479 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected479 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected479 ((6 : Int),(1 : Int)) hp6_6_branches479 hp6_6_evidence479 hp6_6_check479 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node478 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected478 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected478 ((6 : Int),(1 : Int)) hp6_6_branches478 hp6_6_evidence478 hp6_6_check478 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node477 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected477 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected477 ((0 : Int),(2 : Int)) hp6_6_branches477 hp6_6_evidence477 hp6_6_check477 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node476 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected476 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected476 ((0 : Int),(2 : Int)) hp6_6_branches476 hp6_6_evidence476 hp6_6_check476 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node475 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected475 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected475 ((3 : Int),(1 : Int)) hp6_6_branches475 hp6_6_evidence475 hp6_6_check475 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node476 T childKnown
  · exact hp6_6_node477 T childKnown
theorem hp6_6_node474 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected474 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected474 ((6 : Int),(1 : Int)) hp6_6_branches474 hp6_6_evidence474 hp6_6_check474 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node475 T childKnown
theorem hp6_6_node473 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected473 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected473 ((5 : Int),(1 : Int)) hp6_6_branches473 hp6_6_evidence473 hp6_6_check473 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node474 T childKnown
  · exact hp6_6_node478 T childKnown
  · exact hp6_6_node479 T childKnown
  · exact hp6_6_node480 T childKnown
theorem hp6_6_node472 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected472 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected472 ((7 : Int),(1 : Int)) hp6_6_branches472 hp6_6_evidence472 hp6_6_check472 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node471 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected471 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected471 ((7 : Int),(0 : Int)) hp6_6_branches471 hp6_6_evidence471 hp6_6_check471 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node472 T childKnown
theorem hp6_6_node470 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected470 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected470 ((5 : Int),(1 : Int)) hp6_6_branches470 hp6_6_evidence470 hp6_6_check470 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node471 T childKnown
theorem hp6_6_node469 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected469 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected469 ((0 : Int),(2 : Int)) hp6_6_branches469 hp6_6_evidence469 hp6_6_check469 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node468 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected468 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected468 ((0 : Int),(2 : Int)) hp6_6_branches468 hp6_6_evidence468 hp6_6_check468 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node467 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected467 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected467 ((3 : Int),(1 : Int)) hp6_6_branches467 hp6_6_evidence467 hp6_6_check467 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node468 T childKnown
  · exact hp6_6_node469 T childKnown
theorem hp6_6_node466 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected466 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected466 ((7 : Int),(0 : Int)) hp6_6_branches466 hp6_6_evidence466 hp6_6_check466 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node467 T childKnown
theorem hp6_6_node465 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected465 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected465 ((5 : Int),(1 : Int)) hp6_6_branches465 hp6_6_evidence465 hp6_6_check465 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node466 T childKnown
theorem hp6_6_node464 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected464 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected464 ((5 : Int),(1 : Int)) hp6_6_branches464 hp6_6_evidence464 hp6_6_check464 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node463 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected463 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected463 ((6 : Int),(0 : Int)) hp6_6_branches463 hp6_6_evidence463 hp6_6_check463 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node464 T childKnown
  · exact hp6_6_node465 T childKnown
  · exact hp6_6_node470 T childKnown
  · exact hp6_6_node473 T childKnown
  · exact hp6_6_node481 T childKnown
theorem hp6_6_node462 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected462 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected462 ((9 : Int),(1 : Int)) hp6_6_branches462 hp6_6_evidence462 hp6_6_check462 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node461 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected461 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected461 ((7 : Int),(2 : Int)) hp6_6_branches461 hp6_6_evidence461 hp6_6_check461 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node460 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected460 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected460 ((8 : Int),(1 : Int)) hp6_6_branches460 hp6_6_evidence460 hp6_6_check460 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node461 T childKnown
  · exact hp6_6_node462 T childKnown
theorem hp6_6_node459 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected459 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected459 ((6 : Int),(0 : Int)) hp6_6_branches459 hp6_6_evidence459 hp6_6_check459 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node460 T childKnown
theorem hp6_6_node458 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected458 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected458 ((1 : Int),(2 : Int)) hp6_6_branches458 hp6_6_evidence458 hp6_6_check458 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node457 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected457 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected457 ((1 : Int),(2 : Int)) hp6_6_branches457 hp6_6_evidence457 hp6_6_check457 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node456 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected456 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected456 ((1 : Int),(2 : Int)) hp6_6_branches456 hp6_6_evidence456 hp6_6_check456 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node455 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected455 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected455 ((2 : Int),(2 : Int)) hp6_6_branches455 hp6_6_evidence455 hp6_6_check455 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node454 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected454 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected454 ((1 : Int),(2 : Int)) hp6_6_branches454 hp6_6_evidence454 hp6_6_check454 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node455 T childKnown
theorem hp6_6_node453 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected453 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected453 ((0 : Int),(2 : Int)) hp6_6_branches453 hp6_6_evidence453 hp6_6_check453 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node454 T childKnown
  · exact hp6_6_node456 T childKnown
  · exact hp6_6_node457 T childKnown
  · exact hp6_6_node458 T childKnown
theorem hp6_6_node452 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected452 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected452 ((8 : Int),(1 : Int)) hp6_6_branches452 hp6_6_evidence452 hp6_6_check452 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node451 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected451 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected451 ((10 : Int),(1 : Int)) hp6_6_branches451 hp6_6_evidence451 hp6_6_check451 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node450 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected450 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected450 ((9 : Int),(1 : Int)) hp6_6_branches450 hp6_6_evidence450 hp6_6_check450 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node451 T childKnown
theorem hp6_6_node449 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected449 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected449 ((2 : Int),(2 : Int)) hp6_6_branches449 hp6_6_evidence449 hp6_6_check449 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node450 T childKnown
  · exact hp6_6_node452 T childKnown
theorem hp6_6_node448 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected448 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected448 ((8 : Int),(1 : Int)) hp6_6_branches448 hp6_6_evidence448 hp6_6_check448 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node447 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected447 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected447 ((10 : Int),(1 : Int)) hp6_6_branches447 hp6_6_evidence447 hp6_6_check447 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node446 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected446 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected446 ((9 : Int),(1 : Int)) hp6_6_branches446 hp6_6_evidence446 hp6_6_check446 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node447 T childKnown
theorem hp6_6_node445 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected445 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected445 ((2 : Int),(2 : Int)) hp6_6_branches445 hp6_6_evidence445 hp6_6_check445 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node446 T childKnown
  · exact hp6_6_node448 T childKnown
theorem hp6_6_node444 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected444 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected444 ((8 : Int),(1 : Int)) hp6_6_branches444 hp6_6_evidence444 hp6_6_check444 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node443 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected443 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected443 ((10 : Int),(1 : Int)) hp6_6_branches443 hp6_6_evidence443 hp6_6_check443 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node442 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected442 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected442 ((9 : Int),(1 : Int)) hp6_6_branches442 hp6_6_evidence442 hp6_6_check442 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node443 T childKnown
theorem hp6_6_node441 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected441 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected441 ((8 : Int),(1 : Int)) hp6_6_branches441 hp6_6_evidence441 hp6_6_check441 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node440 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected440 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected440 ((3 : Int),(2 : Int)) hp6_6_branches440 hp6_6_evidence440 hp6_6_check440 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node439 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected439 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected439 ((8 : Int),(1 : Int)) hp6_6_branches439 hp6_6_evidence439 hp6_6_check439 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node440 T childKnown
theorem hp6_6_node438 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected438 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected438 ((8 : Int),(1 : Int)) hp6_6_branches438 hp6_6_evidence438 hp6_6_check438 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node437 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected437 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected437 ((2 : Int),(2 : Int)) hp6_6_branches437 hp6_6_evidence437 hp6_6_check437 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node438 T childKnown
  · exact hp6_6_node439 T childKnown
  · exact hp6_6_node441 T childKnown
  · exact hp6_6_node442 T childKnown
  · exact hp6_6_node444 T childKnown
theorem hp6_6_node436 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected436 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected436 ((2 : Int),(2 : Int)) hp6_6_branches436 hp6_6_evidence436 hp6_6_check436 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node435 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected435 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected435 ((7 : Int),(2 : Int)) hp6_6_branches435 hp6_6_evidence435 hp6_6_check435 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node434 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected434 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected434 ((2 : Int),(2 : Int)) hp6_6_branches434 hp6_6_evidence434 hp6_6_check434 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node433 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected433 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected433 ((2 : Int),(2 : Int)) hp6_6_branches433 hp6_6_evidence433 hp6_6_check433 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node432 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected432 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected432 ((10 : Int),(1 : Int)) hp6_6_branches432 hp6_6_evidence432 hp6_6_check432 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node431 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected431 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected431 ((9 : Int),(1 : Int)) hp6_6_branches431 hp6_6_evidence431 hp6_6_check431 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node432 T childKnown
theorem hp6_6_node430 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected430 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected430 ((8 : Int),(1 : Int)) hp6_6_branches430 hp6_6_evidence430 hp6_6_check430 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node431 T childKnown
  · exact hp6_6_node433 T childKnown
  · exact hp6_6_node434 T childKnown
  · exact hp6_6_node435 T childKnown
  · exact hp6_6_node436 T childKnown
theorem hp6_6_node429 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected429 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected429 ((0 : Int),(2 : Int)) hp6_6_branches429 hp6_6_evidence429 hp6_6_check429 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node430 T childKnown
  · exact hp6_6_node437 T childKnown
  · exact hp6_6_node445 T childKnown
  · exact hp6_6_node449 T childKnown
theorem hp6_6_node428 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected428 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected428 ((6 : Int),(0 : Int)) hp6_6_branches428 hp6_6_evidence428 hp6_6_check428 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node429 T childKnown
theorem hp6_6_node427 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected427 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected427 ((1 : Int),(2 : Int)) hp6_6_branches427 hp6_6_evidence427 hp6_6_check427 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node426 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected426 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected426 ((1 : Int),(2 : Int)) hp6_6_branches426 hp6_6_evidence426 hp6_6_check426 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node425 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected425 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected425 ((1 : Int),(1 : Int)) hp6_6_branches425 hp6_6_evidence425 hp6_6_check425 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node426 T childKnown
  · exact hp6_6_node427 T childKnown
theorem hp6_6_node424 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected424 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected424 ((10 : Int),(1 : Int)) hp6_6_branches424 hp6_6_evidence424 hp6_6_check424 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node423 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected423 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected423 ((8 : Int),(2 : Int)) hp6_6_branches423 hp6_6_evidence423 hp6_6_check423 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node422 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected422 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected422 ((9 : Int),(1 : Int)) hp6_6_branches422 hp6_6_evidence422 hp6_6_check422 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node423 T childKnown
  · exact hp6_6_node424 T childKnown
theorem hp6_6_node421 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected421 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected421 ((6 : Int),(0 : Int)) hp6_6_branches421 hp6_6_evidence421 hp6_6_check421 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node422 T childKnown
theorem hp6_6_node420 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected420 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected420 ((6 : Int),(0 : Int)) hp6_6_branches420 hp6_6_evidence420 hp6_6_check420 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node419 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected419 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected419 ((1 : Int),(1 : Int)) hp6_6_branches419 hp6_6_evidence419 hp6_6_check419 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node420 T childKnown
  · exact hp6_6_node421 T childKnown
theorem hp6_6_node418 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected418 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected418 ((1 : Int),(2 : Int)) hp6_6_branches418 hp6_6_evidence418 hp6_6_check418 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node417 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected417 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected417 ((1 : Int),(2 : Int)) hp6_6_branches417 hp6_6_evidence417 hp6_6_check417 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node416 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected416 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected416 ((1 : Int),(1 : Int)) hp6_6_branches416 hp6_6_evidence416 hp6_6_check416 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node417 T childKnown
  · exact hp6_6_node418 T childKnown
theorem hp6_6_node415 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected415 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected415 ((1 : Int),(2 : Int)) hp6_6_branches415 hp6_6_evidence415 hp6_6_check415 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node414 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected414 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected414 ((1 : Int),(2 : Int)) hp6_6_branches414 hp6_6_evidence414 hp6_6_check414 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node413 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected413 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected413 ((1 : Int),(2 : Int)) hp6_6_branches413 hp6_6_evidence413 hp6_6_check413 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node412 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected412 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected412 ((1 : Int),(1 : Int)) hp6_6_branches412 hp6_6_evidence412 hp6_6_check412 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_6_node413 T childKnown
  · exact hp6_6_node414 T childKnown
  · exact hp6_6_node415 T childKnown
theorem hp6_6_node411 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected411 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected411 ((2 : Int),(2 : Int)) hp6_6_branches411 hp6_6_evidence411 hp6_6_check411 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node410 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected410 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected410 ((1 : Int),(2 : Int)) hp6_6_branches410 hp6_6_evidence410 hp6_6_check410 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node411 T childKnown
theorem hp6_6_node409 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected409 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected409 ((6 : Int),(0 : Int)) hp6_6_branches409 hp6_6_evidence409 hp6_6_check409 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node408 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected408 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected408 ((9 : Int),(1 : Int)) hp6_6_branches408 hp6_6_evidence408 hp6_6_check408 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node407 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected407 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected407 ((11 : Int),(1 : Int)) hp6_6_branches407 hp6_6_evidence407 hp6_6_check407 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node406 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected406 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected406 ((10 : Int),(1 : Int)) hp6_6_branches406 hp6_6_evidence406 hp6_6_check406 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node407 T childKnown
theorem hp6_6_node405 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected405 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected405 ((3 : Int),(2 : Int)) hp6_6_branches405 hp6_6_evidence405 hp6_6_check405 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node406 T childKnown
  · exact hp6_6_node408 T childKnown
theorem hp6_6_node404 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected404 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected404 ((6 : Int),(0 : Int)) hp6_6_branches404 hp6_6_evidence404 hp6_6_check404 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node405 T childKnown
theorem hp6_6_node403 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected403 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected403 ((1 : Int),(2 : Int)) hp6_6_branches403 hp6_6_evidence403 hp6_6_check403 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node404 T childKnown
theorem hp6_6_node402 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected402 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected402 ((2 : Int),(2 : Int)) hp6_6_branches402 hp6_6_evidence402 hp6_6_check402 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node401 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected401 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected401 ((2 : Int),(2 : Int)) hp6_6_branches401 hp6_6_evidence401 hp6_6_check401 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node400 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected400 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected400 ((2 : Int),(1 : Int)) hp6_6_branches400 hp6_6_evidence400 hp6_6_check400 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node401 T childKnown
  · exact hp6_6_node402 T childKnown
theorem hp6_6_node399 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected399 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected399 ((11 : Int),(1 : Int)) hp6_6_branches399 hp6_6_evidence399 hp6_6_check399 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node398 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected398 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected398 ((9 : Int),(2 : Int)) hp6_6_branches398 hp6_6_evidence398 hp6_6_check398 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node397 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected397 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected397 ((10 : Int),(1 : Int)) hp6_6_branches397 hp6_6_evidence397 hp6_6_check397 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node398 T childKnown
  · exact hp6_6_node399 T childKnown
theorem hp6_6_node396 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected396 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected396 ((2 : Int),(1 : Int)) hp6_6_branches396 hp6_6_evidence396 hp6_6_check396 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node397 T childKnown
theorem hp6_6_node395 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected395 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected395 ((6 : Int),(0 : Int)) hp6_6_branches395 hp6_6_evidence395 hp6_6_check395 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node396 T childKnown
theorem hp6_6_node394 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected394 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected394 ((1 : Int),(1 : Int)) hp6_6_branches394 hp6_6_evidence394 hp6_6_check394 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node395 T childKnown
  · exact hp6_6_node400 T childKnown
  · exact hp6_6_node403 T childKnown
  · exact hp6_6_node409 T childKnown
  · exact hp6_6_node410 T childKnown
theorem hp6_6_node393 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected393 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected393 ((0 : Int),(1 : Int)) hp6_6_branches393 hp6_6_evidence393 hp6_6_check393 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node394 T childKnown
  · exact hp6_6_node412 T childKnown
  · exact hp6_6_node416 T childKnown
  · exact hp6_6_node419 T childKnown
  · exact hp6_6_node425 T childKnown
  · exact hp6_6_node428 T childKnown
  · exact hp6_6_node453 T childKnown
  · exact hp6_6_node459 T childKnown
theorem hp6_6_node392 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected392 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected392 ((6 : Int),(1 : Int)) hp6_6_branches392 hp6_6_evidence392 hp6_6_check392 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node391 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected391 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected391 ((4 : Int),(1 : Int)) hp6_6_branches391 hp6_6_evidence391 hp6_6_check391 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node390 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected390 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected390 ((4 : Int),(1 : Int)) hp6_6_branches390 hp6_6_evidence390 hp6_6_check390 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node389 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected389 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected389 ((4 : Int),(1 : Int)) hp6_6_branches389 hp6_6_evidence389 hp6_6_check389 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node388 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected388 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected388 ((5 : Int),(1 : Int)) hp6_6_branches388 hp6_6_evidence388 hp6_6_check388 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node389 T childKnown
  · exact hp6_6_node390 T childKnown
  · exact hp6_6_node391 T childKnown
  · exact hp6_6_node392 T childKnown
theorem hp6_6_node387 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected387 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected387 ((5 : Int),(1 : Int)) hp6_6_branches387 hp6_6_evidence387 hp6_6_check387 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node386 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected386 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected386 ((5 : Int),(1 : Int)) hp6_6_branches386 hp6_6_evidence386 hp6_6_check386 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node385 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected385 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected385 ((5 : Int),(1 : Int)) hp6_6_branches385 hp6_6_evidence385 hp6_6_check385 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node384 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected384 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected384 ((0 : Int),(2 : Int)) hp6_6_branches384 hp6_6_evidence384 hp6_6_check384 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node383 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected383 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected383 ((0 : Int),(2 : Int)) hp6_6_branches383 hp6_6_evidence383 hp6_6_check383 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node382 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected382 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected382 ((2 : Int),(1 : Int)) hp6_6_branches382 hp6_6_evidence382 hp6_6_check382 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node383 T childKnown
  · exact hp6_6_node384 T childKnown
theorem hp6_6_node381 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected381 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected381 ((5 : Int),(1 : Int)) hp6_6_branches381 hp6_6_evidence381 hp6_6_check381 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node382 T childKnown
theorem hp6_6_node380 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected380 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected380 ((4 : Int),(1 : Int)) hp6_6_branches380 hp6_6_evidence380 hp6_6_check380 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node381 T childKnown
  · exact hp6_6_node385 T childKnown
  · exact hp6_6_node386 T childKnown
  · exact hp6_6_node387 T childKnown
theorem hp6_6_node379 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected379 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected379 ((6 : Int),(1 : Int)) hp6_6_branches379 hp6_6_evidence379 hp6_6_check379 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node378 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected378 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected378 ((6 : Int),(0 : Int)) hp6_6_branches378 hp6_6_evidence378 hp6_6_check378 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node379 T childKnown
theorem hp6_6_node377 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected377 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected377 ((4 : Int),(1 : Int)) hp6_6_branches377 hp6_6_evidence377 hp6_6_check377 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node378 T childKnown
theorem hp6_6_node376 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected376 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected376 ((0 : Int),(2 : Int)) hp6_6_branches376 hp6_6_evidence376 hp6_6_check376 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node375 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected375 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected375 ((0 : Int),(2 : Int)) hp6_6_branches375 hp6_6_evidence375 hp6_6_check375 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node374 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected374 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected374 ((2 : Int),(1 : Int)) hp6_6_branches374 hp6_6_evidence374 hp6_6_check374 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node375 T childKnown
  · exact hp6_6_node376 T childKnown
theorem hp6_6_node373 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected373 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected373 ((6 : Int),(0 : Int)) hp6_6_branches373 hp6_6_evidence373 hp6_6_check373 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node374 T childKnown
theorem hp6_6_node372 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected372 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected372 ((4 : Int),(1 : Int)) hp6_6_branches372 hp6_6_evidence372 hp6_6_check372 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node373 T childKnown
theorem hp6_6_node371 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected371 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected371 ((4 : Int),(1 : Int)) hp6_6_branches371 hp6_6_evidence371 hp6_6_check371 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node370 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected370 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected370 ((5 : Int),(0 : Int)) hp6_6_branches370 hp6_6_evidence370 hp6_6_check370 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node371 T childKnown
  · exact hp6_6_node372 T childKnown
  · exact hp6_6_node377 T childKnown
  · exact hp6_6_node380 T childKnown
  · exact hp6_6_node388 T childKnown
theorem hp6_6_node369 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected369 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected369 ((14 : Int),(1 : Int)) hp6_6_branches369 hp6_6_evidence369 hp6_6_check369 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node368 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected368 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected368 ((12 : Int),(1 : Int)) hp6_6_branches368 hp6_6_evidence368 hp6_6_check368 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node367 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected367 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected367 ((12 : Int),(1 : Int)) hp6_6_branches367 hp6_6_evidence367 hp6_6_check367 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node366 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected366 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected366 ((12 : Int),(1 : Int)) hp6_6_branches366 hp6_6_evidence366 hp6_6_check366 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node365 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected365 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected365 ((13 : Int),(1 : Int)) hp6_6_branches365 hp6_6_evidence365 hp6_6_check365 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node366 T childKnown
  · exact hp6_6_node367 T childKnown
  · exact hp6_6_node368 T childKnown
  · exact hp6_6_node369 T childKnown
theorem hp6_6_node364 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected364 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected364 ((13 : Int),(1 : Int)) hp6_6_branches364 hp6_6_evidence364 hp6_6_check364 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node363 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected363 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected363 ((13 : Int),(1 : Int)) hp6_6_branches363 hp6_6_evidence363 hp6_6_check363 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node362 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected362 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected362 ((13 : Int),(1 : Int)) hp6_6_branches362 hp6_6_evidence362 hp6_6_check362 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node361 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected361 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected361 ((6 : Int),(2 : Int)) hp6_6_branches361 hp6_6_evidence361 hp6_6_check361 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node360 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected360 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected360 ((10 : Int),(1 : Int)) hp6_6_branches360 hp6_6_evidence360 hp6_6_check360 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node361 T childKnown
theorem hp6_6_node359 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected359 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected359 ((12 : Int),(1 : Int)) hp6_6_branches359 hp6_6_evidence359 hp6_6_check359 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node360 T childKnown
  · exact hp6_6_node362 T childKnown
  · exact hp6_6_node363 T childKnown
  · exact hp6_6_node364 T childKnown
theorem hp6_6_node358 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected358 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected358 ((6 : Int),(2 : Int)) hp6_6_branches358 hp6_6_evidence358 hp6_6_check358 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node357 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected357 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected357 ((10 : Int),(1 : Int)) hp6_6_branches357 hp6_6_evidence357 hp6_6_check357 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node358 T childKnown
theorem hp6_6_node356 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected356 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected356 ((12 : Int),(1 : Int)) hp6_6_branches356 hp6_6_evidence356 hp6_6_check356 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node357 T childKnown
theorem hp6_6_node355 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected355 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected355 ((6 : Int),(2 : Int)) hp6_6_branches355 hp6_6_evidence355 hp6_6_check355 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node354 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected354 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected354 ((10 : Int),(1 : Int)) hp6_6_branches354 hp6_6_evidence354 hp6_6_check354 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node355 T childKnown
theorem hp6_6_node353 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected353 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected353 ((12 : Int),(1 : Int)) hp6_6_branches353 hp6_6_evidence353 hp6_6_check353 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node354 T childKnown
theorem hp6_6_node352 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected352 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected352 ((12 : Int),(1 : Int)) hp6_6_branches352 hp6_6_evidence352 hp6_6_check352 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node351 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected351 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected351 ((13 : Int),(0 : Int)) hp6_6_branches351 hp6_6_evidence351 hp6_6_check351 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node352 T childKnown
  · exact hp6_6_node353 T childKnown
  · exact hp6_6_node356 T childKnown
  · exact hp6_6_node359 T childKnown
  · exact hp6_6_node365 T childKnown
theorem hp6_6_node350 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected350 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected350 ((1 : Int),(1 : Int)) hp6_6_branches350 hp6_6_evidence350 hp6_6_check350 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node349 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected349 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected349 ((1 : Int),(1 : Int)) hp6_6_branches349 hp6_6_evidence349 hp6_6_check349 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node348 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected348 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected348 ((1 : Int),(1 : Int)) hp6_6_branches348 hp6_6_evidence348 hp6_6_check348 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node347 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected347 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected347 ((2 : Int),(1 : Int)) hp6_6_branches347 hp6_6_evidence347 hp6_6_check347 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node346 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected346 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected346 ((1 : Int),(1 : Int)) hp6_6_branches346 hp6_6_evidence346 hp6_6_check346 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node347 T childKnown
theorem hp6_6_node345 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected345 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected345 ((0 : Int),(1 : Int)) hp6_6_branches345 hp6_6_evidence345 hp6_6_check345 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node346 T childKnown
  · exact hp6_6_node348 T childKnown
  · exact hp6_6_node349 T childKnown
  · exact hp6_6_node350 T childKnown
theorem hp6_6_node344 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected344 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected344 ((0 : Int),(1 : Int)) hp6_6_branches344 hp6_6_evidence344 hp6_6_check344 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node343 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected343 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected343 ((4 : Int),(1 : Int)) hp6_6_branches343 hp6_6_evidence343 hp6_6_check343 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node344 T childKnown
theorem hp6_6_node342 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected342 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected342 ((0 : Int),(1 : Int)) hp6_6_branches342 hp6_6_evidence342 hp6_6_check342 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node341 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected341 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected341 ((4 : Int),(1 : Int)) hp6_6_branches341 hp6_6_evidence341 hp6_6_check341 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node342 T childKnown
theorem hp6_6_node340 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected340 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected340 ((4 : Int),(1 : Int)) hp6_6_branches340 hp6_6_evidence340 hp6_6_check340 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node339 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected339 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected339 ((0 : Int),(1 : Int)) hp6_6_branches339 hp6_6_evidence339 hp6_6_check339 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node338 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected338 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected338 ((0 : Int),(1 : Int)) hp6_6_branches338 hp6_6_evidence338 hp6_6_check338 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node337 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected337 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected337 ((1 : Int),(2 : Int)) hp6_6_branches337 hp6_6_evidence337 hp6_6_check337 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node336 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected336 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected336 ((1 : Int),(2 : Int)) hp6_6_branches336 hp6_6_evidence336 hp6_6_check336 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node335 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected335 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected335 ((1 : Int),(2 : Int)) hp6_6_branches335 hp6_6_evidence335 hp6_6_check335 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node334 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected334 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected334 ((2 : Int),(2 : Int)) hp6_6_branches334 hp6_6_evidence334 hp6_6_check334 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node333 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected333 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected333 ((1 : Int),(2 : Int)) hp6_6_branches333 hp6_6_evidence333 hp6_6_check333 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node334 T childKnown
theorem hp6_6_node332 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected332 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected332 ((0 : Int),(2 : Int)) hp6_6_branches332 hp6_6_evidence332 hp6_6_check332 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node333 T childKnown
  · exact hp6_6_node335 T childKnown
  · exact hp6_6_node336 T childKnown
  · exact hp6_6_node337 T childKnown
theorem hp6_6_node331 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected331 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected331 ((5 : Int),(0 : Int)) hp6_6_branches331 hp6_6_evidence331 hp6_6_check331 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node332 T childKnown
  · exact hp6_6_node338 T childKnown
  · exact hp6_6_node339 T childKnown
  · exact hp6_6_node340 T childKnown
  · exact hp6_6_node341 T childKnown
  · exact hp6_6_node343 T childKnown
  · exact hp6_6_node345 T childKnown
  · exact hp6_6_node351 T childKnown
theorem hp6_6_node330 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected330 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected330 ((5 : Int),(1 : Int)) hp6_6_branches330 hp6_6_evidence330 hp6_6_check330 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node329 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected329 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected329 ((3 : Int),(1 : Int)) hp6_6_branches329 hp6_6_evidence329 hp6_6_check329 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node328 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected328 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected328 ((3 : Int),(1 : Int)) hp6_6_branches328 hp6_6_evidence328 hp6_6_check328 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node327 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected327 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected327 ((3 : Int),(1 : Int)) hp6_6_branches327 hp6_6_evidence327 hp6_6_check327 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node326 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected326 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected326 ((4 : Int),(1 : Int)) hp6_6_branches326 hp6_6_evidence326 hp6_6_check326 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node327 T childKnown
  · exact hp6_6_node328 T childKnown
  · exact hp6_6_node329 T childKnown
  · exact hp6_6_node330 T childKnown
theorem hp6_6_node325 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected325 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected325 ((4 : Int),(1 : Int)) hp6_6_branches325 hp6_6_evidence325 hp6_6_check325 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node324 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected324 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected324 ((4 : Int),(1 : Int)) hp6_6_branches324 hp6_6_evidence324 hp6_6_check324 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node323 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected323 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected323 ((4 : Int),(1 : Int)) hp6_6_branches323 hp6_6_evidence323 hp6_6_check323 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node322 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected322 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected322 ((0 : Int),(2 : Int)) hp6_6_branches322 hp6_6_evidence322 hp6_6_check322 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node321 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected321 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected321 ((0 : Int),(2 : Int)) hp6_6_branches321 hp6_6_evidence321 hp6_6_check321 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node320 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected320 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected320 ((1 : Int),(1 : Int)) hp6_6_branches320 hp6_6_evidence320 hp6_6_check320 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node321 T childKnown
  · exact hp6_6_node322 T childKnown
theorem hp6_6_node319 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected319 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected319 ((4 : Int),(1 : Int)) hp6_6_branches319 hp6_6_evidence319 hp6_6_check319 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node320 T childKnown
theorem hp6_6_node318 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected318 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected318 ((3 : Int),(1 : Int)) hp6_6_branches318 hp6_6_evidence318 hp6_6_check318 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node319 T childKnown
  · exact hp6_6_node323 T childKnown
  · exact hp6_6_node324 T childKnown
  · exact hp6_6_node325 T childKnown
theorem hp6_6_node317 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected317 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected317 ((5 : Int),(1 : Int)) hp6_6_branches317 hp6_6_evidence317 hp6_6_check317 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node316 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected316 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected316 ((5 : Int),(0 : Int)) hp6_6_branches316 hp6_6_evidence316 hp6_6_check316 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node317 T childKnown
theorem hp6_6_node315 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected315 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected315 ((3 : Int),(1 : Int)) hp6_6_branches315 hp6_6_evidence315 hp6_6_check315 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node316 T childKnown
theorem hp6_6_node314 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected314 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected314 ((0 : Int),(2 : Int)) hp6_6_branches314 hp6_6_evidence314 hp6_6_check314 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node313 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected313 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected313 ((0 : Int),(2 : Int)) hp6_6_branches313 hp6_6_evidence313 hp6_6_check313 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node312 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected312 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected312 ((1 : Int),(1 : Int)) hp6_6_branches312 hp6_6_evidence312 hp6_6_check312 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node313 T childKnown
  · exact hp6_6_node314 T childKnown
theorem hp6_6_node311 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected311 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected311 ((5 : Int),(0 : Int)) hp6_6_branches311 hp6_6_evidence311 hp6_6_check311 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node312 T childKnown
theorem hp6_6_node310 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected310 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected310 ((3 : Int),(1 : Int)) hp6_6_branches310 hp6_6_evidence310 hp6_6_check310 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node311 T childKnown
theorem hp6_6_node309 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected309 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected309 ((3 : Int),(1 : Int)) hp6_6_branches309 hp6_6_evidence309 hp6_6_check309 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node308 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected308 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected308 ((4 : Int),(0 : Int)) hp6_6_branches308 hp6_6_evidence308 hp6_6_check308 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node309 T childKnown
  · exact hp6_6_node310 T childKnown
  · exact hp6_6_node315 T childKnown
  · exact hp6_6_node318 T childKnown
  · exact hp6_6_node326 T childKnown
theorem hp6_6_node307 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected307 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected307 ((13 : Int),(1 : Int)) hp6_6_branches307 hp6_6_evidence307 hp6_6_check307 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node306 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected306 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected306 ((11 : Int),(1 : Int)) hp6_6_branches306 hp6_6_evidence306 hp6_6_check306 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node305 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected305 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected305 ((11 : Int),(1 : Int)) hp6_6_branches305 hp6_6_evidence305 hp6_6_check305 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node304 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected304 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected304 ((11 : Int),(1 : Int)) hp6_6_branches304 hp6_6_evidence304 hp6_6_check304 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node303 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected303 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected303 ((12 : Int),(1 : Int)) hp6_6_branches303 hp6_6_evidence303 hp6_6_check303 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node304 T childKnown
  · exact hp6_6_node305 T childKnown
  · exact hp6_6_node306 T childKnown
  · exact hp6_6_node307 T childKnown
theorem hp6_6_node302 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected302 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected302 ((12 : Int),(1 : Int)) hp6_6_branches302 hp6_6_evidence302 hp6_6_check302 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node301 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected301 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected301 ((12 : Int),(1 : Int)) hp6_6_branches301 hp6_6_evidence301 hp6_6_check301 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node300 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected300 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected300 ((12 : Int),(1 : Int)) hp6_6_branches300 hp6_6_evidence300 hp6_6_check300 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node299 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected299 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected299 ((5 : Int),(2 : Int)) hp6_6_branches299 hp6_6_evidence299 hp6_6_check299 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node298 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected298 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected298 ((9 : Int),(1 : Int)) hp6_6_branches298 hp6_6_evidence298 hp6_6_check298 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node299 T childKnown
theorem hp6_6_node297 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected297 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected297 ((11 : Int),(1 : Int)) hp6_6_branches297 hp6_6_evidence297 hp6_6_check297 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node298 T childKnown
  · exact hp6_6_node300 T childKnown
  · exact hp6_6_node301 T childKnown
  · exact hp6_6_node302 T childKnown
theorem hp6_6_node296 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected296 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected296 ((5 : Int),(2 : Int)) hp6_6_branches296 hp6_6_evidence296 hp6_6_check296 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node295 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected295 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected295 ((9 : Int),(1 : Int)) hp6_6_branches295 hp6_6_evidence295 hp6_6_check295 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node296 T childKnown
theorem hp6_6_node294 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected294 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected294 ((11 : Int),(1 : Int)) hp6_6_branches294 hp6_6_evidence294 hp6_6_check294 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node295 T childKnown
theorem hp6_6_node293 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected293 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected293 ((5 : Int),(2 : Int)) hp6_6_branches293 hp6_6_evidence293 hp6_6_check293 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node292 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected292 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected292 ((9 : Int),(1 : Int)) hp6_6_branches292 hp6_6_evidence292 hp6_6_check292 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node293 T childKnown
theorem hp6_6_node291 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected291 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected291 ((11 : Int),(1 : Int)) hp6_6_branches291 hp6_6_evidence291 hp6_6_check291 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node292 T childKnown
theorem hp6_6_node290 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected290 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected290 ((11 : Int),(1 : Int)) hp6_6_branches290 hp6_6_evidence290 hp6_6_check290 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node289 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected289 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected289 ((12 : Int),(0 : Int)) hp6_6_branches289 hp6_6_evidence289 hp6_6_check289 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node290 T childKnown
  · exact hp6_6_node291 T childKnown
  · exact hp6_6_node294 T childKnown
  · exact hp6_6_node297 T childKnown
  · exact hp6_6_node303 T childKnown
theorem hp6_6_node288 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected288 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected288 ((1 : Int),(1 : Int)) hp6_6_branches288 hp6_6_evidence288 hp6_6_check288 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node287 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected287 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected287 ((1 : Int),(1 : Int)) hp6_6_branches287 hp6_6_evidence287 hp6_6_check287 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node286 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected286 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected286 ((1 : Int),(1 : Int)) hp6_6_branches286 hp6_6_evidence286 hp6_6_check286 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node285 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected285 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected285 ((2 : Int),(1 : Int)) hp6_6_branches285 hp6_6_evidence285 hp6_6_check285 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node284 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected284 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected284 ((1 : Int),(1 : Int)) hp6_6_branches284 hp6_6_evidence284 hp6_6_check284 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node285 T childKnown
theorem hp6_6_node283 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected283 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected283 ((0 : Int),(1 : Int)) hp6_6_branches283 hp6_6_evidence283 hp6_6_check283 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node284 T childKnown
  · exact hp6_6_node286 T childKnown
  · exact hp6_6_node287 T childKnown
  · exact hp6_6_node288 T childKnown
theorem hp6_6_node282 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected282 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected282 ((0 : Int),(1 : Int)) hp6_6_branches282 hp6_6_evidence282 hp6_6_check282 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node281 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected281 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected281 ((3 : Int),(1 : Int)) hp6_6_branches281 hp6_6_evidence281 hp6_6_check281 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node282 T childKnown
theorem hp6_6_node280 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected280 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected280 ((0 : Int),(1 : Int)) hp6_6_branches280 hp6_6_evidence280 hp6_6_check280 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node279 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected279 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected279 ((3 : Int),(1 : Int)) hp6_6_branches279 hp6_6_evidence279 hp6_6_check279 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node280 T childKnown
theorem hp6_6_node278 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected278 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected278 ((3 : Int),(1 : Int)) hp6_6_branches278 hp6_6_evidence278 hp6_6_check278 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node277 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected277 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected277 ((0 : Int),(1 : Int)) hp6_6_branches277 hp6_6_evidence277 hp6_6_check277 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node276 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected276 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected276 ((0 : Int),(1 : Int)) hp6_6_branches276 hp6_6_evidence276 hp6_6_check276 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node275 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected275 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected275 ((1 : Int),(2 : Int)) hp6_6_branches275 hp6_6_evidence275 hp6_6_check275 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node274 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected274 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected274 ((1 : Int),(2 : Int)) hp6_6_branches274 hp6_6_evidence274 hp6_6_check274 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node273 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected273 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected273 ((1 : Int),(2 : Int)) hp6_6_branches273 hp6_6_evidence273 hp6_6_check273 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node272 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected272 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected272 ((2 : Int),(2 : Int)) hp6_6_branches272 hp6_6_evidence272 hp6_6_check272 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node271 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected271 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected271 ((1 : Int),(2 : Int)) hp6_6_branches271 hp6_6_evidence271 hp6_6_check271 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node272 T childKnown
theorem hp6_6_node270 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected270 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected270 ((0 : Int),(2 : Int)) hp6_6_branches270 hp6_6_evidence270 hp6_6_check270 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node271 T childKnown
  · exact hp6_6_node273 T childKnown
  · exact hp6_6_node274 T childKnown
  · exact hp6_6_node275 T childKnown
theorem hp6_6_node269 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected269 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected269 ((4 : Int),(0 : Int)) hp6_6_branches269 hp6_6_evidence269 hp6_6_check269 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node270 T childKnown
  · exact hp6_6_node276 T childKnown
  · exact hp6_6_node277 T childKnown
  · exact hp6_6_node278 T childKnown
  · exact hp6_6_node279 T childKnown
  · exact hp6_6_node281 T childKnown
  · exact hp6_6_node283 T childKnown
  · exact hp6_6_node289 T childKnown
theorem hp6_6_node268 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected268 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected268 ((4 : Int),(1 : Int)) hp6_6_branches268 hp6_6_evidence268 hp6_6_check268 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node267 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected267 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected267 ((2 : Int),(1 : Int)) hp6_6_branches267 hp6_6_evidence267 hp6_6_check267 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node266 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected266 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected266 ((2 : Int),(1 : Int)) hp6_6_branches266 hp6_6_evidence266 hp6_6_check266 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node265 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected265 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected265 ((2 : Int),(1 : Int)) hp6_6_branches265 hp6_6_evidence265 hp6_6_check265 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node264 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected264 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected264 ((3 : Int),(1 : Int)) hp6_6_branches264 hp6_6_evidence264 hp6_6_check264 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node265 T childKnown
  · exact hp6_6_node266 T childKnown
  · exact hp6_6_node267 T childKnown
  · exact hp6_6_node268 T childKnown
theorem hp6_6_node263 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected263 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected263 ((3 : Int),(1 : Int)) hp6_6_branches263 hp6_6_evidence263 hp6_6_check263 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node262 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected262 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected262 ((3 : Int),(1 : Int)) hp6_6_branches262 hp6_6_evidence262 hp6_6_check262 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node261 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected261 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected261 ((3 : Int),(1 : Int)) hp6_6_branches261 hp6_6_evidence261 hp6_6_check261 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node260 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected260 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected260 ((0 : Int),(2 : Int)) hp6_6_branches260 hp6_6_evidence260 hp6_6_check260 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node259 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected259 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected259 ((0 : Int),(2 : Int)) hp6_6_branches259 hp6_6_evidence259 hp6_6_check259 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node258 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected258 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected258 ((0 : Int),(1 : Int)) hp6_6_branches258 hp6_6_evidence258 hp6_6_check258 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node259 T childKnown
  · exact hp6_6_node260 T childKnown
theorem hp6_6_node257 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected257 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected257 ((3 : Int),(1 : Int)) hp6_6_branches257 hp6_6_evidence257 hp6_6_check257 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node258 T childKnown
theorem hp6_6_node256 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected256 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected256 ((2 : Int),(1 : Int)) hp6_6_branches256 hp6_6_evidence256 hp6_6_check256 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node257 T childKnown
  · exact hp6_6_node261 T childKnown
  · exact hp6_6_node262 T childKnown
  · exact hp6_6_node263 T childKnown
theorem hp6_6_node255 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected255 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected255 ((4 : Int),(1 : Int)) hp6_6_branches255 hp6_6_evidence255 hp6_6_check255 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node254 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected254 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected254 ((4 : Int),(0 : Int)) hp6_6_branches254 hp6_6_evidence254 hp6_6_check254 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node255 T childKnown
theorem hp6_6_node253 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected253 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected253 ((2 : Int),(1 : Int)) hp6_6_branches253 hp6_6_evidence253 hp6_6_check253 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node254 T childKnown
theorem hp6_6_node252 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected252 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected252 ((0 : Int),(2 : Int)) hp6_6_branches252 hp6_6_evidence252 hp6_6_check252 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node251 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected251 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected251 ((0 : Int),(2 : Int)) hp6_6_branches251 hp6_6_evidence251 hp6_6_check251 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node250 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected250 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected250 ((0 : Int),(1 : Int)) hp6_6_branches250 hp6_6_evidence250 hp6_6_check250 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node251 T childKnown
  · exact hp6_6_node252 T childKnown
theorem hp6_6_node249 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected249 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected249 ((4 : Int),(0 : Int)) hp6_6_branches249 hp6_6_evidence249 hp6_6_check249 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node250 T childKnown
theorem hp6_6_node248 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected248 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected248 ((2 : Int),(1 : Int)) hp6_6_branches248 hp6_6_evidence248 hp6_6_check248 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node249 T childKnown
theorem hp6_6_node247 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected247 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected247 ((2 : Int),(1 : Int)) hp6_6_branches247 hp6_6_evidence247 hp6_6_check247 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node246 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected246 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected246 ((3 : Int),(0 : Int)) hp6_6_branches246 hp6_6_evidence246 hp6_6_check246 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node247 T childKnown
  · exact hp6_6_node248 T childKnown
  · exact hp6_6_node253 T childKnown
  · exact hp6_6_node256 T childKnown
  · exact hp6_6_node264 T childKnown
theorem hp6_6_node245 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected245 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected245 ((12 : Int),(1 : Int)) hp6_6_branches245 hp6_6_evidence245 hp6_6_check245 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node244 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected244 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected244 ((10 : Int),(1 : Int)) hp6_6_branches244 hp6_6_evidence244 hp6_6_check244 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node243 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected243 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected243 ((10 : Int),(1 : Int)) hp6_6_branches243 hp6_6_evidence243 hp6_6_check243 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node242 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected242 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected242 ((10 : Int),(1 : Int)) hp6_6_branches242 hp6_6_evidence242 hp6_6_check242 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node241 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected241 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected241 ((11 : Int),(1 : Int)) hp6_6_branches241 hp6_6_evidence241 hp6_6_check241 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node242 T childKnown
  · exact hp6_6_node243 T childKnown
  · exact hp6_6_node244 T childKnown
  · exact hp6_6_node245 T childKnown
theorem hp6_6_node240 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected240 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected240 ((11 : Int),(1 : Int)) hp6_6_branches240 hp6_6_evidence240 hp6_6_check240 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node239 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected239 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected239 ((11 : Int),(1 : Int)) hp6_6_branches239 hp6_6_evidence239 hp6_6_check239 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node238 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected238 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected238 ((11 : Int),(1 : Int)) hp6_6_branches238 hp6_6_evidence238 hp6_6_check238 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node237 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected237 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected237 ((4 : Int),(2 : Int)) hp6_6_branches237 hp6_6_evidence237 hp6_6_check237 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node236 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected236 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected236 ((8 : Int),(1 : Int)) hp6_6_branches236 hp6_6_evidence236 hp6_6_check236 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node237 T childKnown
theorem hp6_6_node235 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected235 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected235 ((10 : Int),(1 : Int)) hp6_6_branches235 hp6_6_evidence235 hp6_6_check235 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node236 T childKnown
  · exact hp6_6_node238 T childKnown
  · exact hp6_6_node239 T childKnown
  · exact hp6_6_node240 T childKnown
theorem hp6_6_node234 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected234 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected234 ((4 : Int),(2 : Int)) hp6_6_branches234 hp6_6_evidence234 hp6_6_check234 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node233 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected233 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected233 ((8 : Int),(1 : Int)) hp6_6_branches233 hp6_6_evidence233 hp6_6_check233 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node234 T childKnown
theorem hp6_6_node232 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected232 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected232 ((10 : Int),(1 : Int)) hp6_6_branches232 hp6_6_evidence232 hp6_6_check232 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node233 T childKnown
theorem hp6_6_node231 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected231 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected231 ((4 : Int),(2 : Int)) hp6_6_branches231 hp6_6_evidence231 hp6_6_check231 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node230 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected230 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected230 ((8 : Int),(1 : Int)) hp6_6_branches230 hp6_6_evidence230 hp6_6_check230 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node231 T childKnown
theorem hp6_6_node229 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected229 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected229 ((10 : Int),(1 : Int)) hp6_6_branches229 hp6_6_evidence229 hp6_6_check229 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node230 T childKnown
theorem hp6_6_node228 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected228 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected228 ((10 : Int),(1 : Int)) hp6_6_branches228 hp6_6_evidence228 hp6_6_check228 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node227 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected227 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected227 ((11 : Int),(0 : Int)) hp6_6_branches227 hp6_6_evidence227 hp6_6_check227 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node228 T childKnown
  · exact hp6_6_node229 T childKnown
  · exact hp6_6_node232 T childKnown
  · exact hp6_6_node235 T childKnown
  · exact hp6_6_node241 T childKnown
theorem hp6_6_node226 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected226 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected226 ((1 : Int),(1 : Int)) hp6_6_branches226 hp6_6_evidence226 hp6_6_check226 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node225 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected225 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected225 ((1 : Int),(1 : Int)) hp6_6_branches225 hp6_6_evidence225 hp6_6_check225 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node224 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected224 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected224 ((1 : Int),(1 : Int)) hp6_6_branches224 hp6_6_evidence224 hp6_6_check224 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node223 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected223 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected223 ((2 : Int),(1 : Int)) hp6_6_branches223 hp6_6_evidence223 hp6_6_check223 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node222 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected222 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected222 ((1 : Int),(1 : Int)) hp6_6_branches222 hp6_6_evidence222 hp6_6_check222 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node223 T childKnown
theorem hp6_6_node221 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected221 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected221 ((0 : Int),(1 : Int)) hp6_6_branches221 hp6_6_evidence221 hp6_6_check221 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node222 T childKnown
  · exact hp6_6_node224 T childKnown
  · exact hp6_6_node225 T childKnown
  · exact hp6_6_node226 T childKnown
theorem hp6_6_node220 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected220 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected220 ((0 : Int),(1 : Int)) hp6_6_branches220 hp6_6_evidence220 hp6_6_check220 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node219 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected219 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected219 ((2 : Int),(1 : Int)) hp6_6_branches219 hp6_6_evidence219 hp6_6_check219 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node220 T childKnown
theorem hp6_6_node218 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected218 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected218 ((0 : Int),(1 : Int)) hp6_6_branches218 hp6_6_evidence218 hp6_6_check218 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node217 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected217 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected217 ((2 : Int),(1 : Int)) hp6_6_branches217 hp6_6_evidence217 hp6_6_check217 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node218 T childKnown
theorem hp6_6_node216 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected216 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected216 ((2 : Int),(1 : Int)) hp6_6_branches216 hp6_6_evidence216 hp6_6_check216 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node215 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected215 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected215 ((0 : Int),(1 : Int)) hp6_6_branches215 hp6_6_evidence215 hp6_6_check215 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node214 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected214 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected214 ((0 : Int),(1 : Int)) hp6_6_branches214 hp6_6_evidence214 hp6_6_check214 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node213 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected213 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected213 ((1 : Int),(2 : Int)) hp6_6_branches213 hp6_6_evidence213 hp6_6_check213 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node212 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected212 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected212 ((1 : Int),(2 : Int)) hp6_6_branches212 hp6_6_evidence212 hp6_6_check212 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node211 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected211 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected211 ((1 : Int),(2 : Int)) hp6_6_branches211 hp6_6_evidence211 hp6_6_check211 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node210 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected210 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected210 ((2 : Int),(2 : Int)) hp6_6_branches210 hp6_6_evidence210 hp6_6_check210 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node209 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected209 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected209 ((1 : Int),(2 : Int)) hp6_6_branches209 hp6_6_evidence209 hp6_6_check209 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node210 T childKnown
theorem hp6_6_node208 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected208 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected208 ((0 : Int),(2 : Int)) hp6_6_branches208 hp6_6_evidence208 hp6_6_check208 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node209 T childKnown
  · exact hp6_6_node211 T childKnown
  · exact hp6_6_node212 T childKnown
  · exact hp6_6_node213 T childKnown
theorem hp6_6_node207 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected207 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected207 ((3 : Int),(0 : Int)) hp6_6_branches207 hp6_6_evidence207 hp6_6_check207 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node208 T childKnown
  · exact hp6_6_node214 T childKnown
  · exact hp6_6_node215 T childKnown
  · exact hp6_6_node216 T childKnown
  · exact hp6_6_node217 T childKnown
  · exact hp6_6_node219 T childKnown
  · exact hp6_6_node221 T childKnown
  · exact hp6_6_node227 T childKnown
theorem hp6_6_node206 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected206 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected206 ((1 : Int),(1 : Int)) hp6_6_branches206 hp6_6_evidence206 hp6_6_check206 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node205 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected205 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected205 ((1 : Int),(1 : Int)) hp6_6_branches205 hp6_6_evidence205 hp6_6_check205 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node204 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected204 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected204 ((1 : Int),(0 : Int)) hp6_6_branches204 hp6_6_evidence204 hp6_6_check204 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node205 T childKnown
  · exact hp6_6_node206 T childKnown
theorem hp6_6_node203 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected203 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected203 ((2 : Int),(1 : Int)) hp6_6_branches203 hp6_6_evidence203 hp6_6_check203 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node202 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected202 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected202 ((1 : Int),(1 : Int)) hp6_6_branches202 hp6_6_evidence202 hp6_6_check202 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node203 T childKnown
theorem hp6_6_node201 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected201 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected201 ((3 : Int),(2 : Int)) hp6_6_branches201 hp6_6_evidence201 hp6_6_check201 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node200 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected200 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected200 ((3 : Int),(2 : Int)) hp6_6_branches200 hp6_6_evidence200 hp6_6_check200 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node199 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected199 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected199 ((3 : Int),(1 : Int)) hp6_6_branches199 hp6_6_evidence199 hp6_6_check199 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node200 T childKnown
  · exact hp6_6_node201 T childKnown
theorem hp6_6_node198 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected198 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected198 ((1 : Int),(1 : Int)) hp6_6_branches198 hp6_6_evidence198 hp6_6_check198 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node199 T childKnown
theorem hp6_6_node197 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected197 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected197 ((2 : Int),(1 : Int)) hp6_6_branches197 hp6_6_evidence197 hp6_6_check197 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node196 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected196 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected196 ((2 : Int),(0 : Int)) hp6_6_branches196 hp6_6_evidence196 hp6_6_check196 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node197 T childKnown
theorem hp6_6_node195 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected195 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected195 ((3 : Int),(2 : Int)) hp6_6_branches195 hp6_6_evidence195 hp6_6_check195 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node194 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected194 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected194 ((3 : Int),(2 : Int)) hp6_6_branches194 hp6_6_evidence194 hp6_6_check194 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node193 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected193 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected193 ((3 : Int),(2 : Int)) hp6_6_branches193 hp6_6_evidence193 hp6_6_check193 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node192 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected192 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected192 ((4 : Int),(2 : Int)) hp6_6_branches192 hp6_6_evidence192 hp6_6_check192 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node191 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected191 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected191 ((3 : Int),(2 : Int)) hp6_6_branches191 hp6_6_evidence191 hp6_6_check191 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node192 T childKnown
theorem hp6_6_node190 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected190 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected190 ((2 : Int),(2 : Int)) hp6_6_branches190 hp6_6_evidence190 hp6_6_check190 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node191 T childKnown
  · exact hp6_6_node193 T childKnown
  · exact hp6_6_node194 T childKnown
  · exact hp6_6_node195 T childKnown
theorem hp6_6_node189 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected189 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected189 ((2 : Int),(0 : Int)) hp6_6_branches189 hp6_6_evidence189 hp6_6_check189 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node190 T childKnown
theorem hp6_6_node188 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected188 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected188 ((1 : Int),(0 : Int)) hp6_6_branches188 hp6_6_evidence188 hp6_6_check188 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node189 T childKnown
  · exact hp6_6_node196 T childKnown
  · exact hp6_6_node198 T childKnown
  · exact hp6_6_node202 T childKnown
theorem hp6_6_node187 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected187 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected187 ((2 : Int),(1 : Int)) hp6_6_branches187 hp6_6_evidence187 hp6_6_check187 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node186 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected186 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected186 ((1 : Int),(1 : Int)) hp6_6_branches186 hp6_6_evidence186 hp6_6_check186 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node187 T childKnown
theorem hp6_6_node185 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected185 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected185 ((3 : Int),(2 : Int)) hp6_6_branches185 hp6_6_evidence185 hp6_6_check185 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node184 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected184 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected184 ((3 : Int),(2 : Int)) hp6_6_branches184 hp6_6_evidence184 hp6_6_check184 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node183 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected183 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected183 ((3 : Int),(1 : Int)) hp6_6_branches183 hp6_6_evidence183 hp6_6_check183 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node184 T childKnown
  · exact hp6_6_node185 T childKnown
theorem hp6_6_node182 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected182 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected182 ((1 : Int),(1 : Int)) hp6_6_branches182 hp6_6_evidence182 hp6_6_check182 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node183 T childKnown
theorem hp6_6_node181 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected181 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected181 ((2 : Int),(1 : Int)) hp6_6_branches181 hp6_6_evidence181 hp6_6_check181 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node180 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected180 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected180 ((2 : Int),(0 : Int)) hp6_6_branches180 hp6_6_evidence180 hp6_6_check180 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node181 T childKnown
theorem hp6_6_node179 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected179 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected179 ((3 : Int),(2 : Int)) hp6_6_branches179 hp6_6_evidence179 hp6_6_check179 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node178 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected178 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected178 ((3 : Int),(2 : Int)) hp6_6_branches178 hp6_6_evidence178 hp6_6_check178 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node177 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected177 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected177 ((3 : Int),(2 : Int)) hp6_6_branches177 hp6_6_evidence177 hp6_6_check177 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node176 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected176 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected176 ((4 : Int),(2 : Int)) hp6_6_branches176 hp6_6_evidence176 hp6_6_check176 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node175 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected175 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected175 ((3 : Int),(2 : Int)) hp6_6_branches175 hp6_6_evidence175 hp6_6_check175 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node176 T childKnown
theorem hp6_6_node174 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected174 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected174 ((2 : Int),(2 : Int)) hp6_6_branches174 hp6_6_evidence174 hp6_6_check174 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node175 T childKnown
  · exact hp6_6_node177 T childKnown
  · exact hp6_6_node178 T childKnown
  · exact hp6_6_node179 T childKnown
theorem hp6_6_node173 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected173 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected173 ((2 : Int),(0 : Int)) hp6_6_branches173 hp6_6_evidence173 hp6_6_check173 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node174 T childKnown
theorem hp6_6_node172 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected172 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected172 ((1 : Int),(0 : Int)) hp6_6_branches172 hp6_6_evidence172 hp6_6_check172 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node173 T childKnown
  · exact hp6_6_node180 T childKnown
  · exact hp6_6_node182 T childKnown
  · exact hp6_6_node186 T childKnown
theorem hp6_6_node171 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected171 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected171 ((3 : Int),(1 : Int)) hp6_6_branches171 hp6_6_evidence171 hp6_6_check171 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node170 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected170 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected170 ((1 : Int),(1 : Int)) hp6_6_branches170 hp6_6_evidence170 hp6_6_check170 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node169 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected169 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected169 ((1 : Int),(1 : Int)) hp6_6_branches169 hp6_6_evidence169 hp6_6_check169 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node168 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected168 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected168 ((1 : Int),(1 : Int)) hp6_6_branches168 hp6_6_evidence168 hp6_6_check168 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node167 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected167 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected167 ((2 : Int),(1 : Int)) hp6_6_branches167 hp6_6_evidence167 hp6_6_check167 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node168 T childKnown
  · exact hp6_6_node169 T childKnown
  · exact hp6_6_node170 T childKnown
  · exact hp6_6_node171 T childKnown
theorem hp6_6_node166 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected166 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected166 ((2 : Int),(1 : Int)) hp6_6_branches166 hp6_6_evidence166 hp6_6_check166 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node165 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected165 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected165 ((2 : Int),(1 : Int)) hp6_6_branches165 hp6_6_evidence165 hp6_6_check165 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node164 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected164 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected164 ((2 : Int),(1 : Int)) hp6_6_branches164 hp6_6_evidence164 hp6_6_check164 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node163 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected163 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected163 ((4 : Int),(2 : Int)) hp6_6_branches163 hp6_6_evidence163 hp6_6_check163 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node162 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected162 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected162 ((4 : Int),(2 : Int)) hp6_6_branches162 hp6_6_evidence162 hp6_6_check162 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node161 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected161 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected161 ((4 : Int),(1 : Int)) hp6_6_branches161 hp6_6_evidence161 hp6_6_check161 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node162 T childKnown
  · exact hp6_6_node163 T childKnown
theorem hp6_6_node160 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected160 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected160 ((2 : Int),(1 : Int)) hp6_6_branches160 hp6_6_evidence160 hp6_6_check160 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node161 T childKnown
theorem hp6_6_node159 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected159 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected159 ((1 : Int),(1 : Int)) hp6_6_branches159 hp6_6_evidence159 hp6_6_check159 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node160 T childKnown
  · exact hp6_6_node164 T childKnown
  · exact hp6_6_node165 T childKnown
  · exact hp6_6_node166 T childKnown
theorem hp6_6_node158 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected158 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected158 ((3 : Int),(1 : Int)) hp6_6_branches158 hp6_6_evidence158 hp6_6_check158 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node157 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected157 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected157 ((3 : Int),(0 : Int)) hp6_6_branches157 hp6_6_evidence157 hp6_6_check157 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node158 T childKnown
theorem hp6_6_node156 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected156 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected156 ((1 : Int),(1 : Int)) hp6_6_branches156 hp6_6_evidence156 hp6_6_check156 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node157 T childKnown
theorem hp6_6_node155 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected155 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected155 ((4 : Int),(2 : Int)) hp6_6_branches155 hp6_6_evidence155 hp6_6_check155 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node154 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected154 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected154 ((4 : Int),(2 : Int)) hp6_6_branches154 hp6_6_evidence154 hp6_6_check154 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node153 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected153 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected153 ((3 : Int),(2 : Int)) hp6_6_branches153 hp6_6_evidence153 hp6_6_check153 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node154 T childKnown
  · exact hp6_6_node155 T childKnown
theorem hp6_6_node152 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected152 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected152 ((3 : Int),(0 : Int)) hp6_6_branches152 hp6_6_evidence152 hp6_6_check152 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node153 T childKnown
theorem hp6_6_node151 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected151 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected151 ((1 : Int),(1 : Int)) hp6_6_branches151 hp6_6_evidence151 hp6_6_check151 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node152 T childKnown
theorem hp6_6_node150 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected150 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected150 ((1 : Int),(1 : Int)) hp6_6_branches150 hp6_6_evidence150 hp6_6_check150 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node149 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected149 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected149 ((2 : Int),(0 : Int)) hp6_6_branches149 hp6_6_evidence149 hp6_6_check149 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node150 T childKnown
  · exact hp6_6_node151 T childKnown
  · exact hp6_6_node156 T childKnown
  · exact hp6_6_node159 T childKnown
  · exact hp6_6_node167 T childKnown
theorem hp6_6_node148 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected148 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected148 ((11 : Int),(1 : Int)) hp6_6_branches148 hp6_6_evidence148 hp6_6_check148 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node147 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected147 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected147 ((9 : Int),(1 : Int)) hp6_6_branches147 hp6_6_evidence147 hp6_6_check147 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node146 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected146 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected146 ((9 : Int),(1 : Int)) hp6_6_branches146 hp6_6_evidence146 hp6_6_check146 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node145 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected145 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected145 ((9 : Int),(1 : Int)) hp6_6_branches145 hp6_6_evidence145 hp6_6_check145 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node144 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected144 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected144 ((10 : Int),(1 : Int)) hp6_6_branches144 hp6_6_evidence144 hp6_6_check144 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node145 T childKnown
  · exact hp6_6_node146 T childKnown
  · exact hp6_6_node147 T childKnown
  · exact hp6_6_node148 T childKnown
theorem hp6_6_node143 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected143 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected143 ((10 : Int),(1 : Int)) hp6_6_branches143 hp6_6_evidence143 hp6_6_check143 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node142 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected142 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected142 ((10 : Int),(1 : Int)) hp6_6_branches142 hp6_6_evidence142 hp6_6_check142 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node141 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected141 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected141 ((10 : Int),(1 : Int)) hp6_6_branches141 hp6_6_evidence141 hp6_6_check141 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node140 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected140 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected140 ((3 : Int),(2 : Int)) hp6_6_branches140 hp6_6_evidence140 hp6_6_check140 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node139 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected139 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected139 ((7 : Int),(1 : Int)) hp6_6_branches139 hp6_6_evidence139 hp6_6_check139 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node140 T childKnown
theorem hp6_6_node138 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected138 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected138 ((9 : Int),(1 : Int)) hp6_6_branches138 hp6_6_evidence138 hp6_6_check138 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node139 T childKnown
  · exact hp6_6_node141 T childKnown
  · exact hp6_6_node142 T childKnown
  · exact hp6_6_node143 T childKnown
theorem hp6_6_node137 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected137 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected137 ((3 : Int),(2 : Int)) hp6_6_branches137 hp6_6_evidence137 hp6_6_check137 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node136 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected136 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected136 ((7 : Int),(1 : Int)) hp6_6_branches136 hp6_6_evidence136 hp6_6_check136 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node137 T childKnown
theorem hp6_6_node135 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected135 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected135 ((9 : Int),(1 : Int)) hp6_6_branches135 hp6_6_evidence135 hp6_6_check135 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node136 T childKnown
theorem hp6_6_node134 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected134 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected134 ((3 : Int),(2 : Int)) hp6_6_branches134 hp6_6_evidence134 hp6_6_check134 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node133 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected133 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected133 ((7 : Int),(1 : Int)) hp6_6_branches133 hp6_6_evidence133 hp6_6_check133 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node134 T childKnown
theorem hp6_6_node132 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected132 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected132 ((9 : Int),(1 : Int)) hp6_6_branches132 hp6_6_evidence132 hp6_6_check132 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node133 T childKnown
theorem hp6_6_node131 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected131 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected131 ((9 : Int),(1 : Int)) hp6_6_branches131 hp6_6_evidence131 hp6_6_check131 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node130 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected130 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected130 ((10 : Int),(0 : Int)) hp6_6_branches130 hp6_6_evidence130 hp6_6_check130 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node131 T childKnown
  · exact hp6_6_node132 T childKnown
  · exact hp6_6_node135 T childKnown
  · exact hp6_6_node138 T childKnown
  · exact hp6_6_node144 T childKnown
theorem hp6_6_node129 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected129 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected129 ((1 : Int),(1 : Int)) hp6_6_branches129 hp6_6_evidence129 hp6_6_check129 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node128 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected128 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected128 ((1 : Int),(1 : Int)) hp6_6_branches128 hp6_6_evidence128 hp6_6_check128 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node127 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected127 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected127 ((1 : Int),(1 : Int)) hp6_6_branches127 hp6_6_evidence127 hp6_6_check127 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node126 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected126 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected126 ((2 : Int),(1 : Int)) hp6_6_branches126 hp6_6_evidence126 hp6_6_check126 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node125 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected125 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected125 ((1 : Int),(1 : Int)) hp6_6_branches125 hp6_6_evidence125 hp6_6_check125 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node126 T childKnown
theorem hp6_6_node124 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected124 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected124 ((0 : Int),(1 : Int)) hp6_6_branches124 hp6_6_evidence124 hp6_6_check124 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node125 T childKnown
  · exact hp6_6_node127 T childKnown
  · exact hp6_6_node128 T childKnown
  · exact hp6_6_node129 T childKnown
theorem hp6_6_node123 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected123 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected123 ((0 : Int),(1 : Int)) hp6_6_branches123 hp6_6_evidence123 hp6_6_check123 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node122 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected122 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected122 ((1 : Int),(1 : Int)) hp6_6_branches122 hp6_6_evidence122 hp6_6_check122 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node123 T childKnown
theorem hp6_6_node121 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected121 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected121 ((0 : Int),(1 : Int)) hp6_6_branches121 hp6_6_evidence121 hp6_6_check121 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node120 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected120 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected120 ((1 : Int),(1 : Int)) hp6_6_branches120 hp6_6_evidence120 hp6_6_check120 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node121 T childKnown
theorem hp6_6_node119 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected119 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected119 ((1 : Int),(1 : Int)) hp6_6_branches119 hp6_6_evidence119 hp6_6_check119 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node118 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected118 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected118 ((0 : Int),(1 : Int)) hp6_6_branches118 hp6_6_evidence118 hp6_6_check118 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node117 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected117 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected117 ((0 : Int),(1 : Int)) hp6_6_branches117 hp6_6_evidence117 hp6_6_check117 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node116 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected116 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected116 ((1 : Int),(2 : Int)) hp6_6_branches116 hp6_6_evidence116 hp6_6_check116 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node115 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected115 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected115 ((1 : Int),(2 : Int)) hp6_6_branches115 hp6_6_evidence115 hp6_6_check115 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node114 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected114 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected114 ((1 : Int),(2 : Int)) hp6_6_branches114 hp6_6_evidence114 hp6_6_check114 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node113 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected113 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected113 ((3 : Int),(1 : Int)) hp6_6_branches113 hp6_6_evidence113 hp6_6_check113 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node112 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected112 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected112 ((3 : Int),(1 : Int)) hp6_6_branches112 hp6_6_evidence112 hp6_6_check112 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node111 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected111 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected111 ((4 : Int),(1 : Int)) hp6_6_branches111 hp6_6_evidence111 hp6_6_check111 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node110 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected110 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected110 ((4 : Int),(0 : Int)) hp6_6_branches110 hp6_6_evidence110 hp6_6_check110 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node111 T childKnown
theorem hp6_6_node109 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected109 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected109 ((4 : Int),(2 : Int)) hp6_6_branches109 hp6_6_evidence109 hp6_6_check109 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node108 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected108 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected108 ((4 : Int),(0 : Int)) hp6_6_branches108 hp6_6_evidence108 hp6_6_check108 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node109 T childKnown
theorem hp6_6_node107 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected107 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected107 ((3 : Int),(0 : Int)) hp6_6_branches107 hp6_6_evidence107 hp6_6_check107 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node108 T childKnown
  · exact hp6_6_node110 T childKnown
  · exact hp6_6_node112 T childKnown
  · exact hp6_6_node113 T childKnown
theorem hp6_6_node106 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected106 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected106 ((1 : Int),(2 : Int)) hp6_6_branches106 hp6_6_evidence106 hp6_6_check106 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node107 T childKnown
theorem hp6_6_node105 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected105 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected105 ((0 : Int),(2 : Int)) hp6_6_branches105 hp6_6_evidence105 hp6_6_check105 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node106 T childKnown
  · exact hp6_6_node114 T childKnown
  · exact hp6_6_node115 T childKnown
  · exact hp6_6_node116 T childKnown
theorem hp6_6_node104 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected104 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected104 ((2 : Int),(0 : Int)) hp6_6_branches104 hp6_6_evidence104 hp6_6_check104 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node105 T childKnown
  · exact hp6_6_node117 T childKnown
  · exact hp6_6_node118 T childKnown
  · exact hp6_6_node119 T childKnown
  · exact hp6_6_node120 T childKnown
  · exact hp6_6_node122 T childKnown
  · exact hp6_6_node124 T childKnown
  · exact hp6_6_node130 T childKnown
theorem hp6_6_node103 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected103 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected103 ((2 : Int),(1 : Int)) hp6_6_branches103 hp6_6_evidence103 hp6_6_check103 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node102 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected102 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected102 ((0 : Int),(1 : Int)) hp6_6_branches102 hp6_6_evidence102 hp6_6_check102 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node101 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected101 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected101 ((0 : Int),(1 : Int)) hp6_6_branches101 hp6_6_evidence101 hp6_6_check101 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node100 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected100 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected100 ((0 : Int),(1 : Int)) hp6_6_branches100 hp6_6_evidence100 hp6_6_check100 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node99 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected99 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected99 ((1 : Int),(1 : Int)) hp6_6_branches99 hp6_6_evidence99 hp6_6_check99 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node100 T childKnown
  · exact hp6_6_node101 T childKnown
  · exact hp6_6_node102 T childKnown
  · exact hp6_6_node103 T childKnown
theorem hp6_6_node98 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected98 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected98 ((1 : Int),(1 : Int)) hp6_6_branches98 hp6_6_evidence98 hp6_6_check98 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node97 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected97 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected97 ((1 : Int),(1 : Int)) hp6_6_branches97 hp6_6_evidence97 hp6_6_check97 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node96 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected96 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected96 ((1 : Int),(1 : Int)) hp6_6_branches96 hp6_6_evidence96 hp6_6_check96 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node95 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected95 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected95 ((3 : Int),(2 : Int)) hp6_6_branches95 hp6_6_evidence95 hp6_6_check95 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node94 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected94 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected94 ((3 : Int),(2 : Int)) hp6_6_branches94 hp6_6_evidence94 hp6_6_check94 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node93 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected93 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected93 ((3 : Int),(1 : Int)) hp6_6_branches93 hp6_6_evidence93 hp6_6_check93 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node94 T childKnown
  · exact hp6_6_node95 T childKnown
theorem hp6_6_node92 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected92 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected92 ((1 : Int),(1 : Int)) hp6_6_branches92 hp6_6_evidence92 hp6_6_check92 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node93 T childKnown
theorem hp6_6_node91 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected91 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected91 ((0 : Int),(1 : Int)) hp6_6_branches91 hp6_6_evidence91 hp6_6_check91 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node92 T childKnown
  · exact hp6_6_node96 T childKnown
  · exact hp6_6_node97 T childKnown
  · exact hp6_6_node98 T childKnown
theorem hp6_6_node90 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected90 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected90 ((2 : Int),(1 : Int)) hp6_6_branches90 hp6_6_evidence90 hp6_6_check90 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node89 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected89 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected89 ((2 : Int),(0 : Int)) hp6_6_branches89 hp6_6_evidence89 hp6_6_check89 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node90 T childKnown
theorem hp6_6_node88 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected88 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected88 ((0 : Int),(1 : Int)) hp6_6_branches88 hp6_6_evidence88 hp6_6_check88 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node89 T childKnown
theorem hp6_6_node87 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected87 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected87 ((3 : Int),(2 : Int)) hp6_6_branches87 hp6_6_evidence87 hp6_6_check87 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node86 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected86 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected86 ((3 : Int),(2 : Int)) hp6_6_branches86 hp6_6_evidence86 hp6_6_check86 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node85 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected85 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected85 ((2 : Int),(2 : Int)) hp6_6_branches85 hp6_6_evidence85 hp6_6_check85 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node86 T childKnown
  · exact hp6_6_node87 T childKnown
theorem hp6_6_node84 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected84 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected84 ((2 : Int),(0 : Int)) hp6_6_branches84 hp6_6_evidence84 hp6_6_check84 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node85 T childKnown
theorem hp6_6_node83 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected83 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected83 ((0 : Int),(1 : Int)) hp6_6_branches83 hp6_6_evidence83 hp6_6_check83 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node84 T childKnown
theorem hp6_6_node82 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected82 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected82 ((0 : Int),(1 : Int)) hp6_6_branches82 hp6_6_evidence82 hp6_6_check82 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node81 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected81 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected81 ((1 : Int),(0 : Int)) hp6_6_branches81 hp6_6_evidence81 hp6_6_check81 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node82 T childKnown
  · exact hp6_6_node83 T childKnown
  · exact hp6_6_node88 T childKnown
  · exact hp6_6_node91 T childKnown
  · exact hp6_6_node99 T childKnown
theorem hp6_6_node80 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected80 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected80 ((10 : Int),(1 : Int)) hp6_6_branches80 hp6_6_evidence80 hp6_6_check80 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node79 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected79 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected79 ((8 : Int),(1 : Int)) hp6_6_branches79 hp6_6_evidence79 hp6_6_check79 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node78 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected78 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected78 ((8 : Int),(1 : Int)) hp6_6_branches78 hp6_6_evidence78 hp6_6_check78 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node77 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected77 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected77 ((8 : Int),(1 : Int)) hp6_6_branches77 hp6_6_evidence77 hp6_6_check77 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node76 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected76 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected76 ((9 : Int),(1 : Int)) hp6_6_branches76 hp6_6_evidence76 hp6_6_check76 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node77 T childKnown
  · exact hp6_6_node78 T childKnown
  · exact hp6_6_node79 T childKnown
  · exact hp6_6_node80 T childKnown
theorem hp6_6_node75 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected75 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected75 ((9 : Int),(1 : Int)) hp6_6_branches75 hp6_6_evidence75 hp6_6_check75 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node74 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected74 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected74 ((9 : Int),(1 : Int)) hp6_6_branches74 hp6_6_evidence74 hp6_6_check74 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node73 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected73 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected73 ((9 : Int),(1 : Int)) hp6_6_branches73 hp6_6_evidence73 hp6_6_check73 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node72 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected72 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected72 ((2 : Int),(2 : Int)) hp6_6_branches72 hp6_6_evidence72 hp6_6_check72 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node71 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected71 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected71 ((6 : Int),(1 : Int)) hp6_6_branches71 hp6_6_evidence71 hp6_6_check71 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node72 T childKnown
theorem hp6_6_node70 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected70 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected70 ((8 : Int),(1 : Int)) hp6_6_branches70 hp6_6_evidence70 hp6_6_check70 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node71 T childKnown
  · exact hp6_6_node73 T childKnown
  · exact hp6_6_node74 T childKnown
  · exact hp6_6_node75 T childKnown
theorem hp6_6_node69 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected69 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected69 ((2 : Int),(2 : Int)) hp6_6_branches69 hp6_6_evidence69 hp6_6_check69 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node68 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected68 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected68 ((6 : Int),(1 : Int)) hp6_6_branches68 hp6_6_evidence68 hp6_6_check68 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node69 T childKnown
theorem hp6_6_node67 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected67 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected67 ((8 : Int),(1 : Int)) hp6_6_branches67 hp6_6_evidence67 hp6_6_check67 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node68 T childKnown
theorem hp6_6_node66 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected66 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected66 ((2 : Int),(2 : Int)) hp6_6_branches66 hp6_6_evidence66 hp6_6_check66 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node65 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected65 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected65 ((6 : Int),(1 : Int)) hp6_6_branches65 hp6_6_evidence65 hp6_6_check65 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node66 T childKnown
theorem hp6_6_node64 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected64 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected64 ((8 : Int),(1 : Int)) hp6_6_branches64 hp6_6_evidence64 hp6_6_check64 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node65 T childKnown
theorem hp6_6_node63 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected63 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected63 ((8 : Int),(1 : Int)) hp6_6_branches63 hp6_6_evidence63 hp6_6_check63 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node62 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected62 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected62 ((9 : Int),(0 : Int)) hp6_6_branches62 hp6_6_evidence62 hp6_6_check62 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node63 T childKnown
  · exact hp6_6_node64 T childKnown
  · exact hp6_6_node67 T childKnown
  · exact hp6_6_node70 T childKnown
  · exact hp6_6_node76 T childKnown
theorem hp6_6_node61 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected61 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected61 ((1 : Int),(1 : Int)) hp6_6_branches61 hp6_6_evidence61 hp6_6_check61 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node60 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected60 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected60 ((1 : Int),(1 : Int)) hp6_6_branches60 hp6_6_evidence60 hp6_6_check60 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node59 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected59 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected59 ((1 : Int),(1 : Int)) hp6_6_branches59 hp6_6_evidence59 hp6_6_check59 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node58 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected58 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected58 ((3 : Int),(2 : Int)) hp6_6_branches58 hp6_6_evidence58 hp6_6_check58 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node57 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected57 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected57 ((3 : Int),(2 : Int)) hp6_6_branches57 hp6_6_evidence57 hp6_6_check57 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node56 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected56 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected56 ((3 : Int),(1 : Int)) hp6_6_branches56 hp6_6_evidence56 hp6_6_check56 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node57 T childKnown
  · exact hp6_6_node58 T childKnown
theorem hp6_6_node55 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected55 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected55 ((1 : Int),(1 : Int)) hp6_6_branches55 hp6_6_evidence55 hp6_6_check55 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node56 T childKnown
theorem hp6_6_node54 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected54 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected54 ((0 : Int),(1 : Int)) hp6_6_branches54 hp6_6_evidence54 hp6_6_check54 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node55 T childKnown
  · exact hp6_6_node59 T childKnown
  · exact hp6_6_node60 T childKnown
  · exact hp6_6_node61 T childKnown
theorem hp6_6_node53 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected53 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected53 ((2 : Int),(1 : Int)) hp6_6_branches53 hp6_6_evidence53 hp6_6_check53 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node52 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected52 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected52 ((2 : Int),(0 : Int)) hp6_6_branches52 hp6_6_evidence52 hp6_6_check52 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node53 T childKnown
theorem hp6_6_node51 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected51 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected51 ((0 : Int),(1 : Int)) hp6_6_branches51 hp6_6_evidence51 hp6_6_check51 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node52 T childKnown
theorem hp6_6_node50 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected50 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected50 ((3 : Int),(2 : Int)) hp6_6_branches50 hp6_6_evidence50 hp6_6_check50 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node49 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected49 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected49 ((3 : Int),(2 : Int)) hp6_6_branches49 hp6_6_evidence49 hp6_6_check49 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node48 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected48 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected48 ((2 : Int),(2 : Int)) hp6_6_branches48 hp6_6_evidence48 hp6_6_check48 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node49 T childKnown
  · exact hp6_6_node50 T childKnown
theorem hp6_6_node47 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected47 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected47 ((2 : Int),(0 : Int)) hp6_6_branches47 hp6_6_evidence47 hp6_6_check47 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node48 T childKnown
theorem hp6_6_node46 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected46 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected46 ((0 : Int),(1 : Int)) hp6_6_branches46 hp6_6_evidence46 hp6_6_check46 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node47 T childKnown
theorem hp6_6_node45 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected45 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected45 ((0 : Int),(1 : Int)) hp6_6_branches45 hp6_6_evidence45 hp6_6_check45 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node44 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected44 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected44 ((0 : Int),(1 : Int)) hp6_6_branches44 hp6_6_evidence44 hp6_6_check44 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node43 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected43 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected43 ((0 : Int),(1 : Int)) hp6_6_branches43 hp6_6_evidence43 hp6_6_check43 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node42 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected42 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected42 ((2 : Int),(1 : Int)) hp6_6_branches42 hp6_6_evidence42 hp6_6_check42 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node41 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected41 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected41 ((2 : Int),(1 : Int)) hp6_6_branches41 hp6_6_evidence41 hp6_6_check41 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node40 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected40 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected40 ((3 : Int),(1 : Int)) hp6_6_branches40 hp6_6_evidence40 hp6_6_check40 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node39 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected39 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected39 ((3 : Int),(0 : Int)) hp6_6_branches39 hp6_6_evidence39 hp6_6_check39 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node40 T childKnown
theorem hp6_6_node38 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected38 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected38 ((3 : Int),(2 : Int)) hp6_6_branches38 hp6_6_evidence38 hp6_6_check38 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node37 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected37 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected37 ((3 : Int),(0 : Int)) hp6_6_branches37 hp6_6_evidence37 hp6_6_check37 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node38 T childKnown
theorem hp6_6_node36 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected36 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected36 ((2 : Int),(0 : Int)) hp6_6_branches36 hp6_6_evidence36 hp6_6_check36 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node37 T childKnown
  · exact hp6_6_node39 T childKnown
  · exact hp6_6_node41 T childKnown
  · exact hp6_6_node42 T childKnown
theorem hp6_6_node35 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected35 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected35 ((2 : Int),(1 : Int)) hp6_6_branches35 hp6_6_evidence35 hp6_6_check35 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node34 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected34 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected34 ((2 : Int),(1 : Int)) hp6_6_branches34 hp6_6_evidence34 hp6_6_check34 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node33 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected33 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected33 ((3 : Int),(1 : Int)) hp6_6_branches33 hp6_6_evidence33 hp6_6_check33 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node32 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected32 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected32 ((3 : Int),(0 : Int)) hp6_6_branches32 hp6_6_evidence32 hp6_6_check32 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node33 T childKnown
theorem hp6_6_node31 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected31 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected31 ((3 : Int),(2 : Int)) hp6_6_branches31 hp6_6_evidence31 hp6_6_check31 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node30 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected30 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected30 ((3 : Int),(0 : Int)) hp6_6_branches30 hp6_6_evidence30 hp6_6_check30 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node31 T childKnown
theorem hp6_6_node29 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected29 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected29 ((2 : Int),(0 : Int)) hp6_6_branches29 hp6_6_evidence29 hp6_6_check29 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node30 T childKnown
  · exact hp6_6_node32 T childKnown
  · exact hp6_6_node34 T childKnown
  · exact hp6_6_node35 T childKnown
theorem hp6_6_node28 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected28 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected28 ((3 : Int),(1 : Int)) hp6_6_branches28 hp6_6_evidence28 hp6_6_check28 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node27 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected27 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected27 ((2 : Int),(1 : Int)) hp6_6_branches27 hp6_6_evidence27 hp6_6_check27 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node28 T childKnown
theorem hp6_6_node26 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected26 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected26 ((4 : Int),(2 : Int)) hp6_6_branches26 hp6_6_evidence26 hp6_6_check26 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node25 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected25 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected25 ((4 : Int),(2 : Int)) hp6_6_branches25 hp6_6_evidence25 hp6_6_check25 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node24 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected24 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected24 ((4 : Int),(1 : Int)) hp6_6_branches24 hp6_6_evidence24 hp6_6_check24 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node25 T childKnown
  · exact hp6_6_node26 T childKnown
theorem hp6_6_node23 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected23 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected23 ((2 : Int),(1 : Int)) hp6_6_branches23 hp6_6_evidence23 hp6_6_check23 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node24 T childKnown
theorem hp6_6_node22 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected22 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected22 ((3 : Int),(1 : Int)) hp6_6_branches22 hp6_6_evidence22 hp6_6_check22 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node21 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected21 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected21 ((3 : Int),(0 : Int)) hp6_6_branches21 hp6_6_evidence21 hp6_6_check21 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node22 T childKnown
theorem hp6_6_node20 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected20 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected20 ((4 : Int),(2 : Int)) hp6_6_branches20 hp6_6_evidence20 hp6_6_check20 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node19 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected19 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected19 ((4 : Int),(2 : Int)) hp6_6_branches19 hp6_6_evidence19 hp6_6_check19 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node18 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected18 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected18 ((3 : Int),(2 : Int)) hp6_6_branches18 hp6_6_evidence18 hp6_6_check18 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node19 T childKnown
  · exact hp6_6_node20 T childKnown
theorem hp6_6_node17 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected17 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected17 ((3 : Int),(0 : Int)) hp6_6_branches17 hp6_6_evidence17 hp6_6_check17 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node18 T childKnown
theorem hp6_6_node16 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected16 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected16 ((2 : Int),(0 : Int)) hp6_6_branches16 hp6_6_evidence16 hp6_6_check16 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node17 T childKnown
  · exact hp6_6_node21 T childKnown
  · exact hp6_6_node23 T childKnown
  · exact hp6_6_node27 T childKnown
theorem hp6_6_node15 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected15 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected15 ((3 : Int),(1 : Int)) hp6_6_branches15 hp6_6_evidence15 hp6_6_check15 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node14 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected14 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected14 ((2 : Int),(1 : Int)) hp6_6_branches14 hp6_6_evidence14 hp6_6_check14 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node15 T childKnown
theorem hp6_6_node13 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected13 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected13 ((4 : Int),(2 : Int)) hp6_6_branches13 hp6_6_evidence13 hp6_6_check13 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node12 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected12 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected12 ((4 : Int),(2 : Int)) hp6_6_branches12 hp6_6_evidence12 hp6_6_check12 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node11 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected11 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected11 ((4 : Int),(1 : Int)) hp6_6_branches11 hp6_6_evidence11 hp6_6_check11 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node12 T childKnown
  · exact hp6_6_node13 T childKnown
theorem hp6_6_node10 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected10 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected10 ((2 : Int),(1 : Int)) hp6_6_branches10 hp6_6_evidence10 hp6_6_check10 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node11 T childKnown
theorem hp6_6_node9 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected9 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected9 ((3 : Int),(1 : Int)) hp6_6_branches9 hp6_6_evidence9 hp6_6_check9 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node8 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected8 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected8 ((3 : Int),(0 : Int)) hp6_6_branches8 hp6_6_evidence8 hp6_6_check8 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node9 T childKnown
theorem hp6_6_node7 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected7 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected7 ((4 : Int),(2 : Int)) hp6_6_branches7 hp6_6_evidence7 hp6_6_check7 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node6 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected6 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected6 ((4 : Int),(2 : Int)) hp6_6_branches6 hp6_6_evidence6 hp6_6_check6 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_6_node5 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected5 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected5 ((3 : Int),(2 : Int)) hp6_6_branches5 hp6_6_evidence5 hp6_6_check5 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_6_node6 T childKnown
  · exact hp6_6_node7 T childKnown
theorem hp6_6_node4 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected4 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected4 ((3 : Int),(0 : Int)) hp6_6_branches4 hp6_6_evidence4 hp6_6_check4 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_6_node5 T childKnown
theorem hp6_6_node3 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected3 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected3 ((2 : Int),(0 : Int)) hp6_6_branches3 hp6_6_evidence3 hp6_6_check3 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node4 T childKnown
  · exact hp6_6_node8 T childKnown
  · exact hp6_6_node10 T childKnown
  · exact hp6_6_node14 T childKnown
theorem hp6_6_node2 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected2 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected2 ((0 : Int),(2 : Int)) hp6_6_branches2 hp6_6_evidence2 hp6_6_check2 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_6_node3 T childKnown
  · exact hp6_6_node16 T childKnown
  · exact hp6_6_node29 T childKnown
  · exact hp6_6_node36 T childKnown
theorem hp6_6_node1 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected1 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected1 ((1 : Int),(0 : Int)) hp6_6_branches1 hp6_6_evidence1 hp6_6_check1 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node2 T childKnown
  · exact hp6_6_node43 T childKnown
  · exact hp6_6_node44 T childKnown
  · exact hp6_6_node45 T childKnown
  · exact hp6_6_node46 T childKnown
  · exact hp6_6_node51 T childKnown
  · exact hp6_6_node54 T childKnown
  · exact hp6_6_node62 T childKnown
theorem hp6_6_node0 (T : Tiling (6 : Int) (6 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_6_selected0 → T.world s) : False := by
  apply replay_step (6 : Int) (6 : Int) (by decide) (by decide) T hp6_6_selected0 ((0 : Int),(0 : Int)) hp6_6_branches0 hp6_6_evidence0 hp6_6_check0 ?_ known
  intro t member childKnown
  simp only [hp6_6_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_6_node1 T childKnown
  · exact hp6_6_node81 T childKnown
  · exact hp6_6_node104 T childKnown
  · exact hp6_6_node149 T childKnown
  · exact hp6_6_node172 T childKnown
  · exact hp6_6_node188 T childKnown
  · exact hp6_6_node204 T childKnown
  · exact hp6_6_node207 T childKnown
  · exact hp6_6_node246 T childKnown
  · exact hp6_6_node269 T childKnown
  · exact hp6_6_node308 T childKnown
  · exact hp6_6_node331 T childKnown
  · exact hp6_6_node370 T childKnown
  · exact hp6_6_node393 T childKnown
  · exact hp6_6_node463 T childKnown
  · exact hp6_6_node486 T childKnown
  · exact hp6_6_node556 T childKnown
  · exact hp6_6_node579 T childKnown
  · exact hp6_6_node581 T childKnown
  · exact hp6_6_node588 T childKnown
  · exact hp6_6_node590 T childKnown
  · exact hp6_6_node900 T childKnown

theorem hp6_6_no_half_plane : ¬Tiles (6 : Int) (6 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp6_6_node0 T (by simp [hp6_6_selected0])
#print axioms hp6_6_no_half_plane

end THalfPlaneFinite

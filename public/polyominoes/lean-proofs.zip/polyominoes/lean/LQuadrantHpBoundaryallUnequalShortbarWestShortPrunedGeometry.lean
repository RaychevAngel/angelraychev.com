import LQuadrantHpBoundaryallUnequalShortbarWestShortPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_shortbar_west_short_pruned_M (a b : Int) : Int := 4*(a+b+1)
def HP_boundaryall_unequal_shortbar_west_short_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_shortbar_west_short_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_shortbar_west_short_pruned_M a b ∧ y≤HP_boundaryall_unequal_shortbar_west_short_pruned_M a b
def HP_boundaryall_unequal_shortbar_west_short_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht2
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_point a b (hlong) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o0 a b jx jy (hstrict) (sep0).1 (hb) (insideT) (sep1).2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o1 a b jx jy (insideT) (hlong) (hb) (hit) (sep1).2.1 (sep2).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o2 a b jx jy (sep2).2.1 (hit) (hlong) (hb) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o3 a b jx jy (sep0).2.1 (hit) (insideT) (hb) (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o4 a b jx jy (hit) (hlong) (insideT) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o5 a b jx jy (sep0).2.1 (hstrict) (insideT) (hit) (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o6 a b jx jy (hb) (hlong) (sep1).2.1 (sep0).1 (insideT) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n001_o7 a b jx jy (insideT) (hb) (sep1).2.1 (hit) (hstrict)

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_point a b (hb) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o0 a b jx jy (hit) (sep1).2.2.1 (sep3).2.1 (hstrict) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o1 a b jx jy (hb) (sep3).1 (hlong) (hit) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o2 a b jx jy (hb) (insideT) (hlong) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o3 a b jx jy (hb) (hlong) (sep1).2.1 (sep0).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o4 a b jx jy (sep3).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o5 a b jx jy (hit) (insideT) (sep1).2.1 (sep0).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o6 a b jx jy (sep3).2.1 (insideT) (sep1).2.1 (sep0).1 (hb) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n003_o7 a b jx jy (sep1).2.1 (insideT) (hb) (hstrict) (hit)

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_point a b (hb) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_empty a b (ap0_2).2.2.1 ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o0 a b jx jy (hit) (sep4).2.1 (hb) (sep1).2.1 (sep0).2.2.1 (hstrict) (hlong) (ap0_2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o1 a b jx jy (sep4).2.2.1 (hlong) (sep1).2.1 (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o2 a b jx jy (hb) (hit) (sep2).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o3 a b jx jy (insideT) (hb) (sep0).2.1 (hlong) (sep1).2.1 (hit) (ap0_2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o4 a b jx jy (insideT) (hlong) (hb) (sep4).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o5 a b jx jy (sep1).2.1 (hb) (hit) (hstrict) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o6 a b jx jy (hit) (insideT) (sep0).1 (sep4).2.1 (hlong) (ap0_2).2.2.1 (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n005_o7 a b jx jy (hstrict) (sep1).2.1 (insideT) (hb) (hit)

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o0 a b jx jy (hb) (sep3).2.1 (sep1).2.1 (hit) (hstrict) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (sep1).2.1 (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node005 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o2 a b jx jy (hlong) (sep2).2.1 (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o3 a b jx jy (insideT) (sep1).2.1 (hit) (hlong) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o4 a b jx jy (sep3).2.1 (hb) (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o5 a b jx jy (hb) (sep1).2.1 (hit) (insideT) (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o6 a b jx jy (sep1).2.2.1 (hb) (sep1).2.1 (sep0).2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n004_o7 a b jx jy (sep1).2.1 (hstrict) (insideT) (hb) (hit)

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht2
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_point a b (hlong) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_empty a b (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o0 a b jx jy (sep1).2.2.1 (sep1).2.1 (hb) (hstrict) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o1 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (sep1).2.1 (hb) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node003 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o2 a b jx jy (hlong) (hit) (sep2).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o3 a b jx jy (hit) (sep0).2.1 (hb) (sep1).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o4 a b jx jy (insideT) (hit) (hb) (hlong) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node004 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o5 a b jx jy (hstrict) (hb) (sep1).2.1 (hit) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o6 a b jx jy (hlong) (sep0).2.2.1 (hb) (hit) (sep2).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n002_o7 a b jx jy (hstrict) (hb) (insideT) (sep1).2.1 (hit)

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_point a b ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o0 a b jx jy (sep1).2.1 (insideT) (hstrict) (sep0).1 (hb) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o1 a b jx jy (hb) (sep1).2.1 (sep3).2.2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o2 a b jx jy (hb) (sep2).2.1 (hlong) (insideT) (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o3 a b jx jy (sep1).2.1 (hb) (sep0).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o4 a b jx jy (hlong) (insideT) (sep3).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o5 a b jx jy (hit) (hb) (sep0).2.1 (sep1).2.1 (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o6 a b jx jy (sep0).1 (sep3).2.1 (hit) (hb) (sep1).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n007_o7 a b jx jy (hb) (sep1).2.1 (hit) (insideT) (hlong) (sep3).2.2.1

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht2
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_point a b (hb) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o0 a b jx jy (insideT) (hit) (hstrict) (hb) (sep1).2.1 (sep0).1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o1 a b jx jy (hb) (sep1).2.1 (hit) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node007 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o2 a b jx jy (sep2).2.1 (insideT) (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o3 a b jx jy (hlong) (hb) (sep1).2.1 (insideT) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o4 a b jx jy (hlong) (hb) (insideT) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o5 a b jx jy (hstrict) (sep0).2.1 (sep1).2.1 (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o6 a b jx jy (hlong) (sep2).2.1 (hb) (hit) (sep1).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n006_o7 a b jx jy (hstrict) (hb) (hit) (insideT) (sep1).2.1

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht1
  have support : HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b (1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_shortbar_west_short_pruned_Box,HP_boundaryall_unequal_shortbar_west_short_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o0 a b jx jy (sep1).2.1 (hit) (sep1).2.2.1 (hb) (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o1 a b jx jy (hit) (insideT) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node001 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hb) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node002 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o3 a b jx jy (hit) (sep0).2.1 (sep1).2.2.2 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (sep1).2.2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_shortbar_west_short_pruned_node006 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o5 a b jx jy (sep0).2.1 (hit) (insideT) (hb) (hstrict) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o6 a b jx jy (sep0).2.1 (sep1).2.2.1 (hb) (hlong) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_west_short_pruned_n000_o7 a b jx jy (hit) (hstrict) (hb) (insideT) (sep1).2.1

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_west_short_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_west_short_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_shortbar_west_short_pruned_node000 a b ha hb hstrict hlong world copies inside cover sep avoid avoidPair anchor0 anchor1 rootap0_1

theorem HP_boundaryall_unequal_shortbar_west_short_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair := avoid_boundary_pairs a b (by omega) (by omega) (by omega) T
  apply HP_boundaryall_unequal_shortbar_west_short_pruned_bounded_obstruction a b ha hb hstrict hlong T.world T.copies ?_ ?_ T.disjoint avoid avoidPair anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_shortbar_west_short_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_shortbar_west_short_pruned_anchored_obstruction a b ha hb hstrict hlong U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_shortbar_west_short_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_shortbar_west_short_pruned_bounded_obstruction
end PolyominoFormal.LRegion

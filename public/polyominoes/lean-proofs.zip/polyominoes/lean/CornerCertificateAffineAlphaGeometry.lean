import CornerAffineAlphaArithmetic
import CornerCertificateAffineReplay

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

def affine_alpha_known000 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))]
def affine_alpha_known001 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known002 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known003 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known004 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known005 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known006 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known007 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known008 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known009 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known010 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known011 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known012 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known013 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known014 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known015 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known016 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known017 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known018 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known019 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known020 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known021 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known022 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known023 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known024 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (3 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known025 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known026 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known027 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known028 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known029 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known030 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known031 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known032 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known033 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known034 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known035 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known036 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known037 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known038 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known039 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known040 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known041 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known042 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known043 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known044 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known045 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known046 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known047 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known048 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known049 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known050 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known051 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known052 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known053 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known054 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known055 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known056 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known057 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known058 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known059 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known060 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known061 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known062 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known063 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known064 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known065 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known066 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known067 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known068 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known069 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known070 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known071 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known072 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known073 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known074 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known075 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known076 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known077 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known078 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known079 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known080 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known081 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known082 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known083 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known084 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known085 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known086 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known087 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known088 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known089 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known090 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known091 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known092 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known093 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known094 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known095 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known096 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known097 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known098 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known099 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known100 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known101 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known102 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known103 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known104 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known105 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known106 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known107 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known108 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known109 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known110 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known111 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known112 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known113 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known114 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known115 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known116 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_alpha_known117 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_alpha_known118 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known119 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known120 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known121 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known122 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known123 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known124 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_alpha_known125 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known126 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known127 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known128 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_alpha_known129 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known130 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known131 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known132 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known133 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known134 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known135 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_alpha_known136 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_alpha_known137 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known138 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_known139 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_alpha_known140 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_alpha_branches000 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known001 a)),Branch.mk (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known047 a)),Branch.mk (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known066 a)),Branch.mk (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known072 a)),Branch.mk (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known089 a)),Branch.mk (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known135 a))]
def affine_alpha_branches001 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known002 a)),Branch.mk (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known021 a)),Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known027 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known043 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known044 a))]
def affine_alpha_branches002 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known003 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known004 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known005 a))]
def affine_alpha_branches005 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known006 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known009 a)),Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known010 a)),Branch.mk (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known011 a)),Branch.mk (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known018 a)),Branch.mk (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known019 a)),Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known020 a))]
def affine_alpha_branches006 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known007 a)),Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known008 a))]
def affine_alpha_branches007 (a : Int) : List Branch := []
def affine_alpha_branches008 (a : Int) : List Branch := []
def affine_alpha_branches009 (a : Int) : List Branch := []
def affine_alpha_branches010 (a : Int) : List Branch := []
def affine_alpha_branches011 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known012 a)),Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known015 a))]
def affine_alpha_branches012 (a : Int) : List Branch := [Branch.mk (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known013 a)),Branch.mk (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known014 a))]
def affine_alpha_branches013 (a : Int) : List Branch := []
def affine_alpha_branches014 (a : Int) : List Branch := []
def affine_alpha_branches015 (a : Int) : List Branch := [Branch.mk (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known016 a)),Branch.mk (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known017 a))]
def affine_alpha_branches016 (a : Int) : List Branch := []
def affine_alpha_branches017 (a : Int) : List Branch := []
def affine_alpha_branches019 (a : Int) : List Branch := []
def affine_alpha_branches020 (a : Int) : List Branch := []
def affine_alpha_branches021 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known022 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known023 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known026 a))]
def affine_alpha_branches022 (a : Int) : List Branch := []
def affine_alpha_branches023 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known024 a)),Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known025 a))]
def affine_alpha_branches024 (a : Int) : List Branch := []
def affine_alpha_branches025 (a : Int) : List Branch := []
def affine_alpha_branches026 (a : Int) : List Branch := []
def affine_alpha_branches027 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known028 a)),Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known029 a))]
def affine_alpha_branches029 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known030 a)),Branch.mk (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known031 a)),Branch.mk (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known038 a)),Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known040 a)),Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known041 a))]
def affine_alpha_branches031 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known032 a)),Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known035 a))]
def affine_alpha_branches032 (a : Int) : List Branch := [Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known033 a)),Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known034 a))]
def affine_alpha_branches033 (a : Int) : List Branch := []
def affine_alpha_branches034 (a : Int) : List Branch := []
def affine_alpha_branches035 (a : Int) : List Branch := [Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known036 a)),Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known037 a))]
def affine_alpha_branches036 (a : Int) : List Branch := []
def affine_alpha_branches037 (a : Int) : List Branch := []
def affine_alpha_branches038 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known039 a))]
def affine_alpha_branches039 (a : Int) : List Branch := []
def affine_alpha_branches040 (a : Int) : List Branch := []
def affine_alpha_branches041 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known042 a))]
def affine_alpha_branches042 (a : Int) : List Branch := []
def affine_alpha_branches044 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known045 a)),Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known046 a))]
def affine_alpha_branches045 (a : Int) : List Branch := []
def affine_alpha_branches046 (a : Int) : List Branch := []
def affine_alpha_branches047 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known048 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known049 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known050 a))]
def affine_alpha_branches050 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known051 a)),Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known054 a)),Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known055 a)),Branch.mk (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known056 a)),Branch.mk (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known063 a)),Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known064 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known065 a))]
def affine_alpha_branches051 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known052 a)),Branch.mk (Cross.mk (2 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known053 a))]
def affine_alpha_branches052 (a : Int) : List Branch := []
def affine_alpha_branches053 (a : Int) : List Branch := []
def affine_alpha_branches054 (a : Int) : List Branch := []
def affine_alpha_branches055 (a : Int) : List Branch := []
def affine_alpha_branches056 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known057 a)),Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known060 a))]
def affine_alpha_branches057 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known058 a)),Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known059 a))]
def affine_alpha_branches058 (a : Int) : List Branch := []
def affine_alpha_branches059 (a : Int) : List Branch := []
def affine_alpha_branches060 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known061 a)),Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known062 a))]
def affine_alpha_branches061 (a : Int) : List Branch := []
def affine_alpha_branches062 (a : Int) : List Branch := []
def affine_alpha_branches064 (a : Int) : List Branch := []
def affine_alpha_branches065 (a : Int) : List Branch := []
def affine_alpha_branches066 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known067 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known068 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known071 a))]
def affine_alpha_branches067 (a : Int) : List Branch := []
def affine_alpha_branches068 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known069 a)),Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known070 a))]
def affine_alpha_branches069 (a : Int) : List Branch := []
def affine_alpha_branches070 (a : Int) : List Branch := []
def affine_alpha_branches071 (a : Int) : List Branch := []
def affine_alpha_branches072 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known073 a)),Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known074 a)),Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known075 a))]
def affine_alpha_branches075 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known076 a)),Branch.mk (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known077 a)),Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known084 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known086 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known087 a))]
def affine_alpha_branches077 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known078 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known081 a))]
def affine_alpha_branches078 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known079 a)),Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known080 a))]
def affine_alpha_branches079 (a : Int) : List Branch := []
def affine_alpha_branches080 (a : Int) : List Branch := []
def affine_alpha_branches081 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known082 a)),Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known083 a))]
def affine_alpha_branches082 (a : Int) : List Branch := []
def affine_alpha_branches083 (a : Int) : List Branch := []
def affine_alpha_branches084 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known085 a))]
def affine_alpha_branches085 (a : Int) : List Branch := []
def affine_alpha_branches086 (a : Int) : List Branch := []
def affine_alpha_branches087 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known088 a))]
def affine_alpha_branches088 (a : Int) : List Branch := []
def affine_alpha_branches089 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known090 a)),Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known091 a)),Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known109 a)),Branch.mk (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known112 a)),Branch.mk (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known129 a))]
def affine_alpha_branches091 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known092 a)),Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known093 a))]
def affine_alpha_branches093 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known094 a)),Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known097 a)),Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known098 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known099 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known106 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known107 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known108 a))]
def affine_alpha_branches094 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known095 a)),Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known096 a))]
def affine_alpha_branches095 (a : Int) : List Branch := []
def affine_alpha_branches096 (a : Int) : List Branch := []
def affine_alpha_branches097 (a : Int) : List Branch := []
def affine_alpha_branches098 (a : Int) : List Branch := []
def affine_alpha_branches099 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known100 a)),Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known103 a))]
def affine_alpha_branches100 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known101 a)),Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known102 a))]
def affine_alpha_branches101 (a : Int) : List Branch := []
def affine_alpha_branches102 (a : Int) : List Branch := []
def affine_alpha_branches103 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known104 a)),Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known105 a))]
def affine_alpha_branches104 (a : Int) : List Branch := []
def affine_alpha_branches105 (a : Int) : List Branch := []
def affine_alpha_branches107 (a : Int) : List Branch := []
def affine_alpha_branches108 (a : Int) : List Branch := []
def affine_alpha_branches109 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known110 a)),Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known111 a))]
def affine_alpha_branches110 (a : Int) : List Branch := []
def affine_alpha_branches111 (a : Int) : List Branch := []
def affine_alpha_branches112 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known113 a)),Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known114 a)),Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known115 a))]
def affine_alpha_branches115 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known116 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known117 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known124 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known126 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known127 a))]
def affine_alpha_branches117 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known118 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known121 a))]
def affine_alpha_branches118 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known119 a)),Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known120 a))]
def affine_alpha_branches119 (a : Int) : List Branch := []
def affine_alpha_branches120 (a : Int) : List Branch := []
def affine_alpha_branches121 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known122 a)),Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known123 a))]
def affine_alpha_branches122 (a : Int) : List Branch := []
def affine_alpha_branches123 (a : Int) : List Branch := []
def affine_alpha_branches124 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known125 a))]
def affine_alpha_branches125 (a : Int) : List Branch := []
def affine_alpha_branches126 (a : Int) : List Branch := []
def affine_alpha_branches127 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known128 a))]
def affine_alpha_branches128 (a : Int) : List Branch := []
def affine_alpha_branches129 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known130 a)),Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known133 a)),Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known134 a))]
def affine_alpha_branches130 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known131 a)),Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known132 a))]
def affine_alpha_branches131 (a : Int) : List Branch := []
def affine_alpha_branches132 (a : Int) : List Branch := []
def affine_alpha_branches133 (a : Int) : List Branch := []
def affine_alpha_branches134 (a : Int) : List Branch := []
def affine_alpha_branches135 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known136 a)),Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known139 a)),Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known140 a))]
def affine_alpha_branches136 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known137 a)),Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known138 a))]
def affine_alpha_branches137 (a : Int) : List Branch := []
def affine_alpha_branches138 (a : Int) : List Branch := []
def affine_alpha_branches139 (a : Int) : List Branch := []
def affine_alpha_branches140 (a : Int) : List Branch := []

theorem affine_alpha_nonnegative000 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known000 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known000, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty000 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known000 a) (0 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n000_empty a ((by simpa only [KnownContains, affine_alpha_known000, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window000 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known000 a)) B) : QueryWindow h (0 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative000 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known000])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n000_height a h (top0) ((by omega))

theorem affine_alpha_complete000 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known000 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches000 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart0 := separated (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known000])
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known000])
  have apart4 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known000])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known000])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o0 a jx jy (apart0).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known072 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart0).1 (ha) (apart4).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known066 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o2 a jx jy (apart0).1 (ha) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known089 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n000_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (apart4).2.2.1 (apart1).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).2.2.1 (apart5).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known001 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o5 a jx jy (apart0).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart4).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known135 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n000_o6 a jx jy (apart0).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart4).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known047 a)), by simp [affine_alpha_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n000_o7 a jx jy (apart1).1 (ha) (apart0).1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative001 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known001 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known001, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty001 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known001 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n001_empty a ((by simpa only [KnownContains, affine_alpha_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window001 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known001 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative001 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known001])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n001_height a h ((by omega)) (top0)

theorem affine_alpha_complete001 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known001 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches001 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart4 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known001])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known001])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known001])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known001])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n001_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (apart8).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known027 a)), by simp [affine_alpha_branches001], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n001_o1 a jx jy (ha) (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known021 a)), by simp [affine_alpha_branches001], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n001_o2 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known043 a)), by simp [affine_alpha_branches001], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n001_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha) (apart5).2.2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n001_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart6).2.2.1 (apart5).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n001_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.1 (apart5).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known044 a)), by simp [affine_alpha_branches001], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n001_o6 a jx jy (apart5).2.2.1 (ha) (apart4).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known002 a)), by simp [affine_alpha_branches001], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n001_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart6).2.2.1)

theorem affine_alpha_nonnegative002 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known002 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known002, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty002 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known002 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n002_empty a ((by simpa only [KnownContains, affine_alpha_known002, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window002 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known002 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative002 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known002])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n002_height a h ((by omega)) (top0)

theorem affine_alpha_complete002 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known002 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches002 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart0 := separated (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known002])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known002])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known002])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known002])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n002_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart0).1 (apart6).2.2.1 (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known003 a)), by simp [affine_alpha_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n002_o1 a jx jy (ha) (apart7).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n002_o2 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known004 a)), by simp [affine_alpha_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n002_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart9).1 (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n002_o4 a jx jy (ha) (apart9).2.1 (apart7).2.2.1 (apart6).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n002_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known005 a)), by simp [affine_alpha_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n002_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart6).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n002_o7 a jx jy (apart9).2.2.2 (apart0).1 (apart7).2.2.1 (apart9).2.2.1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative003 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known003 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall0 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall2 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall3 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall4 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall5 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall6 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall7 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall8 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover9_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall9 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(5 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall10 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall11 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_003 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known003 a) ((2 : Int)+(1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n003_wall12 a ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf003 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known003 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known003 a) .gamma (2 : Int) (1 : Int) (affine_alpha_nonnegative003 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_003 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(5 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_003 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n003_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) ((by simpa only [KnownContains, affine_alpha_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx)
    · intro extra
      have mem := (mem_extraCells .gamma (x-(2 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((2 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_003 a ha
      · have ex : x=((2 : Int)+(1 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_003 a ha

theorem affine_alpha_nonnegative004 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known004 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall0 a ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall2 a ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall6 a ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall7 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover8_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall8 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover9_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall9 a (ha) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover10_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(5 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall10 a ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_004 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known004 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n004_wall11 a ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf004 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known004 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known004 a) .beta (2 : Int) (1 : Int) (affine_alpha_nonnegative004 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_004 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(5 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_004 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n004_dirty a x y (hx) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) ((by simpa only [KnownContains, affine_alpha_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .beta (x-(2 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((2 : Int)+(0 : Int)) := by omega
      have ey : y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover11_004 a ha

theorem affine_alpha_nonnegative005 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known005 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known005, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty005 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known005 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n005_empty a ((by simpa only [KnownContains, affine_alpha_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window005 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known005 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative005 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known005])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n005_height a h (top2) ((by omega))

theorem affine_alpha_complete005 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known005 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches005 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known005])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known005])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known019 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known010 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n005_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.2 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known011 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o4 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known006 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known020 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o6 a jx jy (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known009 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n005_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known018 a)), by simp [affine_alpha_branches005], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative006 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known006 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known006, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty006 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known006 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n006_empty a ((by simpa only [KnownContains, affine_alpha_known006, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window006 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known006 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative006 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known006])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n006_height a h (top1) ((by omega))

theorem affine_alpha_complete006 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known006 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches006 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known006])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known006])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known006])
  have apart11 := separated (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known006])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n006_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known008 a)), by simp [affine_alpha_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o2 a jx jy (apart8).2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o4 a jx jy (apart11).2.1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n006_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known007 a)), by simp [affine_alpha_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n006_o7 a jx jy (apart11).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1)

theorem affine_alpha_nonnegative007 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known007 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known007, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty007 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known007 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n007_empty a ((by simpa only [KnownContains, affine_alpha_known007, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window007 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known007 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative007 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known007])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n007_height a h (top1) ((by omega))

theorem affine_alpha_complete007 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known007 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches007 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known007])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known007])
  have apart12 := separated (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known007])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o0 a jx jy (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o1 a jx jy (apart10).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o2 a jx jy (ha) (apart10).2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o4 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o5 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o6 a jx jy (ha) (apart10).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n007_o7 a jx jy (apart12).2.2.1 (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)

theorem affine_alpha_nonnegative008 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known008 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known008, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty008 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known008 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n008_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known008, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window008 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known008 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative008 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known008])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n008_height a h (top1) ((by omega))

theorem affine_alpha_complete008 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known008 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches008 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known008])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known008])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known008])
  have apart12 := separated (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known008])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o0 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o1 a jx jy (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o2 a jx jy (apart10).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o5 a jx jy (apart8).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n008_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart10).2.1)

theorem affine_alpha_nonnegative009 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known009 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known009, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty009 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known009 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n009_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known009, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window009 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known009 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative009 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known009])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n009_height a h ((by omega)) (top1)

theorem affine_alpha_complete009 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known009 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches009 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known009])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known009])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known009])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known009])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o1 a jx jy (ha) (apart11).2.2.2 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o4 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o5 a jx jy (apart10).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o6 a jx jy (apart11).2.2.1 (apart7).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n009_o7 a jx jy (ha) (apart10).2.1 (apart11).2.1 (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative010 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known010 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known010, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty010 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known010 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n010_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known010, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window010 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known010 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative010 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known010])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n010_height a h ((by omega)) (top1)

theorem affine_alpha_complete010 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known010 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches010 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known010])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known010])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known010])
  have apart11 := separated (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known010])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o0 a jx jy (apart9).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o2 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o4 a jx jy (apart11).2.1 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o6 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n010_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (apart11).2.1 (apart10).2.1 (ha))

theorem affine_alpha_nonnegative011 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known011 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known011, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty011 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known011 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n011_empty a ((by simpa only [KnownContains, affine_alpha_known011, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window011 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known011 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative011 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known011])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n011_height a h ((by omega)) (top3)

theorem affine_alpha_complete011 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known011 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches011 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known011])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known011])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known011])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known011])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o0 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n011_o1 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known015 a)), by simp [affine_alpha_branches011], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n011_o4 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known012 a)), by simp [affine_alpha_branches011], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o5 a jx jy (apart3).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o6 a jx jy (apart9).2.2.2 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n011_o7 a jx jy (apart11).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)

theorem affine_alpha_nonnegative012 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known012 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known012, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty012 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known012 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n012_empty a ((by simpa only [KnownContains, affine_alpha_known012, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window012 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known012 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative012 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known012])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n012_height a h ((by omega)) (top1)

theorem affine_alpha_complete012 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known012 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches012 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known012])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known012])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known012])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o0 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n012_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known014 a)), by simp [affine_alpha_branches012], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o2 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o3 a jx jy (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o4 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o5 a jx jy (apart10).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n012_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known013 a)), by simp [affine_alpha_branches012], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n012_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart11).2.1 (ha))

theorem affine_alpha_nonnegative013 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known013 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known013, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty013 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known013 a) (5 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n013_empty a ((by simpa only [KnownContains, affine_alpha_known013, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window013 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known013 a)) B) : QueryWindow h (5 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative013 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known013])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n013_height a h (top1) ((by omega))

theorem affine_alpha_complete013 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (5 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known013 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches013 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known013])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known013])
  have apart13 := separated (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known013])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o0 a jx jy (apart10).2.1 (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart10).2.2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o3 a jx jy (apart10).2.2.1 (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o4 a jx jy (ha) (apart13).2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o5 a jx jy (apart10).2.1 (apart10).2.2.1 (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o6 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n013_o7 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)

theorem affine_alpha_nonnegative014 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known014 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known014, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty014 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known014 a) (5 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n014_empty a ((by simpa only [KnownContains, affine_alpha_known014, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window014 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known014 a)) B) : QueryWindow h (5 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative014 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known014])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n014_height a h (top1) ((by omega))

theorem affine_alpha_complete014 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (5 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known014 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches014 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known014])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known014])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known014])
  have apart13 := separated (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known014])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1 (apart10).2.2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o3 a jx jy (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o4 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o5 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o6 a jx jy (apart10).2.2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n014_o7 a jx jy (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)

theorem affine_alpha_nonnegative015 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known015 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known015, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty015 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known015 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n015_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known015, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window015 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known015 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative015 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known015])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n015_height a h ((by omega)) (top1)

theorem affine_alpha_complete015 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known015 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches015 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known015])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known015])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known015])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known015])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o0 a jx jy (apart10).2.1 (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n015_o1 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known017 a)), by simp [affine_alpha_branches015], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o2 a jx jy (ha) (apart8).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart11).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o4 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o5 a jx jy (apart9).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n015_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known016 a)), by simp [affine_alpha_branches015], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n015_o7 a jx jy (apart11).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative016 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known016 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known016, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty016 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known016 a) (5 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n016_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known016, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window016 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known016 a)) B) : QueryWindow h (5 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative016 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known016])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n016_height a h ((by omega)) (top1)

theorem affine_alpha_complete016 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (5 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known016 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches016 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known016])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known016])
  have apart13 := separated (Cross.mk (4 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known016])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o0 a jx jy (apart10).2.1 (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o1 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o2 a jx jy (apart10).2.1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o3 a jx jy (apart10).2.2.1 (ha) (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o4 a jx jy (apart13).2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o5 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n016_o7 a jx jy (apart10).2.1 (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (ha))

theorem affine_alpha_nonnegative017 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known017 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known017, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty017 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known017 a) (5 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n017_empty a ((by simpa only [KnownContains, affine_alpha_known017, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window017 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known017 a)) B) : QueryWindow h (5 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative017 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known017])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n017_height a h (top1) ((by omega))

theorem affine_alpha_complete017 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (5 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known017 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches017 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known017])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known017])
  have apart13 := separated (Cross.mk (4 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known017])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o1 a jx jy (apart13).1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o3 a jx jy (apart13).2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o4 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o5 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o6 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n017_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart13).2.1 (ha))

theorem affine_alpha_nonnegative018 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known018 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall0 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover1_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall1 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover2_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall3 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall4 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall5 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall6 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_018 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known018 a) ((2 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n018_wall7 a ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf018 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known018 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known018 a) .alpha (2 : Int) (3 : Int) (affine_alpha_nonnegative018 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_018 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_018 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n018_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(2 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative019 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known019 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known019, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty019 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known019 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n019_empty a ((by simpa only [KnownContains, affine_alpha_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window019 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known019 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative019 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known019])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n019_height a h ((by omega)) (top1)

theorem affine_alpha_complete019 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known019 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches019 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known019])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known019])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known019])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known019])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o0 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o1 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1 (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o2 a jx jy (apart10).2.2.1 (apart11).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o3 a jx jy (ha) (apart10).2.2.1 (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o4 a jx jy (apart11).2.2.1 (apart10).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o5 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o6 a jx jy (ha) (apart9).1 (apart7).2.2.1 (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n019_o7 a jx jy (apart10).2.1 (ha) (apart11).2.2.2 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative020 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known020 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known020, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty020 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known020 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n020_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known020, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window020 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known020 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative020 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known020])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n020_height a h ((by omega)) (top1)

theorem affine_alpha_complete020 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known020 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches020 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known020])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known020])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known020])
  have apart11 := separated (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known020])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o0 a jx jy (apart10).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o1 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o3 a jx jy (apart10).2.2.1 (apart11).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o4 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o6 a jx jy (ha) (apart7).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n020_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (apart11).2.1 (apart10).2.1 (ha))

theorem affine_alpha_nonnegative021 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known021 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known021, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty021 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known021 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n021_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known021, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window021 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known021 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative021 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known021])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n021_height a h ((by omega)) (top0)

theorem affine_alpha_complete021 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known021 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches021 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known021])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known021])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known021])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n021_o0 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known022 a)), by simp [affine_alpha_branches021], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n021_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (apart9).2.2.2 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n021_o2 a jx jy (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known023 a)), by simp [affine_alpha_branches021], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n021_o3 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n021_o4 a jx jy (apart7).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n021_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart7).1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known026 a)), by simp [affine_alpha_branches021], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n021_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n021_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart9).2.1 (ha))

theorem affine_alpha_nonnegative022 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known022 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known022, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty022 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known022 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n022_empty a ((by simpa only [KnownContains, affine_alpha_known022, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window022 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known022 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative022 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known022])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n022_height a h (top1) ((by omega))

theorem affine_alpha_complete022 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known022 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches022 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known022])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known022])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known022])
  have apart10 := separated (Cross.mk (3 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known022])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o0 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o1 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o2 a jx jy (apart10).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o5 a jx jy (apart1).1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n022_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart9).2.1)

theorem affine_alpha_nonnegative023 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known023 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known023, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty023 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known023 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n023_empty a ((by simpa only [KnownContains, affine_alpha_known023, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window023 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known023 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative023 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known023])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n023_height a h (top1) ((by omega))

theorem affine_alpha_complete023 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known023 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches023 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known023])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known023])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known023])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known023])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n023_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known024 a)), by simp [affine_alpha_branches023], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o1 a jx jy (apart9).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o3 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n023_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known025 a)), by simp [affine_alpha_branches023], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n023_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1 (ha))

theorem affine_alpha_nonnegative024 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known024 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known024, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty024 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known024 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n024_empty a ((by simpa only [KnownContains, affine_alpha_known024, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window024 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known024 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative024 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known024])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n024_height a h ((by omega)) (top2)

theorem affine_alpha_complete024 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known024 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches024 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known024])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known024])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known024])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known024])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known024])
  have apart11 := separated (Cross.mk (3 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known024])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1 (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o1 a jx jy (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o5 a jx jy (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o6 a jx jy (apart6).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n024_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2 (apart9).2.1 (ha))

theorem affine_alpha_nonnegative025 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known025 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known025, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty025 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known025 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n025_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known025, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window025 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known025 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative025 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known025])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n025_height a h ((by omega)) (top2)

theorem affine_alpha_complete025 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known025 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches025 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known025])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known025])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known025])
  have apart11 := separated (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known025])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o1 a jx jy (ha) (apart9).2.2.1 (apart11).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o2 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o3 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o4 a jx jy (ha) (apart10).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o5 a jx jy (ha) (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n025_o7 a jx jy (apart9).2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative026 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known026 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known026, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty026 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known026 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n026_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known026, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window026 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known026 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative026 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known026])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n026_height a h ((by omega)) (top1)

theorem affine_alpha_complete026 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known026 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches026 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known026])
  have apart9 := separated (Cross.mk (1 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known026])
  have apart10 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known026])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o0 a jx jy (apart10).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o1 a jx jy (apart9).2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o2 a jx jy (ha) (apart10).2.2.2 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o4 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o5 a jx jy (ha) (apart9).2.1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o6 a jx jy (apart10).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n026_o7 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))

theorem affine_alpha_nonnegative027 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known027 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known027, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty027 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known027 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n027_empty a ((by simpa only [KnownContains, affine_alpha_known027, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window027 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known027 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative027 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known027])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n027_height a h ((by omega)) (top1)

theorem affine_alpha_complete027 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known027 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches027 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known027])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known027])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known027])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known027])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o0 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n027_o1 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known029 a)), by simp [affine_alpha_branches027], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o2 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (apart1).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o3 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o4 a jx jy (ha) (apart9).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o5 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n027_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.2.1 (apart8).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known028 a)), by simp [affine_alpha_branches027], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n027_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.2 (apart8).2.1)

theorem affine_alpha_nonnegative028 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known028 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall0 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall1 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover2_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall3 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall6 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall7 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover8_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall8 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover9_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall9 a (ha) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover10_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(-1 : Int)) ((1 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall10 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall11 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_028 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known028 a) ((2 : Int)+(0 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n028_wall12 a ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf028 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known028 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known028 a) .gammaTranspose (2 : Int) (1 : Int) (affine_alpha_nonnegative028 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_028 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_028 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n028_dirty a x y (hx) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) ((by simpa only [KnownContains, affine_alpha_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(2 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((2 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_028 a ha
      · have ex : x=((2 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_028 a ha

theorem affine_alpha_nonnegative029 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known029 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known029, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty029 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known029 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n029_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window029 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known029 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative029 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known029])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n029_height a h (top2) ((by omega))

theorem affine_alpha_complete029 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known029 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches029 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known029])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known029])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n029_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known038 a)), by simp [affine_alpha_branches029], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n029_o1 a jx jy (apart9).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.2 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n029_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known040 a)), by simp [affine_alpha_branches029], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n029_o3 a jx jy (apart10).2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known030 a)), by simp [affine_alpha_branches029], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n029_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n029_o5 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known041 a)), by simp [affine_alpha_branches029], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n029_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n029_o7 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known031 a)), by simp [affine_alpha_branches029], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative030 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known030 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall0 a (ha) ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall1 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall3 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall4 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall5 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall6 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_030 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known030 a) ((4 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n030_wall7 a ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf030 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known030 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known030 a) .alpha (4 : Int) (1 : Int) (affine_alpha_nonnegative030 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (4 : Int)+x=((4 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_030 a ha
    · have ex : (4 : Int)+x=((4 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_030 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n030_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(4 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative031 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known031 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known031, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty031 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known031 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n031_empty a ((by simpa only [KnownContains, affine_alpha_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window031 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known031 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative031 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known031])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n031_height a h (top3) ((by omega))

theorem affine_alpha_complete031 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known031 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches031 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known031])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known031])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known031])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known031])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n031_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known032 a)), by simp [affine_alpha_branches031], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o3 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart11).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n031_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known035 a)), by simp [affine_alpha_branches031], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n031_o7 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2 (ha))

theorem affine_alpha_nonnegative032 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known032 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known032, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty032 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known032 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n032_empty a ((by simpa only [KnownContains, affine_alpha_known032, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window032 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known032 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative032 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known032])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n032_height a h ((by omega)) (top1)

theorem affine_alpha_complete032 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known032 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches032 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known032])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known032])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o0 a jx jy (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o1 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n032_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known033 a)), by simp [affine_alpha_branches032], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o3 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o4 a jx jy (apart9).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n032_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart11).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known034 a)), by simp [affine_alpha_branches032], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o6 a jx jy (ha) (apart9).2.2.1 (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n032_o7 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1)

theorem affine_alpha_nonnegative033 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known033 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known033, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty033 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known033 a) (2 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n033_empty a ((by simpa only [KnownContains, affine_alpha_known033, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window033 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known033 a)) B) : QueryWindow h (2 : Int) (4 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative033 a ha) (t := (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known033])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n033_height a h (top12) ((by omega))

theorem affine_alpha_complete033 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known033 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches033 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known033])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known033])
  have apart12 := separated (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known033])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o0 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o1 a jx jy (apart12).2.2.1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o2 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart12).2.1 (apart9).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o4 a jx jy (apart10).2.2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o5 a jx jy (apart10).2.2.2 (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n033_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (apart10).2.1)

theorem affine_alpha_nonnegative034 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known034 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known034, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty034 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known034 a) (2 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n034_empty a ((by simpa only [KnownContains, affine_alpha_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window034 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known034 a)) B) : QueryWindow h (2 : Int) (4 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative034 a ha) (t := (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known034])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n034_height a h (top12) ((by omega))

theorem affine_alpha_complete034 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known034 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches034 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known034])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known034])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known034])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known034])
  have apart12 := separated (Cross.mk (3 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known034])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o0 a jx jy (apart10).2.1 (ha) (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o1 a jx jy (apart10).2.2.2 (apart9).2.2.2 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o2 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o3 a jx jy (apart9).2.2.2 (apart10).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o4 a jx jy (apart10).2.1 (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o5 a jx jy (apart12).2.1 (apart10).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o6 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n034_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart12).2.1)

theorem affine_alpha_nonnegative035 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known035 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known035, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty035 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known035 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n035_empty a ((by simpa only [KnownContains, affine_alpha_known035, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window035 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known035 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative035 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known035])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n035_height a h (top1) ((by omega))

theorem affine_alpha_complete035 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known035 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches035 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known035])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known035])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha) (apart9).2.2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o1 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n035_o2 a jx jy (apart11).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known036 a)), by simp [affine_alpha_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o3 a jx jy (apart11).2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o4 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n035_o5 a jx jy (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((4 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known037 a)), by simp [affine_alpha_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o6 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n035_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart11).2.1)

theorem affine_alpha_nonnegative036 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known036 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known036, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty036 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known036 a) (2 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n036_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known036, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window036 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known036 a)) B) : QueryWindow h (2 : Int) (4 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative036 a ha) (t := (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known036])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n036_height a h (top12) ((by omega))

theorem affine_alpha_complete036 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known036 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches036 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known036])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known036])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known036])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known036])
  have apart12 := separated (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known036])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o0 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o1 a jx jy (apart10).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o3 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o4 a jx jy (ha) (apart10).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o5 a jx jy (apart12).2.2.2 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o6 a jx jy (ha) (apart6).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n036_o7 a jx jy (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)

theorem affine_alpha_nonnegative037 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known037 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known037, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty037 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known037 a) (2 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n037_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known037, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window037 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known037 a)) B) : QueryWindow h (2 : Int) (4 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative037 a ha) (t := (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known037])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n037_height a h ((by omega)) (top12)

theorem affine_alpha_complete037 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known037 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches037 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known037])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known037])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known037])
  have apart12 := separated (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known037])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o2 a jx jy (ha) (apart10).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o3 a jx jy (apart10).2.1 (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n037_o7 a jx jy (apart12).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_alpha_nonnegative038 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known038 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known038, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty038 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known038 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n038_empty a ((by simpa only [KnownContains, affine_alpha_known038, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window038 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known038 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative038 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known038])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n038_height a h (top1) ((by omega))

theorem affine_alpha_complete038 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known038 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches038 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known038])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known038])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known038])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known038])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o0 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o1 a jx jy (apart9).2.1 (apart11).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n038_o2 a jx jy (ha) (apart11).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known039 a)), by simp [affine_alpha_branches038], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o4 a jx jy (ha) (apart11).2.2.2 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o6 a jx jy (apart11).2.2.2 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n038_o7 a jx jy (apart9).2.2.1 (ha) (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)

theorem affine_alpha_nonnegative039 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known039 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known039, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty039 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known039 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n039_empty a ((by simpa only [KnownContains, affine_alpha_known039, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window039 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known039 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative039 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known039])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n039_height a h (top3) ((by omega))

theorem affine_alpha_complete039 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known039 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches039 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known039])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known039])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known039])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known039])
  have apart11 := separated (Cross.mk (3 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known039])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o0 a jx jy (apart11).2.1 (apart3).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o1 a jx jy (ha) (apart9).2.2.2 (apart10).2.2.1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o2 a jx jy (apart11).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (apart9).2.2.2 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart11).2.1 (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o5 a jx jy (apart11).2.1 (ha) (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o6 a jx jy (apart10).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n039_o7 a jx jy (apart10).2.1 (apart11).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative040 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known040 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known040, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty040 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known040 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n040_empty a ((by simpa only [KnownContains, affine_alpha_known040, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window040 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known040 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative040 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known040])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n040_height a h (top1) ((by omega))

theorem affine_alpha_complete040 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known040 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches040 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known040])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known040])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known040])
  have apart11 := separated (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known040])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o0 a jx jy (apart9).2.1 (ha) (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o1 a jx jy (ha) (apart11).2.2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o2 a jx jy (apart8).2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o4 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o5 a jx jy (apart11).2.2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o6 a jx jy (apart11).1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n040_o7 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)

theorem affine_alpha_nonnegative041 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known041 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known041, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty041 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known041 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n041_empty a ((by simpa only [KnownContains, affine_alpha_known041, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window041 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known041 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative041 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known041])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n041_height a h ((by omega)) (top1)

theorem affine_alpha_complete041 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known041 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches041 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known041])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known041])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known041])
  have apart11 := separated (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known041])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o0 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o1 a jx jy (apart7).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n041_o2 a jx jy (apart8).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known042 a)), by simp [affine_alpha_branches041], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart11).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o4 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o5 a jx jy (apart9).2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o6 a jx jy (apart11).2.2.1 (apart7).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n041_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart9).2.2.1 (apart11).2.1)

theorem affine_alpha_nonnegative042 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known042 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known042, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty042 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known042 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n042_empty a ((by simpa only [KnownContains, affine_alpha_known042, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window042 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known042 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative042 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known042])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n042_height a h (top3) ((by omega))

theorem affine_alpha_complete042 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known042 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches042 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known042])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known042])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known042])
  have apart11 := separated (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known042])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o0 a jx jy (ha) (apart11).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o1 a jx jy (apart10).2.2.1 (ha) (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o2 a jx jy (apart8).2.1 (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o4 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o5 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o6 a jx jy (apart10).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n042_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart11).2.1)

theorem affine_alpha_nonnegative043 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known043 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall0 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall1 a ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover2_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall6 a ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_043 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known043 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n043_wall7 a (ha) ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf043 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known043 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known043 a) .alpha (1 : Int) (1 : Int) (affine_alpha_nonnegative043 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_043 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_043 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n043_dirty a x y ((by simpa only [KnownContains, affine_alpha_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative044 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known044 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known044, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty044 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known044 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n044_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known044, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window044 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known044 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative044 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known044])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n044_height a h ((by omega)) (top1)

theorem affine_alpha_complete044 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known044 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches044 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known044])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known044])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known044])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o0 a jx jy (ha) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n044_o1 a jx jy (apart9).2.2.1 (apart8).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known046 a)), by simp [affine_alpha_branches044], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o2 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o4 a jx jy (apart8).2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o5 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n044_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known045 a)), by simp [affine_alpha_branches044], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n044_o7 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))

theorem affine_alpha_nonnegative045 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known045 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known045, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty045 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known045 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n045_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known045, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window045 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known045 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative045 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known045])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n045_height a h ((by omega)) (top1)

theorem affine_alpha_complete045 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known045 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches045 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known045])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known045])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known045])
  have apart10 := separated (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known045])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o0 a jx jy (apart9).2.1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o1 a jx jy (ha) (apart6).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o2 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o3 a jx jy (apart10).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o4 a jx jy (ha) (apart10).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o5 a jx jy (apart9).2.2.1 (apart10).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o6 a jx jy (apart10).2.2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n045_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart1).1 (ha) (apart10).2.2.1)

theorem affine_alpha_nonnegative046 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known046 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known046, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty046 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known046 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n046_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known046, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window046 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known046 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative046 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known046])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n046_height a h ((by omega)) (top1)

theorem affine_alpha_complete046 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known046 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches046 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known046])
  have apart8 := separated (Cross.mk (0 : Int) a (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known046])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known046])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known046])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o0 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (apart10).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o2 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o3 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o6 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n046_o7 a jx jy (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative047 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known047 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known047, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty047 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known047 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n047_empty a ((by simpa only [KnownContains, affine_alpha_known047, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window047 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known047 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative047 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known047])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n047_height a h ((by omega)) (top0)

theorem affine_alpha_complete047 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known047 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches047 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known047])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known047])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known047])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n047_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known048 a)), by simp [affine_alpha_branches047], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n047_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n047_o2 a jx jy (apart8).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known049 a)), by simp [affine_alpha_branches047], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n047_o3 a jx jy (ha) (apart6).2.2.1 (apart5).2.2.1 (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n047_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart6).2.2.1 (apart5).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n047_o5 a jx jy (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known050 a)), by simp [affine_alpha_branches047], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n047_o6 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart5).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n047_o7 a jx jy (apart8).2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (apart5).2.2.1)

theorem affine_alpha_nonnegative048 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known048 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall0 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall2 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall6 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall7 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall8 a (ha) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover9_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall9 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(5 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall10 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall11 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_048 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known048 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n048_wall12 a ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf048 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known048 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known048 a) .gamma (1 : Int) (1 : Int) (affine_alpha_nonnegative048 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_048 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n048_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hx) ((by simpa only [KnownContains, affine_alpha_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .gamma (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_048 a ha
      · have ex : x=((1 : Int)+(1 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_048 a ha

theorem affine_alpha_nonnegative049 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known049 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall0 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall4 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall6 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall7 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall8 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover9_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall9 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(5 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall10 a (ha) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover11_049 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known049 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n049_wall11 a ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf049 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known049 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known049 a) .beta (1 : Int) (1 : Int) (affine_alpha_nonnegative049 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_049 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_049 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n049_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) ((by simpa only [KnownContains, affine_alpha_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover11_049 a ha

theorem affine_alpha_nonnegative050 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known050 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known050, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty050 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known050 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n050_empty a ((by simpa only [KnownContains, affine_alpha_known050, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window050 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known050 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative050 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known050])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n050_height a h (top2) ((by omega))

theorem affine_alpha_complete050 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known050 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches050 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known050])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known050])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o0 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known064 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o1 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known055 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n050_o2 a jx jy (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart8).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known056 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known051 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known065 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known054 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n050_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known063 a)), by simp [affine_alpha_branches050], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative051 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known051 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known051, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty051 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known051 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n051_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known051, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window051 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known051 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative051 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known051])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n051_height a h (top1) ((by omega))

theorem affine_alpha_complete051 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known051 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches051 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known051])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known051])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known051])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known051])
  have apart10 := separated (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known051])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o0 a jx jy (apart9).2.1 (ha) (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n051_o1 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known053 a)), by simp [affine_alpha_branches051], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o3 a jx jy (apart10).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart7).2.2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n051_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known052 a)), by simp [affine_alpha_branches051], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n051_o7 a jx jy (apart8).1 (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative052 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known052 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known052, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty052 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known052 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n052_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window052 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known052 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative052 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known052])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n052_height a h ((by omega)) (top1)

theorem affine_alpha_complete052 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known052 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches052 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known052])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known052])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known052])
  have apart11 := separated (Cross.mk (2 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known052])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o0 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o1 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o3 a jx jy (ha) (apart9).2.2.1 (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o5 a jx jy (apart9).2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n052_o7 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).1 (apart11).2.2.1)

theorem affine_alpha_nonnegative053 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known053 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known053, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty053 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known053 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n053_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known053, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window053 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known053 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative053 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known053])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n053_height a h ((by omega)) (top1)

theorem affine_alpha_complete053 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known053 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches053 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known053])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known053])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known053])
  have apart11 := separated (Cross.mk (2 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known053])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o0 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o3 a jx jy (apart11).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o5 a jx jy (apart9).2.1 (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n053_o7 a jx jy (ha) (apart9).2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative054 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known054 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known054, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty054 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known054 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n054_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known054, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window054 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known054 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative054 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known054])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n054_height a h (top1) ((by omega))

theorem affine_alpha_complete054 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known054 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches054 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known054])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known054])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known054])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known054])
  have apart10 := separated (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known054])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o1 a jx jy (ha) (apart10).2.2.1 (apart6).2.2.1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o2 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o4 a jx jy (apart7).2.2.1 (apart10).2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n054_o7 a jx jy (ha) (apart8).1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)

theorem affine_alpha_nonnegative055 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known055 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known055, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty055 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known055 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n055_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known055, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window055 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known055 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative055 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known055])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n055_height a h ((by omega)) (top1)

theorem affine_alpha_complete055 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known055 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches055 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart0 := separated (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known055])
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known055])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known055])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known055])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known055])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known055])
  have apart10 := separated (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known055])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o0 a jx jy (ha) (apart8).1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o2 a jx jy (apart9).2.2.1 (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o3 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o4 a jx jy (apart7).2.2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o5 a jx jy (ha) (apart9).2.1 (apart0).1 (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o6 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n055_o7 a jx jy (ha) (apart10).2.1 (apart9).2.1 (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative056 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known056 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known056, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty056 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known056 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n056_empty a ((by simpa only [KnownContains, affine_alpha_known056, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window056 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known056 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative056 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known056])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n056_height a h ((by omega)) (top3)

theorem affine_alpha_complete056 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known056 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches056 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known056])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known056])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known056])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o0 a jx jy (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n056_o1 a jx jy (apart8).2.2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known060 a)), by simp [affine_alpha_branches056], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o2 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart10).2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n056_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known057 a)), by simp [affine_alpha_branches056], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o6 a jx jy (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n056_o7 a jx jy (apart3).1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative057 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known057 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known057, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty057 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known057 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n057_empty a ((by simpa only [KnownContains, affine_alpha_known057, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window057 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known057 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative057 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known057])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n057_height a h ((by omega)) (top1)

theorem affine_alpha_complete057 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known057 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches057 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known057])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known057])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known057])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o0 a jx jy (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n057_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known059 a)), by simp [affine_alpha_branches057], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o2 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o3 a jx jy (ha) (apart10).1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o4 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o5 a jx jy (apart9).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n057_o6 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known058 a)), by simp [affine_alpha_branches057], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n057_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)

theorem affine_alpha_nonnegative058 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known058 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known058, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty058 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known058 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n058_empty a ((by simpa only [KnownContains, affine_alpha_known058, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window058 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known058 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative058 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known058])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n058_height a h ((by omega)) (top1)

theorem affine_alpha_complete058 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known058 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches058 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known058])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known058])
  have apart12 := separated (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known058])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o1 a jx jy (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart9).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart12).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o5 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o6 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n058_o7 a jx jy (apart12).2.2.1 (apart9).2.1 (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_alpha_nonnegative059 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known059 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known059, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty059 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known059 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n059_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known059, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window059 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known059 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative059 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known059])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n059_height a h (top1) ((by omega))

theorem affine_alpha_complete059 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known059 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches059 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known059])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known059])
  have apart12 := separated (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known059])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o0 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o1 a jx jy (apart12).1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o6 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n059_o7 a jx jy (apart12).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative060 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known060 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known060, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty060 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known060 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n060_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known060, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window060 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known060 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative060 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known060])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n060_height a h ((by omega)) (top1)

theorem affine_alpha_complete060 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known060 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches060 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known060])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known060])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known060])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o0 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n060_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known062 a)), by simp [affine_alpha_branches060], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o2 a jx jy (ha) (apart9).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o3 a jx jy (apart10).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o5 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n060_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known061 a)), by simp [affine_alpha_branches060], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n060_o7 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)

theorem affine_alpha_nonnegative061 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known061 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known061, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty061 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known061 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n061_empty a ((by simpa only [KnownContains, affine_alpha_known061, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window061 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known061 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative061 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known061])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n061_height a h ((by omega)) (top1)

theorem affine_alpha_complete061 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known061 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches061 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known061])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known061])
  have apart12 := separated (Cross.mk (3 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known061])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o0 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o2 a jx jy (apart9).2.1 (apart12).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o3 a jx jy (apart12).1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o5 a jx jy (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o6 a jx jy (ha) (apart12).1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n061_o7 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart8).1 (ha))

theorem affine_alpha_nonnegative062 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known062 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known062, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty062 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known062 a) (4 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n062_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known062, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window062 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known062 a)) B) : QueryWindow h (4 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative062 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known062])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n062_height a h ((by omega)) (top1)

theorem affine_alpha_complete062 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known062 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches062 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known062])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known062])
  have apart12 := separated (Cross.mk (3 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known062])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o0 a jx jy (apart12).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o1 a jx jy (apart9).2.2.1 (apart12).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o2 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o3 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o6 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n062_o7 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)

theorem affine_alpha_nonnegative063 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known063 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall0 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover1_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall3 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall4 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall5 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall6 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_063 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known063 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n063_wall7 a ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf063 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known063 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known063 a) .alpha (1 : Int) (3 : Int) (affine_alpha_nonnegative063 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_063 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_063 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n063_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative064 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known064 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known064, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty064 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known064 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n064_empty a ((by simpa only [KnownContains, affine_alpha_known064, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window064 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known064 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative064 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known064])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n064_height a h (top1) ((by omega))

theorem affine_alpha_complete064 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known064 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches064 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known064])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known064])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known064])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known064])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o1 a jx jy (apart8).1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.2 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o3 a jx jy (apart10).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o4 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o5 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart8).1 (apart10).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n064_o7 a jx jy (apart9).2.1 (ha) (apart8).1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative065 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known065 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known065, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty065 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known065 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n065_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known065, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window065 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known065 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative065 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known065])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n065_height a h ((by omega)) (top1)

theorem affine_alpha_complete065 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known065 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches065 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known065])
  have apart8 := separated (Cross.mk (0 : Int) (1 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known065])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known065])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known065])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o1 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o2 a jx jy (ha) (apart8).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart10).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o4 a jx jy (apart10).2.2.1 (apart9).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n065_o7 a jx jy (apart8).1 (apart10).1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative066 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known066 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known066, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty066 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known066 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n066_empty a ((by simpa only [KnownContains, affine_alpha_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window066 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known066 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_alpha_nonnegative066 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known066])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n066_height a h ((by omega)) (top0)

theorem affine_alpha_complete066 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known066 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches066 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known066])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known066])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known066])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n066_o0 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart5).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known067 a)), by simp [affine_alpha_branches066], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n066_o1 a jx jy (apart5).2.2.1 (apart8).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n066_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known068 a)), by simp [affine_alpha_branches066], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n066_o3 a jx jy (apart5).2.2.1 (apart8).2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n066_o4 a jx jy (apart8).2.1 (apart6).2.2.1 (ha) (apart5).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n066_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart5).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known071 a)), by simp [affine_alpha_branches066], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n066_o6 a jx jy (apart5).2.2.1 (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n066_o7 a jx jy (apart6).2.2.1 (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative067 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known067 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known067, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty067 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known067 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n067_empty a ((by simpa only [KnownContains, affine_alpha_known067, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window067 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known067 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative067 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known067])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n067_height a h ((by omega)) (top1)

theorem affine_alpha_complete067 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known067 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches067 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known067])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known067])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known067])
  have apart9 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known067])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o0 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o1 a jx jy (apart8).2.2.1 (ha) (apart9).2.2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o3 a jx jy (ha) (apart5).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o5 a jx jy (apart9).2.1 (ha) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o6 a jx jy (apart8).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n067_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart8).2.1 (ha))

theorem affine_alpha_nonnegative068 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known068 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known068, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty068 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known068 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n068_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known068, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window068 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known068 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative068 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known068])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n068_height a h ((by omega)) (top1)

theorem affine_alpha_complete068 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known068 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches068 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known068])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known068])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known068])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known068])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n068_o0 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known069 a)), by simp [affine_alpha_branches068], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart9).2.2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o2 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o3 a jx jy (apart9).2.2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n068_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known070 a)), by simp [affine_alpha_branches068], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o6 a jx jy (apart5).2.2.1 (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n068_o7 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)

theorem affine_alpha_nonnegative069 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known069 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known069, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty069 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known069 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n069_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known069, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window069 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known069 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative069 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known069])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n069_height a h ((by omega)) (top2)

theorem affine_alpha_complete069 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known069 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches069 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known069])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known069])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known069])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known069])
  have apart10 := separated (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known069])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o0 a jx jy (apart2).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (ha) (apart8).2.2.2 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o2 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o4 a jx jy (apart9).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o5 a jx jy (ha) (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o6 a jx jy (ha) (apart8).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n069_o7 a jx jy (ha) (apart10).2.2.2 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative070 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known070 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known070, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty070 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known070 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n070_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known070, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window070 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known070 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative070 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known070])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n070_height a h (top2) ((by omega))

theorem affine_alpha_complete070 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known070 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches070 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known070])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known070])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known070])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known070])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o0 a jx jy (apart2).1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 (apart5).2.2.1 (apart8).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o2 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o3 a jx jy (apart10).2.2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o4 a jx jy (apart8).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o6 a jx jy (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n070_o7 a jx jy (apart10).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_alpha_nonnegative071 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known071 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known071, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty071 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known071 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n071_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known071, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window071 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known071 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative071 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known071])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n071_height a h (top1) ((by omega))

theorem affine_alpha_complete071 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known071 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches071 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known071])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known071])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known071])
  have apart8 := separated (Cross.mk (0 : Int) a (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known071])
  have apart9 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known071])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o0 a jx jy (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart8).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o4 a jx jy (apart6).2.2.1 (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o5 a jx jy (apart8).2.1 (ha) (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 (apart5).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n071_o7 a jx jy (ha) (apart8).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative072 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known072 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known072, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty072 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known072 a) (0 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n072_empty a ((by simpa only [KnownContains, affine_alpha_known072, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window072 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known072 a)) B) : QueryWindow h (0 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative072 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known072])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n072_height a h ((by omega)) (top1)

theorem affine_alpha_complete072 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known072 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches072 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart0 := separated (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known072])
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known072])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known072])
  have apart4 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known072])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known072])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n072_o0 a jx jy (apart8).2.2.2 (apart1).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart0).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n072_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart1).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known075 a)), by simp [affine_alpha_branches072], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n072_o2 a jx jy (apart8).2.1 (apart2).1 (apart1).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n072_o3 a jx jy (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart4).2.2.1 (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n072_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known073 a)), by simp [affine_alpha_branches072], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n072_o5 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n072_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (apart8).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known074 a)), by simp [affine_alpha_branches072], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n072_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 (apart1).1 (apart2).1 (ha))

theorem affine_alpha_nonnegative073 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known073 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall0 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover1_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall5 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall6 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall7 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall8 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover9_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall9 a (ha) ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover10_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(5 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall10 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_073 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known073 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n073_wall11 a ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf073 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known073 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known073 a) .beta (1 : Int) (1 : Int) (affine_alpha_nonnegative073 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_073 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_073 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n073_dirty a x y ((by simpa only [KnownContains, affine_alpha_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover11_073 a ha

theorem affine_alpha_nonnegative074 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known074 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall0 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(4 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall5 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall6 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall7 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover8_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall8 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover9_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall9 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall10 a (ha) ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover11_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall11 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_074 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known074 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n074_wall12 a ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf074 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known074 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known074 a) .gammaTranspose (1 : Int) (1 : Int) (affine_alpha_nonnegative074 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_074 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_074 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n074_dirty a x y ((by simpa only [KnownContains, affine_alpha_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_074 a ha
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((1 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_074 a ha

theorem affine_alpha_nonnegative075 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known075 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known075, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty075 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known075 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n075_empty a ((by simpa only [KnownContains, affine_alpha_known075, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window075 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known075 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative075 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known075])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n075_height a h ((by omega)) (top2)

theorem affine_alpha_complete075 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known075 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches075 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known075])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known075])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n075_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known084 a)), by simp [affine_alpha_branches075], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n075_o1 a jx jy (ha) (apart9).2.2.2 (apart8).2.2.2 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n075_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known086 a)), by simp [affine_alpha_branches075], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n075_o3 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.2 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known076 a)), by simp [affine_alpha_branches075], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n075_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n075_o5 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known087 a)), by simp [affine_alpha_branches075], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n075_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart8).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n075_o7 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known077 a)), by simp [affine_alpha_branches075], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative076 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known076 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall0 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover1_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall1 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall3 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall4 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall5 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall6 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_076 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known076 a) ((3 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n076_wall7 a ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf076 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known076 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known076 a) .alpha (3 : Int) (1 : Int) (affine_alpha_nonnegative076 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_076 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_076 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n076_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(3 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative077 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known077 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known077, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty077 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known077 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n077_empty a ((by simpa only [KnownContains, affine_alpha_known077, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window077 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known077 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative077 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known077])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n077_height a h ((by omega)) (top3)

theorem affine_alpha_complete077 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known077 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches077 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known077])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known077])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known077])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n077_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known078 a)), by simp [affine_alpha_branches077], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o4 a jx jy (ha) (apart9).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n077_o5 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known081 a)), by simp [affine_alpha_branches077], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n077_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.2 (apart9).2.1)

theorem affine_alpha_nonnegative078 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known078 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known078, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty078 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known078 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n078_empty a ((by simpa only [KnownContains, affine_alpha_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window078 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known078 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative078 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known078])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n078_height a h ((by omega)) (top1)

theorem affine_alpha_complete078 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known078 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches078 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known078])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known078])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known078])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o0 a jx jy (apart8).2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n078_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known079 a)), by simp [affine_alpha_branches078], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n078_o5 a jx jy (apart10).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known080 a)), by simp [affine_alpha_branches078], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o6 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n078_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart8).2.2.1)

theorem affine_alpha_nonnegative079 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known079 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known079, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty079 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known079 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n079_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window079 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known079 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative079 a ha) (t := (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known079])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n079_height a h ((by omega)) (top11)

theorem affine_alpha_complete079 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known079 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches079 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known079])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known079])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known079])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o1 a jx jy (apart9).2.2.1 (ha) (apart8).2.2.2 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o2 a jx jy (apart11).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 (ha) (apart11).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o4 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o6 a jx jy (apart8).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n079_o7 a jx jy (ha) (apart9).2.1 (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative080 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known080 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known080, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty080 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known080 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n080_empty a ((by simpa only [KnownContains, affine_alpha_known080, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window080 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known080 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative080 a ha) (t := (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known080])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n080_height a h (top11) ((by omega))

theorem affine_alpha_complete080 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known080 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches080 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known080])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known080])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known080])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o1 a jx jy (ha) (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o3 a jx jy (apart8).2.2.2 (ha) (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o4 a jx jy (apart9).2.1 (apart11).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o5 a jx jy (apart11).2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o6 a jx jy (ha) (apart9).2.2.1 (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n080_o7 a jx jy (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)

theorem affine_alpha_nonnegative081 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known081 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known081, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty081 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known081 a) (3 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n081_empty a ((by simpa only [KnownContains, affine_alpha_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window081 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known081 a)) B) : QueryWindow h (3 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative081 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known081])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n081_height a h (top1) ((by omega))

theorem affine_alpha_complete081 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known081 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches081 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known081])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known081])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known081])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o0 a jx jy (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o1 a jx jy (apart10).2.2.1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n081_o2 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known082 a)), by simp [affine_alpha_branches081], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n081_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart10).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known083 a)), by simp [affine_alpha_branches081], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n081_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart8).2.2.1 (ha))

theorem affine_alpha_nonnegative082 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known082 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known082, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty082 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known082 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n082_empty a ((by simpa only [KnownContains, affine_alpha_known082, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window082 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known082 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative082 a ha) (t := (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known082])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n082_height a h ((by omega)) (top11)

theorem affine_alpha_complete082 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known082 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches082 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known082])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known082])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known082])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known082])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known082])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o0 a jx jy (apart9).2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o1 a jx jy (apart9).2.2.2 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o2 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o3 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o5 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o6 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n082_o7 a jx jy (apart9).2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative083 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known083 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known083, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty083 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known083 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n083_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known083, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window083 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known083 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative083 a ha) (t := (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known083])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n083_height a h ((by omega)) (top11)

theorem affine_alpha_complete083 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known083 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches083 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known083])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known083])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known083])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known083])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o0 a jx jy (ha) (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o1 a jx jy (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart8).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o2 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o4 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o5 a jx jy (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o6 a jx jy (apart9).2.2.1 (ha) (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n083_o7 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha))

theorem affine_alpha_nonnegative084 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known084 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known084, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty084 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known084 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n084_empty a ((by simpa only [KnownContains, affine_alpha_known084, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window084 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known084 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative084 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known084])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n084_height a h (top1) ((by omega))

theorem affine_alpha_complete084 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known084 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches084 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known084])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known084])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known084])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o0 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o1 a jx jy (apart6).2.2.1 (apart8).2.1 (apart10).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n084_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart10).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known085 a)), by simp [affine_alpha_branches084], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o4 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o5 a jx jy (apart8).1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n084_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (ha) (apart10).2.2.2 (apart8).2.2.1)

theorem affine_alpha_nonnegative085 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known085 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known085, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty085 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known085 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n085_empty a ((by simpa only [KnownContains, affine_alpha_known085, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window085 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known085 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative085 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known085])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n085_height a h (top3) ((by omega))

theorem affine_alpha_complete085 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known085 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches085 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known085])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known085])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known085])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known085])
  have apart10 := separated (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known085])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o0 a jx jy (ha) (apart3).1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o1 a jx jy (apart9).2.1 (ha) (apart5).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o2 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o3 a jx jy (apart9).2.1 (ha) (apart10).2.1 (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o4 a jx jy (ha) (apart9).2.2.1 (apart8).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o6 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n085_o7 a jx jy (apart9).2.1 (ha) (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative086 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known086 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known086, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty086 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known086 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n086_empty a ((by simpa only [KnownContains, affine_alpha_known086, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window086 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known086 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative086 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known086])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n086_height a h (top1) ((by omega))

theorem affine_alpha_complete086 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known086 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches086 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known086])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known086])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known086])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o1 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart10).1 (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o5 a jx jy (apart10).2.2.1 (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o6 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n086_o7 a jx jy (ha) (apart8).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative087 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known087 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known087, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty087 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known087 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n087_empty a ((by simpa only [KnownContains, affine_alpha_known087, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window087 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known087 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative087 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known087])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n087_height a h ((by omega)) (top1)

theorem affine_alpha_complete087 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known087 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches087 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known087])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known087])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known087])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart8).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart6).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n087_o2 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known088 a)), by simp [affine_alpha_branches087], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o3 a jx jy (apart10).2.2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n087_o7 a jx jy (apart8).2.1 (apart10).2.1 (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative088 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known088 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known088, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty088 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known088 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n088_empty a ((by simpa only [KnownContains, affine_alpha_known088, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window088 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known088 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative088 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known088])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n088_height a h ((by omega)) (top3)

theorem affine_alpha_complete088 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known088 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches088 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known088])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known088])
  have apart8 := separated (Cross.mk (1 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known088])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known088])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known088])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o0 a jx jy (apart10).2.1 (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o1 a jx jy (ha) (apart9).2.2.2 (apart9).2.2.1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o2 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n088_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart10).2.1)

theorem affine_alpha_nonnegative089 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known089 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known089, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty089 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known089 a) (0 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n089_empty a ((by simpa only [KnownContains, affine_alpha_known089, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window089 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known089 a)) B) : QueryWindow h (0 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative089 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known089])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n089_height a h ((by omega)) (top1)

theorem affine_alpha_complete089 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known089 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches089 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart0 := separated (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known089])
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known089])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known089])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known089])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n089_o0 a jx jy (apart0).1 (apart1).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known112 a)), by simp [affine_alpha_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n089_o1 a jx jy (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart2).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known109 a)), by simp [affine_alpha_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n089_o2 a jx jy (ha) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.2 (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n089_o3 a jx jy (ha) (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n089_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known090 a)), by simp [affine_alpha_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n089_o5 a jx jy (apart0).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart1).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known129 a)), by simp [affine_alpha_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n089_o6 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart1).1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known091 a)), by simp [affine_alpha_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n089_o7 a jx jy (apart2).1 (apart8).2.2.1 (apart1).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative090 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known090 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall0 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover1_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall1 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover2_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall2 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(-1 : Int)) ((1 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall3 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(0 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall4 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(1 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall5 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(2 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall6 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_090 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known090 a) ((1 : Int)+(3 : Int)) ((1 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n090_wall7 a ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf090 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known090 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known090 a) .alpha (1 : Int) (1 : Int) (affine_alpha_nonnegative090 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_090 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (1 : Int)+y=((1 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_090 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n090_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(1 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative091 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known091 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known091, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty091 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known091 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n091_empty a ((by simpa only [KnownContains, affine_alpha_known091, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window091 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known091 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative091 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known091])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n091_height a h ((by omega)) (top1)

theorem affine_alpha_complete091 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known091 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches091 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known091])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known091])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known091])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known091])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n091_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.1 (apart8).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known092 a)), by simp [affine_alpha_branches091], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o1 a jx jy (ha) (apart9).2.2.1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o2 a jx jy (apart8).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o3 a jx jy (ha) (apart8).2.2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o4 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n091_o5 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known093 a)), by simp [affine_alpha_branches091], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o6 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n091_o7 a jx jy (apart8).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1)

theorem affine_alpha_nonnegative092 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known092 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall0 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall1 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover2_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall3 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall4 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall5 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall6 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall7 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall8 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover9_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall9 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(5 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall10 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover11_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall11 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_092 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known092 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n092_wall12 a ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf092 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known092 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known092 a) .gamma (1 : Int) (2 : Int) (affine_alpha_nonnegative092 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_092 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_092 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n092_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) ((by simpa only [KnownContains, affine_alpha_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .gamma (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_092 a ha
      · have ex : x=((1 : Int)+(1 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_092 a ha

theorem affine_alpha_nonnegative093 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known093 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known093, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty093 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known093 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n093_empty a ((by simpa only [KnownContains, affine_alpha_known093, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window093 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known093 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative093 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known093])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n093_height a h (top3) ((by omega))

theorem affine_alpha_complete093 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known093 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches093 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known093])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known093])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known107 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known098 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n093_o2 a jx jy (apart9).2.1 (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.2.1 (ha) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known099 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known094 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known108 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known097 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n093_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known106 a)), by simp [affine_alpha_branches093], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative094 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known094 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known094, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty094 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known094 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n094_empty a ((by simpa only [KnownContains, affine_alpha_known094, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window094 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known094 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative094 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known094])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n094_height a h ((by omega)) (top2)

theorem affine_alpha_complete094 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known094 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches094 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known094])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known094])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known094])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known094])
  have apart11 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known094])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o0 a jx jy (apart9).1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n094_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known096 a)), by simp [affine_alpha_branches094], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o2 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o3 a jx jy (apart10).2.2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o4 a jx jy (apart7).2.2.1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o5 a jx jy (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n094_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known095 a)), by simp [affine_alpha_branches094], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n094_o7 a jx jy (apart10).2.1 (apart11).2.1 (apart9).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative095 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known095 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known095, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty095 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known095 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n095_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window095 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known095 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative095 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known095])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n095_height a h (top2) ((by omega))

theorem affine_alpha_complete095 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known095 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches095 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known095])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known095])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known095])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known095])
  have apart12 := separated (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known095])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o0 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o1 a jx jy (apart7).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o2 a jx jy (apart10).2.1 (ha) (apart12).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o3 a jx jy (apart12).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o4 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o5 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n095_o7 a jx jy (ha) (apart10).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1)

theorem affine_alpha_nonnegative096 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known096 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known096, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty096 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known096 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n096_empty a ((by simpa only [KnownContains, affine_alpha_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window096 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known096 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative096 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known096])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n096_height a h (top2) ((by omega))

theorem affine_alpha_complete096 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known096 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches096 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known096])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known096])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known096])
  have apart12 := separated (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known096])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o0 a jx jy (ha) (apart10).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o1 a jx jy (apart10).2.2.1 (apart12).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o4 a jx jy (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o5 a jx jy (apart10).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart9).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o6 a jx jy (apart12).2.2.1 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n096_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart12).2.1)

theorem affine_alpha_nonnegative097 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known097 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known097, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty097 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known097 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n097_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known097, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window097 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known097 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative097 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known097])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n097_height a h (top2) ((by omega))

theorem affine_alpha_complete097 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known097 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches097 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known097])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known097])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known097])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known097])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known097])
  have apart11 := separated (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known097])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o1 a jx jy (apart11).2.2.2 (apart6).2.2.1 (apart11).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o2 a jx jy (apart3).1 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o3 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o4 a jx jy (apart7).2.2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o6 a jx jy (ha) (apart6).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n097_o7 a jx jy (apart9).1 (apart11).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_alpha_nonnegative098 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known098 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known098, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty098 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known098 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n098_empty a ((by simpa only [KnownContains, affine_alpha_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window098 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known098 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative098 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known098])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n098_height a h ((by omega)) (top2)

theorem affine_alpha_complete098 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known098 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches098 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known098])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known098])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known098])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known098])
  have apart11 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known098])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o2 a jx jy (apart10).2.2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o4 a jx jy (apart7).2.2.1 (apart6).2.2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o6 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n098_o7 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart9).1)

theorem affine_alpha_nonnegative099 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known099 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known099, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty099 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known099 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n099_empty a ((by simpa only [KnownContains, affine_alpha_known099, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window099 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known099 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative099 a ha) (t := (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int))) (by simp [affine_alpha_known099])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n099_height a h (top11) (ha) ((by omega))

theorem affine_alpha_complete099 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known099 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches099 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known099])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known099])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o0 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n099_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known103 a)), by simp [affine_alpha_branches099], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o3 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n099_o4 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known100 a)), by simp [affine_alpha_branches099], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o5 a jx jy (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o6 a jx jy (apart9).2.2.2 (apart9).2.2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n099_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1 (apart9).2.1)

theorem affine_alpha_nonnegative100 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known100 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known100, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty100 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known100 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n100_empty a ((by simpa only [KnownContains, affine_alpha_known100, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window100 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known100 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative100 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known100])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n100_height a h ((by omega)) (top2)

theorem affine_alpha_complete100 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known100 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches100 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known100])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known100])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known100])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known100])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o0 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n100_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known102 a)), by simp [affine_alpha_branches100], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o2 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o3 a jx jy (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o4 a jx jy (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o5 a jx jy (apart9).2.1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n100_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known101 a)), by simp [affine_alpha_branches100], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n100_o7 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.1)

theorem affine_alpha_nonnegative101 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known101 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known101, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty101 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known101 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n101_empty a ((by simpa only [KnownContains, affine_alpha_known101, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window101 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known101 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative101 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known101])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n101_height a h ((by omega)) (top2)

theorem affine_alpha_complete101 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known101 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches101 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known101])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known101])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known101])
  have apart13 := separated (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known101])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o1 a jx jy (apart10).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o2 a jx jy (apart10).2.2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o4 a jx jy (apart10).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o5 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o6 a jx jy (ha) (apart13).1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n101_o7 a jx jy (apart13).2.2.1 (ha) (apart9).1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative102 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known102 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known102, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty102 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known102 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n102_empty a ((by simpa only [KnownContains, affine_alpha_known102, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window102 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known102 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative102 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known102])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n102_height a h (top2) ((by omega))

theorem affine_alpha_complete102 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known102 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches102 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known102])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known102])
  have apart13 := separated (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known102])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1 (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o2 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o3 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o4 a jx jy (apart10).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o6 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n102_o7 a jx jy (apart10).2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative103 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known103 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known103, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty103 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known103 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n103_empty a ((by simpa only [KnownContains, affine_alpha_known103, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window103 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known103 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative103 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known103])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n103_height a h (top2) ((by omega))

theorem affine_alpha_complete103 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known103 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches103 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known103])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known103])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known103])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_alpha_known103])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n103_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known105 a)), by simp [affine_alpha_branches103], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o3 a jx jy (apart11).1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o4 a jx jy (apart8).2.2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o5 a jx jy (apart10).1 (apart9).1 (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n103_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known104 a)), by simp [affine_alpha_branches103], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n103_o7 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.1)

theorem affine_alpha_nonnegative104 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known104 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known104, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty104 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known104 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n104_empty a ((by simpa only [KnownContains, affine_alpha_known104, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window104 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known104 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative104 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known104])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n104_height a h (top2) ((by omega))

theorem affine_alpha_complete104 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known104 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches104 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known104])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known104])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known104])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known104])
  have apart13 := separated (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known104])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o0 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart10).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o2 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o3 a jx jy (ha) (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o4 a jx jy (apart13).2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o5 a jx jy (apart10).2.1 (ha) (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o6 a jx jy (ha) (apart13).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n104_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (apart13).2.2.1 (ha) (apart10).2.1)

theorem affine_alpha_nonnegative105 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known105 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known105, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty105 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known105 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n105_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known105, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window105 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known105 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative105 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known105])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n105_height a h ((by omega)) (top2)

theorem affine_alpha_complete105 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known105 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches105 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known105])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known105])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known105])
  have apart13 := separated (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known105])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o0 a jx jy (ha) (apart13).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o1 a jx jy (apart10).2.2.1 (apart13).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o2 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o3 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o4 a jx jy (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o5 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n105_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart10).2.1)

theorem affine_alpha_nonnegative106 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known106 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall0 a (ha) ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall2 a ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(0 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(1 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall5 a ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(2 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall6 a ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_106 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known106 a) ((1 : Int)+(3 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n106_wall7 a ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf106 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known106 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known106 a) .alpha (1 : Int) (4 : Int) (affine_alpha_nonnegative106 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_106 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_106 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n106_dirty a x y ((by simpa only [KnownContains, affine_alpha_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(4 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative107 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known107 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known107, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty107 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known107 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n107_empty a ((by simpa only [KnownContains, affine_alpha_known107, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window107 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known107 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative107 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known107])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n107_height a h ((by omega)) (top2)

theorem affine_alpha_complete107 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known107 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches107 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known107])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known107])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known107])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known107])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known107])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o0 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o1 a jx jy (apart11).2.2.2 (apart6).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o2 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o3 a jx jy (apart10).2.2.1 (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o4 a jx jy (apart11).2.2.2 (apart6).2.2.1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o5 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o6 a jx jy (apart6).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2 (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n107_o7 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart11).2.2.2)

theorem affine_alpha_nonnegative108 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known108 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known108, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty108 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known108 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n108_empty a ((by simpa only [KnownContains, affine_alpha_known108, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window108 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known108 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative108 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known108])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n108_height a h (top2) ((by omega))

theorem affine_alpha_complete108 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known108 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches108 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known108])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known108])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known108])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known108])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o0 a jx jy (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o1 a jx jy (apart6).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o2 a jx jy (apart10).2.2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o3 a jx jy (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o4 a jx jy (apart6).2.2.1 (apart11).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o6 a jx jy (apart11).2.2.1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n108_o7 a jx jy (apart11).2.1 (ha) (apart10).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative109 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known109 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known109, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty109 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known109 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n109_empty a ((by simpa only [KnownContains, affine_alpha_known109, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window109 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known109 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative109 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known109])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n109_height a h ((by omega)) (top1)

theorem affine_alpha_complete109 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known109 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches109 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known109])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known109])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known109])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n109_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart8).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known110 a)), by simp [affine_alpha_branches109], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o2 a jx jy (ha) (apart9).2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o3 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n109_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known111 a)), by simp [affine_alpha_branches109], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o6 a jx jy (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n109_o7 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)

theorem affine_alpha_nonnegative110 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known110 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known110, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty110 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known110 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n110_empty a ((by simpa only [KnownContains, affine_alpha_known110, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window110 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known110 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative110 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known110])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n110_height a h (top2) ((by omega))

theorem affine_alpha_complete110 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known110 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches110 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known110])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known110])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known110])
  have apart10 := separated (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known110])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o0 a jx jy (apart10).2.1 (apart2).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o1 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o2 a jx jy (apart10).2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o3 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart5).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o4 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o5 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o6 a jx jy (apart5).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n110_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart10).2.2.2)

theorem affine_alpha_nonnegative111 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known111 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known111, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty111 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known111 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n111_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known111, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window111 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known111 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative111 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known111])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n111_height a h (top2) ((by omega))

theorem affine_alpha_complete111 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known111 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches111 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known111])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known111])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known111])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known111])
  have apart10 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known111])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o0 a jx jy (apart2).1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o1 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart5).2.2.1 (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o4 a jx jy (apart8).2.2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o5 a jx jy (ha) (apart9).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o6 a jx jy (ha) (apart5).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n111_o7 a jx jy (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative112 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known112 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known112, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty112 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known112 a) (0 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n112_empty a ((by simpa only [KnownContains, affine_alpha_known112, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window112 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known112 a)) B) : QueryWindow h (0 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative112 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known112])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n112_height a h (top2) ((by omega))

theorem affine_alpha_complete112 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known112 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches112 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known112])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known112])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known112])
  have apart4 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known112])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known112])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n112_o0 a jx jy (apart9).2.2.1 (ha) (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n112_o1 a jx jy (apart9).2.2.1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known115 a)), by simp [affine_alpha_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n112_o2 a jx jy (apart9).2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n112_o3 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n112_o4 a jx jy (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known113 a)), by simp [affine_alpha_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n112_o5 a jx jy (apart2).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n112_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 (apart4).2.2.1 (apart2).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known114 a)), by simp [affine_alpha_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n112_o7 a jx jy (ha) (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (apart9).2.2.1)

theorem affine_alpha_nonnegative113 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known113 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall0 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall3 a ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall4 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover5_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall5 a ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover6_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall6 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall7 a ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover8_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall8 a ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover9_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall9 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover10_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(5 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall10 a (ha) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover11_113 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known113 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n113_wall11 a ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf113 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known113 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known113 a) .beta (1 : Int) (2 : Int) (affine_alpha_nonnegative113 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_113 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_113 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n113_dirty a x y (hy) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hx) ((by simpa only [KnownContains, affine_alpha_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover11_113 a ha

theorem affine_alpha_nonnegative114 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known114 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall0 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall1 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall2 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover3_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall3 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover4_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall4 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall5 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall6 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover7_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall7 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover8_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall8 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover9_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall9 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover10_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall10 a (ha) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover11_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall11 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover12_114 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known114 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n114_wall12 a ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_leaf114 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known114 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known114 a) .gammaTranspose (1 : Int) (2 : Int) (affine_alpha_nonnegative114 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover8_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover9_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover10_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_114 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_114 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n114_dirty a x y (hx) ((by simpa only [KnownContains, affine_alpha_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover11_114 a ha
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_alpha_cover12_114 a ha

theorem affine_alpha_nonnegative115 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known115 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known115, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty115 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known115 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n115_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known115, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window115 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known115 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_alpha_nonnegative115 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known115])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n115_height a h ((by omega)) (top3)

theorem affine_alpha_complete115 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known115 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches115 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known115])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known115])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known115])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n115_o0 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known124 a)), by simp [affine_alpha_branches115], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n115_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n115_o2 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known126 a)), by simp [affine_alpha_branches115], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n115_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.2 (apart10).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_alpha_known116 a)), by simp [affine_alpha_branches115], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n115_o4 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n115_o5 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known127 a)), by simp [affine_alpha_branches115], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n115_o6 a jx jy (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n115_o7 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_alpha_known117 a)), by simp [affine_alpha_branches115], (same_eq m0).symm⟩

theorem affine_alpha_nonnegative116 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known116 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_cover0_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall0 a (ha) ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover1_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall1 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_alpha_cover2_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall2 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover3_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall3 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover4_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall4 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover5_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall5 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover6_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall6 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_cover7_116 (a : Int) (ha : 6≤a) : KnownContains (affine_alpha_known116 a) ((3 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.alpha_n116_wall7 a ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_alpha_leaf116 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known116 a)) B) : Transition world h .alpha B := by
  apply replay_affine_leaf world h .alpha (affine_alpha_known116 a) .alpha (3 : Int) (2 : Int) (affine_alpha_nonnegative116 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover0_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover1_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover2_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover3_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover4_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover5_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover6_116 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_alpha_cover7_116 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.alpha_n116_dirty a x y ((by simpa only [KnownContains, affine_alpha_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(3 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_alpha_nonnegative117 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known117 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known117, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty117 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known117 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n117_empty a ((by simpa only [KnownContains, affine_alpha_known117, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window117 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known117 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top10 := known_top_below state (affine_alpha_nonnegative117 a ha) (t := (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)) (by simp [affine_alpha_known117])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n117_height a h (top10) ((by omega)) (ha)

theorem affine_alpha_complete117 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known117 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches117 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known117])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known117])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known117])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n117_o0 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_alpha_known118 a)), by simp [affine_alpha_branches117], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o1 a jx jy (apart9).2.2.2 (apart10).2.2.2 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o3 a jx jy (apart11).2.2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o4 a jx jy (apart10).2.2.1 (apart11).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n117_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart10).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known121 a)), by simp [affine_alpha_branches117], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o6 a jx jy (apart10).2.2.1 (ha) (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n117_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2 (apart10).2.1 (ha))

theorem affine_alpha_nonnegative118 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known118 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known118, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty118 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known118 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n118_empty a ((by simpa only [KnownContains, affine_alpha_known118, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window118 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known118 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative118 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known118])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n118_height a h ((by omega)) (top2)

theorem affine_alpha_complete118 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known118 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches118 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known118])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known118])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known118])
  have apart12 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known118])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o0 a jx jy (apart9).2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o1 a jx jy (apart11).2.2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n118_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known119 a)), by simp [affine_alpha_branches118], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o4 a jx jy (apart11).2.2.1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n118_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1 (ha) (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known120 a)), by simp [affine_alpha_branches118], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o6 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n118_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha) (apart9).2.2.1)

theorem affine_alpha_nonnegative119 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known119 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known119, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty119 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known119 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n119_empty a ((by simpa only [KnownContains, affine_alpha_known119, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window119 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known119 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative119 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known119])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n119_height a h ((by omega)) (top12)

theorem affine_alpha_complete119 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known119 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches119 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known119])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known119])
  have apart12 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known119])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o1 a jx jy (apart9).2.2.2 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o2 a jx jy (ha) (apart12).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o3 a jx jy (apart10).2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1 (ha) (apart12).2.1 (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.2 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.2 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n119_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (ha) (apart10).2.1)

theorem affine_alpha_nonnegative120 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known120 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known120, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty120 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known120 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n120_empty a ((by simpa only [KnownContains, affine_alpha_known120, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window120 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known120 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative120 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known120])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n120_height a h (top12) ((by omega))

theorem affine_alpha_complete120 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known120 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches120 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known120])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known120])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known120])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known120])
  have apart12 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known120])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o0 a jx jy (ha) (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart10).2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o3 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o4 a jx jy (apart10).2.2.1 (ha) (apart6).2.2.1 (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o5 a jx jy (apart10).2.2.2 (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o6 a jx jy (apart12).2.2.1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n120_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart12).2.2.2 (ha))

theorem affine_alpha_nonnegative121 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known121 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known121, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty121 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known121 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n121_empty a ((by simpa only [KnownContains, affine_alpha_known121, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window121 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known121 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative121 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known121])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n121_height a h (top2) ((by omega))

theorem affine_alpha_complete121 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known121 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches121 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known121])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known121])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known121])
  have apart12 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known121])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o0 a jx jy (apart11).2.2.1 (apart9).2.1 (ha) (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o1 a jx jy (apart12).2.2.1 (ha) (apart7).2.2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n121_o2 a jx jy (apart11).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known122 a)), by simp [affine_alpha_branches121], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o4 a jx jy (apart7).2.2.1 (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n121_o5 a jx jy (ha) (apart11).2.1 (apart9).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_alpha_known123 a)), by simp [affine_alpha_branches121], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o6 a jx jy (apart12).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n121_o7 a jx jy (ha) (apart9).2.2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative122 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known122 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known122, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty122 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known122 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n122_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known122, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window122 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known122 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative122 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known122])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n122_height a h ((by omega)) (top12)

theorem affine_alpha_complete122 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known122 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches122 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known122])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known122])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known122])
  have apart12 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known122])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart10).2.2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o2 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o3 a jx jy (apart12).2.2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o4 a jx jy (apart10).2.2.1 (apart10).2.1 (ha) (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o5 a jx jy (ha) (apart12).2.2.2 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o6 a jx jy (apart10).2.2.1 (apart9).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n122_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart12).2.1)

theorem affine_alpha_nonnegative123 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known123 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known123, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty123 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known123 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n123_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known123, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window123 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known123 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top12 := known_top_below state (affine_alpha_nonnegative123 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known123])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n123_height a h ((by omega)) (top12)

theorem affine_alpha_complete123 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known123 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches123 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known123])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known123])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known123])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_alpha_known123])
  have apart12 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known123])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o1 a jx jy (apart8).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o2 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o3 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o4 a jx jy (apart10).2.1 (apart11).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o5 a jx jy (apart10).2.1 (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o6 a jx jy (apart9).2.2.2 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n123_o7 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)

theorem affine_alpha_nonnegative124 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known124 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known124, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty124 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known124 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n124_empty a ((by simpa only [KnownContains, affine_alpha_known124, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window124 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known124 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative124 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known124])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n124_height a h ((by omega)) (top2)

theorem affine_alpha_complete124 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known124 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches124 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known124])
  have apart7 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known124])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known124])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known124])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o1 a jx jy (ha) (apart9).2.1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n124_o2 a jx jy (apart9).2.1 (apart11).2.2.2 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known125 a)), by simp [affine_alpha_branches124], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o3 a jx jy (apart6).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o4 a jx jy (apart11).2.2.2 (apart9).2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart6).2.2.1 (ha) (apart11).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n124_o7 a jx jy (apart9).2.2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.2)

theorem affine_alpha_nonnegative125 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known125 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known125, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty125 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known125 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n125_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known125, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window125 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known125 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative125 a ha) (t := (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_alpha_known125])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n125_height a h ((by omega)) (top11)

theorem affine_alpha_complete125 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known125 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches125 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known125])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known125])
  have apart11 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known125])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o1 a jx jy (apart10).2.2.1 (ha) (apart10).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o2 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o3 a jx jy (apart9).2.2.2 (apart10).2.1 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o4 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o5 a jx jy (apart10).2.2.2 (apart11).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o6 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n125_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart11).2.2.2 (ha))

theorem affine_alpha_nonnegative126 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known126 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known126, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty126 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known126 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n126_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window126 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known126 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative126 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known126])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n126_height a h (top2) ((by omega))

theorem affine_alpha_complete126 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known126 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches126 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known126])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known126])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known126])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known126])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o0 a jx jy (apart11).2.1 (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (ha) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o2 a jx jy (apart10).2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o3 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n126_o7 a jx jy (apart11).2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative127 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known127 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known127, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty127 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known127 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n127_empty a ((by simpa only [KnownContains, affine_alpha_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window127 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known127 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative127 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known127])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n127_height a h ((by omega)) (top2)

theorem affine_alpha_complete127 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known127 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches127 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known127])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known127])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known127])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known127])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o0 a jx jy (apart11).2.2.1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n127_o2 a jx jy (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart9).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_alpha_known128 a)), by simp [affine_alpha_branches127], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o3 a jx jy (ha) (apart11).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.2.1 (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o5 a jx jy (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n127_o7 a jx jy (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1 (apart9).2.2.1)

theorem affine_alpha_nonnegative128 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known128 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known128, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty128 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known128 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n128_empty a ((by simpa only [KnownContains, affine_alpha_known128, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window128 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known128 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top11 := known_top_below state (affine_alpha_nonnegative128 a ha) (t := (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_alpha_known128])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n128_height a h (top11) ((by omega))

theorem affine_alpha_complete128 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known128 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches128 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known128])
  have apart9 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_alpha_known128])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known128])
  have apart11 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known128])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart11).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o1 a jx jy (apart10).2.2.2 (ha) (apart9).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1 (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o3 a jx jy (ha) (apart11).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o4 a jx jy (apart8).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o5 a jx jy (apart11).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.2 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n128_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart11).2.1)

theorem affine_alpha_nonnegative129 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known129 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known129, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty129 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known129 a) (0 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n129_empty a ((by simpa only [KnownContains, affine_alpha_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window129 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known129 a)) B) : QueryWindow h (0 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative129 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known129])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n129_height a h ((by omega)) (top2)

theorem affine_alpha_complete129 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known129 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches129 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known129])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known129])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known129])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known129])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n129_o0 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n129_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart2).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known134 a)), by simp [affine_alpha_branches129], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n129_o2 a jx jy (ha) (apart2).2.2.1 (apart3).1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n129_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n129_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known130 a)), by simp [affine_alpha_branches129], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n129_o5 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (ha) (apart9).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n129_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart2).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known133 a)), by simp [affine_alpha_branches129], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n129_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (apart3).1 (ha) (apart9).2.1)

theorem affine_alpha_nonnegative130 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known130 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known130, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty130 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known130 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n130_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known130, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window130 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known130 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative130 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known130])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n130_height a h (top2) ((by omega))

theorem affine_alpha_complete130 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known130 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches130 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known130])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known130])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known130])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known130])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n130_o1 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known132 a)), by simp [affine_alpha_branches130], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o2 a jx jy (ha) (apart9).2.2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o4 a jx jy (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1 (apart2).1 (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n130_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart9).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known131 a)), by simp [affine_alpha_branches130], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n130_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)

theorem affine_alpha_nonnegative131 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known131 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known131, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty131 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known131 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n131_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known131, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window131 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known131 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative131 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known131])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n131_height a h ((by omega)) (top2)

theorem affine_alpha_complete131 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known131 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches131 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known131])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known131])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known131])
  have apart11 := separated (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known131])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o0 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o1 a jx jy (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart9).2.1 (apart11).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o3 a jx jy (apart11).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o4 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o5 a jx jy (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o6 a jx jy (apart11).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n131_o7 a jx jy (apart11).2.2.1 (apart2).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)

theorem affine_alpha_nonnegative132 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known132 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known132, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty132 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known132 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n132_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known132, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window132 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known132 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative132 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known132])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n132_height a h (top2) ((by omega))

theorem affine_alpha_complete132 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known132 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches132 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known132])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known132])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known132])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known132])
  have apart11 := separated (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known132])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o0 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o1 a jx jy (apart11).1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o2 a jx jy (apart9).2.1 (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o3 a jx jy (apart9).2.2.1 (apart11).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o4 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart11).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o5 a jx jy (apart1).1 (apart2).1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o6 a jx jy (apart11).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n132_o7 a jx jy (apart11).2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative133 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known133 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known133, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty133 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known133 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n133_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known133, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window133 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known133 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative133 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known133])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n133_height a h ((by omega)) (top2)

theorem affine_alpha_complete133 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known133 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches133 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known133])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known133])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_alpha_known133])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known133])
  have apart10 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known133])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o0 a jx jy (apart9).2.1 (apart10).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o1 a jx jy (apart10).2.2.1 (ha) (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o2 a jx jy (ha) (apart9).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o3 a jx jy (apart10).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o5 a jx jy (apart10).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o6 a jx jy (apart10).2.2.1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n133_o7 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1 (apart9).2.1)

theorem affine_alpha_nonnegative134 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known134 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known134, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty134 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known134 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n134_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known134, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window134 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known134 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_alpha_nonnegative134 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known134])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n134_height a h ((by omega)) (top2)

theorem affine_alpha_complete134 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known134 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches134 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known134])
  have apart9 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known134])
  have apart10 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known134])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o0 a jx jy (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o4 a jx jy (apart10).2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o5 a jx jy (apart9).2.1 (apart9).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o6 a jx jy (apart10).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n134_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart10).2.1)

theorem affine_alpha_nonnegative135 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known135 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known135, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty135 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known135 a) (0 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n135_empty a ((by simpa only [KnownContains, affine_alpha_known135, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window135 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known135 a)) B) : QueryWindow h (0 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative135 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known135])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n135_height a h ((by omega)) (top1)

theorem affine_alpha_complete135 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known135 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches135 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known135])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known135])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known135])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n135_o0 a jx jy (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n135_o1 a jx jy (apart8).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known140 a)), by simp [affine_alpha_branches135], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n135_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (apart1).2.2.1 (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n135_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart2).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n135_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_alpha_known136 a)), by simp [affine_alpha_branches135], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n135_o5 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart1).1 (apart8).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n135_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart1).1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known139 a)), by simp [affine_alpha_branches135], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n135_o7 a jx jy (apart8).2.1 (ha) (apart1).1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative136 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known136 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known136, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty136 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known136 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n136_empty a ((by simpa only [KnownContains, affine_alpha_known136, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window136 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known136 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative136 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known136])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n136_height a h (top1) ((by omega))

theorem affine_alpha_complete136 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known136 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches136 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known136])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known136])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known136])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known136])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o0 a jx jy (apart1).1 (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n136_o1 a jx jy (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_alpha_known138 a)), by simp [affine_alpha_branches136], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o2 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o4 a jx jy (apart8).1 (ha) (apart9).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o5 a jx jy (apart8).2.2.1 (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.alpha_n136_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_alpha_known137 a)), by simp [affine_alpha_branches136], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n136_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1 (apart8).2.1)

theorem affine_alpha_nonnegative137 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known137 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known137, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty137 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known137 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n137_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known137, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window137 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known137 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative137 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known137])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n137_height a h ((by omega)) (top1)

theorem affine_alpha_complete137 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known137 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches137 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known137])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known137])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known137])
  have apart10 := separated (Cross.mk (1 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known137])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o1 a jx jy (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o2 a jx jy (apart8).2.1 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart10).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o5 a jx jy (apart8).2.1 (apart8).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o6 a jx jy (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n137_o7 a jx jy (apart10).2.2.1 (apart1).1 (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_alpha_nonnegative138 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known138 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known138, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty138 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known138 a) (2 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n138_empty a (ha) ((by simpa only [KnownContains, affine_alpha_known138, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_alpha_window138 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known138 a)) B) : QueryWindow h (2 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative138 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known138])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n138_height a h ((by omega)) (top1)

theorem affine_alpha_complete138 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known138 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches138 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known138])
  have apart6 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known138])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known138])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_alpha_known138])
  have apart10 := separated (Cross.mk (1 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known138])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o0 a jx jy (apart1).1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o1 a jx jy (apart8).2.2.1 (ha) (apart10).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o2 a jx jy (ha) (apart9).2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o4 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o5 a jx jy (apart1).1 (ha) (apart8).2.2.1 (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o6 a jx jy (ha) (apart10).2.2.1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n138_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.1 (apart8).2.1 (ha))

theorem affine_alpha_nonnegative139 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known139 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known139, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty139 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known139 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n139_empty a ((by simpa only [KnownContains, affine_alpha_known139, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window139 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known139 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative139 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known139])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n139_height a h (top1) ((by omega))

theorem affine_alpha_complete139 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known139 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches139 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known139])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known139])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known139])
  have apart9 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_alpha_known139])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o0 a jx jy (ha) (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o1 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o2 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.1 (apart8).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o6 a jx jy (apart5).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n139_o7 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1 (apart1).1)

theorem affine_alpha_nonnegative140 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_alpha_known140 a → Nonnegative t := by
  intro t mem
  simp only [affine_alpha_known140, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_alpha_empty140 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_alpha_known140 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.alpha_n140_empty a ((by simpa only [KnownContains, affine_alpha_known140, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_alpha_window140 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_alpha_known140 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_alpha_nonnegative140 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_alpha_known140])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.alpha_n140_height a h (top1) ((by omega))

theorem affine_alpha_complete140 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_alpha_known140 a → Apart t u) :
    ∃ branch, branch ∈ affine_alpha_branches140 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known140])
  have apart5 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_alpha_known140])
  have apart8 := separated (Cross.mk a (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_alpha_known140])
  have apart9 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_alpha_known140])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o0 a jx jy (apart8).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o2 a jx jy (apart9).2.1 (ha) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o3 a jx jy (apart8).2.2.1 (apart9).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart9).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o5 a jx jy (apart8).2.2.1 (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart5).2.2.1 (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.alpha_n140_o7 a jx jy (apart9).2.1 (apart8).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

end CornerCertificate

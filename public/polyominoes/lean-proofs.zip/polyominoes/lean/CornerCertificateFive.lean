import CornerCertificateFiveAlpha
import CornerCertificateFiveBeta
import CornerCertificateFiveGamma
import CornerCertificateFiveBetaTranspose
import CornerCertificateFiveGammaTranspose

namespace CornerCertificate
open CrossUnits

theorem five_local (world : Cross → Prop) (h : Int) (k : Kind)
    (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean k 0 0 B) :
    Transition world h k B := by
  cases k with
  | alpha => exact five_alpha_local world h B copies separate cover ceiling closed bounded clean
  | beta => exact five_beta_local world h B copies separate cover ceiling closed bounded clean
  | gamma => exact five_gamma_local world h B copies separate cover ceiling closed bounded clean
  | betaTranspose => exact five_betaTranspose_local world h B copies separate cover ceiling closed bounded clean
  | gammaTranspose => exact five_gammaTranspose_local world h B copies separate cover ceiling closed bounded clean

#print axioms five_local

end CornerCertificate

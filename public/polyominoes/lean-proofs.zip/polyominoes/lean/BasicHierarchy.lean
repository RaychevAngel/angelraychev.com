import TilingSymmetry
import RectangleHierarchy
import PositiveHierarchy

namespace PolyominoFormal

def Tiling.halfStripToStrip {a b c d h : Int} (T : Tiling a b c d (HalfStrip h)) :
    Tiling a b c d (Strip h) :=
  (T.union (T.mirrorX.translate (-1) 0) (by
    intro x y hp hn
    simp only [HalfStrip] at hp hn
    omega)).congr (by
      intro x y
      simp only [HalfStrip,Strip]
      omega)

theorem half_strip_implies_strip {a b c d : Int} (h : HalfStripTileable a b c d) :
    StripTileable a b c d := by
  obtain ⟨h,hh,⟨T⟩⟩ := h
  exact ⟨h,hh,⟨T.halfStripToStrip⟩⟩

def Tiling.halfStripToBentStrip {a b c d h : Int} (hh : 0<h)
    (T : Tiling a b c d (HalfStrip h)) : Tiling a b c d (BentStrip h h) :=
  (T.union (T.transpose.translate 0 h) (by
    intro x y hp hn
    simp only [HalfStrip] at hp hn
    omega)).congr (by
      intro x y
      simp only [HalfStrip,BentStrip]
      omega)

theorem half_strip_implies_bent_strip {a b c d : Int} (h : HalfStripTileable a b c d) :
    BentStripTileable a b c d := by
  obtain ⟨h,hh,⟨T⟩⟩ := h
  exact ⟨h,h,hh,hh,⟨T.halfStripToBentStrip hh⟩⟩

theorem half_strip_implies_quadrant {a b c d : Int} (h : HalfStripTileable a b c d) :
    Tiles a b c d Quadrant :=
  PositiveHierarchy.bent_tiles_quadrant (half_strip_implies_bent_strip h)

end PolyominoFormal

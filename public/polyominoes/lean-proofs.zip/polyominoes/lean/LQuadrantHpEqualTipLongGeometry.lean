import LQuadrantHpEqualTipLongArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_equal_tip_long_M (a b : Int) : Int := 2*(a+b+1)
def HP_equal_tip_long_Box (a b x y : Int) : Prop := -HP_equal_tip_long_M a b ≤ x ∧ 0≤y ∧ x≤HP_equal_tip_long_M a b ∧ y≤HP_equal_tip_long_M a b
def HP_equal_tip_long_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_equal_tip_long_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_tip_long_Inside t)
    (cover : ∀ x y, HP_equal_tip_long_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a))
    (ht1 : world (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht0
  have in1 := inside (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) ht1
  have support : HP_equal_tip_long_Box a b (1 : Int) ((-2 : Int) + a) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_tip_long_n001_point a b (hb) ((by simpa only [HP_equal_tip_long_Box,HP_equal_tip_long_M] using absent)) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) (1 : Int) ((-2 : Int) + a) ∨ Contains (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) (1 : Int) ((-2 : Int) + a)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_tip_long_n001_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-2 : Int) + a) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o0 a b jx jy (heq) (hit) (sep0).2.1 (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o1 a b jx jy (sep1).2.1 (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o2 a b jx jy (sep1).2.2.1 (heq) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o3 a b jx jy (insideT) (sep1).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o4 a b jx jy (hb) (sep1).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o5 a b jx jy (sep1).2.2.1 (heq) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o6 a b jx jy (sep0).2.1 (hit) (hb) (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n001_o7 a b jx jy (sep1).2.2.1 (hit) (heq) (insideT)

theorem HP_equal_tip_long_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_tip_long_Inside t)
    (cover : ∀ x y, HP_equal_tip_long_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a))
    (ht1 : world (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) ht1
  have support : HP_equal_tip_long_Box a b (1 : Int) ((-2 : Int) + a) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_tip_long_n002_point a b (hb) ((by simpa only [HP_equal_tip_long_Box,HP_equal_tip_long_M] using absent)) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) (1 : Int) ((-2 : Int) + a) ∨ Contains (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) (1 : Int) ((-2 : Int) + a)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_tip_long_n002_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-2 : Int) + a) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o0 a b jx jy (heq) (hit) (insideT) (sep0).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o1 a b jx jy (sep0).2.2.1 (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o2 a b jx jy (hit) (sep1).2.2.1 (heq) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o3 a b jx jy (hit) (insideT) (sep1).2.2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o4 a b jx jy (hit) (insideT) (hb) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o5 a b jx jy (insideT) (sep1).2.2.1 (hit) (heq)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o6 a b jx jy (hit) (insideT) (sep0).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n002_o7 a b jx jy (hit) (sep0).2.2.1 (insideT) (heq)

theorem HP_equal_tip_long_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_tip_long_Inside t)
    (cover : ∀ x y, HP_equal_tip_long_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht0
  have support : HP_equal_tip_long_Box a b (1 : Int) ((-1 : Int) + a) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_equal_tip_long_n000_point a b ((by simpa only [HP_equal_tip_long_Box,HP_equal_tip_long_M] using absent)) (ha) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) (1 : Int) ((-1 : Int) + a)) := by
    intro occupied
    exact LRegionArithmetic.HP_equal_tip_long_n000_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-1 : Int) + a) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty hit)
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o0 a b jx jy (sep0).2.2.1 (sep0).2.1 (hit) (heq) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o1 a b jx jy (hb) (sep0).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o2 a b jx jy (hit) (heq) (sep0).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) ∨ Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_tip_long_n000_o3 a b jx jy (insideT) (hit) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (hb)
    rcases alternatives with matched | matched
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0
      exact HP_equal_tip_long_node001 a b ha hb heq world copies inside cover separate ht0 ht (apart_sym sep0)
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0
      exact HP_equal_tip_long_node002 a b ha hb heq world copies inside cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o4 a b jx jy (hb) (hit) (insideT) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b) ((-1 : Int) + a) (0 : Int) a b (0 : Int)) ∨ Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + a) ((-1 : Int) + a) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_equal_tip_long_n000_o5 a b jx jy (hit) (heq) (sep0).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT)
    rcases alternatives with matched | matched
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0
      exact HP_equal_tip_long_node001 a b ha hb heq world copies inside cover separate ht0 ht (apart_sym sep0)
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0
      exact HP_equal_tip_long_node002 a b ha hb heq world copies inside cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o6 a b jx jy (hit) (sep0).2.1 (hb) (insideT) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_equal_tip_long_n000_o7 a b jx jy (hit) (insideT) (heq) (sep0).2.2.1

theorem HP_equal_tip_long_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_equal_tip_long_Inside t)
    (cover : ∀ x y, HP_equal_tip_long_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  exact HP_equal_tip_long_node000 a b ha hb heq world copies inside cover sep anchor

theorem HP_equal_tip_long_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a)) : False := by
  apply HP_equal_tip_long_bounded_obstruction a b ha hb heq T.world T.copies ?_ ?_ T.disjoint anchor
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_equal_tip_long_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (heq : (a = b))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (shift p 0 (Cross.mk (0 : Int) a b (0 : Int) (0 : Int) a))) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_equal_tip_long_anchored_obstruction a b ha hb heq U
  refine ⟨_,anchor,?_⟩
  apply same_eq
  unfold Same shift; dsimp
  exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_equal_tip_long_no_shifted_anchor
#print axioms HP_equal_tip_long_bounded_obstruction
end PolyominoFormal.LRegion

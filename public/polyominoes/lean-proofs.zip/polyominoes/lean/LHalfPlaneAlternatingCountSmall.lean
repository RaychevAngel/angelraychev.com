import LHalfPlaneAlternatingCount
import LQuadrantHpUnequalFirstShortAwayBthreePrunedGeometry
import LHalfPlaneFiveThree
import LQuadrantHpUnequalAfterShortLeftBthreePrunedGeometry
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits

theorem no_first_short_away_all {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (wall : T.world ⟨0,0,a,b,0,0⟩)
    (bar : T.world ⟨b+1,1,0,a,b,0⟩) : False := by
  by_cases four : 4≤b
  · exact no_first_short_away four hab T wall bar
  have bthree : b=3 := by omega
  subst b
  by_cases five : a=5
  · subst a; exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
  apply LRegion.HP_unequal_first_short_away_bthree_pruned_anchored_obstruction a 3
    (by omega) (by omega) hab ha rfl (Or.inl five) T wall
  simpa only [Int.add_comm] using bar

theorem no_left_junction_after_first_short {a b l : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (hl : l=a ∨ l=b)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (first : T.world ⟨1,1,b,a,0,0⟩)
    (second : T.world ⟨b+2,1,l,a+b-l,0,0⟩) : False := by
  by_cases four : 4≤b
  · apply no_left_junction_after_short (p:=1) (h:=1) four hab hl T first
    simpa only [show 1+b+1=b+2 by omega] using second
  have eqb : b=3 := by omega
  subst b
  rcases hl with hl | hl
  · subst l
    by_cases five : a=5
    · subst a; exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
    rcases bars with ⟨_,_,h0,h1,h2,h3,_,_⟩
    apply LRegion.HP_unequal_after_short_left_bthree_pruned_anchored_obstruction a 3
      (by omega) (by omega) hab ha rfl (Or.inl five) T
    · simpa only [Int.add_comm] using h0
    · exact h1
    · simpa only [Int.add_comm] using h2
    · simpa only [Int.add_comm] using h3
    · exact first
    · simpa only [Int.reduceAdd,show a+3-a=3 by omega] using second
  · subst l
    apply no_same_short_bars (p:=1) (h:=1) hb hab T first
    simpa only [Int.reduceAdd,show a+3-3=a by omega] using second

theorem first_two_bars_all {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) :
    ∃l r m s,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧ (m=a ∨ m=b) ∧ (s=0 ∨ s=m) ∧
      l+m+2≤2*a ∧ T.world ⟨1+r,1,l-r,a+b-l,r,0⟩ ∧
      T.world ⟨l+2+s,1,m-s,a+b-m,s,0⟩ ∧ (l=b → r=0 ∧ s=m) := by
  obtain ⟨l,r,hl,hr,first⟩ := first_horizontal_bar ha (by omega) hab T bars
  obtain ⟨m,s,hm,hs,bound,second⟩ := successor_horizontal (q:=1) ha (by omega) hab hl hr
    (by omega) (by omega) T bars first
  have e : 1+l+1=l+2 := by omega
  rw [e] at bound second
  refine ⟨l,r,m,s,hl,hr,hm,hs,by omega,first,second,?_⟩
  intro eq
  subst l
  have rzero : r=0 := by
    rcases hr with hr | hr
    · exact hr
    · subst r
      have wall := bars.2.2.2.1
      exact False.elim (no_first_short_away_all ha hb hab T wall
        (by simpa only [Int.add_comm,Int.sub_self,show a+b-b=a by omega] using first))
  subst r
  refine ⟨rfl,?_⟩
  rcases hs with hs | hs
  · subst s
    apply False.elim
    apply no_left_junction_after_first_short ha hb hab hm T bars
    · simpa only [Int.add_zero,Int.sub_zero,show a+b-b=a by omega] using first
    · simpa only [Int.add_zero,Int.sub_zero,show 1+b+1=b+2 by omega] using second
  · exact hs


#print axioms first_two_bars_all
#print axioms no_left_junction_after_first_short
#print axioms no_first_short_away_all
end PolyominoFormal.LHalfPlaneAlternating

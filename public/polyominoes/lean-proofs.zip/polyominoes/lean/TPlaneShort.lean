import THalfPlaneUnit
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
namespace PolyominoFormal.TPlaneShort
open CrossUnits TBoundary THalfPlaneStarters THalfPlaneGaps

def CornerForms (a b c p h : Int) (t : Cross) : Prop :=
  ∃ r, (r=a ∨ r=c) ∧
    (t=⟨p+r,h,a+c-r,b,r,0⟩ ∨ t=⟨p+r,h,a+c-r,0,r,b⟩ ∨
     t=⟨p,h+r,b,a+c-r,0,r⟩ ∨ t=⟨p,h+r,0,a+c-r,b,r⟩ ∨
     t=⟨p+b,h,0,a+c-r,b,r⟩ ∨ t=⟨p,h+b,a+c-r,0,r,b⟩)

theorem corner_forms {a b c p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    {t : Cross} (copy : Copy a b c 0 t) (hit : Contains t p h)
    (left : ¬Contains t (p-1) h) (below : ¬Contains t p (h-1)) :
    CornerForms a b c p h t := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with cp | cp | cp | cp | cp | cp | cp | cp
  all_goals rcases cp with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp [Contains] at hit left below
  · refine ⟨c,Or.inr rfl,Or.inl ?_⟩
    apply same_eq; dsimp [Same]; omega
  · refine ⟨a,Or.inl rfl,Or.inr (Or.inr (Or.inl ?_))⟩
    apply same_eq; dsimp [Same]; omega
  · by_cases hy : y=h
    · refine ⟨a,Or.inl rfl,Or.inr (Or.inl ?_)⟩
      apply same_eq; dsimp [Same]; omega
    · refine ⟨a,Or.inl rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ?_))))⟩
      apply same_eq; dsimp [Same]; omega
  · by_cases hx : x=p
    · refine ⟨c,Or.inr rfl,Or.inr (Or.inr (Or.inr (Or.inl ?_)))⟩
      apply same_eq; dsimp [Same]; omega
    · refine ⟨c,Or.inr rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ?_))))⟩
      apply same_eq; dsimp [Same]; omega
  · by_cases hx : x=p
    · refine ⟨a,Or.inl rfl,Or.inr (Or.inr (Or.inr (Or.inl ?_)))⟩
      apply same_eq; dsimp [Same]; omega
    · refine ⟨a,Or.inl rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ?_))))⟩
      apply same_eq; dsimp [Same]; omega
  · refine ⟨a,Or.inl rfl,Or.inl ?_⟩
    apply same_eq; dsimp [Same]; omega
  · refine ⟨c,Or.inr rfl,Or.inr (Or.inr (Or.inl ?_))⟩
    apply same_eq; dsimp [Same]; omega
  · by_cases hy : y=h
    · refine ⟨c,Or.inr rfl,Or.inr (Or.inl ?_)⟩
      apply same_eq; dsimp [Same]; omega
    · refine ⟨c,Or.inr rfl,Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ?_))))⟩
      apply same_eq; dsimp [Same]; omega

/-- A corner has only two surviving crossbar types in the short-stem
regime; the bar extending away from the corner has its stem pointing back. -/
theorem concave_right {a b c e : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) (he : e=a ∨ e=c) (T : Tiling a b c 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+c-e,0⟩) {t : Cross}
    (ht : T.world t) (hit : Contains t 1 1) :
    ∃r,(r=a ∨ r=c) ∧
      (t=⟨1+r,1,a+c-r,0,r,b⟩ ∨ t=⟨1,1+r,0,a+c-r,b,r⟩) := by
  have empty : ¬Contains ⟨0,0,e,b,a+c-e,0⟩ 1 1 := by dsimp [Contains]; omega
  have avoid : ∀{x y}, Contains ⟨0,0,e,b,a+c-e,0⟩ x y → ¬Contains t x y :=
    fun blocked => avoid_closed (single_closed T ho) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by right; dsimp; omega)) (avoid (by left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    exfalso
    apply blocked_short_run (L:=1) (R:=r) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · exact ⟨r,hr,Or.inl eq⟩
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose
    have ho' : U.world ⟨0,0,b,e,0,a+c-e⟩ := ⟨_,ho,rfl⟩
    have ht' : U.world ⟨1+r,1,a+c-r,b,r,0⟩ := ⟨_,ht,rfl⟩
    apply blocked_short_run (L:=1) (R:=r) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) U _ (pair_closed U ho' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · exact ⟨r,hr,Or.inr eq⟩
  · subst t
    exfalso
    apply blocked_short_run (L:=1) (R:=b) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose
    have ho' : U.world ⟨0,0,b,e,0,a+c-e⟩ := ⟨_,ho,rfl⟩
    have ht' : U.world ⟨1+b,1,0,a+c-r,b,r⟩ := ⟨_,ht,rfl⟩
    apply blocked_short_run (L:=1) (R:=b) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) U _ (pair_closed U ho' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega

theorem antiparallel_first {a b c e s : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) (he : e=a ∨ e=c) (hs : s=a ∨ s=c)
    (T : Tiling a b c 0 Plane) (ho : T.world ⟨0,0,e,b,a+c-e,0⟩)
    (hu : T.world ⟨1+s,1,a+c-s,0,s,b⟩) :
    ∃r,(r=a ∨ r=c) ∧ T.world ⟨1,2+r,0,a+c-r,b,r⟩ := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 2 True.intro
  have empty : ¬(Contains ⟨0,0,e,b,a+c-e,0⟩ 1 2 ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ 1 2) := by dsimp [Contains]; omega
  have avoid : ∀{x y}, (Contains ⟨0,0,e,b,a+c-e,0⟩ x y ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ x y) → ¬Contains t x y :=
    fun blocked => avoid_closed (pair_closed T ho hu) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by left; right; dsimp; omega)) (avoid (by right; left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    exfalso
    apply blocked_short_run (L:=1) (R:=r) (h:=3) (by omega) (by omega) (by omega)
      short (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ (1+r) 1 ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.y eq; dsimp at h; omega
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose
    have hu' : U.world ⟨1,1+s,0,a+c-s,b,s⟩ := ⟨_,hu,rfl⟩
    have ht' : U.world ⟨2+r,1,a+c-r,b,r,0⟩ := ⟨_,ht,rfl⟩
    apply blocked_short_run (L:=2) (R:=1+r) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) U _ (pair_closed U hu' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · subst t; exact ⟨r,hr,ht⟩
  · subst t
    have eq := T.disjoint _ _ (1+b) 1 ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.y eq; dsimp at h; omega
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose
    have hu' : U.world ⟨1,1+s,0,a+c-s,b,s⟩ := ⟨_,hu,rfl⟩
    have ht' : U.world ⟨2+b,1,0,a+c-r,b,r⟩ := ⟨_,ht,rfl⟩
    apply blocked_short_run (L:=2) (R:=1+b) (h:=2) (by omega) (by omega) (by omega)
      short (by omega) (by omega) U _ (pair_closed U hu' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega

theorem antiparallel_impossible {a b c e s : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) (he : e=a ∨ e=c) (hs : s=a ∨ s=c)
    (T : Tiling a b c 0 Plane) (ho : T.world ⟨0,0,e,b,a+c-e,0⟩)
    (hu : T.world ⟨1+s,1,a+c-s,0,s,b⟩) : False := by
  obtain ⟨v,hv,hw⟩ := antiparallel_first ha hc hb short he hs T ho hu
  obtain ⟨t,ht,hit⟩ := T.cover 2 2 True.intro
  have empty : ¬(Contains ⟨1,2+v,0,a+c-v,b,v⟩ 2 2 ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ 2 2) := by dsimp [Contains]; omega
  have avoid : ∀{x y}, (Contains ⟨1,2+v,0,a+c-v,b,v⟩ x y ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ x y) → ¬Contains t x y :=
    fun blocked => avoid_closed (pair_closed T hw hu) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by left; right; dsimp; omega)) (avoid (by right; left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    apply blocked_short_run (L:=2) (R:=1+r) (h:=3) (by omega) (by omega) (by omega)
      short (by omega) (by omega) T _ (pair_closed T hw ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ (2+r) 1 ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.y eq; dsimp at h; omega
  · subst t
    let U : Tiling a b c 0 Plane := T.transpose
    have hu' : U.world ⟨1,1+s,0,a+c-s,b,s⟩ := ⟨_,hu,rfl⟩
    have ht' : U.world ⟨2+r,2,a+c-r,b,r,0⟩ := ⟨_,ht,rfl⟩
    apply blocked_short_run (L:=2) (R:=1+r) (h:=3) (by omega) (by omega) (by omega)
      short (by omega) (by omega) U _ (pair_closed U hu' ht')
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · left; right; dsimp; omega
    · right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ 1 (2+r) ht hw
      (by left; dsimp; omega) (by right; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega
  · subst t
    by_cases small : b<a+c
    · have eq := T.disjoint _ _ (2+b) 1 ht hu
        (by right; dsimp; omega) (by left; dsimp; omega)
      have h := congrArg Cross.y eq; dsimp at h; omega
    · have beq : b=a+c := by omega
      apply blocked_short_run (L:=2) (R:=b+1) (h:=3) (by omega) (by omega) (by omega)
        short (by omega) (by omega) T _ (pair_closed T hw ht)
      · intros; trivial
      · intro x h0 h1; dsimp [Contains]; omega
      · intro x h0 h1; right; left; dsimp; omega
      · left; right; dsimp; omega
      · right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ 1 (2+b) ht hw
      (by left; dsimp; omega) (by right; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega

theorem right_forced_vertical {a b c e : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) (he : e=a ∨ e=c) (T : Tiling a b c 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+c-e,0⟩) :
    ∃r,(r=a ∨ r=c) ∧ T.world ⟨1,1+r,0,a+c-r,b,r⟩ := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 1 True.intro
  obtain ⟨r,hr,form⟩ := concave_right ha hc hb short he T ho ht hit
  rcases form with eq | eq
  · subst t
    exact False.elim (antiparallel_impossible ha hc hb short he hr T ho ht)
  · subst t; exact ⟨r,hr,ht⟩

theorem no_anchored_plane {a b c : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) (T : Tiling a b c 0 Plane)
    (ho : T.world ⟨0,0,a,b,c,0⟩) : False := by
  obtain ⟨r,hr,ht⟩ := right_forced_vertical ha hc hb short (Or.inl rfl) T
    (by simpa only [show a+c-a=c by omega] using ho)
  let U : Tiling a b c 0 Plane := T.mirrorX
  have ho' : U.world ⟨0,0,c,b,a,0⟩ := ⟨_,ho,rfl⟩
  obtain ⟨s,hs,hu'⟩ := right_forced_vertical ha hc hb short (Or.inr rfl) U
    (by simpa only [show a+c-c=a by omega] using ho')
  have hu : T.world ⟨-1,1+s,b,a+c-s,0,s⟩ := by
    rcases hu' with ⟨u,hu,eq⟩
    have back : u=⟨-1,1+s,b,a+c-s,0,s⟩ := by
      have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      have he := congrArg Cross.east eq
      have hn := congrArg Cross.north eq
      have hw := congrArg Cross.west eq
      have hz := congrArg Cross.south eq
      apply same_eq; dsimp [Same,mirrorX] at *; omega
    simpa only [back] using hu
  by_cases heights : r≤s
  · have eq := T.disjoint _ _ (-1) (1+r) ht hu
      (by left; dsimp; omega) (by right; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega
  · have eq := T.disjoint _ _ 1 (1+s) ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega

theorem no_plane {a b c : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b)
    (short : b≤a+c) : ¬Tiles a b c 0 Plane := by
  rintro ⟨T⟩
  obtain ⟨U,ho⟩ := normalize_plane T
  exact no_anchored_plane ha hc hb short U ho

#print axioms corner_forms
#print axioms concave_right
#print axioms antiparallel_first
#print axioms antiparallel_impossible
#print axioms no_plane
end PolyominoFormal.TPlaneShort

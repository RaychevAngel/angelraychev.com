import TBoundary
import RectangleRep

namespace PolyominoFormal
namespace TRepObstruction
open CrossUnits TBoundary

def CornerRegion (R : Region) : Prop :=
  (∀ x y, R x y → Quadrant x y) ∧
  (∀ x y, 0≤x → x≤1 → 0≤y → y≤1 → R x y)

theorem corner_bounds {a b c : Int} {R : Region}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (T : Tiling a b c 0 R) (region : CornerRegion R) {t : Cross} (ht : T.world t) :
    0≤t.x-t.west ∧ 0≤t.y-t.south := by
  have nn := TPlane.copy_nonnegative ha hb hc (by omega) (T.copies t ht)
  have hw := region.1 _ _ (T.inside t ht (t.x-t.west) t.y
    (by unfold Contains; unfold TPlane.Nonnegative at nn; left; omega))
  have hs := region.1 _ _ (T.inside t ht t.x (t.y-t.south)
    (by unfold Contains; unfold TPlane.Nonnegative at nn; right; omega))
  exact ⟨hw.1,hs.2⟩

theorem no_horizontal_corner {a b c : Int} {R : Region}
    (ha : 2≤a) (hb : 1≤b) (hc : 2≤c)
    (T : Tiling a b c 0 R) (region : CornerRegion R)
    (anchor : T.world ⟨c,0,a,b,c,0⟩) : False := by
  obtain ⟨u,hu,hit⟩ := T.cover 0 1 (region.2 0 1 (by omega) (by omega) (by omega) (by omega))
  have ap := separate (by omega) (by omega) (by omega) T hu anchor hit
    (by simp only [Contains]; omega)
  have forms := beside_horizontal ha hb hc (T.copies u hu)
    (corner_bounds (by omega) (by omega) (by omega) T region hu) hit ap
  obtain ⟨v,hv,hitv⟩ := T.cover 1 1 (region.2 1 1 (by omega) (by omega) (by omega) (by omega))
  have apv := separate (by omega) (by omega) (by omega) T hv anchor hitv
    (by simp only [Contains]; omega)
  have apu : Apart v u := separate (by omega) (by omega) (by omega) T hv hu hitv (by
    rcases forms with rfl | rfl <;> simp only [Contains] <;> omega)
  apply blocked_diagonal ha hb hc (T.copies v hv)
    (corner_bounds (by omega) (by omega) (by omega) T region hv) hitv apv
  rcases forms with rfl | rfl
  · exact Or.inl apu
  · exact Or.inr apu

theorem no_corner_region {a b c : Int} {R : Region}
    (ha : 2≤a) (hb : 1≤b) (hc : 2≤c) (region : CornerRegion R) :
    ¬Tiles a b c 0 R := by
  rintro ⟨T⟩
  obtain ⟨t,ht,hit⟩ := T.cover 0 0 (region.2 0 0 (by omega) (by omega) (by omega) (by omega))
  have forms := corner_forms (by omega : 1≤a) hb (by omega : 1≤c) (T.copies t ht)
    (corner_bounds (by omega) (by omega) (by omega) T region ht) hit
  have transposed : CornerRegion (fun x y => R y x) := by
    constructor
    · intro x y hxy
      have h := region.1 y x hxy
      exact ⟨h.2,h.1⟩
    · intro x y hx hx1 hy hy1
      exact region.2 y x hy hy1 hx hx1
  rcases forms with rfl | rfl | rfl | rfl
  · exact no_horizontal_corner ha hb hc T region ht
  · exact no_horizontal_corner hc hb ha (swapArms T) region ht
  · have hU : T.transpose.world ⟨c,0,a,b,c,0⟩ := ⟨_,ht,rfl⟩
    exact no_horizontal_corner ha hb hc T.transpose transposed hU
  · have hU : T.transpose.world ⟨a,0,c,b,a,0⟩ := ⟨_,ht,rfl⟩
    exact no_horizontal_corner hc hb ha (swapArms T.transpose) transposed hU

theorem no_scaled_copy {a b c k : Int}
    (ha : 2≤a) (hb : 1≤b) (hc : 2≤c) (hk : 2≤k) :
    ¬Tiles a b c 0 (CoreBoundaryObstructions.ScaledCross a b c 0 k) := by
  rintro ⟨T⟩
  let R : Region := fun x y => CoreBoundaryObstructions.ScaledCross a b c 0 k (x-c*k) y
  let U : Tiling a b c 0 R := (T.translate (c*k) 0).congr (by intro x y; simp [R])
  have ak := Int.mul_nonneg (by omega : 0≤a) (by omega : 0≤k)
  have ck := Int.mul_nonneg (by omega : 0≤c) (by omega : 0≤k)
  have region : CornerRegion R := by
    constructor
    · intro x y hit
      unfold R CoreBoundaryObstructions.ScaledCross at hit
      simp only [Int.zero_mul,Int.neg_mul] at hit
      unfold Quadrant
      omega
    · intro x y hx hx1 hy hy1
      unfold R CoreBoundaryObstructions.ScaledCross
      left
      simp only [Int.neg_mul,Int.add_mul,Int.one_mul]
      exact ⟨by omega,by omega,hy,by omega⟩
  exact no_corner_region ha hb hc region ⟨U⟩

theorem no_rep {a b c : Int} (ha : 2≤a) (hb : 1≤b) (hc : 2≤c) :
    ¬RepTileable a b c 0 := by
  rintro ⟨k,hk,tiled⟩
  exact no_scaled_copy ha hb hc (by omega) tiled

#print axioms no_rep
end TRepObstruction
end PolyominoFormal

import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3583 a b) ∨ (fact_9fdb227ae99d_3587 a b) ∨ (fact_9fdb227ae99d_4720 a b) ∨ (fact_9fdb227ae99d_5750 a b) ∨ (fact_9fdb227ae99d_4339 a b) ∨ (((((-1 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3589 a b) ∨ (fact_9fdb227ae99d_4484 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4487 a b) ∨ (fact_9fdb227ae99d_4489 a b) ∨ (fact_9fdb227ae99d_5543 a b) ∨ (fact_9fdb227ae99d_6324 a b) ∨ (fact_9fdb227ae99d_5199 a b) ∨ (((((-1 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4490 a b) ∨ (fact_9fdb227ae99d_5340 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7548 a b) ∨ (fact_9fdb227ae99d_7646 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7548 a b) ∧ (fact_9fdb227ae99d_7646 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7548 a b) ∧ (fact_9fdb227ae99d_7646 a b) ∧ (((fact_9fdb227ae99d_4350 a b) ∨ (fact_9fdb227ae99d_4367 a b) ∨ (fact_9fdb227ae99d_5460 a b) ∨ (fact_9fdb227ae99d_6183 a b) ∨ (fact_9fdb227ae99d_5118 a b) ∨ (fact_9fdb227ae99d_4438 a b) ∨ (fact_9fdb227ae99d_5221 a b) ∨ (fact_9fdb227ae99d_4467 a b) ∨ (fact_9fdb227ae99d_4377 a b) ∨ (fact_9fdb227ae99d_5249 a b)) ∨ ((fact_9fdb227ae99d_5267 a b) ∨ (fact_9fdb227ae99d_5276 a b) ∨ (fact_9fdb227ae99d_5834 a b) ∨ (fact_9fdb227ae99d_6767 a b) ∨ (fact_9fdb227ae99d_5668 a b) ∨ (fact_9fdb227ae99d_5329 a b) ∨ (fact_9fdb227ae99d_5775 a b) ∨ (fact_9fdb227ae99d_5337 a b) ∨ (fact_9fdb227ae99d_5281 a b) ∨ (fact_9fdb227ae99d_5783 a b)))) ∨ ((fact_9fdb227ae99d_7548 a b) ∧ (fact_9fdb227ae99d_7646 a b) ∧ ((fact_9fdb227ae99d_4350 a b) ∨ (fact_9fdb227ae99d_4367 a b) ∨ (fact_9fdb227ae99d_5460 a b) ∨ (fact_9fdb227ae99d_6183 a b) ∨ (fact_9fdb227ae99d_5118 a b) ∨ (fact_9fdb227ae99d_4438 a b) ∨ (fact_9fdb227ae99d_5221 a b) ∨ (fact_9fdb227ae99d_4467 a b) ∨ (fact_9fdb227ae99d_4377 a b) ∨ (fact_9fdb227ae99d_5249 a b)) ∧ ((fact_9fdb227ae99d_5267 a b) ∨ (fact_9fdb227ae99d_5276 a b) ∨ (fact_9fdb227ae99d_5834 a b) ∨ (fact_9fdb227ae99d_6767 a b) ∨ (fact_9fdb227ae99d_5668 a b) ∨ (fact_9fdb227ae99d_5329 a b) ∨ (fact_9fdb227ae99d_5775 a b) ∨ (fact_9fdb227ae99d_5337 a b) ∨ (fact_9fdb227ae99d_5281 a b) ∨ (fact_9fdb227ae99d_5783 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) + a) < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h4 : ((2 : Int) ≤ run_x))
    (h5 : (run_x ≤ ((-1 : Int) + a)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2697 a b run_x) ∨ (fact_9fdb227ae99d_3044 a b run_x) ∨ (fact_9fdb227ae99d_2732 a b run_x) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3046 a b run_x)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3356 a b run_x) ∨ (fact_9fdb227ae99d_3744 a b run_x) ∨ (fact_9fdb227ae99d_3361 a b run_x) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3746 a b run_x))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((-1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3624 a b) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3168 a b) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7527 a b) ∨ (fact_9fdb227ae99d_7412 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7527 a b) ∧ (fact_9fdb227ae99d_7412 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7527 a b) ∧ (fact_9fdb227ae99d_7412 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4439 a b) ∨ (fact_9fdb227ae99d_5222 a b) ∨ (fact_9fdb227ae99d_4468 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_4482 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3515 a b) ∨ (fact_9fdb227ae99d_4278 a b) ∨ (fact_9fdb227ae99d_3538 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_3546 a b)))) ∨ ((fact_9fdb227ae99d_7527 a b) ∧ (fact_9fdb227ae99d_7412 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4439 a b) ∨ (fact_9fdb227ae99d_5222 a b) ∨ (fact_9fdb227ae99d_4468 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_4482 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3515 a b) ∨ (fact_9fdb227ae99d_4278 a b) ∨ (fact_9fdb227ae99d_3538 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_3546 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2697 a b run_x) ∨ (fact_9fdb227ae99d_3044 a b run_x) ∨ (fact_9fdb227ae99d_2732 a b run_x) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))))))
    (h1 : ((((2 : Int) + a) < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (run_x ≤ a))
    (h3 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n364_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3356 a b run_x) ∨ (fact_9fdb227ae99d_3744 a b run_x) ∨ (fact_9fdb227ae99d_3361 a b run_x) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ a))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5686 a b) ∨ (fact_9fdb227ae99d_5699 a b) ∨ (fact_9fdb227ae99d_6367 a b) ∨ (fact_9fdb227ae99d_6963 a b) ∨ (fact_9fdb227ae99d_5993 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5706 a b) ∨ (fact_9fdb227ae99d_6985 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3415 a b) ∨ (fact_9fdb227ae99d_3433 a b) ∨ (fact_9fdb227ae99d_4508 a b) ∨ (fact_9fdb227ae99d_5592 a b) ∨ (fact_9fdb227ae99d_3880 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3447 a b) ∨ (fact_9fdb227ae99d_5728 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7787 a b) ∨ (fact_9fdb227ae99d_7531 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7787 a b) ∧ (fact_9fdb227ae99d_7531 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7787 a b) ∧ (fact_9fdb227ae99d_7531 a b) ∧ (((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6243 a b) ∨ (fact_9fdb227ae99d_6705 a b) ∨ (fact_9fdb227ae99d_6291 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∨ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4234 a b) ∨ (fact_9fdb227ae99d_5075 a b) ∨ (fact_9fdb227ae99d_4282 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b)))) ∨ ((fact_9fdb227ae99d_7787 a b) ∧ (fact_9fdb227ae99d_7531 a b) ∧ ((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6243 a b) ∨ (fact_9fdb227ae99d_6705 a b) ∨ (fact_9fdb227ae99d_6291 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∧ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4234 a b) ∨ (fact_9fdb227ae99d_5075 a b) ∨ (fact_9fdb227ae99d_4282 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ (fact_9fdb227ae99d_2481 a b run_x) ∨ (fact_9fdb227ae99d_2397 a b run_x) ∨ (fact_9fdb227ae99d_3615 a b run_x)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h5 : ((-4 : Int) ≥ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n365_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ (fact_9fdb227ae99d_3242 a b run_x) ∨ (fact_9fdb227ae99d_3196 a b run_x) ∨ (fact_9fdb227ae99d_5362 a b run_x))))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3467 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3121 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7382 a b) ∨ (fact_9fdb227ae99d_7297 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7382 a b) ∧ (fact_9fdb227ae99d_7297 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7382 a b) ∧ (fact_9fdb227ae99d_7297 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_4838 a b) ∨ (fact_9fdb227ae99d_3997 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3695 a b) ∨ (fact_9fdb227ae99d_3313 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7382 a b) ∧ (fact_9fdb227ae99d_7297 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_4838 a b) ∨ (fact_9fdb227ae99d_3997 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3695 a b) ∨ (fact_9fdb227ae99d_3313 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2532 a b run_x) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n366_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3217 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ a))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_tall (a b : Int)
    (h0 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7524 a b) ∨ (fact_9fdb227ae99d_7318 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7524 a b) ∧ (fact_9fdb227ae99d_7318 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7524 a b) ∧ (fact_9fdb227ae99d_7318 a b) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))))) ∨ ((fact_9fdb227ae99d_4065 a b) ∨ (fact_9fdb227ae99d_4093 a b) ∨ (fact_9fdb227ae99d_5299 a b) ∨ (fact_9fdb227ae99d_5914 a b) ∨ (fact_9fdb227ae99d_4728 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5069 a b) ∨ (fact_9fdb227ae99d_6156 a b)))) ∨ ((fact_9fdb227ae99d_7524 a b) ∧ (fact_9fdb227ae99d_7318 a b) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))))) ∧ ((fact_9fdb227ae99d_4065 a b) ∨ (fact_9fdb227ae99d_4093 a b) ∨ (fact_9fdb227ae99d_5299 a b) ∨ (fact_9fdb227ae99d_5914 a b) ∨ (fact_9fdb227ae99d_4728 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5069 a b) ∨ (fact_9fdb227ae99d_6156 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((-3 : Int) ≥ run_x))
    (h6 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2926 a b run_x) ∨ (fact_9fdb227ae99d_2464 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n367_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3488 a b run_x) ∨ (fact_9fdb227ae99d_3220 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))))))
    (h1 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-3 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5683 a b) ∨ (fact_9fdb227ae99d_5696 a b) ∨ (fact_9fdb227ae99d_6364 a b) ∨ (fact_9fdb227ae99d_6960 a b) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5760 a b) ∨ (fact_9fdb227ae99d_6978 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3411 a b) ∨ (fact_9fdb227ae99d_3429 a b) ∨ (fact_9fdb227ae99d_4504 a b) ∨ (fact_9fdb227ae99d_5588 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3507 a b) ∨ (fact_9fdb227ae99d_5722 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7369 a b) ∨ (fact_9fdb227ae99d_7246 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7369 a b) ∧ (fact_9fdb227ae99d_7246 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7369 a b) ∧ (fact_9fdb227ae99d_7246 a b) ∧ (((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6579 a b) ∨ (fact_9fdb227ae99d_6224 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∨ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4724 a b) ∨ (fact_9fdb227ae99d_4221 a b) ∨ (fact_9fdb227ae99d_6143 a b)))) ∨ ((fact_9fdb227ae99d_7369 a b) ∧ (fact_9fdb227ae99d_7246 a b) ∧ ((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6579 a b) ∨ (fact_9fdb227ae99d_6224 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∧ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4724 a b) ∨ (fact_9fdb227ae99d_4221 a b) ∨ (fact_9fdb227ae99d_6143 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2926 a b run_x) ∨ (fact_9fdb227ae99d_2464 a b run_x) ∨ (fact_9fdb227ae99d_3606 a b run_x)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : ((-2 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n368_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3488 a b run_x) ∨ (fact_9fdb227ae99d_3220 a b run_x) ∨ (fact_9fdb227ae99d_5350 a b run_x))))
    (h1 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-2 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3091 a b) ∨ ((((-2 : Int) ≥ ((-1 : Int) - b)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (b = (5 : Int)))
    (h8 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (fact_9fdb227ae99d_2924 a b jy))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ ((0 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o4 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))) ∨ (((-2 : Int) = jx) ∧ ((0 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n369_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_3126 a b) ∨ ((((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h3 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2924 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n370_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h3 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + b) - b)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (0 : Int)))))))
    (h4 : (b = (5 : Int)))
    (h5 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h3 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o1 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2924 a b jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o3 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h8 : (¬ ((((-3 : Int) = jx) ∧ ((0 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h6 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n371_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_short (a b : Int)
    (h0 : (¬ ((b - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7544 a b) ∨ (fact_9fdb227ae99d_7435 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7544 a b) ∧ (fact_9fdb227ae99d_7435 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7544 a b) ∧ (fact_9fdb227ae99d_7435 a b) ∧ (((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7077 a b)) ∨ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))))))) ∨ ((fact_9fdb227ae99d_7544 a b) ∧ (fact_9fdb227ae99d_7435 a b) ∧ ((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7077 a b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b)))))))))
    (h1 : (a ≥ b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (run_x ≤ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) + a) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h7 : ((fact_9fdb227ae99d_3628 a b run_x) ∨ (fact_9fdb227ae99d_3637 a b run_x) ∨ (fact_9fdb227ae99d_5036 a b run_x) ∨ (fact_9fdb227ae99d_5789 a b run_x) ∨ (fact_9fdb227ae99d_4411 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n372_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (run_x ≤ b))
    (h2 : (¬ ((fact_9fdb227ae99d_5411 a b run_x) ∨ (fact_9fdb227ae99d_5414 a b run_x) ∨ (fact_9fdb227ae99d_5989 a b run_x) ∨ (fact_9fdb227ae99d_6842 a b run_x) ∨ (fact_9fdb227ae99d_5795 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((1 : Int) ≤ b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_tall (a b : Int)
    (h0 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7327 a b) ∨ (fact_9fdb227ae99d_7271 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7327 a b) ∧ (fact_9fdb227ae99d_7271 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7327 a b) ∧ (fact_9fdb227ae99d_7271 a b) ∧ (((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b))))) ∨ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b))))))) ∨ ((fact_9fdb227ae99d_7327 a b) ∧ (fact_9fdb227ae99d_7271 a b) ∧ ((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b))))) ∧ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ b))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : ((((2 : Int) + a) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-3 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-3 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n373_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))))))
    (h1 : (run_x ≤ b))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_3126 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + a))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_2922 a b jy))
    (h6 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n374_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_3126 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - a)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2923 a b jy))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2924 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_2922 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ ((((((jy = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = ((jx + a) + (1 : Int))) ∨ (jx = (((0 : Int) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((0 : Int) = jy) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = ((jx + b) + (1 : Int))) ∨ ((((0 : Int) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n375_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_empty (a b : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_3126 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - a)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + b))))))
    (h2 : ((((2 : Int) + ((2 : Int) * b)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o0 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2923 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h2 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_2922 a b jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o6 (a b jx jy : Int)
    (h0 : (¬ ((((((jy = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = ((jx + a) + (1 : Int))) ∨ (jx = (((0 : Int) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((0 : Int) = jy) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = ((jx + b) + (1 : Int))) ∨ ((((0 : Int) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (jx + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((0 : Int) = (jx - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((0 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (jx = ((0 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n376_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2925 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5683 a b) ∨ (fact_9fdb227ae99d_5696 a b) ∨ (fact_9fdb227ae99d_6364 a b) ∨ (fact_9fdb227ae99d_6960 a b) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6978 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3411 a b) ∨ (fact_9fdb227ae99d_3429 a b) ∨ (fact_9fdb227ae99d_4504 a b) ∨ (fact_9fdb227ae99d_5588 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5722 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7386 a b) ∨ (fact_9fdb227ae99d_7250 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7386 a b) ∧ (fact_9fdb227ae99d_7250 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7386 a b) ∧ (fact_9fdb227ae99d_7250 a b) ∧ (((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6579 a b) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7072 a b)) ∨ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4724 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6143 a b)))) ∨ ((fact_9fdb227ae99d_7386 a b) ∧ (fact_9fdb227ae99d_7250 a b) ∧ ((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6579 a b) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7072 a b)) ∧ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4724 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6143 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2926 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3606 a b run_x)))
    (h2 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : ((-2 : Int) ≥ run_x))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n377_run_floor (a b run_x : Int)
    (h0 : ((-2 : Int) ≥ run_x))
    (h1 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3488 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5350 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2950 a b)))
    (h2 : (((-1 : Int) > ((2 : Int) + ((2 : Int) * b))) ∨ ((-1 : Int) < ((2 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < ((0 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o0 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h6 : (b = (5 : Int)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o6 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n378_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3091 a b) ∨ (fact_9fdb227ae99d_2955 a b)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_7276 a b jx jy))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n379_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_7277 a b jx jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_empty (a b : Int)
    (h0 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_9fdb227ae99d_2864 a b) ∨ (fact_9fdb227ae99d_2866 a b) ∨ (fact_9fdb227ae99d_3260 a b) ∨ (fact_9fdb227ae99d_4167 a b) ∨ ((((-2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-2 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≥ ((2 : Int) + a)) ∧ ((-2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2956 a b) ∨ (fact_9fdb227ae99d_4394 a b)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((jx < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2923 a b jy))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_7276 a b jx jy))
    (h5 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((-2 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n380_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_29 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ ((((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≥ ((1 : Int) + b))) ∨ (((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((-2 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((-2 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o0 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h8 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h10 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h11 : (b = (5 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h6 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o2 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n381_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_2925 a b jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5689 a b) ∨ (fact_9fdb227ae99d_5702 a b) ∨ (fact_9fdb227ae99d_6370 a b) ∨ (fact_9fdb227ae99d_6966 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5758 a b) ∨ (fact_9fdb227ae99d_6977 a b) ∨ (fact_9fdb227ae99d_6261 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_6311 a b) ∨ (fact_9fdb227ae99d_6312 a b) ∨ (fact_9fdb227ae99d_6882 a b) ∨ (fact_9fdb227ae99d_7057 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6325 a b) ∨ (fact_9fdb227ae99d_7119 a b) ∨ (fact_9fdb227ae99d_6779 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7522 a b) ∨ (fact_9fdb227ae99d_7613 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7522 a b) ∧ (fact_9fdb227ae99d_7613 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7522 a b) ∧ (fact_9fdb227ae99d_7613 a b) ∧ (((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6570 a b) ∨ (fact_9fdb227ae99d_6191 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∨ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6924 a b) ∨ (fact_9fdb227ae99d_6769 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b)))) ∨ ((fact_9fdb227ae99d_7522 a b) ∧ (fact_9fdb227ae99d_7613 a b) ∧ ((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6570 a b) ∨ (fact_9fdb227ae99d_6191 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∧ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6924 a b) ∨ (fact_9fdb227ae99d_6769 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (b = (5 : Int)))
    (h5 : (run_x ≤ ((-1 : Int) + a)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((fact_9fdb227ae99d_3627 a b run_x) ∨ (fact_9fdb227ae99d_3636 a b run_x) ∨ (fact_9fdb227ae99d_5035 a b run_x) ∨ (fact_9fdb227ae99d_5788 a b run_x) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3680 a b run_x) ∨ (fact_9fdb227ae99d_5820 a b run_x) ∨ (fact_9fdb227ae99d_4522 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n382_run_floor (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5410 a b run_x) ∨ (fact_9fdb227ae99d_5413 a b run_x) ∨ (fact_9fdb227ae99d_5988 a b run_x) ∨ (fact_9fdb227ae99d_6841 a b run_x) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5482 a b run_x) ∨ (fact_9fdb227ae99d_6897 a b run_x) ∨ (fact_9fdb227ae99d_5812 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + a)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2894 a b) ∨ ((((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o0 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n383_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h4 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2898 a b) ∨ ((((3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o5 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n384_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3391 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3899 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7507 a b) ∨ (fact_9fdb227ae99d_7620 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7507 a b) ∧ (fact_9fdb227ae99d_7620 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7507 a b) ∧ (fact_9fdb227ae99d_7620 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_5964 a b) ∨ (fact_9fdb227ae99d_3981 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_6540 a b) ∨ (fact_9fdb227ae99d_4830 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7507 a b) ∧ (fact_9fdb227ae99d_7620 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_5964 a b) ∨ (fact_9fdb227ae99d_3981 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_6540 a b) ∨ (fact_9fdb227ae99d_4830 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : (run_x ≤ ((2 : Int) + b)))
    (h6 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_3605 a b run_x) ∨ (fact_9fdb227ae99d_2479 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n385_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_5349 a b run_x) ∨ (fact_9fdb227ae99d_3239 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3393 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3896 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7512 a b) ∨ (fact_9fdb227ae99d_7615 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7512 a b) ∧ (fact_9fdb227ae99d_7615 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7512 a b) ∧ (fact_9fdb227ae99d_7615 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_5966 a b) ∨ (fact_9fdb227ae99d_3989 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_6536 a b) ∨ (fact_9fdb227ae99d_4820 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7512 a b) ∧ (fact_9fdb227ae99d_7615 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_5966 a b) ∨ (fact_9fdb227ae99d_3989 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_6536 a b) ∨ (fact_9fdb227ae99d_4820 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (run_x ≤ ((1 : Int) + a)))
    (h5 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_3604 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n386_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_5348 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3390 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3898 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7388 a b) ∨ (fact_9fdb227ae99d_7455 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7388 a b) ∧ (fact_9fdb227ae99d_7455 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7388 a b) ∧ (fact_9fdb227ae99d_7455 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_5960 a b) ∨ (fact_9fdb227ae99d_3971 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_6538 a b) ∨ (fact_9fdb227ae99d_4824 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7388 a b) ∧ (fact_9fdb227ae99d_7455 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_5960 a b) ∨ (fact_9fdb227ae99d_3971 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_6538 a b) ∨ (fact_9fdb227ae99d_4824 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((2 : Int) ≤ run_x))
    (h5 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_3605 a b run_x) ∨ (fact_9fdb227ae99d_2479 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n387_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_5349 a b run_x) ∨ (fact_9fdb227ae99d_3239 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_four (a b : Int)
    (h0 : (¬ ((-1 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_short (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) - (-1 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + b + a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5874 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6358 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-1 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7746 a b) ∨ (fact_9fdb227ae99d_7738 a b))) ∨ (((1 : Int) ≥ ((-1 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7746 a b) ∧ (fact_9fdb227ae99d_7738 a b)) ∨ ((1 : Int) ≥ ((-1 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7746 a b) ∧ (fact_9fdb227ae99d_7738 a b) ∧ (((fact_9fdb227ae99d_6438 a b) ∨ (fact_9fdb227ae99d_6452 a b) ∨ (fact_9fdb227ae99d_6948 a b) ∨ (fact_9fdb227ae99d_7126 a b) ∨ (fact_9fdb227ae99d_6844 a b) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_7143 a b) ∨ (fact_9fdb227ae99d_6517 a b) ∨ (fact_9fdb227ae99d_6869 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_7137 a b) ∨ (fact_9fdb227ae99d_6427 a b) ∨ (fact_9fdb227ae99d_6796 a b)))) ∨ ((fact_9fdb227ae99d_7746 a b) ∧ (fact_9fdb227ae99d_7738 a b) ∧ ((fact_9fdb227ae99d_6438 a b) ∨ (fact_9fdb227ae99d_6452 a b) ∨ (fact_9fdb227ae99d_6948 a b) ∨ (fact_9fdb227ae99d_7126 a b) ∨ (fact_9fdb227ae99d_6844 a b) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((0 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_7143 a b) ∨ (fact_9fdb227ae99d_6517 a b) ∨ (fact_9fdb227ae99d_6869 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_7137 a b) ∨ (fact_9fdb227ae99d_6427 a b) ∨ (fact_9fdb227ae99d_6796 a b))))))
    (h1 : (a ≥ b))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4220 a b run_x) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4997 a b run_x)))
    (h1 : (a ≥ b))
    (h2 : ((1 : Int) ≥ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((-1 : Int) ≤ run_x))
    (h5 : (a > b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n388_run_floor (a b run_x : Int)
    (h0 : ((-1 : Int) ≤ run_x))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5670 a b run_x) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5956 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2870 a b) ∨ (fact_9fdb227ae99d_2872 a b) ∨ (fact_9fdb227ae99d_3262 a b) ∨ (fact_9fdb227ae99d_4169 a b) ∨ (fact_9fdb227ae99d_3101 a b) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2873 a b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (((jx + a) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o2 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((-3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o6 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n389_o7 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (a + (1 : Int))) ∧ ((3 : Int) ≥ (a + (1 : Int)))) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7564 a b) ∨ (fact_9fdb227ae99d_7436 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7564 a b) ∧ (fact_9fdb227ae99d_7436 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7564 a b) ∧ (fact_9fdb227ae99d_7436 a b) ∧ (((fact_9fdb227ae99d_4346 a b) ∨ (fact_9fdb227ae99d_4363 a b) ∨ (fact_9fdb227ae99d_5456 a b) ∨ (fact_9fdb227ae99d_6179 a b) ∨ (fact_9fdb227ae99d_5114 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6333 a b) ∨ (fact_9fdb227ae99d_4455 a b) ∨ (fact_9fdb227ae99d_4375 a b) ∨ (fact_9fdb227ae99d_5231 a b)) ∨ ((fact_9fdb227ae99d_3420 a b) ∨ (fact_9fdb227ae99d_3438 a b) ∨ (fact_9fdb227ae99d_4513 a b) ∨ (fact_9fdb227ae99d_5597 a b) ∨ (fact_9fdb227ae99d_3885 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5718 a b) ∨ (fact_9fdb227ae99d_3528 a b) ∨ (fact_9fdb227ae99d_3450 a b) ∨ (fact_9fdb227ae99d_4292 a b)))) ∨ ((fact_9fdb227ae99d_7564 a b) ∧ (fact_9fdb227ae99d_7436 a b) ∧ ((fact_9fdb227ae99d_4346 a b) ∨ (fact_9fdb227ae99d_4363 a b) ∨ (fact_9fdb227ae99d_5456 a b) ∨ (fact_9fdb227ae99d_6179 a b) ∨ (fact_9fdb227ae99d_5114 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_6333 a b) ∨ (fact_9fdb227ae99d_4455 a b) ∨ (fact_9fdb227ae99d_4375 a b) ∨ (fact_9fdb227ae99d_5231 a b)) ∧ ((fact_9fdb227ae99d_3420 a b) ∨ (fact_9fdb227ae99d_3438 a b) ∨ (fact_9fdb227ae99d_4513 a b) ∨ (fact_9fdb227ae99d_5597 a b) ∨ (fact_9fdb227ae99d_3885 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5718 a b) ∨ (fact_9fdb227ae99d_3528 a b) ∨ (fact_9fdb227ae99d_3450 a b) ∨ (fact_9fdb227ae99d_4292 a b))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ a))
    (h2 : (b = (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (fact_9fdb227ae99d_2694 a b run_x) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n390_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (fact_9fdb227ae99d_3353 a b run_x) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n391_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n391_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-1 : Int) + ((-1 : Int) * a))) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

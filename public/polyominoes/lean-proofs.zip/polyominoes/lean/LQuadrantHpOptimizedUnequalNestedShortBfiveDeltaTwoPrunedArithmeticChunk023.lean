import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n644_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3415 a b) ∨ (fact_9fdb227ae99d_3433 a b) ∨ (fact_9fdb227ae99d_4508 a b) ∨ (fact_9fdb227ae99d_5592 a b) ∨ (fact_9fdb227ae99d_3880 a b) ∨ (((((-1 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3447 a b) ∨ (fact_9fdb227ae99d_5728 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n644_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7781 a b) ∨ (fact_9fdb227ae99d_7528 a b))) ∨ (((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7781 a b) ∧ (fact_9fdb227ae99d_7528 a b)) ∨ ((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-4 : Int) = (((-1 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7781 a b) ∧ (fact_9fdb227ae99d_7528 a b) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((((-4 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * b)) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((-4 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a))))) ∨ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (((((-2 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5086 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b)))) ∨ ((fact_9fdb227ae99d_7781 a b) ∧ (fact_9fdb227ae99d_7528 a b) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((((-4 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * b)) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((-4 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a))))) ∧ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (((((-2 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5086 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n644_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2473 a b run_x) ∨ (fact_9fdb227ae99d_3002 a b run_x) ∨ (fact_9fdb227ae99d_2397 a b run_x) ∨ (fact_9fdb227ae99d_3615 a b run_x)))
    (h7 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n644_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3229 a b run_x) ∨ (fact_9fdb227ae99d_3575 a b run_x) ∨ (fact_9fdb227ae99d_3196 a b run_x) ∨ (fact_9fdb227ae99d_5362 a b run_x))))
    (h3 : ((-4 : Int) ≥ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3466 a b) ∨ (fact_9fdb227ae99d_3468 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3120 a b) ∨ (fact_9fdb227ae99d_3122 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7379 a b) ∨ (fact_9fdb227ae99d_7294 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7379 a b) ∧ (fact_9fdb227ae99d_7294 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7379 a b) ∧ (fact_9fdb227ae99d_7294 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3950 a b) ∨ (fact_9fdb227ae99d_4899 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3307 a b) ∨ (fact_9fdb227ae99d_3709 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7379 a b) ∧ (fact_9fdb227ae99d_7294 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3950 a b) ∨ (fact_9fdb227ae99d_4899 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3307 a b) ∨ (fact_9fdb227ae99d_3709 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (run_x ≤ a))
    (h2 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2531 a b run_x) ∨ (fact_9fdb227ae99d_2533 a b run_x) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (b = (5 : Int)))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n645_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (run_x ≤ a))
    (h3 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3211 a b run_x) ∨ (fact_9fdb227ae99d_3227 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2894 a b) ∨ (fact_9fdb227ae99d_2896 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o4 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n646_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2898 a b) ∨ (fact_9fdb227ae99d_2902 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n647_o7 (a b jx jy : Int)
    (h0 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3391 a b) ∨ (fact_9fdb227ae99d_3401 a b) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3899 a b) ∨ (fact_9fdb227ae99d_3946 a b) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7478 a b) ∨ (fact_9fdb227ae99d_7593 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7478 a b) ∧ (fact_9fdb227ae99d_7593 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7478 a b) ∧ (fact_9fdb227ae99d_7593 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3952 a b) ∨ (fact_9fdb227ae99d_4003 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4801 a b) ∨ (fact_9fdb227ae99d_4864 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7478 a b) ∧ (fact_9fdb227ae99d_7593 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3952 a b) ∨ (fact_9fdb227ae99d_4003 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4801 a b) ∨ (fact_9fdb227ae99d_4864 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2474 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h6 : (run_x ≤ ((2 : Int) + b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n648_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3230 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3393 a b) ∨ (fact_9fdb227ae99d_3403 a b) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3896 a b) ∨ (fact_9fdb227ae99d_3943 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7484 a b) ∨ (fact_9fdb227ae99d_7587 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7484 a b) ∧ (fact_9fdb227ae99d_7587 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7484 a b) ∧ (fact_9fdb227ae99d_7587 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3958 a b) ∨ (fact_9fdb227ae99d_4011 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4795 a b) ∨ (fact_9fdb227ae99d_4854 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7484 a b) ∧ (fact_9fdb227ae99d_7587 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3958 a b) ∨ (fact_9fdb227ae99d_4011 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4795 a b) ∨ (fact_9fdb227ae99d_4854 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2473 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (b = (5 : Int)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n649_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3229 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3390 a b) ∨ (fact_9fdb227ae99d_3400 a b) ∨ (((((-3 : Int) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3898 a b) ∨ (fact_9fdb227ae99d_3945 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7356 a b) ∨ (fact_9fdb227ae99d_7427 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7356 a b) ∧ (fact_9fdb227ae99d_7427 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7356 a b) ∧ (fact_9fdb227ae99d_7427 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3948 a b) ∨ (fact_9fdb227ae99d_3995 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4799 a b) ∨ (fact_9fdb227ae99d_4860 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7356 a b) ∧ (fact_9fdb227ae99d_7427 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3948 a b) ∨ (fact_9fdb227ae99d_3995 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4799 a b) ∨ (fact_9fdb227ae99d_4860 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2474 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (run_x ≤ ((1 : Int) + b)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n650_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3230 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : (run_x ≤ ((1 : Int) + b)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_29 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3332 a b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o2 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n651_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (fact_9fdb227ae99d_2925 a b jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2820 a b) ∨ (fact_9fdb227ae99d_2822 a b) ∨ (fact_9fdb227ae99d_3204 a b) ∨ (fact_9fdb227ae99d_3850 a b) ∨ (fact_9fdb227ae99d_3066 a b) ∨ (fact_9fdb227ae99d_2899 a b) ∨ (fact_9fdb227ae99d_2903 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2823 a b)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (¬ (((jx = ((3 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (¬ ((((3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n652_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2964 a b) ∨ (fact_9fdb227ae99d_2967 a b) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_3108 a b)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h5 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o0 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o3 (a b jx jy : Int)
    (h0 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o5 (a b jx jy : Int)
    (h0 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o6 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n653_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_29 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_5157 a b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((jx + a) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h10 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o2 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h5 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b = (5 : Int)))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h5 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h6 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n654_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2925 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h4 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_6128 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_5583 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7826 a b) ∨ (fact_9fdb227ae99d_7756 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7826 a b) ∧ (fact_9fdb227ae99d_7756 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7826 a b) ∧ (fact_9fdb227ae99d_7756 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_6559 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5825 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7826 a b) ∧ (fact_9fdb227ae99d_7756 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_6559 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5825 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((1 : Int) + a) ≤ run_x))
    (h3 : (fact_9fdb227ae99d_3207 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_3663 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (run_x ≤ (b + a)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n655_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((1 : Int) + a) ≤ run_x))
    (h2 : (run_x ≤ (b + a)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_5357 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_short (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_nonnegative (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h1 : (¬ (((2 : Int) + b) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4356 a b) ∨ (fact_9fdb227ae99d_4373 a b) ∨ (fact_9fdb227ae99d_5466 a b) ∨ (fact_9fdb227ae99d_6189 a b) ∨ (fact_9fdb227ae99d_5124 a b) ∨ (fact_9fdb227ae99d_4427 a b) ∨ (fact_9fdb227ae99d_4451 a b) ∨ (fact_9fdb227ae99d_4474 a b) ∨ (fact_9fdb227ae99d_4383 a b) ∨ (fact_9fdb227ae99d_5152 a b) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + b) - (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_6326 a b))))
    (h1 : (fact_9fdb227ae99d_3478 a b))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((fact_9fdb227ae99d_4357 a b) ∨ (fact_9fdb227ae99d_4374 a b) ∨ (fact_9fdb227ae99d_5467 a b) ∨ (fact_9fdb227ae99d_6190 a b) ∨ (fact_9fdb227ae99d_5125 a b) ∨ (fact_9fdb227ae99d_4428 a b) ∨ (fact_9fdb227ae99d_4452 a b) ∨ (fact_9fdb227ae99d_4475 a b) ∨ (fact_9fdb227ae99d_4384 a b) ∨ (fact_9fdb227ae99d_5153 a b) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_6327 a b))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + b) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_9fdb227ae99d_7861 a b) ∨ (fact_9fdb227ae99d_7863 a b))) ∨ (((((2 : Int) + b) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_9fdb227ae99d_7861 a b) ∧ (fact_9fdb227ae99d_7863 a b)) ∨ ((((2 : Int) + b) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = (((2 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7861 a b) ∧ (fact_9fdb227ae99d_7863 a b) ∧ (((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5225 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_6781 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∨ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5226 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_6782 a b) ∨ (fact_9fdb227ae99d_6773 a b)))) ∨ ((fact_9fdb227ae99d_7861 a b) ∧ (fact_9fdb227ae99d_7863 a b) ∧ ((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5225 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_6781 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∧ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5226 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_6782 a b) ∨ (fact_9fdb227ae99d_6773 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + b) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : ((fact_9fdb227ae99d_2586 a b run_x) ∨ (fact_9fdb227ae99d_2591 a b run_x) ∨ (fact_9fdb227ae99d_3152 a b run_x) ∨ (fact_9fdb227ae99d_3672 a b run_x) ∨ (fact_9fdb227ae99d_3030 a b run_x) ∨ (fact_9fdb227ae99d_2692 a b run_x) ∨ (fact_9fdb227ae99d_2712 a b run_x) ∨ (fact_9fdb227ae99d_2731 a b run_x) ∨ (fact_9fdb227ae99d_2632 a b run_x) ∨ (fact_9fdb227ae99d_3035 a b run_x) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3742 a b run_x)))
    (h5 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n656_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3319 a b run_x) ∨ (fact_9fdb227ae99d_3323 a b run_x) ∨ (fact_9fdb227ae99d_4334 a b run_x) ∨ (fact_9fdb227ae99d_5468 a b run_x) ∨ (fact_9fdb227ae99d_3676 a b run_x) ∨ (fact_9fdb227ae99d_3351 a b run_x) ∨ (fact_9fdb227ae99d_3357 a b run_x) ∨ (fact_9fdb227ae99d_3360 a b run_x) ∨ (fact_9fdb227ae99d_3327 a b run_x) ∨ (fact_9fdb227ae99d_3720 a b run_x) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5550 a b run_x))))
    (h1 : (b = (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : (((2 : Int) + b) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_point (a b : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1 a b))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_3206 a b))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : ((fact_9fdb227ae99d_3051 a b) ∨ (fact_9fdb227ae99d_3053 a b) ∨ (fact_9fdb227ae99d_3563 a b) ∨ (fact_9fdb227ae99d_4701 a b) ∨ (fact_9fdb227ae99d_3285 a b) ∨ (fact_9fdb227ae99d_3112 a b) ∨ (fact_9fdb227ae99d_3115 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - a)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3055 a b) ∨ (fact_9fdb227ae99d_3292 a b) ∨ (fact_9fdb227ae99d_5105 a b) ∨ (fact_9fdb227ae99d_3598 a b)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1606 a b jx jy))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1611 a b jx jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1615 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_1618 a b jx jy))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (fact_9fdb227ae99d_1619 a b jx jy))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h3 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : ((jy - a) ≥ (0 : Int)))
    (h11 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_1614 a b jx jy))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_3037 a b))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_1610 a b jx jy))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n657_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + a) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1607 a b jx jy))
    (h4 : (b = (5 : Int)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h9 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + ((2 : Int) * b))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3061 a b) ∨ (fact_9fdb227ae99d_3062 a b) ∨ (fact_9fdb227ae99d_3567 a b) ∨ (fact_9fdb227ae99d_4706 a b) ∨ (fact_9fdb227ae99d_3298 a b) ∨ (fact_9fdb227ae99d_3118 a b) ∨ (fact_9fdb227ae99d_3119 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3063 a b) ∨ (fact_9fdb227ae99d_3299 a b) ∨ (fact_9fdb227ae99d_5106 a b) ∨ (fact_9fdb227ae99d_3599 a b) ∨ (fact_9fdb227ae99d_3568 a b)))
    (h1 : (a ≥ b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1672 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1675 a b jx jy))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - a) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o2 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1677 a b jx jy))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_1678 a b jx jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1679 a b jx jy))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1676 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - a)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1674 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n658_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1673 a b jx jy))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h10 : (fact_9fdb227ae99d_2925 a b jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_3208 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ (fact_9fdb227ae99d_2965 a b) ∨ ((((-4 : Int) ≥ ((-2 : Int) - a)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2970 a b) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + b + a)) ∧ ((4 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3266 a b)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o3 (a b jx jy : Int)
    (h0 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n659_o7 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (fact_9fdb227ae99d_5759 a b) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5778 a b) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6451 a b) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_6040 a b) ∨ (fact_9fdb227ae99d_6078 a b) ∨ (fact_9fdb227ae99d_6840 a b) ∨ (fact_9fdb227ae99d_7052 a b) ∨ (fact_9fdb227ae99d_6606 a b) ∨ (fact_9fdb227ae99d_6219 a b) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6299 a b) ∨ (fact_9fdb227ae99d_6102 a b) ∨ (fact_9fdb227ae99d_6652 a b) ∨ (fact_9fdb227ae99d_7103 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∨ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6693 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6693 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b))) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6693 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6258 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7001 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b)))) ∨ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6693 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6258 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7001 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (fact_9fdb227ae99d_3681 a b run_x) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3697 a b run_x) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5101 a b run_x) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h8 : (run_x ≤ ((3 : Int) + b)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (fact_9fdb227ae99d_3206 a b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n660_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (fact_9fdb227ae99d_5483 a b run_x) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5492 a b run_x) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6041 a b run_x) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((2 : Int) + b) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((2 : Int) + b) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_3206 a b))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-2 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-2 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-2 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-2 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-2 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((2 : Int) + a)) ∧ ((-2 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-2 : Int) - a)) ∧ ((-2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - b)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - b)) ∧ ((-2 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + b))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h9 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2923 a b jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - b))))
    (h2 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h8 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o5 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n661_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_four (a b : Int)
    (h0 : (((-4 : Int) < ((-2 : Int) - a)) ∨ ((-4 : Int) > ((-2 : Int) + (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int)))))
    (h1 : (¬ (((1 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((1 : Int) + ((2 : Int) * b)) - ((1 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_left (a b : Int)
    (h0 : (¬ (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - a)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_right (a b : Int)
    (h0 : (¬ (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - a)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((fact_9fdb227ae99d_7942 a b) ∨ ((fact_9fdb227ae99d_5952 a b) ∨ (fact_9fdb227ae99d_5954 a b) ∨ (fact_9fdb227ae99d_6785 a b) ∨ (fact_9fdb227ae99d_7012 a b) ∨ (fact_9fdb227ae99d_6494 a b) ∨ (fact_9fdb227ae99d_5997 a b) ∨ (fact_9fdb227ae99d_6000 a b) ∨ (fact_9fdb227ae99d_6001 a b) ∨ (fact_9fdb227ae99d_5955 a b) ∨ (fact_9fdb227ae99d_6535 a b) ∨ (fact_9fdb227ae99d_7056 a b) ∨ (fact_9fdb227ae99d_6855 a b) ∨ (fact_9fdb227ae99d_6793 a b) ∨ (fact_9fdb227ae99d_6003 a b) ∨ (fact_9fdb227ae99d_7053 a b)))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (fact_9fdb227ae99d_7942 a b) ∧ ((fact_9fdb227ae99d_5952 a b) ∨ (fact_9fdb227ae99d_5954 a b) ∨ (fact_9fdb227ae99d_6785 a b) ∨ (fact_9fdb227ae99d_7012 a b) ∨ (fact_9fdb227ae99d_6494 a b) ∨ (fact_9fdb227ae99d_5997 a b) ∨ (fact_9fdb227ae99d_6000 a b) ∨ (fact_9fdb227ae99d_6001 a b) ∨ (fact_9fdb227ae99d_5955 a b) ∨ (fact_9fdb227ae99d_6535 a b) ∨ (fact_9fdb227ae99d_7056 a b) ∨ (fact_9fdb227ae99d_6855 a b) ∨ (fact_9fdb227ae99d_6793 a b) ∨ (fact_9fdb227ae99d_6003 a b) ∨ (fact_9fdb227ae99d_7053 a b))) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∨ ((((1 : Int) + ((2 : Int) * b)) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7942 a b) ∧ ((fact_9fdb227ae99d_5952 a b) ∨ (fact_9fdb227ae99d_5954 a b) ∨ (fact_9fdb227ae99d_6785 a b) ∨ (fact_9fdb227ae99d_7012 a b) ∨ (fact_9fdb227ae99d_6494 a b) ∨ (fact_9fdb227ae99d_5997 a b) ∨ (fact_9fdb227ae99d_6000 a b) ∨ (fact_9fdb227ae99d_6001 a b) ∨ (fact_9fdb227ae99d_5955 a b) ∨ (fact_9fdb227ae99d_6535 a b) ∨ (fact_9fdb227ae99d_7056 a b) ∨ (fact_9fdb227ae99d_6855 a b) ∨ (fact_9fdb227ae99d_6793 a b) ∨ (fact_9fdb227ae99d_6003 a b) ∨ (fact_9fdb227ae99d_7053 a b)) ∧ (((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + a)) ∧ ((1 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + a)) ∧ ((-3 : Int) ≥ ((-3 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + a)) ∧ ((2 : Int) ≥ ((-3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + a)) ∧ ((3 : Int) ≥ ((-3 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ ((-3 : Int) + a)) ∧ ((-4 : Int) ≥ ((-3 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + a)) ∧ ((1 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + a)) ∧ ((-3 : Int) ≥ ((-3 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + a)) ∧ ((2 : Int) ≥ ((-3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + a)) ∧ ((3 : Int) ≥ ((-3 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((-3 : Int) + a)) ∧ ((-4 : Int) ≥ ((-3 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int)))))))) ∨ ((fact_9fdb227ae99d_7942 a b) ∧ ((fact_9fdb227ae99d_5952 a b) ∨ (fact_9fdb227ae99d_5954 a b) ∨ (fact_9fdb227ae99d_6785 a b) ∨ (fact_9fdb227ae99d_7012 a b) ∨ (fact_9fdb227ae99d_6494 a b) ∨ (fact_9fdb227ae99d_5997 a b) ∨ (fact_9fdb227ae99d_6000 a b) ∨ (fact_9fdb227ae99d_6001 a b) ∨ (fact_9fdb227ae99d_5955 a b) ∨ (fact_9fdb227ae99d_6535 a b) ∨ (fact_9fdb227ae99d_7056 a b) ∨ (fact_9fdb227ae99d_6855 a b) ∨ (fact_9fdb227ae99d_6793 a b) ∨ (fact_9fdb227ae99d_6003 a b) ∨ (fact_9fdb227ae99d_7053 a b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + a)) ∧ ((1 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + a)) ∧ ((-3 : Int) ≥ ((-3 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + a)) ∧ ((2 : Int) ≥ ((-3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + a)) ∧ ((3 : Int) ≥ ((-3 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ ((-3 : Int) + a)) ∧ ((-4 : Int) ≥ ((-3 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + a)) ∧ ((1 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + a)) ∧ ((-3 : Int) ≥ ((-3 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + a)) ∧ ((2 : Int) ≥ ((-3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + a)) ∧ ((3 : Int) ≥ ((-3 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + a)) ∧ ((-1 : Int) ≥ ((-3 : Int) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + a)) ∧ ((0 : Int) ≥ ((-3 : Int) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((-3 : Int) + a)) ∧ ((-4 : Int) ≥ ((-3 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + a)) ∧ (((-3 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + a)) ∧ ((-2 : Int) ≥ ((-3 : Int) + a)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))))))))))
    (h3 : (((-4 : Int) < ((-2 : Int) - a)) ∨ ((-4 : Int) > ((-2 : Int) + (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_3208 a b))
    (h1 : (run_x ≤ ((1 : Int) + ((2 : Int) * b))))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((1 : Int) + a) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - a)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    (h8 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h9 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n662_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + ((2 : Int) * b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((1 : Int) + a) ≤ run_x))
    (h3 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((3 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_32 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_3206 a b))
    (h2 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3148 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3662 a b) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_3208 a b))
    (h5 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (b = (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o1 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_2923 a b jy))
    (h9 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (b = (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (((jx + (0 : Int)) < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h10 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n663_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h1 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((jx + a) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ (((-4 : Int) - ((-1 : Int) + ((-1 : Int) * a))) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b + a)) ∧ ((5 : Int) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * b)) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (fact_9fdb227ae99d_3499 a b) ∨ (((((-2 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3536 a b) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4529 a b) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ (((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6287 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∨ (fact_9fdb227ae99d_7921 a b))) ∨ (((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ ((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6287 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7921 a b)) ∨ ((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-4 : Int) = (((-1 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6287 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7921 a b) ∧ (((fact_9fdb227ae99d_6011 a b) ∨ (fact_9fdb227ae99d_6049 a b) ∨ (fact_9fdb227ae99d_6811 a b) ∨ (fact_9fdb227ae99d_7023 a b) ∨ (fact_9fdb227ae99d_6577 a b) ∨ (fact_9fdb227ae99d_6197 a b) ∨ (fact_9fdb227ae99d_6254 a b) ∨ (((((-3 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6082 a b) ∨ (fact_9fdb227ae99d_6638 a b) ∨ (fact_9fdb227ae99d_7093 a b) ∨ (fact_9fdb227ae99d_6883 a b) ∨ (fact_9fdb227ae99d_6863 a b) ∨ (fact_9fdb227ae99d_7107 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4251 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ (((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6287 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7921 a b) ∧ ((fact_9fdb227ae99d_6011 a b) ∨ (fact_9fdb227ae99d_6049 a b) ∨ (fact_9fdb227ae99d_6811 a b) ∨ (fact_9fdb227ae99d_7023 a b) ∨ (fact_9fdb227ae99d_6577 a b) ∨ (fact_9fdb227ae99d_6197 a b) ∨ (fact_9fdb227ae99d_6254 a b) ∨ (((((-3 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6082 a b) ∨ (fact_9fdb227ae99d_6638 a b) ∨ (fact_9fdb227ae99d_7093 a b) ∨ (fact_9fdb227ae99d_6883 a b) ∨ (fact_9fdb227ae99d_6863 a b) ∨ (fact_9fdb227ae99d_7107 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4251 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_empty (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2475 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3048 a b run_x) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n664_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3231 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + b + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3779 a b run_x) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h1 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((2 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3845 a b) ∨ (fact_9fdb227ae99d_3846 a b) ∨ (fact_9fdb227ae99d_5286 a b) ∨ (fact_9fdb227ae99d_5900 a b) ∨ (fact_9fdb227ae99d_4704 a b) ∨ (fact_9fdb227ae99d_4180 a b) ∨ (fact_9fdb227ae99d_4181 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3847 a b) ∨ (fact_9fdb227ae99d_4705 a b) ∨ (fact_9fdb227ae99d_6129 a b) ∨ (fact_9fdb227ae99d_5346 a b) ∨ (fact_9fdb227ae99d_5901 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_right (a b : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((fact_9fdb227ae99d_3295 a b) ∨ (fact_9fdb227ae99d_3296 a b) ∨ (fact_9fdb227ae99d_4318 a b) ∨ (fact_9fdb227ae99d_5449 a b) ∨ (fact_9fdb227ae99d_3667 a b) ∨ (fact_9fdb227ae99d_3349 a b) ∨ (fact_9fdb227ae99d_3350 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((2 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3297 a b) ∨ (fact_9fdb227ae99d_3668 a b) ∨ ((((1 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((1 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((1 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4400 a b) ∨ (fact_9fdb227ae99d_5450 a b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7913 a b) ∨ (fact_9fdb227ae99d_7832 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7913 a b) ∧ (fact_9fdb227ae99d_7832 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7913 a b) ∧ (fact_9fdb227ae99d_7832 a b) ∧ (((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∨ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3700 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b)))) ∨ ((fact_9fdb227ae99d_7913 a b) ∧ (fact_9fdb227ae99d_7832 a b) ∧ ((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∧ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3700 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_empty (a b run_x : Int)
    (h0 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ (b + a)))
    (h4 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (fact_9fdb227ae99d_3206 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (((2 : Int) + a) ≤ run_x))
    (h10 : ((fact_9fdb227ae99d_2431 a b run_x) ∨ (fact_9fdb227ae99d_2432 a b run_x) ∨ (fact_9fdb227ae99d_3059 a b run_x) ∨ (fact_9fdb227ae99d_3565 a b run_x) ∨ (fact_9fdb227ae99d_2974 a b run_x) ∨ (fact_9fdb227ae99d_2529 a b run_x) ∨ (fact_9fdb227ae99d_2530 a b run_x) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2433 a b run_x) ∨ (fact_9fdb227ae99d_2975 a b run_x) ∨ (fact_9fdb227ae99d_3666 a b run_x) ∨ (fact_9fdb227ae99d_3117 a b run_x) ∨ (fact_9fdb227ae99d_3566 a b run_x)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n665_run_floor (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ (b + a)))
    (h3 : (¬ ((fact_9fdb227ae99d_3172 a b run_x) ∨ (fact_9fdb227ae99d_3182 a b run_x) ∨ (fact_9fdb227ae99d_3725 a b run_x) ∨ (fact_9fdb227ae99d_5190 a b run_x) ∨ (fact_9fdb227ae99d_3484 a b run_x) ∨ (fact_9fdb227ae99d_3210 a b run_x) ∨ (fact_9fdb227ae99d_3226 a b run_x) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3192 a b run_x) ∨ (fact_9fdb227ae99d_3555 a b run_x) ∨ (fact_9fdb227ae99d_5358 a b run_x) ∨ (fact_9fdb227ae99d_3922 a b run_x) ∨ (fact_9fdb227ae99d_5261 a b run_x))))
    (h4 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h6 : (((2 : Int) + a) ≤ run_x))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_short (a b : Int)
    (h0 : (¬ (((1 : Int) - (-3 : Int)) < b)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_nonnegative (a b : Int)
    (h0 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5874 a b) ∨ (fact_9fdb227ae99d_5876 a b) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5818 a b) ∨ (fact_9fdb227ae99d_6359 a b) ∨ (fact_9fdb227ae99d_6437 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-3 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7906 a b) ∨ (fact_9fdb227ae99d_7887 a b))) ∨ (((1 : Int) ≥ ((-3 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7906 a b) ∧ (fact_9fdb227ae99d_7887 a b)) ∨ ((1 : Int) ≥ ((-3 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7906 a b) ∧ (fact_9fdb227ae99d_7887 a b) ∧ (((fact_9fdb227ae99d_6445 a b) ∨ (fact_9fdb227ae99d_6459 a b) ∨ (fact_9fdb227ae99d_6955 a b) ∨ (fact_9fdb227ae99d_7133 a b) ∨ (fact_9fdb227ae99d_6851 a b) ∨ (fact_9fdb227ae99d_6501 a b) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6527 a b) ∨ (fact_9fdb227ae99d_6468 a b) ∨ (fact_9fdb227ae99d_6875 a b) ∨ (fact_9fdb227ae99d_6893 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6420 a b) ∨ (fact_9fdb227ae99d_6429 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b)))) ∨ ((fact_9fdb227ae99d_7906 a b) ∧ (fact_9fdb227ae99d_7887 a b) ∧ ((fact_9fdb227ae99d_6445 a b) ∨ (fact_9fdb227ae99d_6459 a b) ∨ (fact_9fdb227ae99d_6955 a b) ∨ (fact_9fdb227ae99d_7133 a b) ∨ (fact_9fdb227ae99d_6851 a b) ∨ (fact_9fdb227ae99d_6501 a b) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) - (1 : Int))) ∧ (((-3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-2 : Int) ≤ ((-3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6527 a b) ∨ (fact_9fdb227ae99d_6468 a b) ∨ (fact_9fdb227ae99d_6875 a b) ∨ (fact_9fdb227ae99d_6893 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6420 a b) ∨ (fact_9fdb227ae99d_6429 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_empty (a b run_x : Int)
    (h0 : ((1 : Int) ≥ run_x))
    (h1 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4220 a b run_x) ∨ (fact_9fdb227ae99d_4257 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4125 a b run_x) ∨ (fact_9fdb227ae99d_5017 a b run_x) ∨ (fact_9fdb227ae99d_5094 a b run_x)))
    (h2 : (a ≥ b))
    (h3 : ((-3 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n666_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5670 a b run_x) ∨ (fact_9fdb227ae99d_5672 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5626 a b run_x) ∨ (fact_9fdb227ae99d_5957 a b run_x) ∨ (fact_9fdb227ae99d_6002 a b run_x))))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : ((-3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3622 a b) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (fact_9fdb227ae99d_4390 a b) ∨ (fact_9fdb227ae99d_4485 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3166 a b) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (fact_9fdb227ae99d_3463 a b) ∨ (fact_9fdb227ae99d_3548 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7659 a b) ∨ (fact_9fdb227ae99d_7538 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7659 a b) ∧ (fact_9fdb227ae99d_7538 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7659 a b) ∧ (fact_9fdb227ae99d_7538 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4448 a b) ∨ (fact_9fdb227ae99d_4469 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3523 a b) ∨ (fact_9fdb227ae99d_3539 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b)))) ∨ ((fact_9fdb227ae99d_7659 a b) ∧ (fact_9fdb227ae99d_7538 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4448 a b) ∨ (fact_9fdb227ae99d_4469 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3523 a b) ∨ (fact_9fdb227ae99d_3539 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_empty (a b run_x : Int)
    (h0 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) > ((1 : Int) + b))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2695 a b run_x) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3036 a b run_x) ∨ (fact_9fdb227ae99d_3047 a b run_x)))
    (h5 : (b = (5 : Int)))
    (h6 : (run_x ≤ a))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n667_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ a))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3354 a b run_x) ∨ (((((-2 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3721 a b run_x) ∨ (fact_9fdb227ae99d_3747 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_29 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3132 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (b = (5 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (b = (5 : Int)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n668_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_4179 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3348 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7797 a b) ∨ (fact_9fdb227ae99d_7707 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7797 a b) ∧ (fact_9fdb227ae99d_7707 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7797 a b) ∧ (fact_9fdb227ae99d_7707 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7797 a b) ∧ (fact_9fdb227ae99d_7707 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ (b + a)))
    (h1 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_2524 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_3207 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h8 : (((1 : Int) + a) ≤ run_x))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n669_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ (b + a)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3253 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h3 : (((1 : Int) + a) ≤ run_x))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_short (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h2 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_nonnegative (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h1 : (¬ (((2 : Int) + b) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4356 a b) ∨ (fact_9fdb227ae99d_4373 a b) ∨ (fact_9fdb227ae99d_5466 a b) ∨ (fact_9fdb227ae99d_6189 a b) ∨ (fact_9fdb227ae99d_5124 a b) ∨ (fact_9fdb227ae99d_4427 a b) ∨ (fact_9fdb227ae99d_4451 a b) ∨ (fact_9fdb227ae99d_4474 a b) ∨ (fact_9fdb227ae99d_4383 a b) ∨ (fact_9fdb227ae99d_5152 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + b) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6326 a b))))
    (h1 : (fact_9fdb227ae99d_3478 a b))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((fact_9fdb227ae99d_4357 a b) ∨ (fact_9fdb227ae99d_4374 a b) ∨ (fact_9fdb227ae99d_5467 a b) ∨ (fact_9fdb227ae99d_6190 a b) ∨ (fact_9fdb227ae99d_5125 a b) ∨ (fact_9fdb227ae99d_4428 a b) ∨ (fact_9fdb227ae99d_4452 a b) ∨ (fact_9fdb227ae99d_4475 a b) ∨ (fact_9fdb227ae99d_4384 a b) ∨ (fact_9fdb227ae99d_5153 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6327 a b))))
    (h3 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((((2 : Int) + b) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_9fdb227ae99d_7844 a b) ∨ (fact_9fdb227ae99d_7848 a b))) ∨ (((((2 : Int) + b) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_9fdb227ae99d_7844 a b) ∧ (fact_9fdb227ae99d_7848 a b)) ∨ ((((2 : Int) + b) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = (((2 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7844 a b) ∧ (fact_9fdb227ae99d_7848 a b) ∧ (((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5225 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5253 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∨ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5226 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5254 a b) ∨ (fact_9fdb227ae99d_6773 a b)))) ∨ ((fact_9fdb227ae99d_7844 a b) ∧ (fact_9fdb227ae99d_7848 a b) ∧ ((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5225 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5253 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∧ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5226 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5254 a b) ∨ (fact_9fdb227ae99d_6773 a b))))))
    (h5 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a > b))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_empty (a b run_x : Int)
    (h0 : (((2 : Int) + b) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2586 a b run_x) ∨ (fact_9fdb227ae99d_2591 a b run_x) ∨ (fact_9fdb227ae99d_3152 a b run_x) ∨ (fact_9fdb227ae99d_3672 a b run_x) ∨ (fact_9fdb227ae99d_3030 a b run_x) ∨ (fact_9fdb227ae99d_2692 a b run_x) ∨ (fact_9fdb227ae99d_2712 a b run_x) ∨ (fact_9fdb227ae99d_2731 a b run_x) ∨ (fact_9fdb227ae99d_2632 a b run_x) ∨ (fact_9fdb227ae99d_3035 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3742 a b run_x)))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h7 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n670_run_floor (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) + b) ≤ run_x))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : (¬ ((fact_9fdb227ae99d_3319 a b run_x) ∨ (fact_9fdb227ae99d_3323 a b run_x) ∨ (fact_9fdb227ae99d_4334 a b run_x) ∨ (fact_9fdb227ae99d_5468 a b run_x) ∨ (fact_9fdb227ae99d_3676 a b run_x) ∨ (fact_9fdb227ae99d_3351 a b run_x) ∨ (fact_9fdb227ae99d_3357 a b run_x) ∨ (fact_9fdb227ae99d_3360 a b run_x) ∨ (fact_9fdb227ae99d_3327 a b run_x) ∨ (fact_9fdb227ae99d_3720 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((2 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5550 a b run_x))))
    (h5 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_32 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3102 a b) ∨ (fact_9fdb227ae99d_3103 a b) ∨ (fact_9fdb227ae99d_3597 a b) ∨ (fact_9fdb227ae99d_5033 a b) ∨ (fact_9fdb227ae99d_3338 a b) ∨ (fact_9fdb227ae99d_3147 a b) ∨ (fact_9fdb227ae99d_3148 a b) ∨ (fact_9fdb227ae99d_3150 a b) ∨ (fact_9fdb227ae99d_3104 a b) ∨ (fact_9fdb227ae99d_3339 a b) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3662 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_3206 a b))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o0 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_2000 a b jx jy))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_2003 a b jx jy))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o2 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_2005 a b jx jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (fact_9fdb227ae99d_2006 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2007 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2004 a b jx jy))
    (h1 : (b = (5 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2002 a b jx jy))
    (h6 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n671_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_2001 a b jx jy))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n672_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_29 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n672_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3380 a b)))
    (h1 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n672_o0 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n672_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

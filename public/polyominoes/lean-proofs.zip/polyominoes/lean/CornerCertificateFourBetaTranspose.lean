import CornerCertificateFourBetaTransposeData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FourBetaTranspose
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include copies separate cover ceiling in
theorem four_betaTranspose_node0002 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0002 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0002 ((1 : Int),(1 : Int)) four_betaTranspose_branches0002 copies separate cover ceiling four_betaTranspose_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
theorem four_betaTranspose_node0004 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0004 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0004 .gamma (1 : Int) (2 : Int) four_betaTranspose_check0004 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0007 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0007 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0007 ((3 : Int),(2 : Int)) four_betaTranspose_branches0007 copies separate cover ceiling four_betaTranspose_check0007 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0007, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0008 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0008 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0008 ((3 : Int),(2 : Int)) four_betaTranspose_branches0008 copies separate cover ceiling four_betaTranspose_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0006 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0006 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0006 ((2 : Int),(2 : Int)) four_betaTranspose_branches0006 copies separate cover ceiling four_betaTranspose_check0006 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0006, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0007 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0008 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0009 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0009 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0009 ((2 : Int),(2 : Int)) four_betaTranspose_branches0009 copies separate cover ceiling four_betaTranspose_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0010 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0010 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0010 ((2 : Int),(2 : Int)) four_betaTranspose_branches0010 copies separate cover ceiling four_betaTranspose_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0013 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0013 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0013 ((4 : Int),(2 : Int)) four_betaTranspose_branches0013 copies separate cover ceiling four_betaTranspose_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0014 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0014 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0014 ((4 : Int),(2 : Int)) four_betaTranspose_branches0014 copies separate cover ceiling four_betaTranspose_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0012 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0012 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0012 ((3 : Int),(2 : Int)) four_betaTranspose_branches0012 copies separate cover ceiling four_betaTranspose_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0013 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0014 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0016 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0016 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0016 ((4 : Int),(2 : Int)) four_betaTranspose_branches0016 copies separate cover ceiling four_betaTranspose_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0017 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0017 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0017 ((4 : Int),(2 : Int)) four_betaTranspose_branches0017 copies separate cover ceiling four_betaTranspose_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0015 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0015 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0015 ((3 : Int),(2 : Int)) four_betaTranspose_branches0015 copies separate cover ceiling four_betaTranspose_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0016 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0017 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0011 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0011 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0011 ((1 : Int),(4 : Int)) four_betaTranspose_branches0011 copies separate cover ceiling four_betaTranspose_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0012 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0015 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0019 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0019 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0019 .alpha (2 : Int) (4 : Int) four_betaTranspose_check0019 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0020 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0020 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0020 ((3 : Int),(2 : Int)) four_betaTranspose_branches0020 copies separate cover ceiling four_betaTranspose_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0021 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0021 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0021 ((3 : Int),(2 : Int)) four_betaTranspose_branches0021 copies separate cover ceiling four_betaTranspose_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0022 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0022 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0022 ((3 : Int),(2 : Int)) four_betaTranspose_branches0022 copies separate cover ceiling four_betaTranspose_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0023 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0023 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0023 ((3 : Int),(2 : Int)) four_betaTranspose_branches0023 copies separate cover ceiling four_betaTranspose_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0018 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0018 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0018 ((1 : Int),(4 : Int)) four_betaTranspose_branches0018 copies separate cover ceiling four_betaTranspose_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0019 world h nextB nextState
  · exact four_betaTranspose_node0020 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0021 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0022 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0023 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0024 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0024 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0024 ((2 : Int),(2 : Int)) four_betaTranspose_branches0024 copies separate cover ceiling four_betaTranspose_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0025 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0025 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0025 ((2 : Int),(2 : Int)) four_betaTranspose_branches0025 copies separate cover ceiling four_betaTranspose_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0005 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0005 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0005 ((1 : Int),(3 : Int)) four_betaTranspose_branches0005 copies separate cover ceiling four_betaTranspose_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0006 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0009 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0010 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0011 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0018 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0024 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0025 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0003 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0003 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0003 ((1 : Int),(1 : Int)) four_betaTranspose_branches0003 copies separate cover ceiling four_betaTranspose_check0003 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0003, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0004 world h nextB nextState
  · exact four_betaTranspose_node0005 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0026 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0026 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0026 ((1 : Int),(1 : Int)) four_betaTranspose_branches0026 copies separate cover ceiling four_betaTranspose_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0001 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0001 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0001 ((1 : Int),(0 : Int)) four_betaTranspose_branches0001 copies separate cover ceiling four_betaTranspose_check0001 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0001, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0002 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0003 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0026 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0028 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0028 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0028 ((1 : Int),(1 : Int)) four_betaTranspose_branches0028 copies separate cover ceiling four_betaTranspose_check0028 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0028, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0030 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0030 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0030 ((1 : Int),(2 : Int)) four_betaTranspose_branches0030 copies separate cover ceiling four_betaTranspose_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0031 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0031 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0031 ((1 : Int),(2 : Int)) four_betaTranspose_branches0031 copies separate cover ceiling four_betaTranspose_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0029 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0029 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0029 ((1 : Int),(1 : Int)) four_betaTranspose_branches0029 copies separate cover ceiling four_betaTranspose_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0030 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0031 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0032 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0032 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0032 ((1 : Int),(1 : Int)) four_betaTranspose_branches0032 copies separate cover ceiling four_betaTranspose_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0027 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0027 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0027 ((1 : Int),(0 : Int)) four_betaTranspose_branches0027 copies separate cover ceiling four_betaTranspose_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0028 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0029 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0032 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0036 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0036 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0036 .gamma (3 : Int) (1 : Int) four_betaTranspose_check0036 B state
theorem four_betaTranspose_node0037 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0037 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0037 .beta (3 : Int) (1 : Int) four_betaTranspose_check0037 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0040 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0040 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0040 ((5 : Int),(1 : Int)) four_betaTranspose_branches0040 copies separate cover ceiling four_betaTranspose_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0041 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0041 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0041 ((5 : Int),(1 : Int)) four_betaTranspose_branches0041 copies separate cover ceiling four_betaTranspose_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0039 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0039 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0039 ((4 : Int),(1 : Int)) four_betaTranspose_branches0039 copies separate cover ceiling four_betaTranspose_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0040 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0041 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0042 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0042 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0042 ((4 : Int),(1 : Int)) four_betaTranspose_branches0042 copies separate cover ceiling four_betaTranspose_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0043 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0043 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0043 ((4 : Int),(1 : Int)) four_betaTranspose_branches0043 copies separate cover ceiling four_betaTranspose_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0047 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0047 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0047 ((6 : Int),(1 : Int)) four_betaTranspose_branches0047 copies separate cover ceiling four_betaTranspose_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0048 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0048 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0048 ((6 : Int),(1 : Int)) four_betaTranspose_branches0048 copies separate cover ceiling four_betaTranspose_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0046 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0046 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0046 ((1 : Int),(6 : Int)) four_betaTranspose_branches0046 copies separate cover ceiling four_betaTranspose_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0047 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0048 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0050 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0050 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0050 ((6 : Int),(1 : Int)) four_betaTranspose_branches0050 copies separate cover ceiling four_betaTranspose_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0051 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0051 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0051 ((6 : Int),(1 : Int)) four_betaTranspose_branches0051 copies separate cover ceiling four_betaTranspose_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0049 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0049 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0049 ((1 : Int),(6 : Int)) four_betaTranspose_branches0049 copies separate cover ceiling four_betaTranspose_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0050 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0051 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0045 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0045 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0045 ((5 : Int),(1 : Int)) four_betaTranspose_branches0045 copies separate cover ceiling four_betaTranspose_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0046 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0049 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0054 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0054 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0054 ((6 : Int),(1 : Int)) four_betaTranspose_branches0054 copies separate cover ceiling four_betaTranspose_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0055 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0055 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0055 ((6 : Int),(1 : Int)) four_betaTranspose_branches0055 copies separate cover ceiling four_betaTranspose_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0056 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0056 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0056 ((6 : Int),(1 : Int)) four_betaTranspose_branches0056 copies separate cover ceiling four_betaTranspose_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0053 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0053 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0053 ((1 : Int),(6 : Int)) four_betaTranspose_branches0053 copies separate cover ceiling four_betaTranspose_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0054 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0055 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0056 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0058 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0058 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0058 ((6 : Int),(1 : Int)) four_betaTranspose_branches0058 copies separate cover ceiling four_betaTranspose_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0059 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0059 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0059 ((6 : Int),(1 : Int)) four_betaTranspose_branches0059 copies separate cover ceiling four_betaTranspose_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0060 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0060 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0060 ((6 : Int),(1 : Int)) four_betaTranspose_branches0060 copies separate cover ceiling four_betaTranspose_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0057 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0057 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0057 ((1 : Int),(6 : Int)) four_betaTranspose_branches0057 copies separate cover ceiling four_betaTranspose_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0058 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0059 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0060 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0052 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0052 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0052 ((5 : Int),(1 : Int)) four_betaTranspose_branches0052 copies separate cover ceiling four_betaTranspose_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0053 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0057 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0044 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0044 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0044 ((3 : Int),(3 : Int)) four_betaTranspose_branches0044 copies separate cover ceiling four_betaTranspose_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0045 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0052 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0062 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0062 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0062 .alpha (4 : Int) (3 : Int) four_betaTranspose_check0062 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0063 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0063 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0063 ((5 : Int),(1 : Int)) four_betaTranspose_branches0063 copies separate cover ceiling four_betaTranspose_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0064 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0064 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0064 ((5 : Int),(1 : Int)) four_betaTranspose_branches0064 copies separate cover ceiling four_betaTranspose_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0065 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0065 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0065 ((5 : Int),(1 : Int)) four_betaTranspose_branches0065 copies separate cover ceiling four_betaTranspose_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0066 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0066 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0066 ((5 : Int),(1 : Int)) four_betaTranspose_branches0066 copies separate cover ceiling four_betaTranspose_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0061 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0061 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0061 ((3 : Int),(3 : Int)) four_betaTranspose_branches0061 copies separate cover ceiling four_betaTranspose_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0062 world h nextB nextState
  · exact four_betaTranspose_node0063 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0064 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0065 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0066 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0067 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0067 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0067 ((4 : Int),(1 : Int)) four_betaTranspose_branches0067 copies separate cover ceiling four_betaTranspose_check0067 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0067, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0068 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0068 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0068 ((4 : Int),(1 : Int)) four_betaTranspose_branches0068 copies separate cover ceiling four_betaTranspose_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0038 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0038 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0038 ((3 : Int),(2 : Int)) four_betaTranspose_branches0038 copies separate cover ceiling four_betaTranspose_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0039 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0042 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0043 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0044 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0061 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0067 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0068 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0035 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0035 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0035 ((3 : Int),(0 : Int)) four_betaTranspose_branches0035 copies separate cover ceiling four_betaTranspose_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0036 world h nextB nextState
  · exact four_betaTranspose_node0037 world h nextB nextState
  · exact four_betaTranspose_node0038 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0070 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0070 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0070 ((3 : Int),(1 : Int)) four_betaTranspose_branches0070 copies separate cover ceiling four_betaTranspose_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0072 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0072 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0072 ((3 : Int),(2 : Int)) four_betaTranspose_branches0072 copies separate cover ceiling four_betaTranspose_check0072 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0072, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0073 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0073 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0073 ((3 : Int),(2 : Int)) four_betaTranspose_branches0073 copies separate cover ceiling four_betaTranspose_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0071 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0071 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0071 ((3 : Int),(1 : Int)) four_betaTranspose_branches0071 copies separate cover ceiling four_betaTranspose_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0072 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0073 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0074 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0074 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0074 ((3 : Int),(1 : Int)) four_betaTranspose_branches0074 copies separate cover ceiling four_betaTranspose_check0074 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0074, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0069 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0069 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0069 ((3 : Int),(0 : Int)) four_betaTranspose_branches0069 copies separate cover ceiling four_betaTranspose_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0070 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0071 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0074 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0076 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0076 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0076 .gammaTranspose (3 : Int) (1 : Int) four_betaTranspose_check0076 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0078 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0078 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0078 ((3 : Int),(3 : Int)) four_betaTranspose_branches0078 copies separate cover ceiling four_betaTranspose_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0082 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0082 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0082 ((3 : Int),(4 : Int)) four_betaTranspose_branches0082 copies separate cover ceiling four_betaTranspose_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0083 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0083 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0083 ((3 : Int),(4 : Int)) four_betaTranspose_branches0083 copies separate cover ceiling four_betaTranspose_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0084 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0084 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0084 ((3 : Int),(4 : Int)) four_betaTranspose_branches0084 copies separate cover ceiling four_betaTranspose_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0081 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0081 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0081 ((1 : Int),(6 : Int)) four_betaTranspose_branches0081 copies separate cover ceiling four_betaTranspose_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0082 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0083 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0084 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0086 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0086 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0086 ((3 : Int),(4 : Int)) four_betaTranspose_branches0086 copies separate cover ceiling four_betaTranspose_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0087 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0087 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0087 ((3 : Int),(4 : Int)) four_betaTranspose_branches0087 copies separate cover ceiling four_betaTranspose_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0088 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0088 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0088 ((3 : Int),(4 : Int)) four_betaTranspose_branches0088 copies separate cover ceiling four_betaTranspose_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0085 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0085 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0085 ((1 : Int),(6 : Int)) four_betaTranspose_branches0085 copies separate cover ceiling four_betaTranspose_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0086 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0087 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0088 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0080 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0080 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0080 ((5 : Int),(1 : Int)) four_betaTranspose_branches0080 copies separate cover ceiling four_betaTranspose_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0081 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0085 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0091 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0091 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0091 ((3 : Int),(4 : Int)) four_betaTranspose_branches0091 copies separate cover ceiling four_betaTranspose_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0092 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0092 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0092 ((3 : Int),(4 : Int)) four_betaTranspose_branches0092 copies separate cover ceiling four_betaTranspose_check0092 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0092, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0093 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0093 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0093 ((3 : Int),(4 : Int)) four_betaTranspose_branches0093 copies separate cover ceiling four_betaTranspose_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0090 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0090 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0090 ((1 : Int),(6 : Int)) four_betaTranspose_branches0090 copies separate cover ceiling four_betaTranspose_check0090 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0090, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0091 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0092 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0093 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0095 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0095 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0095 ((3 : Int),(4 : Int)) four_betaTranspose_branches0095 copies separate cover ceiling four_betaTranspose_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0096 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0096 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0096 ((3 : Int),(4 : Int)) four_betaTranspose_branches0096 copies separate cover ceiling four_betaTranspose_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0097 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0097 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0097 ((3 : Int),(4 : Int)) four_betaTranspose_branches0097 copies separate cover ceiling four_betaTranspose_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0094 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0094 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0094 ((1 : Int),(6 : Int)) four_betaTranspose_branches0094 copies separate cover ceiling four_betaTranspose_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0095 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0096 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0097 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0089 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0089 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0089 ((5 : Int),(1 : Int)) four_betaTranspose_branches0089 copies separate cover ceiling four_betaTranspose_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0090 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0094 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0079 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0079 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0079 ((3 : Int),(3 : Int)) four_betaTranspose_branches0079 copies separate cover ceiling four_betaTranspose_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0080 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0089 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0099 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0099 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0099 ((3 : Int),(3 : Int)) four_betaTranspose_branches0099 copies separate cover ceiling four_betaTranspose_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0098 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0098 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0098 ((4 : Int),(1 : Int)) four_betaTranspose_branches0098 copies separate cover ceiling four_betaTranspose_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0099 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0100 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0100 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0100 ((4 : Int),(1 : Int)) four_betaTranspose_branches0100 copies separate cover ceiling four_betaTranspose_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0102 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0102 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0102 ((3 : Int),(3 : Int)) four_betaTranspose_branches0102 copies separate cover ceiling four_betaTranspose_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0101 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0101 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0101 ((4 : Int),(1 : Int)) four_betaTranspose_branches0101 copies separate cover ceiling four_betaTranspose_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0102 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0077 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0077 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0077 ((3 : Int),(2 : Int)) four_betaTranspose_branches0077 copies separate cover ceiling four_betaTranspose_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0078 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0079 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0098 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0100 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0101 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0075 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0075 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0075 ((2 : Int),(1 : Int)) four_betaTranspose_branches0075 copies separate cover ceiling four_betaTranspose_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0076 world h nextB nextState
  · exact four_betaTranspose_node0077 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0103 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0103 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0103 .alpha (2 : Int) (1 : Int) four_betaTranspose_check0103 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0105 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0105 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0105 ((3 : Int),(1 : Int)) four_betaTranspose_branches0105 copies separate cover ceiling four_betaTranspose_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0106 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0106 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0106 ((3 : Int),(1 : Int)) four_betaTranspose_branches0106 copies separate cover ceiling four_betaTranspose_check0106 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0106, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0104 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0104 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0104 ((2 : Int),(1 : Int)) four_betaTranspose_branches0104 copies separate cover ceiling four_betaTranspose_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0105 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0106 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0034 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0034 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0034 ((2 : Int),(0 : Int)) four_betaTranspose_branches0034 copies separate cover ceiling four_betaTranspose_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0035 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0069 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0075 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0103 world h nextB nextState
  · exact four_betaTranspose_node0104 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0109 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0109 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0109 .gamma (3 : Int) (1 : Int) four_betaTranspose_check0109 B state
theorem four_betaTranspose_node0110 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0110 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0110 .beta (3 : Int) (1 : Int) four_betaTranspose_check0110 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0113 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0113 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0113 ((5 : Int),(1 : Int)) four_betaTranspose_branches0113 copies separate cover ceiling four_betaTranspose_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0114 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0114 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0114 ((5 : Int),(1 : Int)) four_betaTranspose_branches0114 copies separate cover ceiling four_betaTranspose_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0112 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0112 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0112 ((4 : Int),(1 : Int)) four_betaTranspose_branches0112 copies separate cover ceiling four_betaTranspose_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0113 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0114 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0115 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0115 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0115 ((4 : Int),(1 : Int)) four_betaTranspose_branches0115 copies separate cover ceiling four_betaTranspose_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0116 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0116 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0116 ((4 : Int),(1 : Int)) four_betaTranspose_branches0116 copies separate cover ceiling four_betaTranspose_check0116 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0116, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0119 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0119 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0119 ((6 : Int),(1 : Int)) four_betaTranspose_branches0119 copies separate cover ceiling four_betaTranspose_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0120 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0120 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0120 ((6 : Int),(1 : Int)) four_betaTranspose_branches0120 copies separate cover ceiling four_betaTranspose_check0120 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0120, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0118 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0118 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0118 ((5 : Int),(1 : Int)) four_betaTranspose_branches0118 copies separate cover ceiling four_betaTranspose_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0119 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0120 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0122 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0122 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0122 ((6 : Int),(1 : Int)) four_betaTranspose_branches0122 copies separate cover ceiling four_betaTranspose_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0123 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0123 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0123 ((6 : Int),(1 : Int)) four_betaTranspose_branches0123 copies separate cover ceiling four_betaTranspose_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0121 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0121 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0121 ((5 : Int),(1 : Int)) four_betaTranspose_branches0121 copies separate cover ceiling four_betaTranspose_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0122 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0123 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0117 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0117 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0117 ((3 : Int),(3 : Int)) four_betaTranspose_branches0117 copies separate cover ceiling four_betaTranspose_check0117 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0117, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0118 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0121 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0125 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0125 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0125 .alpha (4 : Int) (3 : Int) four_betaTranspose_check0125 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0126 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0126 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0126 ((5 : Int),(1 : Int)) four_betaTranspose_branches0126 copies separate cover ceiling four_betaTranspose_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0127 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0127 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0127 ((5 : Int),(1 : Int)) four_betaTranspose_branches0127 copies separate cover ceiling four_betaTranspose_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0128 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0128 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0128 ((5 : Int),(1 : Int)) four_betaTranspose_branches0128 copies separate cover ceiling four_betaTranspose_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0129 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0129 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0129 ((5 : Int),(1 : Int)) four_betaTranspose_branches0129 copies separate cover ceiling four_betaTranspose_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0124 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0124 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0124 ((3 : Int),(3 : Int)) four_betaTranspose_branches0124 copies separate cover ceiling four_betaTranspose_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0125 world h nextB nextState
  · exact four_betaTranspose_node0126 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0127 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0128 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0129 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0130 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0130 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0130 ((4 : Int),(1 : Int)) four_betaTranspose_branches0130 copies separate cover ceiling four_betaTranspose_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0131 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0131 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0131 ((4 : Int),(1 : Int)) four_betaTranspose_branches0131 copies separate cover ceiling four_betaTranspose_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0111 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0111 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0111 ((3 : Int),(2 : Int)) four_betaTranspose_branches0111 copies separate cover ceiling four_betaTranspose_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0112 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0115 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0116 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0117 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0124 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0130 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0131 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0108 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0108 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0108 ((3 : Int),(0 : Int)) four_betaTranspose_branches0108 copies separate cover ceiling four_betaTranspose_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0109 world h nextB nextState
  · exact four_betaTranspose_node0110 world h nextB nextState
  · exact four_betaTranspose_node0111 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0133 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0133 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0133 ((3 : Int),(1 : Int)) four_betaTranspose_branches0133 copies separate cover ceiling four_betaTranspose_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0135 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0135 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0135 ((3 : Int),(2 : Int)) four_betaTranspose_branches0135 copies separate cover ceiling four_betaTranspose_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0136 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0136 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0136 ((3 : Int),(2 : Int)) four_betaTranspose_branches0136 copies separate cover ceiling four_betaTranspose_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0134 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0134 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0134 ((3 : Int),(1 : Int)) four_betaTranspose_branches0134 copies separate cover ceiling four_betaTranspose_check0134 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0134, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0135 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0136 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0137 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0137 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0137 ((3 : Int),(1 : Int)) four_betaTranspose_branches0137 copies separate cover ceiling four_betaTranspose_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0132 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0132 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0132 ((3 : Int),(0 : Int)) four_betaTranspose_branches0132 copies separate cover ceiling four_betaTranspose_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0133 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0134 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0137 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0139 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0139 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0139 .gammaTranspose (3 : Int) (1 : Int) four_betaTranspose_check0139 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0141 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0141 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0141 ((3 : Int),(3 : Int)) four_betaTranspose_branches0141 copies separate cover ceiling four_betaTranspose_check0141 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0141, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0144 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0144 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0144 ((3 : Int),(4 : Int)) four_betaTranspose_branches0144 copies separate cover ceiling four_betaTranspose_check0144 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0144, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0145 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0145 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0145 ((3 : Int),(4 : Int)) four_betaTranspose_branches0145 copies separate cover ceiling four_betaTranspose_check0145 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0145, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0143 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0143 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0143 ((5 : Int),(1 : Int)) four_betaTranspose_branches0143 copies separate cover ceiling four_betaTranspose_check0143 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0143, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0144 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0145 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0147 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0147 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0147 ((3 : Int),(4 : Int)) four_betaTranspose_branches0147 copies separate cover ceiling four_betaTranspose_check0147 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0147, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0148 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0148 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0148 ((3 : Int),(4 : Int)) four_betaTranspose_branches0148 copies separate cover ceiling four_betaTranspose_check0148 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0148, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0146 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0146 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0146 ((5 : Int),(1 : Int)) four_betaTranspose_branches0146 copies separate cover ceiling four_betaTranspose_check0146 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0146, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0147 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0148 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0142 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0142 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0142 ((3 : Int),(3 : Int)) four_betaTranspose_branches0142 copies separate cover ceiling four_betaTranspose_check0142 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0142, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0143 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0146 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0150 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0150 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0150 ((3 : Int),(3 : Int)) four_betaTranspose_branches0150 copies separate cover ceiling four_betaTranspose_check0150 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0150, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0149 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0149 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0149 ((4 : Int),(1 : Int)) four_betaTranspose_branches0149 copies separate cover ceiling four_betaTranspose_check0149 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0149, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0150 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0151 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0151 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0151 ((4 : Int),(1 : Int)) four_betaTranspose_branches0151 copies separate cover ceiling four_betaTranspose_check0151 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0151, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0153 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0153 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0153 ((3 : Int),(3 : Int)) four_betaTranspose_branches0153 copies separate cover ceiling four_betaTranspose_check0153 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0153, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0152 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0152 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0152 ((4 : Int),(1 : Int)) four_betaTranspose_branches0152 copies separate cover ceiling four_betaTranspose_check0152 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0152, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0153 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0140 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0140 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0140 ((3 : Int),(2 : Int)) four_betaTranspose_branches0140 copies separate cover ceiling four_betaTranspose_check0140 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0140, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0141 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0142 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0149 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0151 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0152 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0138 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0138 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0138 ((2 : Int),(1 : Int)) four_betaTranspose_branches0138 copies separate cover ceiling four_betaTranspose_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0139 world h nextB nextState
  · exact four_betaTranspose_node0140 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0154 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0154 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0154 .alpha (2 : Int) (1 : Int) four_betaTranspose_check0154 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0156 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0156 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0156 ((3 : Int),(1 : Int)) four_betaTranspose_branches0156 copies separate cover ceiling four_betaTranspose_check0156 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0156, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0157 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0157 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0157 ((3 : Int),(1 : Int)) four_betaTranspose_branches0157 copies separate cover ceiling four_betaTranspose_check0157 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0157, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0155 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0155 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0155 ((2 : Int),(1 : Int)) four_betaTranspose_branches0155 copies separate cover ceiling four_betaTranspose_check0155 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0155, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0156 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0157 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0107 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0107 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0107 ((2 : Int),(0 : Int)) four_betaTranspose_branches0107 copies separate cover ceiling four_betaTranspose_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0108 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0132 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0138 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0154 world h nextB nextState
  · exact four_betaTranspose_node0155 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0033 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0033 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0033 ((0 : Int),(2 : Int)) four_betaTranspose_branches0033 copies separate cover ceiling four_betaTranspose_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0034 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0107 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0158 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0158 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0158 .alpha (0 : Int) (2 : Int) four_betaTranspose_check0158 B state
theorem four_betaTranspose_node0161 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0161 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0161 .betaTranspose (1 : Int) (2 : Int) four_betaTranspose_check0161 B state
theorem four_betaTranspose_node0162 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0162 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0162 .gammaTranspose (1 : Int) (2 : Int) four_betaTranspose_check0162 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0164 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0164 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0164 ((1 : Int),(4 : Int)) four_betaTranspose_branches0164 copies separate cover ceiling four_betaTranspose_check0164 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0164, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0167 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0167 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0167 ((1 : Int),(5 : Int)) four_betaTranspose_branches0167 copies separate cover ceiling four_betaTranspose_check0167 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0167, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0168 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0168 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0168 ((1 : Int),(5 : Int)) four_betaTranspose_branches0168 copies separate cover ceiling four_betaTranspose_check0168 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0168, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0166 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0166 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0166 ((3 : Int),(2 : Int)) four_betaTranspose_branches0166 copies separate cover ceiling four_betaTranspose_check0166 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0166, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0167 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0168 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0170 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0170 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0170 ((1 : Int),(5 : Int)) four_betaTranspose_branches0170 copies separate cover ceiling four_betaTranspose_check0170 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0170, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0171 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0171 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0171 ((1 : Int),(5 : Int)) four_betaTranspose_branches0171 copies separate cover ceiling four_betaTranspose_check0171 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0171, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0169 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0169 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0169 ((3 : Int),(2 : Int)) four_betaTranspose_branches0169 copies separate cover ceiling four_betaTranspose_check0169 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0169, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0170 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0171 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0165 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0165 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0165 ((1 : Int),(4 : Int)) four_betaTranspose_branches0165 copies separate cover ceiling four_betaTranspose_check0165 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0165, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0166 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0169 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0173 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0173 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0173 ((1 : Int),(4 : Int)) four_betaTranspose_branches0173 copies separate cover ceiling four_betaTranspose_check0173 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0173, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0172 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0172 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0172 ((2 : Int),(2 : Int)) four_betaTranspose_branches0172 copies separate cover ceiling four_betaTranspose_check0172 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0172, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0173 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0174 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0174 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0174 ((2 : Int),(2 : Int)) four_betaTranspose_branches0174 copies separate cover ceiling four_betaTranspose_check0174 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0174, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0176 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0176 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0176 ((1 : Int),(4 : Int)) four_betaTranspose_branches0176 copies separate cover ceiling four_betaTranspose_check0176 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0176, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0175 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0175 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0175 ((2 : Int),(2 : Int)) four_betaTranspose_branches0175 copies separate cover ceiling four_betaTranspose_check0175 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0175, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0176 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0163 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0163 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0163 ((1 : Int),(3 : Int)) four_betaTranspose_branches0163 copies separate cover ceiling four_betaTranspose_check0163 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0163, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0164 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0165 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0172 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0174 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0175 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0160 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0160 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0160 ((0 : Int),(2 : Int)) four_betaTranspose_branches0160 copies separate cover ceiling four_betaTranspose_check0160 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0160, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0161 world h nextB nextState
  · exact four_betaTranspose_node0162 world h nextB nextState
  · exact four_betaTranspose_node0163 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0159 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0159 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0159 ((1 : Int),(0 : Int)) four_betaTranspose_branches0159 copies separate cover ceiling four_betaTranspose_check0159 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0159, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0160 world h copies separate cover ceiling nextB nextState
theorem four_betaTranspose_node0177 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0177 B) : Transition world h .betaTranspose B := by
  exact replay_leaf world h .betaTranspose four_betaTranspose_occ0177 .alpha (0 : Int) (2 : Int) four_betaTranspose_check0177 B state
include copies separate cover ceiling in
theorem four_betaTranspose_node0181 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0181 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0181 ((2 : Int),(2 : Int)) four_betaTranspose_branches0181 copies separate cover ceiling four_betaTranspose_check0181 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0181, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0182 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0182 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0182 ((2 : Int),(2 : Int)) four_betaTranspose_branches0182 copies separate cover ceiling four_betaTranspose_check0182 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0182, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0180 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0180 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0180 ((1 : Int),(2 : Int)) four_betaTranspose_branches0180 copies separate cover ceiling four_betaTranspose_check0180 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0180, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_betaTranspose_node0181 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0182 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0183 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0183 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0183 ((1 : Int),(2 : Int)) four_betaTranspose_branches0183 copies separate cover ceiling four_betaTranspose_check0183 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0183, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0184 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0184 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0184 ((1 : Int),(2 : Int)) four_betaTranspose_branches0184 copies separate cover ceiling four_betaTranspose_check0184 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0184, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_betaTranspose_node0179 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0179 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0179 ((0 : Int),(2 : Int)) four_betaTranspose_branches0179 copies separate cover ceiling four_betaTranspose_check0179 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0179, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_betaTranspose_node0180 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0183 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0184 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0178 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0178 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0178 ((1 : Int),(0 : Int)) four_betaTranspose_branches0178 copies separate cover ceiling four_betaTranspose_check0178 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0178, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_betaTranspose_node0179 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_betaTranspose_node0000 (B : Int → Int → Prop)
    (state : State world h four_betaTranspose_occ0000 B) : Transition world h .betaTranspose B := by
  apply replay_step (4 : Int) (by decide) world h .betaTranspose four_betaTranspose_occ0000 ((0 : Int),(1 : Int)) four_betaTranspose_branches0000 copies separate cover ceiling four_betaTranspose_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [four_betaTranspose_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_betaTranspose_node0001 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0027 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0033 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0158 world h nextB nextState
  · exact four_betaTranspose_node0159 world h copies separate cover ceiling nextB nextState
  · exact four_betaTranspose_node0177 world h nextB nextState
  · exact four_betaTranspose_node0178 world h copies separate cover ceiling nextB nextState
end FourBetaTranspose

theorem four_betaTranspose_seed_eq : SameCells (seed .betaTranspose) four_betaTranspose_occ0000 := by decide

theorem four_betaTranspose_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .betaTranspose 0 0 B) :
    Transition world h .betaTranspose B := by
  exact four_betaTranspose_node0000 world h copies separate cover ceiling B
    (state_congr four_betaTranspose_seed_eq (seed_state world h .betaTranspose B closed bounded clean))
#print axioms four_betaTranspose_local

end CornerCertificate

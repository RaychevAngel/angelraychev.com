import LQuadrantHpSamebarsUnequalBarLongPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LQuadrantBoundaryTips
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_samebars_unequal_bar_long_pruned_M (a b : Int) : Int := 6*(a+b+1)
def HP_samebars_unequal_bar_long_pruned_Box (a b x y : Int) : Prop := -HP_samebars_unequal_bar_long_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_samebars_unequal_bar_long_pruned_M a b ∧ y≤HP_samebars_unequal_bar_long_pruned_M a b
def HP_samebars_unequal_bar_long_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_samebars_unequal_bar_long_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep1).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o1 a b jx jy (hb) (hlong) (sep2).2.2.1 (insideT) (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o2 a b jx jy (hit) (insideT) (hb) (hlong) (sep2).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o3 a b jx jy (hb) (hit) (sep3).2.2.2 (hlong) (sep0).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o4 a b jx jy (hit) (hb) (sep2).2.2.1 (hlong) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o5 a b jx jy (hit) (hlong) (sep0).2.1 (hb) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o6 a b jx jy (sep3).2.2.1 (hit) (sep2).2.2.1 (hlong) (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n002_o7 a b jx jy (sep2).2.2.1 (hb) (sep3).2.1 (hlong) (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht3 : world (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o0 a b jx jy (hlong) (hit) (hb) (insideT) (sep1).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o1 a b jx jy (hb) (sep2).1 (insideT) (hlong) (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o2 a b jx jy (sep3).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o3 a b jx jy (sep3).2.2.1 (hit) (hlong) (sep1).2.1 (insideT) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o4 a b jx jy (hb) (insideT) (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o5 a b jx jy (insideT) (sep1).2.1 (hit) (hb) (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o6 a b jx jy (hb) (sep0).2.2.1 (hlong) (sep2).2.2.1 (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n003_o7 a b jx jy (hb) (insideT) (hlong) (sep3).2.2.1 (hit) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o0 a b jx jy (hlong) (hb) (sep0).2.1 (hit) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o1 a b jx jy (sep0).2.2.1 (hit) (hlong) (hb) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o2 a b jx jy (sep2).2.1 (hlong) (hb) (sep2).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o3 a b jx jy (sep2).2.1 (hb) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep0).1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node002 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o4 a b jx jy (insideT) (sep2).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o5 a b jx jy (hb) (hit) (sep0).2.1 (hlong) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o6 a b jx jy (sep2).2.2.1 (hlong) (insideT) (sep0).1 (hit) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n001_o7 a b jx jy (allowed) ((by simpa only [Same,eq_comm] using absent)) (hb) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node003 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_samebars_unequal_bar_long_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o0 a b jx jy (hlong) (hb) (insideT) (hit) (sep0).2.1 (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o1 a b jx jy (hstrict) (sep2).2.2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o2 a b jx jy (hb) (allowed) (sep2).2.2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o3 a b jx jy (hstrict) (hb) (hit) (insideT) (sep0).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o4 a b jx jy (hb) (hstrict) (sep2).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o5 a b jx jy (hb) (sep0).2.1 (insideT) (ha) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o6 a b jx jy (hb) (sep4).2.2.2 (sep0).2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n006_o7 a b jx jy (hb) (insideT) (hlong) (hit) (sep2).2.2.1 (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep0).2.1 (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o1 a b jx jy (sep2).2.2.1 (hb) (sep0).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o2 a b jx jy (hb) (hlong) (allowed) (sep2).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o3 a b jx jy (hb) (sep0).2.1 (sep2).2.2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o4 a b jx jy (hb) (insideT) (hstrict) (hit) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o5 a b jx jy (hit) (hlong) (sep3).2.1 (sep0).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o6 a b jx jy (hit) (hb) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node006 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n005_o7 a b jx jy (hit) (hb) (insideT) (hlong) (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node009 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o0 a b jx jy (hb) (hlong) (hit) (sep3).2.1 (sep4).2.2.1 (sep4).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o1 a b jx jy (sep2).2.2.1 (hlong) (hb) (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o2 a b jx jy (hb) (allowed) (hit) (insideT) (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o3 a b jx jy (sep5).2.1 (hb) (sep3).2.1 (sep4).2.2.1 (ha) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o4 a b jx jy (hb) (sep2).2.2.1 (insideT) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o5 a b jx jy (sep3).2.1 (ha) (hb) (hit) (sep5).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o6 a b jx jy (sep5).2.2.2 (hb) (hlong) (sep3).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n009_o7 a b jx jy (hb) (allowed) (hlong) (sep2).2.2.1 (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node008 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o0 a b jx jy (hlong) (hb) (insideT) (hit) (sep3).2.1 (sep4).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o1 a b jx jy (hb) (hlong) (sep2).2.2.1 (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o2 a b jx jy (allowed) (hlong) (hb) (sep2).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o3 a b jx jy (hb) (sep2).2.2.1 (hstrict) (insideT) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o4 a b jx jy (sep2).2.2.1 (hb) (insideT) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o5 a b jx jy (hit) (hb) (hlong) (sep3).2.1 (sep4).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o6 a b jx jy (hit) (hb) (sep3).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node009 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n008_o7 a b jx jy (sep2).2.2.1 (allowed) (hb) (hlong) (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node010 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o0 a b jx jy (sep4).2.1 (sep3).2.1 (ha) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o1 a b jx jy (insideT) (hit) (sep2).2.2.1 (hb) (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o2 a b jx jy (hlong) (insideT) (hb) (sep2).2.2.1 (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o3 a b jx jy (sep3).2.1 (sep4).2.1 (sep4).2.2.1 (hit) (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o4 a b jx jy (hit) (hstrict) (sep2).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o5 a b jx jy (sep2).2.2.1 (hlong) (sep4).2.2.1 (sep0).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o6 a b jx jy (sep4).2.2.2 (hit) (hb) (sep3).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n010_o7 a b jx jy (hlong) (allowed) (sep2).2.2.1 (insideT) (hb) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o0 a b jx jy (hb) (sep3).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node008 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o1 a b jx jy (hit) (sep0).2.1 (hb) (hlong) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o2 a b jx jy (hlong) (allowed) (hit) (hb) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o3 a b jx jy (insideT) (sep2).2.2.1 (hit) (sep3).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o4 a b jx jy (hstrict) (hit) (sep2).2.2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o5 a b jx jy (insideT) (hb) (sep2).2.2.1 (hlong) (hit) (sep3).1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o6 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hb) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node010 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n007_o7 a b jx jy (hit) (hb) (hlong) (sep2).2.1 (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node011 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht3 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have in3 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed3 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_point a b (hb) (hstrict) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o0 a b jx jy (sep0).2.1 (hb) (sep3).2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o1 a b jx jy (hit) (hstrict) (insideT) (hb) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o2 a b jx jy (allowed) (hb) (insideT) (sep2).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o3 a b jx jy (hb) (hit) (sep3).2.1 (sep0).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o4 a b jx jy (hstrict) (sep2).2.2.1 (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o5 a b jx jy (hb) (hstrict) (insideT) (sep3).2.1 (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o6 a b jx jy (hit) (insideT) (hstrict) (sep0).2.1 (sep3).2.2.2 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n011_o7 a b jx jy (hstrict) (hb) (sep2).2.1 (hit) (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o0 a b jx jy (hlong) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node005 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o1 a b jx jy (hlong) (sep2).2.2.1 (hb) (hit) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o2 a b jx jy (hb) (hit) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o3 a b jx jy (hit) (hb) (insideT) (sep2).2.2.1 (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o4 a b jx jy (hb) (hit) (insideT) (hstrict) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o5 a b jx jy (insideT) (sep0).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node007 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep0).2.1 (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node011 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n004_o7 a b jx jy (insideT) (hit) (allowed) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node013 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o0 a b jx jy (sep1).2.1 (insideT) (hit) (hlong) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o1 a b jx jy (sep2).2.1 (hb) (sep3).2.2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o2 a b jx jy (hit) (sep3).2.2.1 (hb) (insideT) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o3 a b jx jy (insideT) (hb) (hit) (hlong) (sep0).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o4 a b jx jy (hb) (sep3).2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o5 a b jx jy (insideT) (sep0).2.1 (hlong) (hit) (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o6 a b jx jy (hb) (sep0).2.1 (sep2).2.2.1 (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n013_o7 a b jx jy (insideT) (hit) (sep2).2.1 (hstrict) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node015 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep1).2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o1 a b jx jy (sep2).2.1 (hlong) (hit) (insideT) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o2 a b jx jy (insideT) (hit) (hlong) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o3 a b jx jy (hb) (sep2).2.1 (hit) (insideT) (hlong) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o4 a b jx jy (hit) (hlong) (sep4).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o5 a b jx jy (insideT) (hb) (hit) (hlong) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o6 a b jx jy (hb) (hit) (hlong) (sep2).2.2.1 (sep3).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n015_o7 a b jx jy (hb) (insideT) (sep4).2.2.1 (hit) (hlong) (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node019 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o0 a b jx jy (hlong) (hb) (insideT) (hit) (sep0).2.1 (sep7).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o1 a b jx jy (sep4).2.1 (hit) (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o2 a b jx jy (insideT) (hit) (hlong) (hb) (sep6).2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o3 a b jx jy (sep0).2.1 (hit) (insideT) (hb) (hstrict) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o4 a b jx jy (hit) (hstrict) (insideT) (hb) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o5 a b jx jy (hb) (insideT) (hlong) (hit) (sep0).2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o6 a b jx jy (hb) (hit) (hstrict) (sep6).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n019_o7 a b jx jy (hb) (sep3).2.1 (hlong) (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node022 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht9
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep7).2.1 (sep8).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o1 a b jx jy (sep6).2.2.1 (hb) (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o2 a b jx jy (hb) (hlong) (ap6_9).2.1 (sep9).2.1 (insideT) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o3 a b jx jy (insideT) (hb) (hit) (hstrict) (sep6).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o4 a b jx jy (hit) (insideT) (hb) (hstrict) (sep6).2.1 (ap6_9).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o5 a b jx jy (sep9).2.2.1 (sep8).2.1 (hit) (ha) (sep7).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o6 a b jx jy (sep7).2.1 (insideT) (sep9).2.2.2 (ha) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n022_o7 a b jx jy (hb) (ap6_9).2.1 (sep5).2.1 (hstrict) (insideT) (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node021 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht8
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep7).2.1 (sep8).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o1 a b jx jy (sep6).2.2.1 (hb) (hlong) (sep0).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o2 a b jx jy (hb) (allowed) (hlong) (insideT) (hit) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o3 a b jx jy (sep6).2.2.1 (hb) (sep7).2.1 (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o4 a b jx jy (sep6).2.2.1 (hb) (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o5 a b jx jy (hit) (sep3).2.1 (sep8).2.2.1 (hb) (sep6).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (hb) (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_samebars_unequal_bar_long_pruned_node022 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n021_o7 a b jx jy (hit) (hlong) (insideT) (sep3).2.1 (hb)

theorem HP_samebars_unequal_bar_long_pruned_node023 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht8
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_point a b (hb) (ha) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o0 a b jx jy (hstrict) (insideT) (sep8).2.1 (hit) (sep7).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o1 a b jx jy (sep4).2.1 (hlong) (ap6_8).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o2 a b jx jy (hstrict) (hb) (sep8).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o3 a b jx jy (insideT) (sep7).2.1 (hit) (hb) (hstrict) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o4 a b jx jy (ap6_8).2.1 (insideT) (hb) (sep6).2.1 (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o5 a b jx jy (hb) (hit) (sep8).2.2.1 (sep7).2.1 (sep6).2.2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o6 a b jx jy (insideT) (sep7).2.1 (hb) (sep8).2.2.2 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n023_o7 a b jx jy (hb) (insideT) (sep3).2.1 (ha) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node020 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o0 a b jx jy (insideT) (hb) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_samebars_unequal_bar_long_pruned_node021 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o1 a b jx jy (sep6).2.2.1 (hb) (sep0).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o2 a b jx jy (hb) (allowed) (hit) (insideT) (sep6).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o3 a b jx jy (sep6).2.2.1 (hb) (insideT) (hit) (sep7).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o4 a b jx jy (hstrict) (sep6).2.2.1 (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o5 a b jx jy (hlong) (hb) (sep6).2.2.1 (hit) (sep7).2.1 (sep7).1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o6 a b jx jy (sep7).2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_samebars_unequal_bar_long_pruned_node023 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n020_o7 a b jx jy (insideT) (hit) (hlong) (sep3).2.1 (hb)

theorem HP_samebars_unequal_bar_long_pruned_node018 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o0 a b jx jy (hlong) (hb) (insideT) (hit) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node019 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o1 a b jx jy (sep4).2.1 (hb) (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o2 a b jx jy (hb) (insideT) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o3 a b jx jy (sep6).2.2.1 (hb) (hstrict) (hit) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o4 a b jx jy (hstrict) (insideT) (hb) (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o5 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node020 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o6 a b jx jy (hb) (hstrict) (insideT) (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n018_o7 a b jx jy (hb) (insideT) (hit) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node024 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (in6) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) (-1 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o0 a b jx jy (sep0).1 (sep6).2.1 (hlong) (hit) (insideT) (hstrict) (in6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o1 a b jx jy (hlong) (hit) (in6) (sep4).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o2 a b jx jy (hit) (allowed) (insideT) (hlong) (in6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o3 a b jx jy (insideT) (hlong) (in6) (hstrict) (hit) (sep2).2.2.1 (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o4 a b jx jy (sep6).2.1 (hstrict) (in6) (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o5 a b jx jy (sep6).2.1 (insideT) (hlong) (in6) (hit) (hstrict) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o6 a b jx jy (hstrict) (sep6).2.1 (sep0).1 (hit) (hlong) (insideT) (in6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n024_o7 a b jx jy (allowed) (hit) (insideT) (in6) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node026 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht7 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_7 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have in7 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have allowed7 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o0 a b jx jy (sep6).2.1 (hb) (hlong) (insideT) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o1 a b jx jy (insideT) (sep6).2.2.1 (hb) (hit) (hlong) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o2 a b jx jy (hb) (insideT) (hit) (hlong) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o3 a b jx jy (hb) (insideT) (sep7).2.1 (sep6).2.2.1 (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o4 a b jx jy (hb) (insideT) (sep6).2.2.1 (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o5 a b jx jy (sep7).1 (hb) (hit) (sep7).2.1 (sep6).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o6 a b jx jy (insideT) (sep7).2.1 (hb) (hit) (sep6).2.1 (hlong) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n026_o7 a b jx jy (hb) (hlong) (sep3).2.1 (hit) (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node025 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht6 : world (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_6 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have in6 := inside (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed6 := avoid (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) b := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) b ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) b ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (-1 : Int) b ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) b ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) b ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (-1 : Int) b ∨ Contains (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (-1 : Int) b) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ha)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) b support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o0 a b jx jy (hit) (sep0).2.1 (hlong) (sep6).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o1 a b jx jy (hstrict) (sep6).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o2 a b jx jy (sep6).2.2.1 (allowed) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o3 a b jx jy (sep6).2.2.1 (hstrict) (sep0).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o4 a b jx jy (hstrict) (sep6).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep6).2.1 (hit) (sep0).2.1 (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node026 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o6 a b jx jy (hit) (hstrict) (insideT) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n025_o7 a b jx jy (hlong) (sep6).2.2.1 (hit) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node017 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (0 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (0 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_empty a b ((by simpa only [Contains] using occupied)) (ha) (hb)
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o0 a b jx jy (hlong) (hb) (hit) (sep0).2.2.2 (sep3).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node018 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) * b) ((1 : Int) + b) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o1 a b jx jy (sep3).2.1 (sep3).2.2.1 (hlong) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node024 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o2 a b jx jy (hit) (sep3).2.2.1 (hlong) (sep0).2.2.2 (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o3 a b jx jy (hlong) (hit) (hb) (sep3).2.2.1 (sep0).2.2.2 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o4 a b jx jy (sep3).2.1 (sep0).2.2.2 (hlong) (sep3).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o5 a b jx jy (hit) (sep0).2.2.2 (hlong) (hb) (sep3).2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o6 a b jx jy (insideT) (sep3).2.2.1 (hlong) (hit) (hstrict) (sep0).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) * a) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n017_o7 a b jx jy (hlong) (sep3).2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (sep3).2.2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node025 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_samebars_unequal_bar_long_pruned_node016 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o0 a b jx jy (hlong) (hit) (sep1).2.1 (insideT) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o1 a b jx jy (sep2).2.1 (hb) (hlong) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node017 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o2 a b jx jy (hb) (hlong) (hit) (insideT) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o3 a b jx jy (hb) (sep0).2.1 (hit) (insideT) (hlong) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o4 a b jx jy (sep4).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o5 a b jx jy (insideT) (sep1).2.1 (hlong) (hit) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o6 a b jx jy (hb) (hit) (hlong) (sep2).2.1 (sep3).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n016_o7 a b jx jy (sep2).2.1 (hstrict) (insideT) (hit) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node014 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o0 a b jx jy (hlong) (insideT) (sep1).2.1 (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o1 a b jx jy (sep2).2.1 (hlong) (hb) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node015 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o2 a b jx jy (hlong) (hb) (sep3).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o3 a b jx jy (hlong) (hit) (sep2).2.1 (hb) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o4 a b jx jy (sep2).2.2.1 (hit) (hb) (hlong) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node016 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o5 a b jx jy (insideT) (hlong) (sep1).2.1 (hb) (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o6 a b jx jy (hit) (sep0).2.2.1 (sep3).2.1 (sep2).2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n014_o7 a b jx jy (hit) (sep2).2.1 (insideT) (hb) (hstrict)

theorem HP_samebars_unequal_bar_long_pruned_node028 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o0 a b jx jy (hit) (sep1).2.1 (sep0).2.1 (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o1 a b jx jy (hb) (insideT) (sep2).2.1 (hlong) (hit) (sep4).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o2 a b jx jy (hlong) (hb) (sep3).2.1 (sep4).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o3 a b jx jy (hit) (sep0).2.1 (sep2).2.1 (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o4 a b jx jy (sep4).2.1 (hit) (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o5 a b jx jy (hit) (sep0).2.1 (hlong) (sep1).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o6 a b jx jy (sep2).2.1 (hit) (hb) (sep0).2.1 (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n028_o7 a b jx jy (insideT) (hb) (sep2).2.1 (sep4).2.2.1 (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node027 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o0 a b jx jy (hb) (insideT) (sep0).2.1 (hlong) (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hb) (sep2).2.1 (insideT) (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node028 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o2 a b jx jy (sep3).2.1 (hb) (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o3 a b jx jy (sep0).2.1 (hlong) (sep2).2.1 (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o4 a b jx jy (insideT) (sep3).2.1 (hb) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o5 a b jx jy (hit) (insideT) (hb) (sep1).2.1 (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o6 a b jx jy (sep3).2.1 (hlong) (hb) (sep2).2.1 (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n027_o7 a b jx jy (hb) (hstrict) (sep2).2.1 (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node012 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o0 a b jx jy (sep0).2.1 (hlong) (hit) (hb) (sep2).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o1 a b jx jy (hb) (hlong) (sep2).2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node013 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o2 a b jx jy (hb) (hit) (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node014 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o3 a b jx jy (sep2).2.2.2 (insideT) (sep0).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o4 a b jx jy (hb) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.1 (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node027 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o5 a b jx jy (hb) (sep1).2.2.2 (sep0).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o6 a b jx jy (sep0).2.1 (hlong) (sep2).2.2.1 (hit) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n012_o7 a b jx jy (insideT) (hstrict) (hb) (sep2).2.1 (hit)

theorem HP_samebars_unequal_bar_long_pruned_node031 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o0 a b jx jy (insideT) (hit) (sep0).2.1 (sep1).2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o1 a b jx jy (hit) (hlong) (hb) (sep3).2.2.1 (insideT) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o2 a b jx jy (ap1_4).2.2.1 (hlong) (hit) (insideT) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o3 a b jx jy (sep4).2.2.2 (hit) (hlong) (hb) (insideT) (sep0).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o4 a b jx jy (hb) (sep4).2.2.1 (sep3).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o5 a b jx jy (sep0).2.1 (sep1).2.1 (insideT) (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o6 a b jx jy (hb) (hit) (sep4).2.2.1 (sep3).2.2.1 (sep3).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n031_o7 a b jx jy (hb) (sep4).2.1 (hit) (hlong) (insideT) (ap1_4).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node032 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o0 a b jx jy (insideT) (hb) (hit) (sep4).2.1 (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o1 a b jx jy (hlong) (sep0).2.2.1 (hb) (insideT) (sep3).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o2 a b jx jy (hit) (hlong) (hb) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o3 a b jx jy (hlong) (hb) (sep4).2.2.1 (sep1).2.1 (sep4).2.1 (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o4 a b jx jy (hb) (insideT) (hit) (sep3).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o5 a b jx jy (hlong) (sep0).2.1 (sep1).2.1 (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o6 a b jx jy (sep3).2.2.1 (hlong) (hb) (hit) (sep0).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n032_o7 a b jx jy (sep4).2.2.1 (insideT) (allowed) (hb) (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node030 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o0 a b jx jy (hit) (sep3).2.1 (sep1).2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o1 a b jx jy (hit) (hlong) (sep3).1 (hb) (sep0).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o2 a b jx jy (insideT) (hit) (sep2).2.1 (sep3).2.2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o3 a b jx jy (sep3).2.1 (sep0).1 (hb) ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node031 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o4 a b jx jy (hit) (insideT) (hlong) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o5 a b jx jy (sep1).2.1 (insideT) (hit) (sep0).2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o6 a b jx jy (sep0).1 (hlong) (sep3).2.2.1 (sep3).2.1 (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n030_o7 a b jx jy (insideT) (hb) (allowed) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node032 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_samebars_unequal_bar_long_pruned_node034 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o0 a b jx jy (insideT) (sep1).2.1 (hit) (hb) (hlong) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o1 a b jx jy (sep3).2.1 (sep4).2.2.1 (hlong) (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o2 a b jx jy (sep2).2.1 (hlong) (sep4).2.2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o3 a b jx jy (sep0).2.1 (sep3).2.1 (hb) (sep4).2.1 (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o4 a b jx jy (sep4).2.1 (hb) (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o5 a b jx jy (sep0).2.1 (hb) (insideT) (hlong) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o6 a b jx jy (sep4).2.1 (hlong) (sep0).2.2.1 (hb) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n034_o7 a b jx jy (hb) (ap1_3).2.2.1 (sep3).2.1 (insideT) (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node036 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o0 a b jx jy (sep1).2.1 (sep5).2.1 (hit) (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o1 a b jx jy (hb) (sep5).1 (hit) (insideT) (sep3).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o2 a b jx jy (hit) (sep5).2.2.1 (hb) (sep2).2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o3 a b jx jy (hlong) (insideT) (hb) (sep5).2.1 (sep3).2.1 (sep0).1 (hit) (sep3).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o4 a b jx jy (hit) (hb) (sep5).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o5 a b jx jy (hb) (hlong) (sep0).2.1 (hit) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o6 a b jx jy (hb) (hit) (sep0).2.2.1 (hlong) (sep3).2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n036_o7 a b jx jy (hit) (hlong) (sep3).2.1 (insideT) (hb) (ap1_3).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node035 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o0 a b jx jy (sep4).2.1 (hb) (insideT) (sep1).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o1 a b jx jy (hlong) (hb) (sep3).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node036 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o2 a b jx jy (hb) (ap1_3).2.2.1 (sep4).2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o3 a b jx jy (hlong) (sep0).2.1 (hit) (insideT) (hb) (sep2).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o4 a b jx jy (hit) (hb) (insideT) (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o5 a b jx jy (hlong) (sep1).2.1 (hb) (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o6 a b jx jy (sep3).2.1 (hlong) (sep0).2.2.1 (hit) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n035_o7 a b jx jy (hb) (ap1_3).2.2.1 (sep3).2.1 (hlong) (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node033 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o0 a b jx jy (hlong) (hit) (hb) (insideT) (sep2).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o1 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb) (hit) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node034 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o2 a b jx jy (sep2).2.1 (hlong) (ap1_3).2.2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o3 a b jx jy (sep0).2.1 (sep2).2.1 (sep3).2.2.2 (hit) (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o4 a b jx jy (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep3).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node035 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o5 a b jx jy (hit) (hb) (hlong) (sep2).2.1 (sep0).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o6 a b jx jy (hit) (sep3).2.2.1 (sep2).2.1 (sep3).2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n033_o7 a b jx jy (sep3).2.1 (ap1_3).2.2.1 (insideT) (hb) (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node039 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o0 a b jx jy (insideT) (sep4).2.1 (sep0).2.1 (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o1 a b jx jy (hit) (insideT) (sep2).2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o2 a b jx jy (allowed) (insideT) (hit) (hlong) (hb) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o3 a b jx jy (hb) (hit) (ap1_3).2.2.1 (sep5).2.1 (insideT) (sep5).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o4 a b jx jy (sep2).2.2.1 (hlong) (hb) (insideT) (sep4).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o5 a b jx jy (sep5).2.1 (sep4).2.1 (hlong) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o6 a b jx jy (hlong) (hit) (sep5).2.2.1 (hb) (sep0).2.1 (sep4).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n039_o7 a b jx jy (hb) (hlong) (hit) (insideT) (sep5).2.1

theorem HP_samebars_unequal_bar_long_pruned_node040 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o0 a b jx jy (hb) (sep4).2.2.2 (hlong) (sep5).2.2.1 (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o1 a b jx jy (hit) (sep5).2.2.1 (sep2).2.2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o2 a b jx jy (hb) (ap1_3).2.2.1 (insideT) (hlong) (sep5).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o3 a b jx jy (hlong) (hit) (hb) (sep0).2.1 (sep5).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o4 a b jx jy (hb) (insideT) (hit) (sep4).2.2.1 (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o5 a b jx jy (hb) (insideT) (sep4).2.1 (sep0).2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o6 a b jx jy (hb) (sep5).2.2.2 (insideT) (hit) (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n040_o7 a b jx jy (sep2).2.2.1 (hit) (hb) (hlong) (insideT) (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node038 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o0 a b jx jy (hit) (hlong) (sep4).2.2.2 (hb) (sep0).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o1 a b jx jy (hit) (sep2).2.1 (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o2 a b jx jy (allowed) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node039 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o3 a b jx jy (sep0).2.1 (hit) (sep4).2.2.1 (hlong) (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o4 a b jx jy (hb) (hit) (sep2).2.2.1 (insideT) (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o5 a b jx jy (sep0).2.1 (insideT) (hit) (hb) (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (sep0).2.1 (insideT) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node040 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n038_o7 a b jx jy (insideT) (hlong) (hb) (sep2).2.1 (hit) (sep2).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node041 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (0 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) (0 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_empty a b (hstrict) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o0 a b jx jy (sep4).2.1 (hb) (hit) (hlong) (sep2).2.1 (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o1 a b jx jy (insideT) (hb) (ap1_3).2.2.1 (sep2).2.2.1 (sep0).2.2.2 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o2 a b jx jy (sep2).2.1 (hlong) (sep4).2.1 (hb) (sep2).2.2.1 (hit) (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o3 a b jx jy (sep4).2.1 (ap1_3).2.2.1 (sep2).2.1 (hlong) (hb) (sep0).2.2.2 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o4 a b jx jy (ap1_3).2.2.1 (sep0).2.2.1 (sep2).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o5 a b jx jy (hb) (ap1_3).2.2.1 (hlong) (sep4).2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o6 a b jx jy (sep4).2.1 (hlong) (ap1_3).2.2.1 (sep0).2.2.2 (hb) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n041_o7 a b jx jy (sep4).2.1 (sep2).2.1 (hit) (hb) (sep2).2.2.1 (ap1_3).2.2.1 (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node042 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (0 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) (0 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_empty a b (hb) ((by simpa only [Contains] using occupied)) (hstrict)
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o0 a b jx jy (sep4).2.1 (hb) (ap1_3).2.2.1 (hit) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o1 a b jx jy (insideT) (ap1_3).2.2.1 (hb) (hit) (sep2).2.2.1 (sep0).2.2.2 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o2 a b jx jy (sep4).2.1 (sep2).2.2.1 (sep2).2.1 (hlong) (hit) (hb) (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o3 a b jx jy (sep2).2.1 (ap1_3).2.2.1 (hlong) (sep0).2.2.2 (hit) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o4 a b jx jy (insideT) (sep2).2.2.1 (hb) (ap1_3).2.2.1 (hit) (sep0).2.2.2 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o5 a b jx jy (hit) (hlong) (hb) (ap1_3).2.2.1 (sep2).2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o6 a b jx jy (hb) (sep2).2.1 (sep4).2.1 (hlong) (ap1_3).2.2.1 (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n042_o7 a b jx jy (hb) (ap1_3).2.2.1 (sep4).2.1 (hlong) (sep2).2.2.1 (sep2).2.1 (hit)

theorem HP_samebars_unequal_bar_long_pruned_node045 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep4).2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o1 a b jx jy (hb) (hlong) (sep6).2.2.1 (insideT) (hit) (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o2 a b jx jy (hlong) (hit) (insideT) (sep5).2.1 (sep6).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o3 a b jx jy (sep6).2.2.1 (ap2_6).2.1 (hb) (sep6).2.1 (sep5).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o4 a b jx jy (hlong) (hb) (insideT) (ap2_6).2.1 (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o5 a b jx jy (hlong) (hit) (sep5).2.1 (sep6).2.1 (hb) (insideT) (sep4).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o6 a b jx jy (hb) (sep4).2.1 (sep5).2.1 (sep6).2.2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n045_o7 a b jx jy (insideT) (sep6).2.1 (hb) (hlong) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node046 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht6 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have in6 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (3 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o0 a b jx jy (hlong) (sep5).2.2.1 (hit) (sep5).2.2.2 (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o1 a b jx jy (hb) (hlong) (sep6).2.2.1 (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o2 a b jx jy (hlong) (hit) (sep6).2.1 (insideT) (hb) (allowed) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o3 a b jx jy (hb) (sep6).2.2.1 (hit) (sep4).2.1 (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o4 a b jx jy (hlong) (hit) (sep2).2.2.1 (insideT) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o5 a b jx jy (hlong) (sep5).2.1 (hb) (hit) (sep4).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o6 a b jx jy (hlong) (hit) (hb) (sep6).2.2.2 (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n046_o7 a b jx jy (sep2).2.2.1 (hlong) (sep2).2.1 (hb) (insideT) (hit) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node044 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep4).2.1 (sep5).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o1 a b jx jy (sep2).2.2.1 (hb) (hlong) (sep2).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o2 a b jx jy (sep5).2.1 (insideT) (hit) (hb) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node045 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o3 a b jx jy (hit) (sep2).2.2.1 (hb) (sep5).2.2.1 (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o4 a b jx jy (sep4).2.2.1 (sep2).2.2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o5 a b jx jy (hit) (hlong) (hb) (sep5).2.1 (sep5).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o6 a b jx jy (insideT) (hb) ((by simpa only [Same,eq_comm] using absent)) (hit) (sep4).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node046 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n044_o7 a b jx jy (sep2).2.2.1 (hlong) (hb) (hit) (insideT) (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node048 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht6 : world (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_6 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have in6 := inside (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have allowed6 := avoid (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o0 a b jx jy (hlong) (hit) (hb) (insideT) (sep0).2.1 (sep5).2.1 (sep6).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o1 a b jx jy (sep5).2.2.1 (hlong) (hb) (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o2 a b jx jy (allowed) (hb) (hit) (hlong) (insideT) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o3 a b jx jy (hlong) (hit) (sep5).2.1 (sep6).2.2.1 (hb) (ap1_3).2.2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o4 a b jx jy (hb) (insideT) (sep5).2.2.1 (ap1_3).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o5 a b jx jy (hlong) (sep5).2.1 (sep6).2.2.1 (hb) (sep5).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o6 a b jx jy (hit) (hb) (insideT) (hlong) (sep5).2.2.1 (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n048_o7 a b jx jy (allowed) (hlong) (hb) (sep5).2.2.1 (insideT) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node047 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-3 : Int) (1 : Int) ∨ Contains (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (-3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-3 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o0 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep5).2.1 (hit) (sep4).2.1 (hb) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node048 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o1 a b jx jy (sep0).2.1 (insideT) (hit) (hb) (sep5).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o2 a b jx jy (hb) (allowed) (hit) (hlong) (sep5).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o3 a b jx jy (hlong) (ap1_3).2.2.1 (hb) (insideT) (sep5).2.2.1 (hit) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o4 a b jx jy (insideT) (hb) (ap1_3).2.2.1 (hit) (hlong) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o5 a b jx jy (sep4).1 (sep4).2.1 (hit) (sep5).2.2.1 (hb) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o6 a b jx jy (hlong) (sep5).2.2.1 (insideT) (hit) (ap1_3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n047_o7 a b jx jy (hlong) (sep5).2.1 (hit) (hb) (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node050 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht6 : world (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap4_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht5
  have in6 := inside (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (ha) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (-1 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) (-1 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_empty a b (hstrict) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o0 a b jx jy (ha) (hit) (hb) (sep4).2.2.2 (sep5).2.1 (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o1 a b jx jy (hb) (ap2_6).2.1 (ha) (insideT) (hit) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o2 a b jx jy (sep5).2.1 (sep2).2.1 (sep4).2.2.2 (hit) (sep6).2.2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o3 a b jx jy (hb) (sep6).2.1 (sep5).2.1 (hit) (sep4).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o4 a b jx jy (hb) (ha) (ap2_6).2.1 (insideT) (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o5 a b jx jy (sep6).2.1 (hb) (ha) (hit) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o6 a b jx jy (hit) (insideT) (ap2_6).2.1 (sep6).2.2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n050_o7 a b jx jy (sep5).2.1 (hb) (hit) (ha) (sep6).2.1

theorem HP_samebars_unequal_bar_long_pruned_node049 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (0 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (0 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) (0 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_empty a b (hb) (hstrict) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (0 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o0 a b jx jy (hb) (sep5).2.1 (hit) (hlong) (sep2).2.1 (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o1 a b jx jy (hb) (ap1_3).2.2.1 (hit) (sep0).2.2.2 (insideT) (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (0 : Int) ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o2 a b jx jy (hb) (sep0).2.2.2 ((by simpa only [Same,eq_comm] using absent)) (hit) (ap1_3).2.2.1 (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node050 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o3 a b jx jy (sep2).2.1 (hlong) (ap1_3).2.2.1 (hit) (hb) (sep0).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o4 a b jx jy (ap1_3).2.2.1 (hlong) (sep2).2.2.1 (hb) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o5 a b jx jy (hb) (sep5).2.1 (ap1_3).2.2.1 (hit) (hlong) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o6 a b jx jy (sep2).2.1 (hb) (sep5).2.1 (sep0).2.2.2 (hlong) (hit) (ap1_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n049_o7 a b jx jy (ap1_3).2.2.1 (sep2).2.2.1 (hlong) (hit) (hb) (sep5).2.1 (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node051 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht5 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have in5 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (2 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o0 a b jx jy (ap1_3).2.2.1 (sep4).2.1 (hit) (hb) (insideT) (sep5).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o1 a b jx jy (hb) (hit) (sep5).2.2.1 (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o2 a b jx jy (insideT) (hb) (hlong) (hit) (sep2).2.2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o3 a b jx jy (sep5).2.2.1 (hlong) (sep4).2.1 (hb) (hit) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o4 a b jx jy (hb) (hlong) (insideT) (hit) (sep4).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o5 a b jx jy (hb) (hit) (ap1_3).2.2.1 (sep5).2.2.1 (hlong) (sep5).2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o6 a b jx jy (sep4).2.1 (hb) (hit) (sep5).2.2.2 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n051_o7 a b jx jy (hlong) (hb) (hit) (sep2).2.1 (sep2).2.2.1 (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node043 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o0 a b jx jy (insideT) (sep4).2.1 (hit) (hlong) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node044 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o1 a b jx jy (hit) (hb) (hlong) (insideT) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-2 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (allowed) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node047 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o3 a b jx jy (sep4).2.1 (insideT) (hlong) (sep4).1 (sep2).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o4 a b jx jy (insideT) (hb) (hit) (sep2).1 (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-2 : Int) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep4).2.2.1 (hit) (hb) (hlong) (sep4).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node049 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o6 a b jx jy (sep4).2.1 (hb) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node051 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n043_o7 a b jx jy (hb) (hlong) (sep2).2.2.1 (hit) (insideT) (sep2).2.1

theorem HP_samebars_unequal_bar_long_pruned_node052 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o0 a b jx jy (hb) (hit) (insideT) (ap1_3).2.2.1 (sep0).2.1 (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o1 a b jx jy (insideT) (hb) (hlong) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o2 a b jx jy (sep2).2.2.1 (sep4).2.1 (insideT) (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o3 a b jx jy (sep4).2.1 (hb) (hit) (sep0).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o4 a b jx jy (hb) (hlong) (insideT) (sep4).2.1 (hit) (sep2).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o5 a b jx jy (insideT) (hit) (ap1_3).2.2.1 (hlong) (sep0).2.1 (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o6 a b jx jy (hit) (hb) (insideT) (hlong) (sep4).2.2.2 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n052_o7 a b jx jy (hit) (sep2).2.2.1 (insideT) (hlong) (sep2).2.1 (hb)

theorem HP_samebars_unequal_bar_long_pruned_node037 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (-1 : Int) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (0 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o0 a b jx jy (sep0).2.1 (insideT) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node038 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o1 a b jx jy (sep2).2.1 (hlong) (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o2 a b jx jy (hit) (insideT) (allowed) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o3 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node041 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) a (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o4 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node042 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o5 a b jx jy (sep0).2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node043 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (0 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o6 a b jx jy (hit) (sep0).2.1 (insideT) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node052 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n037_o7 a b jx jy (insideT) (hit) (hb) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node053 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht3 : world (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have in3 := inside (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o0 a b jx jy (sep3).2.1 (hit) (hlong) (insideT) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o1 a b jx jy (sep3).2.2.1 (hit) (insideT) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o2 a b jx jy (sep3).2.1 (hit) (hb) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o3 a b jx jy (hit) (hstrict) (insideT) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o4 a b jx jy (hb) (insideT) (hlong) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o5 a b jx jy (hb) (hit) (hlong) (sep0).2.1 (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o6 a b jx jy (hstrict) (hit) (sep3).2.2.1 (hb) (sep3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n053_o7 a b jx jy (sep3).2.2.1 (hb) (allowed) (insideT) (hit) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node029 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o0 a b jx jy (hlong) (sep1).2.1 (insideT) (hb) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o1 a b jx jy (hlong) (sep0).2.2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node030 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o2 a b jx jy (hb) (hit) (sep2).2.1 (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o3 a b jx jy (insideT) (hlong) (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep0).1 (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node033 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o4 a b jx jy (sep2).2.1 (insideT) (hb) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o5 a b jx jy (hlong) (sep0).2.1 (hit) (hb) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o6 a b jx jy (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (sep0).2.2.1 (hlong) (sep2).2.2.2
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node037 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n029_o7 a b jx jy (allowed) (hb) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node053 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_samebars_unequal_bar_long_pruned_node072 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o0 a b jx jy (sep1).2.1 (insideT) (sep3).2.1 (hb) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o1 a b jx jy (hb) (sep3).2.2.1 (sep2).2.2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o2 a b jx jy (sep2).2.1 (hb) (insideT) (hlong) (ap1_4).2.2.1 (allowed) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o3 a b jx jy (insideT) (sep0).2.1 (sep4).2.1 (hit) (hb) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o4 a b jx jy (hb) (hlong) (hit) (sep3).2.2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o5 a b jx jy (hb) (sep1).2.1 (hit) (sep0).2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o6 a b jx jy (hlong) (hb) (hit) (sep4).2.2.1 (sep3).2.2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n072_o7 a b jx jy (sep4).2.1 (hit) (hb) (insideT) (ap1_4).2.2.1 (allowed) (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node073 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o0 a b jx jy (hit) (hb) (sep0).2.1 (insideT) (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o1 a b jx jy (sep3).1 (sep2).2.2.1 (insideT) (hlong) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o2 a b jx jy (sep4).2.1 (insideT) (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o3 a b jx jy (sep2).2.2.1 (sep4).2.2.1 (hb) (hit) (sep1).2.1 (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o4 a b jx jy (hb) (sep3).2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o5 a b jx jy (sep1).2.1 (hb) (hit) (hlong) (sep0).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o6 a b jx jy (hb) (sep0).2.2.1 (hit) (hstrict) (sep4).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n073_o7 a b jx jy (hb) (sep4).1 (hit) (insideT) (sep2).2.2.1 (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node071 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o0 a b jx jy (insideT) (hit) (hb) (sep0).2.1 (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o1 a b jx jy (hit) (insideT) (hb) (sep2).2.2.1 (hlong) (sep3).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o2 a b jx jy (sep2).2.1 (insideT) (hit) (hlong) (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o3 a b jx jy (sep2).2.2.1 (hlong) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node072 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o4 a b jx jy (sep3).2.1 (insideT) (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o5 a b jx jy (insideT) (hb) (sep0).2.1 (hit) (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o6 a b jx jy (hb) (sep3).2.2.1 (hit) (sep3).2.1 (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n071_o7 a b jx jy (insideT) (sep2).2.2.1 (hb) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node073 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_samebars_unequal_bar_long_pruned_node076 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((4 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_empty a b (hb) (ap1_4).2.2.1 (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o0 a b jx jy (hb) (ap1_4).2.2.1 (hstrict) (insideT) (hit) (sep1).2.1 (sep3).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o1 a b jx jy (hstrict) (sep4).2.1 (sep5).1 (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o2 a b jx jy (ap1_4).2.2.1 (hit) (hb) (hstrict) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o3 a b jx jy (sep4).2.2.1 (hstrict) (hb) (sep4).2.1 (hit) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o4 a b jx jy (hstrict) (hit) (sep5).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o5 a b jx jy (ap1_4).2.2.1 (insideT) (hit) (hstrict) (sep1).2.1 (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o6 a b jx jy (hstrict) (sep5).2.2.1 (sep3).2.2.1 (hb) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n076_o7 a b jx jy (insideT) (hstrict) (hb) (sep4).2.1 (hit)

theorem HP_samebars_unequal_bar_long_pruned_node075 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((3 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_point a b (hstrict) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_empty a b (hb) (ap1_4).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o0 a b jx jy (insideT) (ap1_4).2.2.1 (hit) (sep1).2.1 (sep0).2.1 (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o1 a b jx jy (hb) (hstrict) (sep4).2.1 (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node076 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o2 a b jx jy (insideT) (ap1_4).2.2.1 (hstrict) (hit) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o3 a b jx jy (sep4).2.2.1 (hstrict) (hit) (sep4).2.1 (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o4 a b jx jy (hb) (sep3).2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o5 a b jx jy (hb) (sep0).2.1 (sep1).2.1 (ap1_4).2.2.1 (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o6 a b jx jy (hstrict) (hit) (sep4).2.1 (hb) (sep4).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n075_o7 a b jx jy (sep4).2.1 (hstrict) (insideT) (hb) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node074 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_empty a b (hb) (ap1_3).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o0 a b jx jy (hit) (insideT) (hb) (sep0).2.1 (sep3).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o1 a b jx jy (hb) (insideT) (hit) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o2 a b jx jy (hb) (hit) (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o3 a b jx jy (hlong) (sep2).1 (sep3).2.2.2 (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node075 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o4 a b jx jy (hit) (hb) (hlong) (insideT) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o5 a b jx jy (sep1).2.1 (hb) (sep0).2.1 (insideT) (ap1_3).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o6 a b jx jy (sep3).2.2.1 (hlong) (sep3).2.2.2 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n074_o7 a b jx jy (hit) (hb) (insideT) (sep3).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node079 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o0 a b jx jy (sep0).2.1 (hb) (insideT) (hit) (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o1 a b jx jy (hb) (sep4).2.2.1 (hit) (insideT) (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o2 a b jx jy (allowed) (ap1_5).2.2.1 (insideT) (hlong) (sep2).2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o3 a b jx jy (hb) (hit) (sep5).2.2.1 (sep5).2.1 (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o4 a b jx jy (sep4).2.2.1 (hb) (hlong) (sep5).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o5 a b jx jy (sep0).2.1 (hb) (insideT) (hlong) (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o6 a b jx jy (hb) (hlong) (hit) (sep2).2.2.1 (sep4).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n079_o7 a b jx jy (hb) (sep5).2.1 (hlong) (allowed) (hit) (ap1_5).2.2.1 (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node081 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht6 : world (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have in6 := inside (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed6 := avoid (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (2 : Int) ∨ Contains (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (5 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep1).2.1 (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o1 a b jx jy (hstrict) (hb) (insideT) (hit) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o2 a b jx jy (hb) (insideT) (hit) (hlong) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o3 a b jx jy (hit) (hstrict) (insideT) (sep6).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o4 a b jx jy (hlong) (sep4).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o5 a b jx jy (sep6).2.2.1 (hlong) (hb) (hit) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o6 a b jx jy (insideT) (hstrict) (hb) (sep5).2.1 (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n081_o7 a b jx jy (hb) (allowed) (insideT) (hit) (sep6).2.2.1 (hlong)

theorem HP_samebars_unequal_bar_long_pruned_node082 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht6 : world (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have in6 := inside (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed6 := avoid (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (2 : Int) ∨ Contains (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) (2 : Int) ∨ Contains (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) (5 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o0 a b jx jy (sep5).2.1 (insideT) (hb) (sep1).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o1 a b jx jy (sep6).2.2.1 (hb) (hstrict) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o2 a b jx jy (sep5).2.1 (hlong) (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o3 a b jx jy (sep6).2.2.1 (insideT) (hb) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o4 a b jx jy (insideT) (hb) (hit) (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o5 a b jx jy (sep0).2.1 (insideT) (hb) (sep6).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o6 a b jx jy (insideT) (hb) (sep6).2.2.1 (sep5).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n082_o7 a b jx jy (hit) (hb) (allowed) (insideT) (hlong) (sep6).2.1

theorem HP_samebars_unequal_bar_long_pruned_node084 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht6 : world (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht7 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_7 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_7 : Apart (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have in6 := inside (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have in7 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed6 := avoid (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have allowed7 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + a) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((2 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o0 a b jx jy (hb) (hlong) (hit) (sep1).2.1 (sep5).2.2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o1 a b jx jy (hb) (sep5).2.2.1 (ap2_6).2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o2 a b jx jy (insideT) (sep5).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o3 a b jx jy (sep6).2.2.1 (hb) (hlong) (ap2_6).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o4 a b jx jy (hb) (sep5).2.2.1 (ap2_6).2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o5 a b jx jy (hlong) (insideT) (hit) (sep7).2.2.2 (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o6 a b jx jy (hlong) (hb) (ap2_6).2.1 (insideT) (sep5).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n084_o7 a b jx jy (hb) (hit) (allowed) (insideT) (hlong) (sep6).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node083 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht6 : world (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have in6 := inside (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed6 := avoid (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied)) (ha)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o0 a b jx jy (hlong) (insideT) (hit) (sep1).1 (hb) (sep1).2.1 (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o1 a b jx jy (insideT) (sep5).2.2.1 (hb) (hit) (ap2_6).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o2 a b jx jy (sep5).2.1 (insideT) (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o3 a b jx jy (hlong) (insideT) (hb) (hit) (sep6).2.2.1 (ap2_6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o4 a b jx jy (sep5).2.2.1 (ap2_6).2.1 (hit) (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o5 a b jx jy (hlong) (sep1).2.1 (hb) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node084 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o6 a b jx jy (ap2_6).2.1 (hb) (insideT) (sep5).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n083_o7 a b jx jy (sep6).1 (allowed) (insideT) (hlong) (hb) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node080 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) ((1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) ((1 : Int) + b) ∨ Contains (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (5 : Int) ((1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_empty a b (hb) (ha) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) ((1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o0 a b jx jy (sep1).2.1 (hb) (hit) (hlong) (sep5).2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o1 a b jx jy (hit) (hstrict) (sep5).2.1 (sep5).2.2.1 (insideT) (hlong) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o2 a b jx jy (hb) (sep5).2.2.1 (sep5).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node081 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o3 a b jx jy (sep5).2.2.1 (hstrict) (hb) (sep0).1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o4 a b jx jy (hstrict) (sep1).2.2.1 (sep5).2.1 (sep5).2.2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) ((1 : Int) + b) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o5 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (hb) (sep5).2.1 (hlong) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node082 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o6 a b jx jy (sep4).2.2.2 (hstrict) (insideT) (hlong) (sep3).2.2.2 (sep5).2.2.1 (hit) (sep2).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n080_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep5).2.1 (hit) (sep5).2.2.1 (hlong) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node083 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_samebars_unequal_bar_long_pruned_node078 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o0 a b jx jy (sep1).2.1 (hit) (sep4).2.1 (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o1 a b jx jy (sep4).1 (insideT) (hb) (hit) (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o2 a b jx jy (insideT) (hb) (sep4).2.2.1 (hit) (hlong) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o3 a b jx jy (sep4).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (sep2).2.2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node079 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o4 a b jx jy (hb) (insideT) (sep4).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o5 a b jx jy (hb) (sep0).2.1 (hlong) (hit) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o6 a b jx jy (hit) (sep4).2.1 (sep4).2.2.1 (hb) (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n078_o7 a b jx jy (sep2).2.2.1 (hit) (hb) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node080 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_samebars_unequal_bar_long_pruned_node088 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o0 a b jx jy (hb) (hstrict) (insideT) (hit) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o1 a b jx jy (sep7).1 (hstrict) (sep4).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o2 a b jx jy (hstrict) (sep2).2.1 (hit) (hb) (allowed) (ap1_5).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o3 a b jx jy (hb) (hit) (sep4).2.2.1 (sep6).2.1 (sep7).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o4 a b jx jy (hstrict) (insideT) (hb) (sep7).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o5 a b jx jy (hb) (hit) (hstrict) (sep0).2.1 (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o6 a b jx jy (sep7).2.2.1 (hstrict) (hb) (sep7).2.1 (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n088_o7 a b jx jy (hit) (allowed) (sep4).2.1 (insideT) (hb) (hstrict)

theorem HP_samebars_unequal_bar_long_pruned_node090 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht8 : world (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_8 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_8 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_8 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have in8 := inside (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_point a b (hb) (hstrict) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o0 a b jx jy (hb) (hstrict) (insideT) (hit) (sep1).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o1 a b jx jy (hb) (sep4).2.1 (hstrict) (sep8).1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o2 a b jx jy (hb) (insideT) (ap1_5).2.2.1 (sep2).2.1 (hit) (hstrict) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o3 a b jx jy (hit) (hb) (sep6).2.1 (hstrict) (sep7).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o4 a b jx jy (insideT) (hit) (hb) (hstrict) (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o5 a b jx jy (hb) (hstrict) (hit) (insideT) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o6 a b jx jy (sep8).2.1 (hstrict) (sep8).2.2.1 (hb) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n090_o7 a b jx jy (hb) (allowed) (hstrict) (hit) (insideT) (sep4).2.1

theorem HP_samebars_unequal_bar_long_pruned_node089 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_point a b (hstrict) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o0 a b jx jy (hit) (hb) (sep0).2.1 (sep1).2.1 (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hstrict) (hb) (insideT) (sep4).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_samebars_unequal_bar_long_pruned_node090 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o2 a b jx jy (hb) (hstrict) (allowed) (sep2).2.1 (ap1_5).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o3 a b jx jy (hit) (hb) (sep6).2.1 (sep7).2.1 (sep4).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o4 a b jx jy (sep7).2.1 (hb) (insideT) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o5 a b jx jy (insideT) (sep0).2.1 (hb) (hstrict) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o6 a b jx jy (sep3).2.1 (hb) (hstrict) (sep4).2.1 (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n089_o7 a b jx jy (insideT) (hb) (allowed) (sep4).2.1 (hstrict) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node087 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_point a b (hb) (hstrict) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o0 a b jx jy (hstrict) (hit) (sep1).2.1 (hb) (insideT) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o1 a b jx jy (hstrict) (hb) (insideT) (sep4).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node088 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o2 a b jx jy (hit) (hb) (allowed) (ap1_5).2.2.1 (hstrict) (insideT) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o3 a b jx jy (hstrict) (hit) (hb) (insideT) (sep4).2.2.2 (sep0).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep4).2.2.1 (hit) (hstrict) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node089 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o5 a b jx jy (sep0).2.1 (insideT) (hb) (hstrict) (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o6 a b jx jy (sep4).2.1 (sep4).2.2.1 (sep3).2.1 (hb) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n087_o7 a b jx jy (hit) (sep4).2.1 (allowed) (hstrict) (hb) (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node086 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((4 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_point a b (hb) (hstrict) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_empty a b ((by simpa only [Contains] using occupied)) (ap1_5).2.2.1 (hb)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o0 a b jx jy (sep4).2.1 (insideT) (sep1).2.1 (ap1_5).2.2.1 (hb) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o1 a b jx jy (hb) (sep5).2.1 (hstrict) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node087 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o2 a b jx jy (hit) (insideT) (ap1_5).2.2.1 (hstrict) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o3 a b jx jy (hit) (hb) (sep4).1 (sep5).2.1 (sep5).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o4 a b jx jy (sep4).2.1 (hstrict) (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o5 a b jx jy (sep0).2.1 (sep1).2.1 (insideT) (hb) (hit) (hstrict) (ap1_5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o6 a b jx jy (sep4).2.2.1 (sep5).2.2.1 (hit) (hstrict) (hb) (sep5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n086_o7 a b jx jy (hb) (hstrict) (hit) (sep5).2.1 (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node085 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_empty a b (hb) (ap1_4).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o0 a b jx jy (sep4).2.2.1 (hb) (insideT) (sep2).2.1 (hit) (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o1 a b jx jy (sep4).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o2 a b jx jy (hb) (insideT) (sep4).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o3 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (sep4).2.2.1 (sep2).1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node086 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o4 a b jx jy (hb) (insideT) (hlong) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o5 a b jx jy (sep1).2.1 (ap1_4).2.2.1 (hit) (sep0).2.1 (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o6 a b jx jy (hb) (sep4).2.2.1 (hit) (sep2).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n085_o7 a b jx jy (hit) (insideT) (hb) (sep4).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node094 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o0 a b jx jy (insideT) (sep1).2.1 (hit) (hb) (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o1 a b jx jy (sep4).2.2.1 (hstrict) (hit) (sep7).1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o2 a b jx jy (hit) (insideT) (hb) (ap1_5).2.2.1 (allowed) (sep2).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o3 a b jx jy (sep4).2.2.1 (sep6).2.1 (hstrict) (hb) (hit) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o4 a b jx jy (hit) (insideT) (hb) (hstrict) (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o5 a b jx jy (sep0).2.1 (hit) (hstrict) (hb) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o6 a b jx jy (hb) (sep7).2.2.1 (hstrict) (hit) (sep4).2.2.1 (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n094_o7 a b jx jy (allowed) (insideT) (hb) (ap1_5).2.2.1 (sep5).2.1 (hit) (hstrict)

theorem HP_samebars_unequal_bar_long_pruned_node096 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht8 : world (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_8 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_8 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_8 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have in8 := inside (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed8 := avoid (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (6 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (6 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (6 : Int) (3 : Int) ∨ Contains (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) (6 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_empty a b ((by simpa only [Contains] using occupied)) (hb) (ap1_4).2.2.1 (hlong)
  obtain ⟨t,ht,hit⟩ := cover (6 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o0 a b jx jy (ap1_5).2.2.1 (hstrict) (hb) (insideT) (hit) (sep1).2.1 (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o1 a b jx jy (hstrict) (sep8).1 (hb) (sep4).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o2 a b jx jy (insideT) (sep2).2.1 (hb) (hstrict) (hit) (ap1_5).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o3 a b jx jy (sep4).2.2.1 (hb) (sep6).2.1 (sep8).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o4 a b jx jy (hb) (hstrict) (hit) (sep8).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o5 a b jx jy (hstrict) (hb) (sep0).2.1 (ap1_5).2.2.1 (sep1).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o6 a b jx jy (hb) (hstrict) (sep6).2.1 (hit) (sep4).2.2.1 (sep8).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n096_o7 a b jx jy (hstrict) (insideT) (sep5).2.1 (hit) (ap1_5).2.2.1 (allowed) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node095 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht7 : world (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_7 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_7 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have in7 := inside (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed7 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o0 a b jx jy (hstrict) (hb) (sep2).2.1 (insideT) (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o1 a b jx jy (insideT) (hb) (sep4).2.2.1 (hstrict) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_samebars_unequal_bar_long_pruned_node096 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o2 a b jx jy (hstrict) (insideT) (hit) (ap1_5).2.2.1 (allowed) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o3 a b jx jy (sep4).2.2.1 (hstrict) (sep6).2.1 (hit) (hb) (sep7).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o4 a b jx jy (hb) (sep7).2.1 (insideT) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o5 a b jx jy (hit) (hstrict) (sep1).2.1 (insideT) (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o6 a b jx jy (sep7).2.1 (sep6).2.1 (hb) (sep4).2.2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n095_o7 a b jx jy (hit) (hstrict) (hb) (allowed) (insideT) (sep6).2.1

theorem HP_samebars_unequal_bar_long_pruned_node093 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_point a b (hstrict) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o0 a b jx jy (hit) (hb) (sep1).2.1 (sep0).2.1 (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o1 a b jx jy (sep4).2.2.1 (hstrict) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node094 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o2 a b jx jy (sep2).2.1 (hstrict) (insideT) (ap1_5).2.2.1 (hb) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o3 a b jx jy (sep6).2.1 (sep0).1 (sep4).2.1 (sep2).2.1 (hb) (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o4 a b jx jy (hstrict) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hb) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_samebars_unequal_bar_long_pruned_node095 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o5 a b jx jy (hb) (sep1).2.1 (insideT) (sep0).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o6 a b jx jy (sep4).2.2.1 (hstrict) (sep6).2.1 (hit) (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n093_o7 a b jx jy (sep6).2.1 (hstrict) (hit) (hb) (insideT) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node097 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o0 a b jx jy (insideT) (sep1).2.1 (hit) (hb) (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o1 a b jx jy (sep6).2.2.1 (sep2).2.2.1 (hit) (insideT) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o2 a b jx jy (ap1_5).2.2.1 (hit) (hstrict) (sep2).2.1 (allowed) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o3 a b jx jy (hstrict) (sep2).2.2.1 (sep6).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o4 a b jx jy (hb) (insideT) (sep2).2.1 (hstrict) (sep6).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o5 a b jx jy (hit) (sep0).2.1 (insideT) (hstrict) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o6 a b jx jy (sep6).2.1 (sep2).2.2.1 (hb) (hstrict) (sep4).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n097_o7 a b jx jy (hstrict) (hit) (sep6).2.1 (allowed) (hb) (insideT)

theorem HP_samebars_unequal_bar_long_pruned_node092 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((4 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_empty a b (hb) (ap1_5).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o0 a b jx jy (hb) (hstrict) (ap1_5).2.2.1 (hit) (insideT) (sep1).2.1 (sep4).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o1 a b jx jy (hb) (hit) (sep5).2.1 (hstrict) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node093 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o2 a b jx jy (ap1_5).2.2.1 (hb) (hit) (hstrict) (insideT) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o3 a b jx jy (hb) (sep5).2.1 (hit) (sep4).1 (sep5).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o4 a b jx jy (sep5).2.2.1 (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hstrict) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_samebars_unequal_bar_long_pruned_node097 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o5 a b jx jy (sep1).2.1 (insideT) (ap1_5).2.2.1 (sep0).2.1 (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o6 a b jx jy (hstrict) (hb) (hit) (sep5).2.1 (sep5).2.2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n092_o7 a b jx jy (hit) (hb) (insideT) (hstrict) (sep5).2.1

theorem HP_samebars_unequal_bar_long_pruned_node091 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_empty a b (ap1_4).2.2.1 ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o0 a b jx jy (sep4).2.2.1 (sep2).1 (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o1 a b jx jy (hit) (hb) (insideT) (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o2 a b jx jy (insideT) (hit) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep2).1 (hb) (sep4).2.2.1 (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node092 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o4 a b jx jy (insideT) (hb) (hlong) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o5 a b jx jy (sep0).2.1 (hit) (sep1).2.1 (hb) (sep4).2.2.1 (ap1_4).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o6 a b jx jy (sep4).2.2.1 (insideT) (hit) (hb) (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n091_o7 a b jx jy (insideT) (sep4).2.2.1 (hb) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node098 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_point a b (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o0 a b jx jy (sep4).2.1 (insideT) (hit) (hb) (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o1 a b jx jy (hit) (sep4).2.2.1 (hstrict) (insideT) (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o2 a b jx jy (insideT) (hb) (sep4).2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o3 a b jx jy (hit) (hb) (sep2).2.1 (sep1).2.1 (sep4).2.2.1 (sep2).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o4 a b jx jy (hit) (hb) (insideT) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o5 a b jx jy (hb) (insideT) (hit) (hlong) (sep1).2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o6 a b jx jy (sep0).2.2.1 (hit) (sep3).2.1 (hstrict) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n098_o7 a b jx jy (hlong) (hb) (sep2).2.2.1 (hit) (insideT) (sep4).1

theorem HP_samebars_unequal_bar_long_pruned_node077 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o0 a b jx jy (hb) (sep0).2.1 (hlong) (sep1).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o1 a b jx jy (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (hit) (sep2).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node078 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o2 a b jx jy (hstrict) (insideT) (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o3 a b jx jy (hb) (sep3).2.1 (hit) (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node085 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o4 a b jx jy (insideT) (hb) (hit) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o5 a b jx jy (hit) (hlong) (insideT) (sep1).2.1 (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o6 a b jx jy (sep2).2.2.1 (hlong) (hit) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node091 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n077_o7 a b jx jy (sep2).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node098 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_samebars_unequal_bar_long_pruned_node101 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((4 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_empty a b ((by simpa only [Contains] using occupied)) (hstrict) (hb) (ap1_4).2.2.1
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o0 a b jx jy (sep3).1 (ap1_4).2.2.1 (insideT) (hit) (hb) (hstrict) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o1 a b jx jy (hb) (insideT) (sep5).1 (hstrict) (hit) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o2 a b jx jy (insideT) (hstrict) (sep2).2.1 (hb) (ap1_4).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o3 a b jx jy (hit) (sep5).2.1 (sep4).2.2.1 (hstrict) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o4 a b jx jy (hb) (hstrict) (insideT) (sep5).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o5 a b jx jy (ap1_4).2.2.1 (sep0).2.1 (insideT) (hstrict) (sep1).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o6 a b jx jy (hit) (hb) (sep4).2.1 (sep4).2.2.1 (hstrict) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n101_o7 a b jx jy (sep4).2.1 (hb) (insideT) (hstrict) (hit)

theorem HP_samebars_unequal_bar_long_pruned_node102 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_5 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_5 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o0 a b jx jy (hit) (hstrict) (sep0).2.1 (insideT) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o1 a b jx jy (hb) (insideT) (hit) (hstrict) (sep5).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o2 a b jx jy (insideT) (ap1_4).2.2.1 (hstrict) (hb) (allowed) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o3 a b jx jy (sep5).2.2.1 (hb) (hit) (insideT) (sep0).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o4 a b jx jy (insideT) (hstrict) (hb) (sep2).2.1 (sep5).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o5 a b jx jy (insideT) (sep0).2.1 (hit) (hstrict) (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o6 a b jx jy (sep3).2.2.1 (hb) (sep5).2.1 (hstrict) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n102_o7 a b jx jy (hit) (allowed) (insideT) (sep5).2.1 (hstrict) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node100 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((3 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_point a b (hstrict) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_empty a b (ap1_4).2.2.1 (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o0 a b jx jy (sep4).2.2.1 (ap1_4).2.2.1 (hstrict) (sep1).2.1 (sep3).1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o1 a b jx jy (hstrict) (insideT) (hb) (sep4).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node101 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o2 a b jx jy (ap1_4).2.2.1 (hit) (hstrict) (hb) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o3 a b jx jy (hstrict) (sep4).2.1 (sep4).2.2.1 (hit) (sep3).1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hstrict) (sep4).2.2.1 (insideT) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_samebars_unequal_bar_long_pruned_node102 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o5 a b jx jy (hit) (hstrict) (ap1_4).2.2.1 (sep0).2.1 (hb) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o6 a b jx jy (hit) (hstrict) (sep3).2.2.1 (sep4).2.2.1 (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n100_o7 a b jx jy (hit) (sep4).2.1 (insideT) (hstrict) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node099 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b ((2 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_point a b (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_empty a b (hb) (ap1_3).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o0 a b jx jy (hit) (hb) (sep2).1 (insideT) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o1 a b jx jy (hb) (hit) (insideT) (hlong) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o2 a b jx jy (insideT) (hit) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o3 a b jx jy (insideT) (hb) (sep3).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep2).1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_samebars_unequal_bar_long_pruned_node100 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o4 a b jx jy (hlong) (insideT) (hb) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o5 a b jx jy (sep1).2.1 (ap1_3).2.2.1 (hlong) (hit) (sep0).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o6 a b jx jy (sep3).2.2.1 (hlong) (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n099_o7 a b jx jy (insideT) (sep3).2.2.1 (hit) (hb)

theorem HP_samebars_unequal_bar_long_pruned_node103 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_point a b (hlong) (hb) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o0 a b jx jy (insideT) (hb) (sep1).2.1 (sep3).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o1 a b jx jy (hstrict) (insideT) (hit) (sep2).2.2.1 (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o2 a b jx jy (hb) (insideT) (hlong) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o3 a b jx jy (hlong) (hit) (insideT) (sep1).2.1 (sep0).2.1 (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o4 a b jx jy (hit) (hb) (insideT) (sep3).2.1 (sep3).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o5 a b jx jy (insideT) (hit) (hb) (sep0).2.1 (sep1).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o6 a b jx jy (sep2).2.1 (hit) (sep3).2.2.1 (hstrict) (sep0).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n103_o7 a b jx jy (hit) (hb) (hlong) (sep2).2.2.1 (insideT) (sep3).2.2.1

theorem HP_samebars_unequal_bar_long_pruned_node054 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_point a b ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o0 a b jx jy (hb) (sep2).2.1 (insideT) (hlong) (hit) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o1 a b jx jy (hlong) (hb) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node071 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o2 a b jx jy (insideT) (sep2).2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o3 a b jx jy (sep2).2.1 (sep0).2.1 (hb) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node074 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o4 a b jx jy (hlong) (hit) (sep2).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node077 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o5 a b jx jy (hb) (hit) (sep0).2.1 (hstrict) (sep1).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o6 a b jx jy (hb) (sep2).2.2.1 (hlong) (sep2).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node099 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n054_o7 a b jx jy (hb) (insideT) (sep2).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_samebars_unequal_bar_long_pruned_node103 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_samebars_unequal_bar_long_pruned_node104 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o0 a b jx jy (hb) (insideT) (sep2).2.1 (hit) (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o1 a b jx jy (hstrict) (hit) (insideT) (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o2 a b jx jy (sep2).2.1 (hit) (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o3 a b jx jy (hb) (sep2).2.2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o4 a b jx jy (hb) (hit) (hlong) (insideT) (sep0).2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o5 a b jx jy (insideT) (hlong) (sep1).2.1 (hit) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o6 a b jx jy (sep2).2.1 (hit) (sep2).2.2.1 (hb) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n104_o7 a b jx jy (insideT) (sep2).2.2.1 (hit) (hb) (hlong) (allowed)

theorem HP_samebars_unequal_bar_long_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have support : HP_samebars_unequal_bar_long_pruned_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_point a b (hb) (hlong) ((by simpa only [HP_samebars_unequal_bar_long_pruned_Box,HP_samebars_unequal_bar_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (1 : Int) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o0 a b jx jy (hb) (hlong) (insideT) (sep1).2.1 (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o1 a b jx jy (hit) (insideT) (sep0).2.2.1 (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node001 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o2 a b jx jy (hit) (hb) (insideT) (allowed) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node004 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((1 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (insideT) (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node012 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o4 a b jx jy (insideT) (sep0).2.2.1 (hit) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node029 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o5 a b jx jy (sep0).2.1 (hlong) (hit) (hb) (insideT) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o6 a b jx jy (sep0).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node054 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_samebars_unequal_bar_long_pruned_n000_o7 a b jx jy (hb) (allowed) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_samebars_unequal_bar_long_pruned_node104 a b ha hb hstrict hlong world copies inside cover separate avoid ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)

theorem HP_samebars_unequal_bar_long_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_samebars_unequal_bar_long_pruned_Inside t)
    (cover : ∀ x y, HP_samebars_unequal_bar_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenShortTip a b t)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_samebars_unequal_bar_long_pruned_node000 a b ha hb hstrict hlong world copies inside cover sep avoid anchor0 anchor1 rootap0_1

theorem HP_samebars_unequal_bar_long_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenShortTip a b t := by
    exact unequal_avoid_short_tips a b (by omega) (by omega) (by omega) T
  apply HP_samebars_unequal_bar_long_pruned_bounded_obstruction a b ha hb hstrict hlong T.world T.copies ?_ ?_ T.disjoint avoid anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_samebars_unequal_bar_long_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk ((1 : Int) + a) (0 : Int) a b (0 : Int) (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_samebars_unequal_bar_long_pruned_anchored_obstruction a b ha hb hstrict hlong U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_samebars_unequal_bar_long_pruned_no_shifted_anchor
#print axioms HP_samebars_unequal_bar_long_pruned_bounded_obstruction
end PolyominoFormal.LRegion

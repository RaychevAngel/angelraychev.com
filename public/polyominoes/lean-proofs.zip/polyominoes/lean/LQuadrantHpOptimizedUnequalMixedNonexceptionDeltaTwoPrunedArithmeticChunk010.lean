import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n281_o6 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n281_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((7 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (((((5 : Int) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7636 a b) ∨ (fact_366edf150095_7767 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7636 a b) ∧ (fact_366edf150095_7767 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7636 a b) ∧ (fact_366edf150095_7767 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6194 a b)))) ∨ ((fact_366edf150095_7636 a b) ∧ (fact_366edf150095_7767 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6194 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n282_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (((4 : Int) + a) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_tall (a b : Int)
    (h0 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7594 a b) ∨ (fact_366edf150095_7653 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7594 a b) ∧ (fact_366edf150095_7653 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7594 a b) ∧ (fact_366edf150095_7653 a b) ∧ (((fact_366edf150095_4185 a b) ∨ (fact_366edf150095_3780 a b) ∨ (fact_366edf150095_5931 a b) ∨ (fact_366edf150095_6014 a b) ∨ (fact_366edf150095_3861 a b) ∨ (fact_366edf150095_4294 a b) ∨ (fact_366edf150095_4669 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5036 a b) ∨ (fact_366edf150095_5051 a b) ∨ (fact_366edf150095_4404 a b)) ∨ ((fact_366edf150095_5156 a b) ∨ (fact_366edf150095_4450 a b) ∨ (fact_366edf150095_6375 a b) ∨ (fact_366edf150095_6463 a b) ∨ (fact_366edf150095_4534 a b) ∨ (fact_366edf150095_5284 a b) ∨ (fact_366edf150095_5456 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5696 a b) ∨ (fact_366edf150095_5719 a b) ∨ (fact_366edf150095_5418 a b)))) ∨ ((fact_366edf150095_7594 a b) ∧ (fact_366edf150095_7653 a b) ∧ ((fact_366edf150095_4185 a b) ∨ (fact_366edf150095_3780 a b) ∨ (fact_366edf150095_5931 a b) ∨ (fact_366edf150095_6014 a b) ∨ (fact_366edf150095_3861 a b) ∨ (fact_366edf150095_4294 a b) ∨ (fact_366edf150095_4669 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5036 a b) ∨ (fact_366edf150095_5051 a b) ∨ (fact_366edf150095_4404 a b)) ∧ ((fact_366edf150095_5156 a b) ∨ (fact_366edf150095_4450 a b) ∨ (fact_366edf150095_6375 a b) ∨ (fact_366edf150095_6463 a b) ∨ (fact_366edf150095_4534 a b) ∨ (fact_366edf150095_5284 a b) ∨ (fact_366edf150095_5456 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5696 a b) ∨ (fact_366edf150095_5719 a b) ∨ (fact_366edf150095_5418 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_empty (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2324 a b run_x) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3019 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (run_x ≤ ((6 : Int) + b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n283_run_floor (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((6 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3323 a b run_x) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3602 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_four (a b : Int)
    (h0 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (((((5 : Int) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7648 a b) ∨ (fact_366edf150095_7778 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7648 a b) ∧ (fact_366edf150095_7778 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7648 a b) ∧ (fact_366edf150095_7778 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6673 a b)))) ∨ ((fact_366edf150095_7648 a b) ∧ (fact_366edf150095_7778 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6673 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n284_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (((((5 : Int) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7649 a b) ∨ (fact_366edf150095_7779 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7649 a b) ∧ (fact_366edf150095_7779 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7649 a b) ∧ (fact_366edf150095_7779 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6742 a b)))) ∨ ((fact_366edf150095_7649 a b) ∧ (fact_366edf150095_7779 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_5688 a b) ∨ (fact_366edf150095_5709 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6742 a b))))))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n285_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (((4 : Int) + a) ≤ run_x))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3505 a b) ∨ (fact_366edf150095_3454 a b) ∨ (fact_366edf150095_5781 a b) ∨ (fact_366edf150095_5789 a b) ∨ (fact_366edf150095_3462 a b) ∨ (fact_366edf150095_3700 a b) ∨ (fact_366edf150095_3918 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3709 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4129 a b) ∨ (fact_366edf150095_3724 a b) ∨ (fact_366edf150095_5875 a b) ∨ (fact_366edf150095_5958 a b) ∨ (fact_366edf150095_3805 a b) ∨ (fact_366edf150095_4238 a b) ∨ (fact_366edf150095_4635 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4394 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7477 a b) ∨ (fact_366edf150095_7552 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7477 a b) ∧ (fact_366edf150095_7552 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7477 a b) ∧ (fact_366edf150095_7552 a b) ∧ (((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_3949 a b) ∨ (fact_366edf150095_4927 a b) ∨ (fact_366edf150095_5029 a b) ∨ (fact_366edf150095_4396 a b)) ∨ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_4715 a b) ∨ (fact_366edf150095_5607 a b) ∨ (fact_366edf150095_5692 a b) ∨ (fact_366edf150095_5410 a b)))) ∨ ((fact_366edf150095_7477 a b) ∧ (fact_366edf150095_7552 a b) ∧ ((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_3949 a b) ∨ (fact_366edf150095_4927 a b) ∨ (fact_366edf150095_5029 a b) ∨ (fact_366edf150095_4396 a b)) ∧ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_4715 a b) ∨ (fact_366edf150095_5607 a b) ∨ (fact_366edf150095_5692 a b) ∨ (fact_366edf150095_5410 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_empty (a b run_x : Int)
    (h0 : ((6 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((5 : Int) + b)))
    (h2 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2324 a b run_x) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3019 a b run_x) ∨ (fact_366edf150095_2975 a b run_x)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n286_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3323 a b run_x) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3602 a b run_x) ∨ (fact_366edf150095_3555 a b run_x))))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_point (a b : Int)
    (h0 : (fact_366edf150095_0 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_empty (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_3222 a b) ∨ (fact_366edf150095_3128 a b) ∨ (fact_366edf150095_4218 a b) ∨ (fact_366edf150095_4307 a b) ∨ (fact_366edf150095_3136 a b) ∨ (fact_366edf150095_3353 a b) ∨ (fact_366edf150095_3389 a b) ∨ (fact_366edf150095_3147 a b) ∨ (fact_366edf150095_3411 a b) ∨ (((((5 : Int) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((4 : Int) + a)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((6 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h4 : ((((2 : Int) + (0 : Int)) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < ((2 : Int) - a)) ∨ (((2 : Int) + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < ((2 : Int) + b))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o0 (a b jx jy : Int)
    (h0 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1814 a b jx jy))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1817 a b jx jy))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o2 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h1 : (fact_366edf150095_1847 a b jx jy))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (fact_366edf150095_1862 a b jx jy))
    (h8 : (((jx + (0 : Int)) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : (fact_366edf150095_1863 a b jx jy))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o5 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_366edf150095_1846 a b jx jy))
    (h9 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o6 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_366edf150095_1816 a b jx jy))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n287_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1815 a b jx jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + a) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_6 a b))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_empty (a b : Int)
    (h0 : ((fact_366edf150095_3228 a b) ∨ (fact_366edf150095_3134 a b) ∨ (fact_366edf150095_4224 a b) ∨ (fact_366edf150095_4313 a b) ∨ (fact_366edf150095_3142 a b) ∨ (fact_366edf150095_3359 a b) ∨ (fact_366edf150095_3393 a b) ∨ (fact_366edf150095_3151 a b) ∨ (fact_366edf150095_3412 a b) ∨ (((((5 : Int) - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) + b)) ∧ ((5 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((2 : Int) + ((2 : Int) * a)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (fact_366edf150095_1838 a b jx jy))
    (h2 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : (((5 : Int) > jx) ∨ ((5 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1843 a b jx jy))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o2 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : (fact_366edf150095_1859 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o3 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1874 a b jx jy))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : ((jx < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1875 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o5 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1858 a b jx jy))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o6 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1842 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n288_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1839 a b jx jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3513 a b) ∨ (fact_366edf150095_3488 a b) ∨ (fact_366edf150095_5821 a b) ∨ (fact_366edf150095_5824 a b) ∨ (fact_366edf150095_3491 a b) ∨ (fact_366edf150095_4097 a b) ∨ (fact_366edf150095_4103 a b) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - a)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - b)) ∧ ((7 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4106 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3237 a b) ∨ (fact_366edf150095_3205 a b) ∨ (fact_366edf150095_5106 a b) ∨ (fact_366edf150095_5108 a b) ∨ (fact_366edf150095_3206 a b) ∨ (fact_366edf150095_3435 a b) ∨ (fact_366edf150095_3436 a b) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - a)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - b)) ∧ ((7 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3437 a b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7485 a b) ∨ (fact_366edf150095_7393 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7485 a b) ∧ (fact_366edf150095_7393 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7485 a b) ∧ (fact_366edf150095_7393 a b) ∧ (((fact_366edf150095_4179 a b) ∨ (fact_366edf150095_3774 a b) ∨ (fact_366edf150095_5925 a b) ∨ (fact_366edf150095_6008 a b) ∨ (fact_366edf150095_3855 a b) ∨ (fact_366edf150095_4288 a b) ∨ (fact_366edf150095_4665 a b) ∨ (fact_366edf150095_3955 a b) ∨ (fact_366edf150095_4930 a b) ∨ (((((5 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5045 a b)) ∨ ((fact_366edf150095_3444 a b) ∨ (fact_366edf150095_3368 a b) ∨ (fact_366edf150095_5240 a b) ∨ (fact_366edf150095_5335 a b) ∨ (fact_366edf150095_3379 a b) ∨ (fact_366edf150095_3636 a b) ∨ (fact_366edf150095_3659 a b) ∨ (fact_366edf150095_3401 a b) ∨ (fact_366edf150095_3684 a b) ∨ (((((5 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3693 a b)))) ∨ ((fact_366edf150095_7485 a b) ∧ (fact_366edf150095_7393 a b) ∧ ((fact_366edf150095_4179 a b) ∨ (fact_366edf150095_3774 a b) ∨ (fact_366edf150095_5925 a b) ∨ (fact_366edf150095_6008 a b) ∨ (fact_366edf150095_3855 a b) ∨ (fact_366edf150095_4288 a b) ∨ (fact_366edf150095_4665 a b) ∨ (fact_366edf150095_3955 a b) ∨ (fact_366edf150095_4930 a b) ∨ (((((5 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5045 a b)) ∧ ((fact_366edf150095_3444 a b) ∨ (fact_366edf150095_3368 a b) ∨ (fact_366edf150095_5240 a b) ∨ (fact_366edf150095_5335 a b) ∨ (fact_366edf150095_3379 a b) ∨ (fact_366edf150095_3636 a b) ∨ (fact_366edf150095_3659 a b) ∨ (fact_366edf150095_3401 a b) ∨ (fact_366edf150095_3684 a b) ∨ (((((5 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3693 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ a))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ (fact_366edf150095_3053 a b run_x) ∨ (fact_366edf150095_2355 a b run_x) ∨ ((((7 : Int) ≥ ((4 : Int) - a)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - b)) ∧ ((7 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3055 a b run_x)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n289_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (fact_366edf150095_3561 a b run_x) ∨ (fact_366edf150095_3320 a b run_x) ∨ (((((4 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3604 a b run_x))))
    (h2 : (run_x ≤ a))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_point (a b : Int)
    (h0 : (fact_366edf150095_0 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_empty (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : ((((2 : Int) + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < ((2 : Int) - a)) ∨ (((2 : Int) + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < ((2 : Int) + b))))
    (h2 : ((fact_366edf150095_3222 a b) ∨ (fact_366edf150095_3128 a b) ∨ (fact_366edf150095_4218 a b) ∨ (fact_366edf150095_4307 a b) ∨ (fact_366edf150095_3136 a b) ∨ (fact_366edf150095_3353 a b) ∨ (fact_366edf150095_3389 a b) ∨ (fact_366edf150095_3147 a b) ∨ (fact_366edf150095_3411 a b) ∨ (fact_366edf150095_3361 a b)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (fact_366edf150095_1814 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1817 a b jx jy))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1847 a b jx jy))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o3 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_1862 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1863 a b jx jy))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (fact_366edf150095_1846 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1816 a b jx jy))
    (h1 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n290_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1815 a b jx jy))
    (h2 : (((jx + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_point (a b : Int)
    (h0 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_empty (a b : Int)
    (h0 : ((fact_366edf150095_2908 a b) ∨ (fact_366edf150095_2588 a b) ∨ (fact_366edf150095_4081 a b) ∨ (fact_366edf150095_4086 a b) ∨ (fact_366edf150095_2591 a b) ∨ (fact_366edf150095_3193 a b) ∨ (fact_366edf150095_3198 a b) ∨ (fact_366edf150095_2595 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - a)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o0 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o1 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o2 (a b jx jy : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (¬ (((jx = ((6 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o5 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o6 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n291_o7 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h4 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_6 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_empty (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_3228 a b) ∨ (fact_366edf150095_3134 a b) ∨ (fact_366edf150095_4224 a b) ∨ (fact_366edf150095_4313 a b) ∨ (fact_366edf150095_3142 a b) ∨ (fact_366edf150095_3359 a b) ∨ (fact_366edf150095_3393 a b) ∨ (fact_366edf150095_3151 a b) ∨ (fact_366edf150095_3412 a b) ∨ (fact_366edf150095_3158 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1838 a b jx jy))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : (fact_366edf150095_1843 a b jx jy))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o2 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1859 a b jx jy))
    (h5 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_1874 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_1875 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o5 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1858 a b jx jy))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_366edf150095_1842 a b jx jy))
    (h2 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n292_o7 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1839 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_point (a b : Int)
    (h0 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_empty (a b : Int)
    (h0 : ((fact_366edf150095_2910 a b) ∨ (fact_366edf150095_2597 a b) ∨ (fact_366edf150095_4096 a b) ∨ (fact_366edf150095_4100 a b) ∨ (fact_366edf150095_2598 a b) ∨ (fact_366edf150095_3204 a b) ∨ (fact_366edf150095_3207 a b) ∨ (fact_366edf150095_2599 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - a)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_2600 a b) ∨ (fact_366edf150095_3209 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o0 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (((jx + b) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o3 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o5 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n293_o7 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5041 a b) ∨ (fact_366edf150095_4055 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6190 a b) ∨ (fact_366edf150095_5845 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7628 a b) ∨ (fact_366edf150095_7760 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7628 a b) ∧ (fact_366edf150095_7760 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7628 a b) ∧ (fact_366edf150095_7760 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_5071 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_6196 a b)))) ∨ ((fact_366edf150095_7628 a b) ∧ (fact_366edf150095_7760 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_5071 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_6196 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_empty (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3022 a b run_x) ∨ (fact_366edf150095_2341 a b run_x)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n294_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3610 a b run_x) ∨ (fact_366edf150095_3342 a b run_x))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (fact_366edf150095_3920 a b) ∨ (fact_366edf150095_3471 a b) ∨ (((((4 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3473 a b) ∨ (fact_366edf150095_4054 a b) ∨ (fact_366edf150095_3711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (fact_366edf150095_4637 a b) ∨ (fact_366edf150095_3926 a b) ∨ (((((4 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4028 a b) ∨ (fact_366edf150095_5044 a b) ∨ (fact_366edf150095_4403 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7590 a b) ∨ (fact_366edf150095_7637 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7590 a b) ∧ (fact_366edf150095_7637 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7590 a b) ∧ (fact_366edf150095_7637 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4934 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5611 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7590 a b) ∧ (fact_366edf150095_7637 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4934 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5611 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_5420 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((6 : Int) + b)))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3007 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3024 a b run_x) ∨ (fact_366edf150095_2978 a b run_x)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n295_run_floor (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((6 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3589 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3611 a b run_x) ∨ (fact_366edf150095_3558 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5041 a b) ∨ (fact_366edf150095_4402 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6190 a b) ∨ (fact_366edf150095_6141 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a > b))
    (h3 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7634 a b) ∨ (fact_366edf150095_7765 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7634 a b) ∧ (fact_366edf150095_7765 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7634 a b) ∧ (fact_366edf150095_7765 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_5416 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_6675 a b)))) ∨ ((fact_366edf150095_7634 a b) ∧ (fact_366edf150095_7765 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_5416 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_6675 a b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_empty (a b run_x : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3022 a b run_x) ∨ (fact_366edf150095_2977 a b run_x)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((4 : Int) + a) ≤ run_x))
    (h6 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n296_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3610 a b run_x) ∨ (fact_366edf150095_3557 a b run_x))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3516 a b) ∨ (fact_366edf150095_3496 a b) ∨ (fact_366edf150095_5828 a b) ∨ (fact_366edf150095_5829 a b) ∨ (fact_366edf150095_3497 a b) ∨ (fact_366edf150095_4109 a b) ∨ (fact_366edf150095_4112 a b) ∨ (fact_366edf150095_3498 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - a)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3499 a b) ∨ (fact_366edf150095_4115 a b) ∨ (fact_366edf150095_4116 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4211 a b) ∨ (fact_366edf150095_4110 a b) ∨ (fact_366edf150095_6125 a b) ∨ (fact_366edf150095_6126 a b) ∨ (fact_366edf150095_4111 a b) ∨ (fact_366edf150095_5111 a b) ∨ (fact_366edf150095_5112 a b) ∨ (fact_366edf150095_4113 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - a)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4114 a b) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5113 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_tall (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7592 a b) ∨ (fact_366edf150095_7639 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7592 a b) ∧ (fact_366edf150095_7639 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7592 a b) ∧ (fact_366edf150095_7639 a b) ∧ (((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4936 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ (fact_366edf150095_5076 a b)) ∨ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5618 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5735 a b) ∨ (fact_366edf150095_5765 a b)))) ∨ ((fact_366edf150095_7592 a b) ∧ (fact_366edf150095_7639 a b) ∧ ((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4936 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ (fact_366edf150095_5076 a b)) ∧ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5618 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5735 a b) ∨ (fact_366edf150095_5765 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((3 : Int) + b)))
    (h4 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ (fact_366edf150095_3059 a b run_x) ∨ (fact_366edf150095_2358 a b run_x) ∨ ((((8 : Int) ≥ ((4 : Int) - a)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_2359 a b run_x) ∨ (fact_366edf150095_3060 a b run_x) ∨ (fact_366edf150095_3061 a b run_x)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n297_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (fact_366edf150095_3562 a b run_x) ∨ (fact_366edf150095_3321 a b run_x) ∨ (((((4 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3337 a b run_x) ∨ (fact_366edf150095_3607 a b run_x) ∨ (fact_366edf150095_3615 a b run_x))))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3919 a b) ∨ (fact_366edf150095_3470 a b) ∨ (((((4 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3710 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_4636 a b) ∨ (fact_366edf150095_3925 a b) ∨ (((((4 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4395 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7463 a b) ∨ (fact_366edf150095_7535 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7463 a b) ∧ (fact_366edf150095_7535 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7463 a b) ∧ (fact_366edf150095_7535 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_3951 a b) ∨ (((((4 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_5454 a b) ∨ (fact_366edf150095_4717 a b) ∨ (((((4 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4981 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7463 a b) ∧ (fact_366edf150095_7535 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_3951 a b) ∨ (((((4 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_5454 a b) ∨ (fact_366edf150095_4717 a b) ∨ (((((4 : Int) - a) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4981 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ ((5 : Int) + b)))
    (h5 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3007 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n298_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3589 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_empty (a b : Int)
    (h0 : ((fact_366edf150095_2910 a b) ∨ (fact_366edf150095_2597 a b) ∨ (fact_366edf150095_4096 a b) ∨ (fact_366edf150095_4100 a b) ∨ (fact_366edf150095_2598 a b) ∨ (fact_366edf150095_3204 a b) ∨ (fact_366edf150095_3207 a b) ∨ (fact_366edf150095_2599 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - a)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_2600 a b) ∨ ((((7 : Int) ≥ ((6 : Int) - b)) ∧ ((7 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o0 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o1 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_366edf150095_2954 a b jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o3 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n299_o7 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h4 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_4055 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_5845 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7629 a b) ∨ (fact_366edf150095_7761 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7629 a b) ∧ (fact_366edf150095_7761 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7629 a b) ∧ (fact_366edf150095_7761 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5071 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6196 a b)))) ∨ ((fact_366edf150095_7629 a b) ∧ (fact_366edf150095_7761 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5071 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6196 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_empty (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h3 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_2341 a b run_x)))
    (h5 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n300_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (((4 : Int) + a) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_3342 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_9 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_3231 a b) ∨ (fact_366edf150095_3161 a b) ∨ (fact_366edf150095_5089 a b) ∨ (fact_366edf150095_5091 a b) ∨ (fact_366edf150095_3163 a b) ∨ (fact_366edf150095_3419 a b) ∨ (fact_366edf150095_3421 a b) ∨ (fact_366edf150095_3164 a b) ∨ ((((2 : Int) ≥ ((4 : Int) - a)) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((2 : Int) ≥ ((6 : Int) - b)) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (fact_366edf150095_1784 a b jx jy))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (¬ (((jx = ((2 : Int) + ((-1 : Int) * a))) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((3 : Int) + ((-1 : Int) * a))) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((4 : Int) + ((-1 : Int) * a))) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o1 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_1789 a b jx jy))
    (h4 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - a))))
    (h6 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o2 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h1 : ((jx < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - b))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (fact_366edf150095_1793 a b jx jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o3 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1796 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (fact_366edf150095_1797 a b jx jy))
    (h8 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o5 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h5 : (fact_366edf150095_1792 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (¬ ((((0 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((2 : Int) + ((-1 : Int) * b))) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((3 : Int) + ((-1 : Int) * b))) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((4 : Int) + ((-1 : Int) * b))) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (fact_366edf150095_1788 a b jx jy))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n301_o7 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (fact_366edf150095_1785 a b jx jy))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - b))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_point (a b : Int)
    (h0 : (fact_366edf150095_11 a b))
    (h1 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((0 : Int) + a) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((4 : Int) + b)) ∨ ((0 : Int) > ((4 : Int) + b))))
    (h2 : ((fact_366edf150095_3233 a b) ∨ (fact_366edf150095_3167 a b) ∨ (fact_366edf150095_5093 a b) ∨ (fact_366edf150095_5095 a b) ∨ (fact_366edf150095_3169 a b) ∨ (fact_366edf150095_3424 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - a)) ∧ ((3 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((3 : Int) ≥ ((4 : Int) - a)) ∧ ((3 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((3 : Int) ≥ ((6 : Int) - b)) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≥ ((2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + b) + b))))))
    (h3 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a > b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1800 a b jx jy))
    (h1 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o1 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h4 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (fact_366edf150095_1805 a b jx jy))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h9 : (((jx + b) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (a ≥ (5 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    (h15 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - b))))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (fact_366edf150095_1809 a b jx jy))
    (h6 : (((jx + (0 : Int)) < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h7 : (((jx + (0 : Int)) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h8 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : ((jy - b) ≥ (0 : Int)))
    (h11 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h12 : (b ≥ (3 : Int)))
    (h13 : (a = (b + (2 : Int))))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((jx < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_1812 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o4 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - a))))
    (h5 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (fact_366edf150095_1813 a b jx jy))
    (h7 : (((jx + (0 : Int)) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o5 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1808 a b jx jy))
    (h1 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jx < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1804 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + b) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n302_o7 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1801 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (jy - b))))
    (h6 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_point (a b : Int)
    (h0 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ (((4 : Int) + b) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ (((4 : Int) + b) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_empty (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a > b))
    (h4 : (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - a)) ∧ ((4 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((4 : Int) ≥ ((4 : Int) - a)) ∧ ((4 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((4 : Int) ≥ ((6 : Int) - b)) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + b) + b))))))
    (h5 : ((((0 : Int) + a) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((4 : Int) + b)) ∨ ((0 : Int) > ((4 : Int) + b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o0 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + b)))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o1 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((jx + b) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h9 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - a))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : ((jy - a) ≥ (0 : Int)))
    (h12 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - b))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h8 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + a)))))
    (h7 : (((jx + (0 : Int)) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < (jx - b)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o4 (a b jx jy : Int)
    (h0 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - a))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o5 (a b jx jy : Int)
    (h0 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((jx + (0 : Int)) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + b)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n303_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - a)) ∧ ((8 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ ((((8 : Int) ≥ ((4 : Int) - a)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - b)) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((4 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((4 : Int) + b) + b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((7 : Int) > (jx + a)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ ((((8 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((4 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (fact_366edf150095_2954 a b jy))
    (h6 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((8 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o4 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o5 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((jx + (0 : Int)) < (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((4 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ (((jx = ((8 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((7 : Int) > (jx + b)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n304_o7 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (¬ ((((8 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_5073 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ (((((8 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((8 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_6198 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ (((((8 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((8 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7790 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6201 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7790 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6201 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7790 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6201 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_6915 a b) ∨ (fact_366edf150095_5084 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_7242 a b) ∨ (fact_366edf150095_6200 a b)))) ∨ ((fact_366edf150095_7790 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6201 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_6915 a b) ∨ (fact_366edf150095_5084 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_7242 a b) ∨ (fact_366edf150095_6200 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_3027 a b run_x) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ (((((8 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ run_x) ∧ ((8 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n305_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_3616 a b run_x) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ (((((8 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((8 : Int) ≤ run_x) ∧ ((8 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_four (a b : Int)
    (h0 : (¬ ((8 : Int) ≤ ((7 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_short (a b : Int)
    (h0 : (¬ ((((7 : Int) + b) - (8 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + b)) ∧ ((5 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + b) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + b)) ∧ ((5 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((7 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + b) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_tall (a b : Int)
    (h0 : (¬ (((((8 : Int) + (3 : Int)) ≤ ((7 : Int) + b)) ∧ ((fact_366edf150095_7739 a b) ∨ (fact_366edf150095_7792 a b))) ∨ ((((8 : Int) + (2 : Int)) ≤ ((7 : Int) + b)) ∧ (fact_366edf150095_7739 a b) ∧ (fact_366edf150095_7792 a b)) ∨ (((8 : Int) + (4 : Int)) ≤ ((7 : Int) + b)) ∨ ((((7 : Int) + b) = ((8 : Int) + (1 : Int))) ∧ (fact_366edf150095_7739 a b) ∧ (fact_366edf150095_7792 a b) ∧ (((fact_366edf150095_4194 a b) ∨ (fact_366edf150095_3789 a b) ∨ (fact_366edf150095_5940 a b) ∨ (fact_366edf150095_6023 a b) ∨ (fact_366edf150095_3870 a b) ∨ (fact_366edf150095_4303 a b) ∨ (fact_366edf150095_4675 a b) ∨ (fact_366edf150095_3965 a b) ∨ (((((4 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4050 a b) ∨ (fact_366edf150095_5065 a b) ∨ (fact_366edf150095_5080 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_4409 a b)) ∨ ((fact_366edf150095_5162 a b) ∨ (fact_366edf150095_4456 a b) ∨ (fact_366edf150095_6381 a b) ∨ (fact_366edf150095_6469 a b) ∨ (fact_366edf150095_4540 a b) ∨ (fact_366edf150095_5290 a b) ∨ (fact_366edf150095_5461 a b) ∨ (fact_366edf150095_4724 a b) ∨ (((((4 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4987 a b) ∨ (fact_366edf150095_5744 a b) ∨ (fact_366edf150095_5759 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5425 a b)))) ∨ ((fact_366edf150095_7739 a b) ∧ (fact_366edf150095_7792 a b) ∧ ((fact_366edf150095_4194 a b) ∨ (fact_366edf150095_3789 a b) ∨ (fact_366edf150095_5940 a b) ∨ (fact_366edf150095_6023 a b) ∨ (fact_366edf150095_3870 a b) ∨ (fact_366edf150095_4303 a b) ∨ (fact_366edf150095_4675 a b) ∨ (fact_366edf150095_3965 a b) ∨ (((((4 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4050 a b) ∨ (fact_366edf150095_5065 a b) ∨ (fact_366edf150095_5080 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_4409 a b)) ∧ ((fact_366edf150095_5162 a b) ∨ (fact_366edf150095_4456 a b) ∨ (fact_366edf150095_6381 a b) ∨ (fact_366edf150095_6469 a b) ∨ (fact_366edf150095_4540 a b) ∨ (fact_366edf150095_5290 a b) ∨ (fact_366edf150095_5461 a b) ∨ (fact_366edf150095_4724 a b) ∨ (((((4 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4987 a b) ∨ (fact_366edf150095_5744 a b) ∨ (fact_366edf150095_5759 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5425 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ ((7 : Int) + b)))
    (h2 : ((((2 : Int) * a) < (((8 : Int) + b) - b)) ∨ ((((8 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((8 : Int) ≤ run_x))
    (h5 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3007 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3026 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n306_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3589 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3614 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((8 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))))))
    (h1 : (run_x ≤ ((7 : Int) + b)))
    (h2 : ((8 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4925 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_5073 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6177 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_6198 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7791 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6678 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7791 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6678 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7791 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6678 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_6915 a b) ∨ (fact_366edf150095_5423 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_7242 a b) ∨ (fact_366edf150095_6677 a b)))) ∨ ((fact_366edf150095_7791 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6712 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_7243 a b) ∨ (fact_366edf150095_6678 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5605 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_6915 a b) ∨ (fact_366edf150095_5423 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6711 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_7242 a b) ∨ (fact_366edf150095_6677 a b))))))
    (h1 : ((((2 : Int) * a) < (((8 : Int) + a) - a)) ∨ ((((8 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_empty (a b run_x : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : (((4 : Int) + a) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) * a) < (((8 : Int) + a) - a)) ∨ ((((8 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3006 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_3027 a b run_x) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h5 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n307_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3588 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_3616 a b run_x) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ ((((((8 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((8 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - a)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((4 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_right (a b : Int)
    (h0 : (¬ (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - a)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((4 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7740 a b) ∨ (fact_366edf150095_7793 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7740 a b) ∧ (fact_366edf150095_7793 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7740 a b) ∧ (fact_366edf150095_7793 a b) ∧ (((fact_366edf150095_4196 a b) ∨ (fact_366edf150095_3791 a b) ∨ (fact_366edf150095_5942 a b) ∨ (fact_366edf150095_6025 a b) ∨ (fact_366edf150095_3872 a b) ∨ (fact_366edf150095_4305 a b) ∨ (fact_366edf150095_4677 a b) ∨ (fact_366edf150095_3967 a b) ∨ (((((4 : Int) - a) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4052 a b) ∨ (fact_366edf150095_5067 a b) ∨ (fact_366edf150095_5082 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5086 a b)) ∨ ((fact_366edf150095_5199 a b) ∨ (fact_366edf150095_4493 a b) ∨ (fact_366edf150095_6418 a b) ∨ (fact_366edf150095_6506 a b) ∨ (fact_366edf150095_4577 a b) ∨ (fact_366edf150095_5327 a b) ∨ (fact_366edf150095_5482 a b) ∨ (fact_366edf150095_4768 a b) ∨ (((((4 : Int) - a) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5027 a b) ∨ (fact_366edf150095_5752 a b) ∨ (fact_366edf150095_5770 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5772 a b)))) ∨ ((fact_366edf150095_7740 a b) ∧ (fact_366edf150095_7793 a b) ∧ ((fact_366edf150095_4196 a b) ∨ (fact_366edf150095_3791 a b) ∨ (fact_366edf150095_5942 a b) ∨ (fact_366edf150095_6025 a b) ∨ (fact_366edf150095_3872 a b) ∨ (fact_366edf150095_4305 a b) ∨ (fact_366edf150095_4677 a b) ∨ (fact_366edf150095_3967 a b) ∨ (((((4 : Int) - a) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4052 a b) ∨ (fact_366edf150095_5067 a b) ∨ (fact_366edf150095_5082 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5086 a b)) ∧ ((fact_366edf150095_5199 a b) ∨ (fact_366edf150095_4493 a b) ∨ (fact_366edf150095_6418 a b) ∨ (fact_366edf150095_6506 a b) ∨ (fact_366edf150095_4577 a b) ∨ (fact_366edf150095_5327 a b) ∨ (fact_366edf150095_5482 a b) ∨ (fact_366edf150095_4768 a b) ∨ (((((4 : Int) - a) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_5027 a b) ∨ (fact_366edf150095_5752 a b) ∨ (fact_366edf150095_5770 a b) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + b)))) ∨ (fact_366edf150095_5772 a b))))))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a ≥ b))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((3 : Int) + b)))
    (h4 : (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - a)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((4 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n308_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) * a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((4 : Int) + ((-1 : Int) * a)) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ ((((4 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((4 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + b)))) ∨ (((((8 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((8 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_four (a b : Int)
    (h0 : (¬ ((1 : Int) ≤ (4 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_short (a b : Int)
    (h0 : (¬ (((4 : Int) - (1 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_nonnegative (a b : Int)
    (h0 : (¬ (((5 : Int) + b) ≥ (0 : Int))))
    (h1 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((-1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ (((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) * a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((5 : Int) + b))) ∨ (((3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + b))) ∨ (((5 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_right (a b : Int)
    (h0 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((-1 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((0 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ (((1 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) * a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((5 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + b))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((7 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + a)))))))
    (h2 : (¬ (((((((1 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (0 : Int)) ∧ (b = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = (((1 : Int) + a) + (1 : Int))) ∨ ((1 : Int) = (((0 : Int) + a) + (1 : Int)))) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (b + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((1 : Int) = ((4 : Int) + b)) ∧ (b = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = (((1 : Int) + b) + (1 : Int))) ∨ ((1 : Int) = (((0 : Int) + b) + (1 : Int)))) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (a + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (1 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h3 : ((((0 : Int) + a) < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((3 : Int) + b)) ∨ ((0 : Int) > ((3 : Int) + b))))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_tall (a b : Int)
    (h0 : (¬ ((((4 : Int) ≥ ((1 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7715 a b) ∨ (fact_366edf150095_7716 a b))) ∨ (((4 : Int) ≥ ((1 : Int) + (2 : Int))) ∧ (fact_366edf150095_7715 a b) ∧ (fact_366edf150095_7716 a b)) ∨ ((4 : Int) ≥ ((1 : Int) + (4 : Int))) ∨ (((4 : Int) = ((1 : Int) + (1 : Int))) ∧ (fact_366edf150095_7715 a b) ∧ (fact_366edf150095_7716 a b) ∧ (((((((-1 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((-1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((1 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((1 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((2 : Int) * a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((2 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((3 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((5 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + b) + a))))) ∨ ((fact_366edf150095_5170 a b) ∨ (fact_366edf150095_4464 a b) ∨ (fact_366edf150095_6389 a b) ∨ (fact_366edf150095_6477 a b) ∨ (fact_366edf150095_4548 a b) ∨ (fact_366edf150095_5298 a b) ∨ (fact_366edf150095_5467 a b) ∨ (fact_366edf150095_4730 a b) ∨ (fact_366edf150095_5615 a b) ∨ (fact_366edf150095_4992 a b) ∨ (fact_366edf150095_5748 a b) ∨ (fact_366edf150095_5762 a b) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + b) + a))))))) ∨ ((fact_366edf150095_7715 a b) ∧ (fact_366edf150095_7716 a b) ∧ ((((((-1 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((-1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((0 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((1 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((1 : Int) ≥ (((5 : Int) + b) + a))) ∨ ((((2 : Int) * a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((2 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) + a)) ∧ ((3 : Int) ≥ (((5 : Int) + b) + a))) ∨ (((5 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + b) + a))))) ∧ ((fact_366edf150095_5170 a b) ∨ (fact_366edf150095_4464 a b) ∨ (fact_366edf150095_6389 a b) ∨ (fact_366edf150095_6477 a b) ∨ (fact_366edf150095_4548 a b) ∨ (fact_366edf150095_5298 a b) ∨ (fact_366edf150095_5467 a b) ∨ (fact_366edf150095_4730 a b) ∨ (fact_366edf150095_5615 a b) ∨ (fact_366edf150095_4992 a b) ∨ (fact_366edf150095_5748 a b) ∨ (fact_366edf150095_5762 a b) ∨ (((((0 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((5 : Int) + b) + a)) ∧ ((((5 : Int) + b) + a) ≤ (((4 : Int) + b) + a)))))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_empty (a b run_x : Int)
    (h0 : (¬ (((((((1 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (0 : Int)) ∧ (b = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = (((1 : Int) + a) + (1 : Int))) ∨ ((1 : Int) = (((0 : Int) + a) + (1 : Int)))) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (b + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((1 : Int) = ((4 : Int) + b)) ∧ (b = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((0 : Int) = (((1 : Int) + b) + (1 : Int))) ∨ ((1 : Int) = (((0 : Int) + b) + (1 : Int)))) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (a + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ ((((1 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) + b) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = ((1 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((0 : Int) = ((1 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((((4 : Int) + b) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = (1 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((1 : Int) = ((0 : Int) + (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((1 : Int) = ((0 : Int) - (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h1 : ((4 : Int) ≥ run_x))
    (h2 : ((((0 : Int) + a) < ((4 : Int) - a)) ∨ (((4 : Int) + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((3 : Int) + b)) ∨ ((0 : Int) > ((3 : Int) + b))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((1 : Int) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + b)) ∧ ((0 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + b)) ∧ ((1 : Int) ≥ ((5 : Int) + b))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((5 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((4 : Int) + b) + a))))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  left
  left
  left
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n309_run_floor (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((4 : Int) ≥ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (¬ ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((5 : Int) + b) - (1 : Int))) ∧ ((((5 : Int) + b) - (1 : Int)) ≤ (((4 : Int) + b) + a)))))))
    (h5 : ((1 : Int) ≤ run_x))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n310_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_11 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n310_empty (a b : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_3233 a b) ∨ (fact_366edf150095_3167 a b) ∨ (fact_366edf150095_5093 a b) ∨ (fact_366edf150095_5095 a b) ∨ (fact_366edf150095_3169 a b) ∨ (fact_366edf150095_3424 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - a)) ∧ ((3 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((3 : Int) ≥ ((4 : Int) - a)) ∧ ((3 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((3 : Int) ≥ ((6 : Int) - b)) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + b))) ∨ (((3 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + b) + a))))))
    (h3 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

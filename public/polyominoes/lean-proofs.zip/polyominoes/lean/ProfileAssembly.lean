import HierarchyProfiles
import RepHierarchy

namespace PolyominoFormal
open CrossUnits

theorem ExactRectangle.classified {a b c d : Int} (h : ExactRectangle a b c d) :
    Classified a b c d .rectangle := by
  intro cap
  cases cap
  all_goals simp only [HasCapability,Supports,iff_true]
  · exact h.rectangle
  · exact h.half_strip
  · exact h.bent_strip
  · exact h.quadrant
  · exact h.strip
  · exact h.half_plane
  · exact h.plane
  · exact h.rep

theorem ExactBS.classified {a : Int} (h : ExactBS a) : Classified a 1 1 0 .bentStrip := by
  intro cap
  cases cap
  all_goals simp only [HasCapability,Supports,iff_true,iff_false]
  · exact h.no_rectangle
  · exact h.no_half_strip
  · exact h.bent_strip
  · exact h.quadrant
  · exact h.strip
  · exact h.half_plane
  · exact h.plane
  · exact h.no_rep

theorem ExactStrip.classified {a b c d : Int} (h : ExactStrip a b c d) :
    Classified a b c d .strip := by
  intro cap
  cases cap
  all_goals simp only [HasCapability,Supports,iff_true,iff_false]
  · exact h.no_rectangle
  · exact h.no_half_strip
  · exact h.no_bent_strip
  · exact h.no_quadrant
  · exact h.strip
  · exact h.half_plane
  · exact h.plane
  · exact h.no_rep

def Tiling.halfPlaneToPlane {a b c d : Int} (T : Tiling a b c d HalfPlane) :
    Tiling a b c d Plane :=
  (T.union (T.mirrorY.translate 0 (-1)) (by intro x y h1 h2; unfold HalfPlane at *; omega)).congr
    (by intro x y; simp only [HalfPlane,Plane,iff_true]; omega)

theorem halfplane_implies_plane {a b c d : Int} (h : Tiles a b c d HalfPlane) :
    Tiles a b c d Plane := by
  obtain ⟨T⟩ := h
  exact ⟨T.halfPlaneToPlane⟩

theorem no_halfplane_zero_south_profile {a b c : Int} {p : Prop} [Decidable p]
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (noHP : ¬Tiles a b c 0 HalfPlane) (plane : Tiles a b c 0 Plane↔p) :
    Classified a b c 0 (if p then .plane else .none) := by
  have noQ : ¬Tiles a b c 0 Quadrant := fun h => noHP (PositiveHierarchy.quadrant_tiles_halfplane h)
  have noS : ¬StripTileable a b c 0 := fun h => noHP (PositiveHierarchy.strip_tiles_halfplane h)
  have noHS : ¬HalfStripTileable a b c 0 := fun h => noQ (half_strip_implies_quadrant h)
  have noBS : ¬BentStripTileable a b c 0 := fun h => noQ (PositiveHierarchy.bent_tiles_quadrant h)
  have noR : ¬RectangleTileable a b c 0 := fun h => noHS (rectangle_implies_half_strip h)
  have noRep : ¬RepTileable a b c 0 := fun h => noQ (rep_zero_south_implies_quadrant ha hb hc h)
  intro cap
  by_cases hp : p
  · simp only [if_pos hp]
    cases cap
    all_goals simp only [HasCapability,Supports,iff_true,iff_false]
    · exact noR
    · exact noHS
    · exact noBS
    · exact noQ
    · exact noS
    · exact noHP
    · exact plane.2 hp
    · exact noRep
  · simp only [if_neg hp]
    cases cap
    all_goals simp only [HasCapability,Supports,iff_false]
    · exact noR
    · exact noHS
    · exact noBS
    · exact noQ
    · exact noS
    · exact noHP
    · exact fun h => hp (plane.1 h)
    · exact noRep

theorem positive_cross_classified (a b c d : Int)
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    Classified a b c d (if (a=1∧c=1)∨(b=1∧d=1) then .plane else .none) := by
  obtain ⟨plane,noHP,noS,noQ,noBS,noHS,noR,noScaled⟩ := classify_positive_cross a b c d ha hb hc hd
  have noRep : ¬RepTileable a b c d := by
    rintro ⟨k,hk,h⟩
    exact noScaled k (by omega) h
  intro cap
  by_cases hp : (a=1∧c=1)∨(b=1∧d=1)
  · simp only [if_pos hp]
    cases cap
    all_goals simp only [HasCapability,Supports,iff_true,iff_false]
    · exact noR
    · exact noHS
    · exact noBS
    · exact noQ
    · exact noS
    · exact noHP
    · exact plane.2 hp
    · exact noRep
  · simp only [if_neg hp]
    cases cap
    all_goals simp only [HasCapability,Supports,iff_false]
    · exact noR
    · exact noHS
    · exact noBS
    · exact noQ
    · exact noS
    · exact noHP
    · exact fun h => hp (plane.1 h)
    · exact noRep

theorem gun_classified (n : Nat) :
    Classified n 1 1 0 (if n≤3 then .rectangle else .bentStrip) := by
  have h := classify_gun n
  by_cases hn : n≤3
  · simp only [if_pos hn] at h ⊢
    exact h.classified
  · simp only [if_neg hn] at h ⊢
    exact h.classified

#print axioms gun_classified
#print axioms positive_cross_classified
end PolyominoFormal

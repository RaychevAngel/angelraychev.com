import LHalfPlaneShortbarEasy
import LHalfPlaneShortbarBranch
import LHalfPlaneHwest
import LHalfPlaneVleftNeighbors
import LHalfPlaneShortbarNestedNear
import LHalfPlaneShortbarNestedLarge

namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits LRegion

theorem nested_short {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    PairObstruction a b ⟨1,1,b,a,0,0⟩ := by
  by_cases near : a≤b+2
  · exact nested_short_near_obstruction a b ha hb hab near
  · exact nested_short_large_obstruction a b ha hb (by omega)

theorem no_shortbars {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    LHalfPlaneAssembly.NoShortBars a b := by
  exact no_shortbar_from_six_and_neighbors ha hb hab
    (upright_long_shortbar_obstruction a b ha hb hab)
    (long_tip_right ha hb hab)
    (upright_short_left ha hb hab)
    (upright_long_left ha hb hab)
    (nested_short ha hb hab)
    (short_tip_right ha hb hab)
    (east_long_neighbor ha hb hab)
    (west_long_neighbor ha hb hab)

#print axioms nested_short
#print axioms no_shortbars
end PolyominoFormal.LHalfPlaneShortbarAssembly

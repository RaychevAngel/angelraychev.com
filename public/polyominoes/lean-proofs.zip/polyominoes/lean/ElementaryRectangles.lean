import TilingCore

namespace PolyominoFormal
namespace ElementaryRectangles
open CrossUnits

def barTile (a c : Int) : Cross := ⟨c,0,a,0,c,0⟩

theorem bar_rectangle (a c : Int) (ha : 0≤a) (hc : 0≤c) :
    Tiles a 0 c 0 (Rectangle (a+c+1) 1) := by
  refine ⟨Tiling.ofIndexed (fun _ : Unit => barTile a c) ?_ ?_ ?_ ?_⟩
  · intro i
    exact Or.inl ⟨rfl,rfl,rfl,rfl⟩
  · intro i x y hit
    simp only [barTile,Contains] at hit
    unfold Rectangle
    omega
  · intro x y hit
    refine ⟨(),?_⟩
    unfold Rectangle at hit
    simp only [barTile,Contains]
    omega
  · intro i j x y hi hj
    rfl

theorem bar_rectangle_tileable (a c : Int) (ha : 0≤a) (hc : 0≤c) :
    RectangleTileable a 0 c 0 :=
  ⟨a+c+1,1,by omega,by omega,bar_rectangle a c ha hc⟩

def lTile (a : Int) : Bool → Cross
  | false => ⟨0,0,a,1,0,0⟩
  | true => ⟨a+1,1,0,0,a,1⟩

theorem unit_l_rectangle (a : Int) (ha : 0≤a) :
    Tiles a 1 0 0 (Rectangle (a+2) 2) := by
  refine ⟨Tiling.ofIndexed (lTile a) ?_ ?_ ?_ ?_⟩
  · intro i
    cases i <;> simp [lTile, Copy, Arms]
  · intro i x y hit
    cases i <;> simp only [lTile,Contains] at hit
    all_goals unfold Rectangle; omega
  · intro x y hit
    have alternatives : Contains (lTile a false) x y ∨ Contains (lTile a true) x y := by
      unfold Rectangle at hit
      simp only [lTile,Contains]
      omega
    rcases alternatives with lo | hi
    · exact ⟨false,lo⟩
    · exact ⟨true,hi⟩
  · intro i j x y hi hj
    cases i <;> cases j
    · rfl
    · simp only [lTile,Contains] at hi hj
      omega
    · simp only [lTile,Contains] at hi hj
      omega
    · rfl

theorem unit_l_rectangle_tileable (a : Int) (ha : 0≤a) :
    RectangleTileable a 1 0 0 :=
  ⟨a+2,2,by omega,by omega,unit_l_rectangle a ha⟩

#print axioms bar_rectangle_tileable
#print axioms unit_l_rectangle_tileable
end ElementaryRectangles
end PolyominoFormal

import CornerCertificateReplay
import TilingCore

namespace THalfPlaneFinite
open CrossUnits PolyominoFormal
open CornerCertificate (Cell cells Nonnegative mem_cells_iff translate)

def templates (a b : Int) : List Cross :=
  [⟨0,0,a,b,1,0⟩,⟨0,0,b,1,0,a⟩,⟨0,0,1,0,a,b⟩,⟨0,0,0,a,b,1⟩,
   ⟨0,0,0,1,b,a⟩,⟨0,0,1,b,a,0⟩,⟨0,0,b,a,0,1⟩,⟨0,0,a,0,1,b⟩]

def candidates (a b : Int) (p : Cell) : List Cross :=
  (templates a b).flatMap fun s =>
    (cells s).map fun q => translate s (p.1-q.1) (p.2-q.2)

theorem template_properties {a b : Int} (ha : 0≤a) (hb : 0≤b) {s : Cross}
    (mem : s ∈ templates a b) : s.x=0 ∧ s.y=0 ∧ Nonnegative s := by
  simp only [templates,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem template_of_copy {a b : Int} {t : Cross} (copy : Copy a b 1 0 t) :
    ∃ s, s ∈ templates a b ∧ t=translate s t.x t.y := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs
  all_goals subst e; subst n; subst w; subst s
  all_goals simp [templates,translate]

theorem candidate_complete {a b : Int} (ha : 0≤a) (hb : 0≤b) {t : Cross} {p : Cell}
    (copy : Copy a b 1 0 t) (hit : Contains t p.1 p.2) : t ∈ candidates a b p := by
  obtain ⟨s,mem,eq⟩ := template_of_copy copy
  obtain ⟨sx,sy,nn⟩ := template_properties ha hb mem
  have localHit : Contains s (p.1-t.x) (p.2-t.y) := by
    rw [eq] at hit
    dsimp [translate,Contains] at hit ⊢
    omega
  have cellMem := (mem_cells_iff nn (p.1-t.x) (p.2-t.y)).2 localHit
  simp only [candidates,List.mem_flatMap,List.mem_map]
  refine ⟨s,mem,(p.1-t.x,p.2-t.y),cellMem,?_⟩
  have coords : translate s (p.1-(p.1-t.x)) (p.2-(p.2-t.y))=translate s t.x t.y := by
    congr 1 <;> omega
  exact coords.trans eq.symm

theorem copy_nonnegative {a b : Int} (ha : 0≤a) (hb : 0≤b) {t : Cross}
    (copy : Copy a b 1 0 t) : Nonnegative t := by
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Nonnegative; omega

inductive Why where
  | outside
  | overlap (index : Nat) (point : Cell)
  | branch (index : Nat)
  deriving DecidableEq

def EvidenceCase (selected branches : List Cross) (pair : Cross × Why) : Prop :=
  match pair.2 with
  | .outside => pair.1.y < pair.1.south
  | .overlap i p => match selected[i]? with
    | none => False
    | some s => Contains pair.1 p.1 p.2 ∧ Contains s p.1 p.2
  | .branch i => match branches[i]? with
    | none => False
    | some t => t=pair.1

instance (selected branches : List Cross) (pair : Cross × Why) :
    Decidable (EvidenceCase selected branches pair) := by
  unfold EvidenceCase
  cases pair.2 with
  | outside => infer_instance
  | overlap i p => dsimp only; cases selected[i]? <;> infer_instance
  | branch i => dsimp only; cases branches[i]? <;> infer_instance

def StepCheck (a b : Int) (selected : List Cross) (p : Cell)
    (branches : List Cross) (witnesses : List Why) : Prop :=
  0≤p.2 ∧ (∀ s, s∈selected → ¬Contains s p.1 p.2) ∧
  (candidates a b p).length≤witnesses.length ∧
  ∀ pair, pair ∈ (candidates a b p).zip witnesses → EvidenceCase selected branches pair

instance (a b : Int) (selected : List Cross) (p : Cell)
    (branches : List Cross) (witnesses : List Why) :
    Decidable (StepCheck a b selected p branches witnesses) := by
  unfold StepCheck
  infer_instance

theorem checked_complete {a b : Int} {selected : List Cross} {p : Cell}
    {branches : List Cross} {witnesses : List Why}
    (checked : StepCheck a b selected p branches witnesses) {t : Cross}
    (member : t∈candidates a b p) :
    t.y<t.south ∨ (∃ s, s∈selected ∧ ∃ x y, Contains t x y ∧ Contains s x y) ∨ t∈branches := by
  have firsts := List.map_fst_zip checked.2.2.1
  have mapped : t ∈ ((candidates a b p).zip witnesses).map Prod.fst := by
    rw [firsts]
    exact member
  obtain ⟨pair,hpair,eq⟩ := List.mem_map.mp mapped
  have why := checked.2.2.2 pair hpair
  cases form : pair.2 with
  | outside =>
    left
    simpa only [EvidenceCase,form,eq] using why
  | overlap i point =>
    unfold EvidenceCase at why
    rw [form] at why
    dsimp only at why
    cases found : selected[i]? with
    | none => simp [found] at why
    | some s =>
      rw [found] at why
      exact Or.inr (Or.inl ⟨s,List.mem_of_getElem? found,point.1,point.2,
        by simpa only [eq] using why.1,why.2⟩)
  | branch i =>
    unfold EvidenceCase at why
    rw [form] at why
    dsimp only at why
    cases found : branches[i]? with
    | none => simp [found] at why
    | some s =>
      rw [found] at why
      have same : s=t := why.trans eq
      exact Or.inr (Or.inr (same ▸ List.mem_of_getElem? found))

/-- One exhaustive node of an arbitrary-world half-plane obstruction.
Only the actual bottom boundary is used; tiles may overhang every patch edge. -/
theorem replay_step (a b : Int) (ha : 0≤a) (hb : 0≤b)
    (T : Tiling a b 1 0 HalfPlane) (selected : List Cross) (p : Cell)
    (branches : List Cross) (witnesses : List Why)
    (checked : StepCheck a b selected p branches witnesses)
    (next : ∀ t, t∈branches → (∀ s, s∈selected++[t] → T.world s) → False)
    (known : ∀ s, s∈selected → T.world s) : False := by
  obtain ⟨t,ht,hit⟩ := T.cover p.1 p.2 checked.1
  have possible := candidate_complete ha hb (T.copies t ht) hit
  obtain outside | collision | child := checked_complete checked possible
  · have nn := copy_nonnegative ha hb (T.copies t ht)
    have bottomHit : Contains t t.x (t.y-t.south) := by
      right
      rcases nn with ⟨he,hn,hw,hs⟩
      exact ⟨by omega,by omega,by omega,by omega⟩
    have := T.inside t ht t.x (t.y-t.south) bottomHit
    unfold HalfPlane at this
    omega
  · obtain ⟨s,hs,x,y,tx,sx⟩ := collision
    have same := T.disjoint t s x y ht (known s hs) tx sx
    exact checked.2.1 s hs (same ▸ hit)
  · apply next t child
    intro s hs
    rcases List.mem_append.mp hs with old | new
    · exact known s old
    · have same := List.mem_singleton.mp new
      exact same ▸ ht

end THalfPlaneFinite

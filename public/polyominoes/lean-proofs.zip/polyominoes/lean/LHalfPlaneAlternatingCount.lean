import LHalfPlaneAlternatingRows
import LStarterRuns

namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits
set_option maxHeartbeats 300000

/-- Once a bar ends before the pocket's right wall, the next cell starts
another whole horizontal bar. This uses actual tile disjointness. -/
theorem successor_horizontal {a b q l r : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hl : l=a ∨ l=b) (hr : r=0 ∨ r=l)
    (hq : 1≤q) (hend : q+l<2*a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (first : T.world ⟨q+r,1,l-r,a+b-l,r,0⟩) :
    ∃m s,(m=a ∨ m=b) ∧ (s=0 ∨ s=m) ∧ q+l+1+m≤2*a ∧
      T.world ⟨q+l+1+s,1,m-s,a+b-m,s,0⟩ := by
  obtain ⟨v,m,s,hm,hs,hv,hvp,hpv,he,second⟩ :=
    row_one_horizontal (p:=q+l+1) ha hb hab (by omega) T bars
  have eq : v=q+l+1 := by
    apply Classical.byContradiction
    intro ne
    have hitFirst : Contains ⟨q+r,1,l-r,a+b-l,r,0⟩ (q+l) 1 := by
      left; dsimp; omega
    have hitSecond : Contains ⟨v+s,1,m-s,a+b-m,s,0⟩ (q+l) 1 := by
      left; dsimp; omega
    have same := T.disjoint _ _ (q+l) 1 first second hitFirst hitSecond
    have endpoint := congrArg (fun t : Cross => t.x+t.east) same
    dsimp only at endpoint
    omega
  subst v
  exact ⟨m,s,hm,hs,he,second⟩

/-- Two long horizontal bars in the pocket must be the very same tile. -/
theorem long_bar_unique {a b q r v s : Int}
    (ha : 1≤a) (hr : r=0 ∨ r=a) (hs : s=0 ∨ s=a)
    (hq : 1≤q ∧ q+a≤2*a) (hv : 1≤v ∧ v+a≤2*a)
    (T : Tiling a b 0 0 HalfPlane)
    (first : T.world ⟨q+r,1,a-r,b,r,0⟩)
    (second : T.world ⟨v+s,1,a-s,b,s,0⟩) :
    (⟨q+r,1,a-r,b,r,0⟩ : Cross)=⟨v+s,1,a-s,b,s,0⟩ := by
  apply T.disjoint _ _ (a+1) 1 first second
  · left; dsimp; omega
  · left; dsimp; omega

/-- Two bars filling the pocket leave two arithmetic possibilities:
two short bars when a=b+1, or one of each length when a=b+2. -/
theorem two_bar_count {a b l m : Int} (hab : b<a)
    (hl : l=a ∨ l=b) (hm : m=a ∨ m=b) (fill : l+m+2=2*a) :
    (a=b+1 ∧ l=b ∧ m=b) ∨ (a=b+2 ∧ ((l=a ∧ m=b) ∨ (l=b ∧ m=a))) := by
  rcases hl with hl | hl <;> rcases hm with hm | hm <;> omega

/-- A first short bar with its tall stem away from the original wall
traps a b-cell run. The original wall and the one tall wall are explicit. -/
theorem no_first_short_away {a b : Int} (hb : 4≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (wall : T.world ⟨0,0,a,b,0,0⟩)
    (bar : T.world ⟨b+1,1,0,a,b,0⟩) : False := by
  let B : Region := fun x y => Contains ⟨0,0,a,b,0,0⟩ x y ∨ Contains ⟨b+1,1,0,a,b,0⟩ x y
  apply LStarterRuns.blocked_short_run_one_tall (L:=1) (R:=b) (h:=2)
    (by omega) (by omega) (by omega) (by omega) T B (THalfPlaneGaps.pair_closed T wall bar)
  · intro x hx hy; unfold HalfPlane; omega
  · intro x hx hy; dsimp [B,Contains]; omega
  · intro x hx hy; dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · right; dsimp [B,Contains]; omega

/-- A short bar followed by any equally directed upright horizontal bar
creates a b-cell run with one sufficiently tall wall. -/
theorem no_left_junction_after_short {a b p h l : Int}
    (hb : 4≤b) (hab : b<a) (hl : l=a ∨ l=b)
    (T : Tiling a b 0 0 HalfPlane)
    (first : T.world ⟨p,h,b,a,0,0⟩)
    (second : T.world ⟨p+b+1,h,l,a+b-l,0,0⟩) : False := by
  let B : Region := fun x y => Contains ⟨p,h,b,a,0,0⟩ x y ∨
    Contains ⟨p+b+1,h,l,a+b-l,0,0⟩ x y
  have hh : 0≤h := T.inside _ first p h (by left; dsimp; omega)
  apply LStarterRuns.blocked_short_run_one_tall (L:=p+1) (R:=p+b) (h:=h+1)
    (by omega) (by omega) (by omega) (by omega) T B (THalfPlaneGaps.pair_closed T first second)
  · intro x hx hy; unfold HalfPlane; omega
  · intro x hx hy; dsimp [B,Contains]; omega
  · intro x hx hy; dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · left; dsimp [B,Contains]; omega

/-- The first two bars start at the actual left endpoint and are adjacent.
If the first is short, both stem directions are forced. -/
theorem first_two_bars {a b : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) :
    ∃l r m s,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧ (m=a ∨ m=b) ∧ (s=0 ∨ s=m) ∧
      l+m+2≤2*a ∧ T.world ⟨1+r,1,l-r,a+b-l,r,0⟩ ∧
      T.world ⟨l+2+s,1,m-s,a+b-m,s,0⟩ ∧ (l=b → r=0 ∧ s=m) := by
  obtain ⟨l,r,hl,hr,first⟩ := first_horizontal_bar ha (by omega) hab T bars
  obtain ⟨m,s,hm,hs,bound,second⟩ := successor_horizontal (q:=1) ha (by omega) hab hl hr
    (by omega) (by omega) T bars first
  have e : 1+l+1=l+2 := by omega
  rw [e] at bound second
  refine ⟨l,r,m,s,hl,hr,hm,hs,by omega,first,second,?_⟩
  intro eq
  subst l
  have rzero : r=0 := by
    rcases hr with hr | hr
    · exact hr
    · subst r
      have wall := bars.2.2.2.1
      exact False.elim (no_first_short_away hb hab T wall
        (by simpa only [Int.add_comm,Int.sub_self,show a+b-b=a by omega] using first))
  subst r
  refine ⟨rfl,?_⟩
  rcases hs with hs | hs
  · subst s
    apply False.elim
    apply no_left_junction_after_short (p:=1) (h:=1) hb hab hm T
    · simpa only [Int.add_zero,Int.sub_zero,show a+b-b=a by omega] using first
    · simpa only [Int.add_zero,Int.sub_zero,show 1+b+1=b+2 by omega] using second
  · exact hs

#print axioms first_two_bars
#print axioms no_left_junction_after_short
#print axioms no_first_short_away
#print axioms successor_horizontal
#print axioms long_bar_unique
#print axioms two_bar_count
end PolyominoFormal.LHalfPlaneAlternating

import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (fact_366edf150095_712 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (a > b))
    (h9 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h10 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o5 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a > b))
    (h2 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (fact_366edf150095_712 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n337_o7 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_four (a b : Int)
    (h0 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5041 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_4055 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6190 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_5845 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7798 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7798 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7798 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5071 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6196 a b)))) ∨ ((fact_366edf150095_7798 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5071 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6196 a b))))))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3022 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_2341 a b run_x)))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n338_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3610 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3342 a b run_x))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (fact_366edf150095_3920 a b) ∨ (fact_366edf150095_3471 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3473 a b) ∨ (fact_366edf150095_4054 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (fact_366edf150095_4637 a b) ∨ (fact_366edf150095_3926 a b) ∨ (((((4 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4028 a b) ∨ (fact_366edf150095_5044 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_4403 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_tall (a b : Int)
    (h0 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7742 a b) ∨ (fact_366edf150095_7802 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7742 a b) ∧ (fact_366edf150095_7802 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7742 a b) ∧ (fact_366edf150095_7802 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4959 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_6643 a b) ∨ (fact_366edf150095_6650 a b) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5642 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_6893 a b) ∨ (fact_366edf150095_6902 a b) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7742 a b) ∧ (fact_366edf150095_7802 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4959 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_6643 a b) ∨ (fact_366edf150095_6650 a b) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5642 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_6893 a b) ∨ (fact_366edf150095_6902 a b) ∨ (fact_366edf150095_5420 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a > b))
    (h3 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (run_x ≤ ((6 : Int) + b)))
    (h5 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3011 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3024 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_2978 a b run_x)))
    (h6 : ((7 : Int) ≤ run_x))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_366edf150095_712 a b))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n339_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3591 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3611 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3558 a b run_x))))
    (h2 : ((7 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5041 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_4402 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6190 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_6141 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7800 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7800 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7800 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5416 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6675 a b)))) ∨ ((fact_366edf150095_7800 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6738 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5711 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5416 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6737 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6675 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : (((4 : Int) + a) ≤ run_x))
    (h5 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3022 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_2977 a b run_x)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n340_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3610 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3557 a b run_x))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3516 a b) ∨ (fact_366edf150095_3496 a b) ∨ (fact_366edf150095_5828 a b) ∨ (fact_366edf150095_5829 a b) ∨ (fact_366edf150095_3497 a b) ∨ (fact_366edf150095_4109 a b) ∨ (fact_366edf150095_4112 a b) ∨ (fact_366edf150095_3498 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3499 a b) ∨ (fact_366edf150095_4115 a b) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_4116 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4211 a b) ∨ (fact_366edf150095_4110 a b) ∨ (fact_366edf150095_6125 a b) ∨ (fact_366edf150095_6126 a b) ∨ (fact_366edf150095_4111 a b) ∨ (fact_366edf150095_5111 a b) ∨ (fact_366edf150095_5112 a b) ∨ (fact_366edf150095_4113 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4114 a b) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5113 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7744 a b) ∨ (fact_366edf150095_7804 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7744 a b) ∧ (fact_366edf150095_7804 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7744 a b) ∧ (fact_366edf150095_7804 a b) ∧ (((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4961 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ (fact_366edf150095_6645 a b) ∨ (fact_366edf150095_6652 a b) ∨ (fact_366edf150095_5076 a b)) ∨ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5648 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5735 a b) ∨ (fact_366edf150095_6897 a b) ∨ (fact_366edf150095_6908 a b) ∨ (fact_366edf150095_5765 a b)))) ∨ ((fact_366edf150095_7744 a b) ∧ (fact_366edf150095_7804 a b) ∧ ((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4961 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5056 a b) ∨ (fact_366edf150095_6645 a b) ∨ (fact_366edf150095_6652 a b) ∨ (fact_366edf150095_5076 a b)) ∧ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5648 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5735 a b) ∨ (fact_366edf150095_6897 a b) ∨ (fact_366edf150095_6908 a b) ∨ (fact_366edf150095_5765 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a ≥ b))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + ((-1 : Int) * a)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((-1 : Int) * a))) ∨ ((((3 : Int) + b) + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (((3 : Int) + b) - (0 : Int)))))
    (h1 : (fact_366edf150095_712 a b))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ (fact_366edf150095_3059 a b run_x) ∨ (fact_366edf150095_2358 a b run_x) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2359 a b run_x) ∨ (fact_366edf150095_3060 a b run_x) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3061 a b run_x)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n341_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (fact_366edf150095_3562 a b run_x) ∨ (fact_366edf150095_3321 a b run_x) ∨ (((((4 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3337 a b run_x) ∨ (fact_366edf150095_3607 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3615 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_10 a b))
    (h2 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a > b))
    (h3 : ((fact_366edf150095_3232 a b) ∨ (fact_366edf150095_3166 a b) ∨ (fact_366edf150095_5092 a b) ∨ (fact_366edf150095_5094 a b) ∨ (fact_366edf150095_3168 a b) ∨ (fact_366edf150095_3423 a b) ∨ (fact_366edf150095_3425 a b) ∨ (fact_366edf150095_3170 a b) ∨ (fact_366edf150095_3426 a b) ∨ (fact_366edf150095_3171 a b) ∨ (fact_366edf150095_3427 a b) ∨ ((((3 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + a))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1798 a b jx jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + a) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h3 : ((jx < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h4 : (fact_366edf150095_1803 a b jx jy))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o2 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_366edf150095_1807 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - b)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_1810 a b jx jy))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (fact_366edf150095_1811 a b jx jy))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_1806 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((jy = (0 : Int)) ∧ (((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((((2 : Int) + ((-1 : Int) * b)) = ((jx + a) + (1 : Int))) ∨ (jx = ((((2 : Int) + ((-1 : Int) * b)) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (fact_366edf150095_2926 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (fact_366edf150095_2928 a b jx)))) ∨ ((jy = ((3 : Int) + b)) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((((jx + b) + (1 : Int)) = ((2 : Int) + ((-1 : Int) * b))) ∨ (((((2 : Int) + ((-1 : Int) * b)) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (fact_366edf150095_2927 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (fact_366edf150095_2929 a b jx)))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (fact_366edf150095_2930 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (fact_366edf150095_2931 a b jx))))))
    (h2 : (fact_366edf150095_1802 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  left
  right
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n342_o7 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - b))))
    (h4 : (fact_366edf150095_1799 a b jx jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ ((4 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_short (a b : Int)
    (h0 : (¬ (((3 : Int) - ((4 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_nonnegative (a b : Int)
    (h0 : (¬ (((4 : Int) + b) ≥ (0 : Int))))
    (h1 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_right (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a > b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (¬ ((((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_366edf150095_7818 a b) ∨ (fact_366edf150095_7682 a b))) ∨ (((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_366edf150095_7818 a b) ∧ (fact_366edf150095_7682 a b)) ∨ ((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((3 : Int) = (((4 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7818 a b) ∧ (fact_366edf150095_7682 a b) ∧ (((fact_366edf150095_6748 a b) ∨ (fact_366edf150095_6679 a b) ∨ (fact_366edf150095_7224 a b) ∨ (fact_366edf150095_7230 a b) ∨ (fact_366edf150095_6683 a b) ∨ (fact_366edf150095_6881 a b) ∨ (fact_366edf150095_6925 a b) ∨ (fact_366edf150095_6694 a b) ∨ (fact_366edf150095_6932 a b) ∨ (fact_366edf150095_6724 a b) ∨ (fact_366edf150095_6936 a b) ∨ (fact_366edf150095_7272 a b)) ∨ ((fact_366edf150095_5165 a b) ∨ (fact_366edf150095_4459 a b) ∨ (fact_366edf150095_6384 a b) ∨ (fact_366edf150095_6472 a b) ∨ (fact_366edf150095_4543 a b) ∨ (fact_366edf150095_5293 a b) ∨ (fact_366edf150095_5464 a b) ∨ (fact_366edf150095_4727 a b) ∨ (fact_366edf150095_5645 a b) ∨ (fact_366edf150095_4990 a b) ∨ (fact_366edf150095_5724 a b) ∨ (fact_366edf150095_6905 a b)))) ∨ ((fact_366edf150095_7818 a b) ∧ (fact_366edf150095_7682 a b) ∧ ((fact_366edf150095_6748 a b) ∨ (fact_366edf150095_6679 a b) ∨ (fact_366edf150095_7224 a b) ∨ (fact_366edf150095_7230 a b) ∨ (fact_366edf150095_6683 a b) ∨ (fact_366edf150095_6881 a b) ∨ (fact_366edf150095_6925 a b) ∨ (fact_366edf150095_6694 a b) ∨ (fact_366edf150095_6932 a b) ∨ (fact_366edf150095_6724 a b) ∨ (fact_366edf150095_6936 a b) ∨ (fact_366edf150095_7272 a b)) ∧ ((fact_366edf150095_5165 a b) ∨ (fact_366edf150095_4459 a b) ∨ (fact_366edf150095_6384 a b) ∨ (fact_366edf150095_6472 a b) ∨ (fact_366edf150095_4543 a b) ∨ (fact_366edf150095_5293 a b) ∨ (fact_366edf150095_5464 a b) ∨ (fact_366edf150095_4727 a b) ∨ (fact_366edf150095_5645 a b) ∨ (fact_366edf150095_4990 a b) ∨ (fact_366edf150095_5724 a b) ∨ (fact_366edf150095_6905 a b))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_empty (a b run_x : Int)
    (h0 : ((((6 : Int) + b) < ((3 : Int) + ((-1 : Int) * b))) ∨ (((3 : Int) + ((-1 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (((3 : Int) + b) - (0 : Int))) ∨ ((((3 : Int) + b) + a) < ((4 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (((4 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((3 : Int) ≥ run_x))
    (h5 : ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a))))))
    (h6 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ (5 : Int)))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n343_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + b) + a)))))))
    (h2 : ((3 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3919 a b) ∨ (fact_366edf150095_3470 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3710 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_4636 a b) ∨ (fact_366edf150095_3925 a b) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4395 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7464 a b) ∨ (fact_366edf150095_7536 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7464 a b) ∧ (fact_366edf150095_7536 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7464 a b) ∧ (fact_366edf150095_7536 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_3951 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_5454 a b) ∨ (fact_366edf150095_4717 a b) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4981 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7464 a b) ∧ (fact_366edf150095_7536 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_4663 a b) ∨ (fact_366edf150095_3951 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4033 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_5454 a b) ∨ (fact_366edf150095_4717 a b) ∨ (((((4 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4981 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((5 : Int) + b)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3011 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n344_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3591 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h1 : (run_x ≤ ((5 : Int) + b)))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_8 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_3230 a b) ∨ (fact_366edf150095_3160 a b) ∨ (fact_366edf150095_5088 a b) ∨ (fact_366edf150095_5090 a b) ∨ (fact_366edf150095_3162 a b) ∨ (fact_366edf150095_3418 a b) ∨ (fact_366edf150095_3420 a b) ∨ ((((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((2 : Int) ≥ ((4 : Int) - b)) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((2 : Int) ≥ ((6 : Int) - b)) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1782 a b jx jy))
    (h1 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (¬ (((jx = ((2 : Int) + ((-1 : Int) * a))) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((3 : Int) + ((-1 : Int) * a))) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1787 a b jx jy))
    (h1 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - a))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (fact_366edf150095_1791 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_366edf150095_1794 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o4 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h2 : (fact_366edf150095_1795 a b jx jy))
    (h3 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h5 : (((jx + (0 : Int)) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_1790 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (fact_366edf150095_1786 a b jx jy))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ (((jx = ((2 : Int) + ((-1 : Int) * b))) ∧ (jy = ((3 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((3 : Int) + ((-1 : Int) * b))) ∧ (jy = ((3 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n345_o7 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h1 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - b))))
    (h3 : (fact_366edf150095_1783 a b jx jy))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_10 a b))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_empty (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < ((2 : Int) + ((-1 : Int) * a))) ∨ (((2 : Int) + ((-1 : Int) * a)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (((3 : Int) + b) - (0 : Int))) ∨ ((0 : Int) > (((3 : Int) + b) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_3232 a b) ∨ (fact_366edf150095_3166 a b) ∨ (fact_366edf150095_5092 a b) ∨ (fact_366edf150095_5094 a b) ∨ (fact_366edf150095_3168 a b) ∨ (fact_366edf150095_3423 a b) ∨ (fact_366edf150095_3425 a b) ∨ (fact_366edf150095_3170 a b) ∨ (fact_366edf150095_3426 a b) ∨ (fact_366edf150095_3171 a b) ∨ ((((3 : Int) ≥ ((6 : Int) - b)) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≥ ((2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + b))))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1798 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o1 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : (fact_366edf150095_1803 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((jx + b) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o2 (a b jx jy : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (fact_366edf150095_1807 a b jx jy))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - b)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_366edf150095_1810 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1811 a b jx jy))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o5 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_366edf150095_1806 a b jx jy))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o6 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + b) < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h3 : (fact_366edf150095_1802 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n346_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_366edf150095_1799 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_point (a b : Int)
    (h0 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_9 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_empty (a b : Int)
    (h0 : (a > b))
    (h1 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((0 : Int) + a) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((3 : Int) + b)) ∨ ((0 : Int) > ((3 : Int) + b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_366edf150095_3231 a b) ∨ (fact_366edf150095_3161 a b) ∨ (fact_366edf150095_5089 a b) ∨ (fact_366edf150095_5091 a b) ∨ (fact_366edf150095_3163 a b) ∨ (fact_366edf150095_3419 a b) ∨ (fact_366edf150095_3421 a b) ∨ (fact_366edf150095_3164 a b) ∨ ((((2 : Int) ≥ ((4 : Int) - b)) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((2 : Int) ≥ ((6 : Int) - b)) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((2 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((2 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + b))))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_1784 a b jx jy))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + a) < ((3 : Int) + ((-1 : Int) * a))) ∨ (((3 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - (0 : Int))) ∨ ((((3 : Int) + b) + b) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1789 a b jx jy))
    (h2 : (fact_366edf150095_2953 a b jy))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((jx + b) < ((3 : Int) + ((-1 : Int) * a))) ∨ (((3 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - (0 : Int))) ∨ ((((3 : Int) + b) + b) < jy)))
    (h7 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - a))))
    (h8 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_366edf150095_1793 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - b))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_1796 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (fact_366edf150095_1797 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h8 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h9 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - a))))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h9 : (fact_366edf150095_1792 a b jx jy))
    (h10 : (((jx + (0 : Int)) < ((3 : Int) + ((-1 : Int) * a))) ∨ (((3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < (((3 : Int) + b) - (0 : Int))) ∨ ((((3 : Int) + b) + b) < jy)))
    (h11 : (a = (b + (2 : Int))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((2 : Int) + ((-1 : Int) * b))) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((3 : Int) + ((-1 : Int) * b))) ∧ (jy = ((4 : Int) + b)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_366edf150095_1788 a b jx jy))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + b) < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n347_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - b))))
    (h2 : (fact_366edf150095_1785 a b jx jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ (3 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_short (a b : Int)
    (h0 : (¬ (((3 : Int) - (3 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_left (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + b)))) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + a)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + b)))) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_tall (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a > b))
    (h5 : (¬ ((((3 : Int) ≥ ((3 : Int) + (3 : Int))) ∧ (((fact_366edf150095_6573 a b) ∨ (fact_366edf150095_6215 a b) ∨ (fact_366edf150095_7070 a b) ∨ (fact_366edf150095_7104 a b) ∨ (fact_366edf150095_6245 a b) ∨ (fact_366edf150095_6759 a b) ∨ (fact_366edf150095_6797 a b) ∨ (fact_366edf150095_6289 a b) ∨ (fact_366edf150095_6853 a b) ∨ (fact_366edf150095_6313 a b) ∨ (fact_366edf150095_6872 a b) ∨ (fact_366edf150095_7261 a b) ∨ (fact_366edf150095_7257 a b)) ∨ ((fact_366edf150095_6569 a b) ∨ (fact_366edf150095_6211 a b) ∨ (fact_366edf150095_7066 a b) ∨ (fact_366edf150095_7100 a b) ∨ (fact_366edf150095_6241 a b) ∨ (fact_366edf150095_6755 a b) ∨ (fact_366edf150095_6795 a b) ∨ (fact_366edf150095_6285 a b) ∨ (fact_366edf150095_6851 a b) ∨ (fact_366edf150095_6311 a b) ∨ (fact_366edf150095_6871 a b) ∨ (fact_366edf150095_7259 a b) ∨ (fact_366edf150095_7255 a b)))) ∨ (((3 : Int) ≥ ((3 : Int) + (2 : Int))) ∧ ((fact_366edf150095_6573 a b) ∨ (fact_366edf150095_6215 a b) ∨ (fact_366edf150095_7070 a b) ∨ (fact_366edf150095_7104 a b) ∨ (fact_366edf150095_6245 a b) ∨ (fact_366edf150095_6759 a b) ∨ (fact_366edf150095_6797 a b) ∨ (fact_366edf150095_6289 a b) ∨ (fact_366edf150095_6853 a b) ∨ (fact_366edf150095_6313 a b) ∨ (fact_366edf150095_6872 a b) ∨ (fact_366edf150095_7261 a b) ∨ (fact_366edf150095_7257 a b)) ∧ ((fact_366edf150095_6569 a b) ∨ (fact_366edf150095_6211 a b) ∨ (fact_366edf150095_7066 a b) ∨ (fact_366edf150095_7100 a b) ∨ (fact_366edf150095_6241 a b) ∨ (fact_366edf150095_6755 a b) ∨ (fact_366edf150095_6795 a b) ∨ (fact_366edf150095_6285 a b) ∨ (fact_366edf150095_6851 a b) ∨ (fact_366edf150095_6311 a b) ∨ (fact_366edf150095_6871 a b) ∨ (fact_366edf150095_7259 a b) ∨ (fact_366edf150095_7255 a b))) ∨ ((3 : Int) ≥ ((3 : Int) + (4 : Int))) ∨ (((3 : Int) = ((3 : Int) + (1 : Int))) ∧ ((fact_366edf150095_6573 a b) ∨ (fact_366edf150095_6215 a b) ∨ (fact_366edf150095_7070 a b) ∨ (fact_366edf150095_7104 a b) ∨ (fact_366edf150095_6245 a b) ∨ (fact_366edf150095_6759 a b) ∨ (fact_366edf150095_6797 a b) ∨ (fact_366edf150095_6289 a b) ∨ (fact_366edf150095_6853 a b) ∨ (fact_366edf150095_6313 a b) ∨ (fact_366edf150095_6872 a b) ∨ (fact_366edf150095_7261 a b) ∨ (fact_366edf150095_7257 a b)) ∧ ((fact_366edf150095_6569 a b) ∨ (fact_366edf150095_6211 a b) ∨ (fact_366edf150095_7066 a b) ∨ (fact_366edf150095_7100 a b) ∨ (fact_366edf150095_6241 a b) ∨ (fact_366edf150095_6755 a b) ∨ (fact_366edf150095_6795 a b) ∨ (fact_366edf150095_6285 a b) ∨ (fact_366edf150095_6851 a b) ∨ (fact_366edf150095_6311 a b) ∨ (fact_366edf150095_6871 a b) ∨ (fact_366edf150095_7259 a b) ∨ (fact_366edf150095_7255 a b)) ∧ (((fact_366edf150095_6572 a b) ∨ (fact_366edf150095_6214 a b) ∨ (fact_366edf150095_7069 a b) ∨ (fact_366edf150095_7103 a b) ∨ (fact_366edf150095_6244 a b) ∨ (fact_366edf150095_6758 a b) ∨ (fact_366edf150095_6796 a b) ∨ (fact_366edf150095_6288 a b) ∨ (fact_366edf150095_6852 a b) ∨ (fact_366edf150095_6312 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2119 a)) ∨ (fact_366edf150095_7260 a b) ∨ (fact_366edf150095_7256 a b)) ∨ ((fact_366edf150095_6568 a b) ∨ (fact_366edf150095_6210 a b) ∨ (fact_366edf150095_7065 a b) ∨ (fact_366edf150095_7099 a b) ∨ (fact_366edf150095_6240 a b) ∨ (fact_366edf150095_6754 a b) ∨ (fact_366edf150095_6794 a b) ∨ (fact_366edf150095_6284 a b) ∨ (fact_366edf150095_6850 a b) ∨ (fact_366edf150095_6310 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2117 a)) ∨ (fact_366edf150095_7258 a b) ∨ (fact_366edf150095_7254 a b)))) ∨ (((fact_366edf150095_6573 a b) ∨ (fact_366edf150095_6215 a b) ∨ (fact_366edf150095_7070 a b) ∨ (fact_366edf150095_7104 a b) ∨ (fact_366edf150095_6245 a b) ∨ (fact_366edf150095_6759 a b) ∨ (fact_366edf150095_6797 a b) ∨ (fact_366edf150095_6289 a b) ∨ (fact_366edf150095_6853 a b) ∨ (fact_366edf150095_6313 a b) ∨ (fact_366edf150095_6872 a b) ∨ (fact_366edf150095_7261 a b) ∨ (fact_366edf150095_7257 a b)) ∧ ((fact_366edf150095_6569 a b) ∨ (fact_366edf150095_6211 a b) ∨ (fact_366edf150095_7066 a b) ∨ (fact_366edf150095_7100 a b) ∨ (fact_366edf150095_6241 a b) ∨ (fact_366edf150095_6755 a b) ∨ (fact_366edf150095_6795 a b) ∨ (fact_366edf150095_6285 a b) ∨ (fact_366edf150095_6851 a b) ∨ (fact_366edf150095_6311 a b) ∨ (fact_366edf150095_6871 a b) ∨ (fact_366edf150095_7259 a b) ∨ (fact_366edf150095_7255 a b)) ∧ ((fact_366edf150095_6572 a b) ∨ (fact_366edf150095_6214 a b) ∨ (fact_366edf150095_7069 a b) ∨ (fact_366edf150095_7103 a b) ∨ (fact_366edf150095_6244 a b) ∨ (fact_366edf150095_6758 a b) ∨ (fact_366edf150095_6796 a b) ∨ (fact_366edf150095_6288 a b) ∨ (fact_366edf150095_6852 a b) ∨ (fact_366edf150095_6312 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2119 a)) ∨ (fact_366edf150095_7260 a b) ∨ (fact_366edf150095_7256 a b)) ∧ ((fact_366edf150095_6568 a b) ∨ (fact_366edf150095_6210 a b) ∨ (fact_366edf150095_7065 a b) ∨ (fact_366edf150095_7099 a b) ∨ (fact_366edf150095_6240 a b) ∨ (fact_366edf150095_6754 a b) ∨ (fact_366edf150095_6794 a b) ∨ (fact_366edf150095_6284 a b) ∨ (fact_366edf150095_6850 a b) ∨ (fact_366edf150095_6310 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2117 a)) ∨ (fact_366edf150095_7258 a b) ∨ (fact_366edf150095_7254 a b))))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (a ≥ b))
    (h3 : ((fact_366edf150095_4215 a b run_x) ∨ (fact_366edf150095_4200 a b run_x) ∨ (fact_366edf150095_6129 a b run_x) ∨ (fact_366edf150095_6135 a b run_x) ∨ (fact_366edf150095_4203 a b run_x) ∨ (fact_366edf150095_5116 a b run_x) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + b)))) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + a))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((3 : Int) ≥ run_x))
    (h6 : (a > b))
    (h7 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n348_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≥ run_x))
    (h1 : (¬ ((fact_366edf150095_5849 a b run_x) ∨ (fact_366edf150095_5834 a b run_x) ∨ (fact_366edf150095_6957 a b run_x) ∨ (fact_366edf150095_6960 a b run_x) ∨ (fact_366edf150095_5837 a b run_x) ∨ (fact_366edf150095_6132 a b run_x) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_680 a run_x)) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((3 : Int) + b) + b)))) ∨ ((((((2 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + b))) ∨ ((((2 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((4 : Int) + b) + a)))))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_point (a b : Int)
    (h0 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2910 a b) ∨ (fact_366edf150095_2597 a b) ∨ (fact_366edf150095_4096 a b) ∨ (fact_366edf150095_4100 a b) ∨ (fact_366edf150095_2598 a b) ∨ (fact_366edf150095_3204 a b) ∨ (fact_366edf150095_3207 a b) ∨ (fact_366edf150095_2599 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - b)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2600 a b) ∨ ((((7 : Int) ≥ ((6 : Int) - b)) ∧ ((7 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((7 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((7 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((7 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((4 : Int) + b) + a))))))
    (h3 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o0 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : (a > b))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_366edf150095_712 a b))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h9 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h10 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o4 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o5 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o6 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n349_o7 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h6 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_four (a b : Int)
    (h0 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_4055 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_5845 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7799 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7799 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7799 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5071 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6196 a b)))) ∨ ((fact_366edf150095_7799 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6197 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5071 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6196 a b))))))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_2341 a b run_x)))
    (h1 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (((4 : Int) + a) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n350_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3342 a b run_x))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_point (a b : Int)
    (h0 : (¬ (((8 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_empty (a b : Int)
    (h0 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - a)) ∧ ((8 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - b)) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((4 : Int) ≤ (((4 : Int) + b) + a)))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o0 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ ((((8 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((7 : Int) > (jx + a)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * b)) + b) < (jx - a)) ∨ (jy < ((4 : Int) + b)) ∨ (((4 : Int) + b) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (fact_366edf150095_712 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h8 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a > b))
    (h11 : (a ≥ b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o3 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((jx = ((8 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o4 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o5 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (¬ (((jx = ((8 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o6 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((7 : Int) > (jx + b)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n351_o7 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((8 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_5073 a b) ∨ (((((8 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((8 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_6198 a b) ∨ (((((8 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((8 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7841 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6201 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7841 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6201 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7841 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6201 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_5084 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_6200 a b)))) ∨ ((fact_366edf150095_7841 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6201 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_5084 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_6200 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_empty (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : ((((2 : Int) * a) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_3027 a b run_x) ∨ (((((8 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ run_x) ∧ ((8 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n352_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3616 a b run_x) ∨ (((((8 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((8 : Int) ≤ run_x) ∧ ((8 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_four (a b : Int)
    (h0 : (¬ ((8 : Int) ≤ ((7 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_short (a b : Int)
    (h0 : (¬ ((((7 : Int) + b) - (8 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + b)) ∧ ((5 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((8 : Int) + b) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + b)) ∧ ((5 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((7 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((8 : Int) + b) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_tall (a b : Int)
    (h0 : (¬ (((((8 : Int) + (3 : Int)) ≤ ((7 : Int) + b)) ∧ ((fact_366edf150095_7809 a b) ∨ (fact_366edf150095_7843 a b))) ∨ ((((8 : Int) + (2 : Int)) ≤ ((7 : Int) + b)) ∧ (fact_366edf150095_7809 a b) ∧ (fact_366edf150095_7843 a b)) ∨ (((8 : Int) + (4 : Int)) ≤ ((7 : Int) + b)) ∨ ((((7 : Int) + b) = ((8 : Int) + (1 : Int))) ∧ (fact_366edf150095_7809 a b) ∧ (fact_366edf150095_7843 a b) ∧ (((fact_366edf150095_4194 a b) ∨ (fact_366edf150095_3789 a b) ∨ (fact_366edf150095_5940 a b) ∨ (fact_366edf150095_6023 a b) ∨ (fact_366edf150095_3870 a b) ∨ (fact_366edf150095_4303 a b) ∨ (fact_366edf150095_4675 a b) ∨ (fact_366edf150095_3965 a b) ∨ (((((4 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4050 a b) ∨ (fact_366edf150095_5065 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5080 a b) ∨ (fact_366edf150095_4409 a b)) ∨ ((fact_366edf150095_5162 a b) ∨ (fact_366edf150095_4456 a b) ∨ (fact_366edf150095_6381 a b) ∨ (fact_366edf150095_6469 a b) ∨ (fact_366edf150095_4540 a b) ∨ (fact_366edf150095_5290 a b) ∨ (fact_366edf150095_5461 a b) ∨ (fact_366edf150095_4724 a b) ∨ (((((4 : Int) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4987 a b) ∨ (fact_366edf150095_5744 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5759 a b) ∨ (fact_366edf150095_5425 a b)))) ∨ ((fact_366edf150095_7809 a b) ∧ (fact_366edf150095_7843 a b) ∧ ((fact_366edf150095_4194 a b) ∨ (fact_366edf150095_3789 a b) ∨ (fact_366edf150095_5940 a b) ∨ (fact_366edf150095_6023 a b) ∨ (fact_366edf150095_3870 a b) ∨ (fact_366edf150095_4303 a b) ∨ (fact_366edf150095_4675 a b) ∨ (fact_366edf150095_3965 a b) ∨ (((((4 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4050 a b) ∨ (fact_366edf150095_5065 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5080 a b) ∨ (fact_366edf150095_4409 a b)) ∧ ((fact_366edf150095_5162 a b) ∨ (fact_366edf150095_4456 a b) ∨ (fact_366edf150095_6381 a b) ∨ (fact_366edf150095_6469 a b) ∨ (fact_366edf150095_4540 a b) ∨ (fact_366edf150095_5290 a b) ∨ (fact_366edf150095_5461 a b) ∨ (fact_366edf150095_4724 a b) ∨ (((((4 : Int) - b) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((7 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4987 a b) ∨ (fact_366edf150095_5744 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((7 : Int) + b) + (1 : Int))) ∧ ((((7 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5759 a b) ∨ (fact_366edf150095_5425 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3011 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3026 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((8 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h1 : (run_x ≤ ((7 : Int) + b)))
    (h2 : ((8 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((2 : Int) * a) < (((8 : Int) + b) - b)) ∨ ((((8 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n353_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3591 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3614 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((8 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((8 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))))))
    (h1 : (run_x ≤ ((7 : Int) + b)))
    (h2 : ((8 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_5073 a b) ∨ ((((((8 : Int) + a) - a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_6198 a b) ∨ ((((((8 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7842 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6678 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7842 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6678 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7842 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6678 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_5423 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_6677 a b)))) ∨ ((fact_366edf150095_7842 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6747 a b) ∨ (fact_366edf150095_6678 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5755 a b) ∨ (fact_366edf150095_5423 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6746 a b) ∨ (fact_366edf150095_6677 a b))))))
    (h2 : ((((2 : Int) * a) < (((8 : Int) + a) - a)) ∨ ((((8 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < (((8 : Int) + a) - a)) ∨ ((((8 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_3027 a b run_x) ∨ ((((((8 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((8 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : (((4 : Int) + a) ≤ run_x))
    (h5 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n354_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3616 a b run_x) ∨ ((((((8 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((8 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((8 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_left (a b : Int)
    (h0 : (¬ (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - b)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_right (a b : Int)
    (h0 : (¬ (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - b)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7810 a b) ∨ (fact_366edf150095_7844 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7810 a b) ∧ (fact_366edf150095_7844 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7810 a b) ∧ (fact_366edf150095_7844 a b) ∧ (((fact_366edf150095_4196 a b) ∨ (fact_366edf150095_3791 a b) ∨ (fact_366edf150095_5942 a b) ∨ (fact_366edf150095_6025 a b) ∨ (fact_366edf150095_3872 a b) ∨ (fact_366edf150095_4305 a b) ∨ (fact_366edf150095_4677 a b) ∨ (fact_366edf150095_3967 a b) ∨ (((((4 : Int) - b) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4052 a b) ∨ (fact_366edf150095_5067 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5082 a b) ∨ (fact_366edf150095_5086 a b)) ∨ ((fact_366edf150095_5199 a b) ∨ (fact_366edf150095_4493 a b) ∨ (fact_366edf150095_6418 a b) ∨ (fact_366edf150095_6506 a b) ∨ (fact_366edf150095_4577 a b) ∨ (fact_366edf150095_5327 a b) ∨ (fact_366edf150095_5482 a b) ∨ (fact_366edf150095_4768 a b) ∨ (((((4 : Int) - b) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5027 a b) ∨ (fact_366edf150095_5752 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5770 a b) ∨ (fact_366edf150095_5772 a b)))) ∨ ((fact_366edf150095_7810 a b) ∧ (fact_366edf150095_7844 a b) ∧ ((fact_366edf150095_4196 a b) ∨ (fact_366edf150095_3791 a b) ∨ (fact_366edf150095_5942 a b) ∨ (fact_366edf150095_6025 a b) ∨ (fact_366edf150095_3872 a b) ∨ (fact_366edf150095_4305 a b) ∨ (fact_366edf150095_4677 a b) ∨ (fact_366edf150095_3967 a b) ∨ (((((4 : Int) - b) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4052 a b) ∨ (fact_366edf150095_5067 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5082 a b) ∨ (fact_366edf150095_5086 a b)) ∧ ((fact_366edf150095_5199 a b) ∨ (fact_366edf150095_4493 a b) ∨ (fact_366edf150095_6418 a b) ∨ (fact_366edf150095_6506 a b) ∨ (fact_366edf150095_4577 a b) ∨ (fact_366edf150095_5327 a b) ∨ (fact_366edf150095_5482 a b) ∨ (fact_366edf150095_4768 a b) ∨ (((((4 : Int) - b) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((9 : Int) + a)) ∧ ((4 : Int) ≥ ((9 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5027 a b) ∨ (fact_366edf150095_5752 a b) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((9 : Int) + a)) ∧ (((9 : Int) + a) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5770 a b) ∨ (fact_366edf150095_5772 a b))))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (fact_366edf150095_712 a b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((((9 : Int) ≥ ((-1 : Int) - a)) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((9 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((9 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((9 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((9 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((9 : Int) ≥ ((2 : Int) * a)) ∧ ((9 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((9 : Int) ≥ ((2 : Int) - a)) ∧ ((9 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((9 : Int) ≥ ((4 : Int) - b)) ∧ ((9 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ ((((9 : Int) ≥ ((6 : Int) - b)) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((9 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((9 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((9 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((9 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h6 : ((((3 : Int) + ((-1 : Int) * a)) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + a) < ((3 : Int) + ((-1 : Int) * a))) ∨ ((((3 : Int) + b) + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (((3 : Int) + b) - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n355_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) * a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((7 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((8 : Int) - (0 : Int)) ≤ ((9 : Int) - (1 : Int))) ∧ (((9 : Int) - (1 : Int)) ≤ ((8 : Int) + a)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≤ ((9 : Int) - (1 : Int))) ∧ ((8 : Int) ≥ ((9 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (fact_366edf150095_3920 a b) ∨ (fact_366edf150095_3471 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3473 a b) ∨ (((((6 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (fact_366edf150095_4637 a b) ∨ (fact_366edf150095_3926 a b) ∨ (((((4 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4028 a b) ∨ (((((6 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_4403 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7743 a b) ∨ (fact_366edf150095_7803 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7743 a b) ∧ (fact_366edf150095_7803 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7743 a b) ∧ (fact_366edf150095_7803 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4959 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5061 a b) ∨ (fact_366edf150095_6643 a b) ∨ (fact_366edf150095_6650 a b) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5642 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5742 a b) ∨ (fact_366edf150095_6893 a b) ∨ (fact_366edf150095_6902 a b) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7743 a b) ∧ (fact_366edf150095_7803 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (fact_366edf150095_4671 a b) ∨ (fact_366edf150095_3961 a b) ∨ (fact_366edf150095_4959 a b) ∨ (fact_366edf150095_4044 a b) ∨ (fact_366edf150095_5061 a b) ∨ (fact_366edf150095_6643 a b) ∨ (fact_366edf150095_6650 a b) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (fact_366edf150095_5458 a b) ∨ (fact_366edf150095_4722 a b) ∨ (fact_366edf150095_5642 a b) ∨ (fact_366edf150095_4984 a b) ∨ (fact_366edf150095_5742 a b) ∨ (fact_366edf150095_6893 a b) ∨ (fact_366edf150095_6902 a b) ∨ (fact_366edf150095_5420 a b))))))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_712 a b))
    (h2 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2986 a b run_x) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_3011 a b run_x) ∨ (fact_366edf150095_2338 a b run_x) ∨ (fact_366edf150095_3026 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + b)) ∧ ((5 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + b)) ∧ ((5 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((5 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_2978 a b run_x)))
    (h3 : ((7 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((6 : Int) + b)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a > b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n356_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3566 a b run_x) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3591 a b run_x) ∨ (fact_366edf150095_3339 a b run_x) ∨ (fact_366edf150095_3614 a b run_x) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3558 a b run_x))))
    (h2 : ((7 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4632 a b) ∨ (fact_366edf150095_3923 a b) ∨ (fact_366edf150095_4941 a b) ∨ (fact_366edf150095_4027 a b) ∨ (fact_366edf150095_5060 a b) ∨ (fact_366edf150095_6642 a b) ∨ (fact_366edf150095_6649 a b) ∨ (fact_366edf150095_4402 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_6178 a b) ∨ (fact_366edf150095_5844 a b) ∨ (fact_366edf150095_6193 a b) ∨ (fact_366edf150095_7061 a b) ∨ (fact_366edf150095_7062 a b) ∨ (fact_366edf150095_6141 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7801 a b) ∨ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7801 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b))) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7801 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5416 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6675 a b)))) ∨ ((fact_366edf150095_7801 a b) ∧ ((fact_366edf150095_6203 a b) ∨ (fact_366edf150095_6147 a b) ∨ (fact_366edf150095_7047 a b) ∨ (fact_366edf150095_7051 a b) ∨ (fact_366edf150095_6151 a b) ∨ (fact_366edf150095_6633 a b) ∨ (fact_366edf150095_6689 a b) ∨ (fact_366edf150095_6164 a b) ∨ (fact_366edf150095_6714 a b) ∨ (fact_366edf150095_6182 a b) ∨ (fact_366edf150095_6741 a b) ∨ (fact_366edf150095_7239 a b) ∨ (fact_366edf150095_7241 a b) ∨ (fact_366edf150095_6676 a b)) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5445 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_5630 a b) ∨ (fact_366edf150095_4975 a b) ∨ (fact_366edf150095_5740 a b) ∨ (fact_366edf150095_6891 a b) ∨ (fact_366edf150095_6900 a b) ∨ (fact_366edf150095_5416 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6713 a b) ∨ (fact_366edf150095_6181 a b) ∨ (fact_366edf150095_6740 a b) ∨ (fact_366edf150095_7238 a b) ∨ (fact_366edf150095_7240 a b) ∨ (fact_366edf150095_6675 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_empty (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_3008 a b run_x) ∨ (fact_366edf150095_2337 a b run_x) ∨ (fact_366edf150095_3025 a b run_x) ∨ (fact_366edf150095_4216 a b run_x) ∨ (fact_366edf150095_4217 a b run_x) ∨ (fact_366edf150095_2977 a b run_x)))
    (h2 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h4 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n357_run_floor (a b run_x : Int)
    (h0 : (((4 : Int) + a) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3590 a b run_x) ∨ (fact_366edf150095_3338 a b run_x) ∨ (fact_366edf150095_3613 a b run_x) ∨ (fact_366edf150095_5850 a b run_x) ∨ (fact_366edf150095_5851 a b run_x) ∨ (fact_366edf150095_3557 a b run_x))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_point (a b : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_6 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_empty (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((fact_366edf150095_3228 a b) ∨ (fact_366edf150095_3134 a b) ∨ (fact_366edf150095_4224 a b) ∨ (fact_366edf150095_4313 a b) ∨ (fact_366edf150095_3142 a b) ∨ (fact_366edf150095_3359 a b) ∨ (fact_366edf150095_3393 a b) ∨ (fact_366edf150095_3151 a b) ∨ (fact_366edf150095_3414 a b) ∨ (fact_366edf150095_3158 a b) ∨ (((((6 : Int) - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (0 : Int))) ∧ ((2 : Int) ≤ (((4 : Int) + b) + a)))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((7 : Int) ≤ ((6 : Int) + b)) ∧ ((7 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a))))))
    (h5 : ((((0 : Int) + a) < (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((3 : Int) + ((-1 : Int) * a)) + a) < ((0 : Int) - (0 : Int))) ∨ ((0 : Int) < ((3 : Int) + b)) ∨ ((0 : Int) > ((3 : Int) + b))))
    (h6 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h8 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o0 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_366edf150095_1838 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_1843 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1859 a b jx jy))
    (h2 : (fact_366edf150095_712 a b))
    (h3 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1874 a b jx jy))
    (h2 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (fact_366edf150095_712 a b))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h11 : (a = (b + (2 : Int))))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (a > b))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a ≥ b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_366edf150095_1875 a b jx jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o5 (a b jx jy : Int)
    (h0 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1858 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (fact_366edf150095_712 a b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a > b))
    (h11 : (a ≥ b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o6 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1842 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n358_o7 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (fact_366edf150095_1839 a b jx jy))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_366edf150095_712 a b))
    (h5 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3516 a b) ∨ (fact_366edf150095_3496 a b) ∨ (fact_366edf150095_5828 a b) ∨ (fact_366edf150095_5829 a b) ∨ (fact_366edf150095_3497 a b) ∨ (fact_366edf150095_4109 a b) ∨ (fact_366edf150095_4112 a b) ∨ (fact_366edf150095_3498 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3499 a b) ∨ ((((8 : Int) ≥ ((6 : Int) - b)) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_4116 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4211 a b) ∨ (fact_366edf150095_4110 a b) ∨ (fact_366edf150095_6125 a b) ∨ (fact_366edf150095_6126 a b) ∨ (fact_366edf150095_4111 a b) ∨ (fact_366edf150095_5111 a b) ∨ (fact_366edf150095_5112 a b) ∨ (fact_366edf150095_4113 a b) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4114 a b) ∨ ((((8 : Int) ≥ ((6 : Int) - b)) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_5113 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7745 a b) ∨ (fact_366edf150095_7805 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7745 a b) ∧ (fact_366edf150095_7805 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7745 a b) ∧ (fact_366edf150095_7805 a b) ∧ (((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4961 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5063 a b) ∨ (fact_366edf150095_6645 a b) ∨ (fact_366edf150095_6652 a b) ∨ (fact_366edf150095_5076 a b)) ∨ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5648 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5750 a b) ∨ (fact_366edf150095_6897 a b) ∨ (fact_366edf150095_6908 a b) ∨ (fact_366edf150095_5765 a b)))) ∨ ((fact_366edf150095_7745 a b) ∧ (fact_366edf150095_7805 a b) ∧ ((fact_366edf150095_4190 a b) ∨ (fact_366edf150095_3785 a b) ∨ (fact_366edf150095_5936 a b) ∨ (fact_366edf150095_6019 a b) ∨ (fact_366edf150095_3866 a b) ∨ (fact_366edf150095_4299 a b) ∨ (fact_366edf150095_4673 a b) ∨ (fact_366edf150095_3963 a b) ∨ (fact_366edf150095_4961 a b) ∨ (fact_366edf150095_4047 a b) ∨ (fact_366edf150095_5063 a b) ∨ (fact_366edf150095_6645 a b) ∨ (fact_366edf150095_6652 a b) ∨ (fact_366edf150095_5076 a b)) ∧ ((fact_366edf150095_5195 a b) ∨ (fact_366edf150095_4489 a b) ∨ (fact_366edf150095_6414 a b) ∨ (fact_366edf150095_6502 a b) ∨ (fact_366edf150095_4573 a b) ∨ (fact_366edf150095_5323 a b) ∨ (fact_366edf150095_5479 a b) ∨ (fact_366edf150095_4766 a b) ∨ (fact_366edf150095_5648 a b) ∨ (fact_366edf150095_5023 a b) ∨ (fact_366edf150095_5750 a b) ∨ (fact_366edf150095_6897 a b) ∨ (fact_366edf150095_6908 a b) ∨ (fact_366edf150095_5765 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ (fact_366edf150095_3059 a b run_x) ∨ (fact_366edf150095_2358 a b run_x) ∨ ((((8 : Int) ≥ ((4 : Int) - b)) ∧ ((8 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2359 a b run_x) ∨ ((((8 : Int) ≥ ((6 : Int) - b)) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * a))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((8 : Int) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ (((8 : Int) ≥ ((3 : Int) + ((-1 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3061 a b run_x)))
    (h2 : ((((3 : Int) + ((-1 : Int) * a)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((-1 : Int) * a))) ∨ ((((3 : Int) + b) + b) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < (((3 : Int) + b) - (0 : Int)))))
    (h3 : (run_x ≤ ((3 : Int) + b)))
    (h4 : ((((4 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n359_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (fact_366edf150095_3562 a b run_x) ∨ (fact_366edf150095_3321 a b run_x) ∨ (((((4 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3337 a b run_x) ∨ (((((6 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * a)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + b)))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((4 : Int) + b) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + a)))) ∨ (fact_366edf150095_3615 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_point (a b : Int)
    (h0 : (fact_366edf150095_10 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_3232 a b) ∨ (fact_366edf150095_3166 a b) ∨ (fact_366edf150095_5092 a b) ∨ (fact_366edf150095_5094 a b) ∨ (fact_366edf150095_3168 a b) ∨ (fact_366edf150095_3423 a b) ∨ (fact_366edf150095_3425 a b) ∨ (fact_366edf150095_3170 a b) ∨ (fact_366edf150095_3426 a b) ∨ (fact_366edf150095_3171 a b) ∨ ((((3 : Int) ≥ ((6 : Int) - b)) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≥ ((2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≤ ((2 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((3 : Int) + b) + a))))))
    (h2 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_366edf150095_1798 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + a) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o1 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h4 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h5 : (fact_366edf150095_1803 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o2 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_366edf150095_1807 a b jx jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + ((-1 : Int) * b))) ∨ (((2 : Int) + ((-1 : Int) * b)) < (jx - a)) ∨ (jy < (((3 : Int) + b) - (0 : Int))) ∨ ((((3 : Int) + b) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_366edf150095_1810 a b jx jy))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < (jx - b)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o4 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_366edf150095_1811 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - b)) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_1806 a b jx jy))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o6 (a b jx jy : Int)
    (h0 : (¬ ((((((jy = (0 : Int)) ∧ (((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((((2 : Int) + ((-1 : Int) * b)) = ((jx + a) + (1 : Int))) ∨ (jx = ((((2 : Int) + ((-1 : Int) * b)) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (fact_366edf150095_2926 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (fact_366edf150095_2928 a b jx)))) ∨ ((jy = ((3 : Int) + b)) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((((jx + b) + (1 : Int)) = ((2 : Int) + ((-1 : Int) * b))) ∨ (((((2 : Int) + ((-1 : Int) * b)) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (fact_366edf150095_2927 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (fact_366edf150095_2929 a b jx)))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (((3 : Int) + b) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (fact_366edf150095_2930 a b jx)) ∨ ((((3 : Int) + b) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (fact_366edf150095_2931 a b jx))))))
    (h1 : (fact_366edf150095_1802 a b jx jy))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  left
  right
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n360_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - a)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < (jy - b))))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1799 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ ((4 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_short (a b : Int)
    (h0 : (¬ (((3 : Int) - ((4 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_nonnegative (a b : Int)
    (h0 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((4 : Int) + b) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a)))))))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_tall (a b : Int)
    (h0 : (¬ ((((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_366edf150095_7819 a b) ∨ (fact_366edf150095_7683 a b))) ∨ (((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_366edf150095_7819 a b) ∧ (fact_366edf150095_7683 a b)) ∨ ((3 : Int) ≥ (((4 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((3 : Int) = (((4 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7819 a b) ∧ (fact_366edf150095_7683 a b) ∧ (((fact_366edf150095_6748 a b) ∨ (fact_366edf150095_6679 a b) ∨ (fact_366edf150095_7224 a b) ∨ (fact_366edf150095_7230 a b) ∨ (fact_366edf150095_6683 a b) ∨ (fact_366edf150095_6881 a b) ∨ (fact_366edf150095_6925 a b) ∨ (fact_366edf150095_6694 a b) ∨ (fact_366edf150095_6932 a b) ∨ (fact_366edf150095_6724 a b) ∨ (((((6 : Int) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2259 a b)) ∨ (fact_366edf150095_7272 a b)) ∨ ((fact_366edf150095_5165 a b) ∨ (fact_366edf150095_4459 a b) ∨ (fact_366edf150095_6384 a b) ∨ (fact_366edf150095_6472 a b) ∨ (fact_366edf150095_4543 a b) ∨ (fact_366edf150095_5293 a b) ∨ (fact_366edf150095_5464 a b) ∨ (fact_366edf150095_4727 a b) ∨ (fact_366edf150095_5645 a b) ∨ (fact_366edf150095_4990 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6905 a b)))) ∨ ((fact_366edf150095_7819 a b) ∧ (fact_366edf150095_7683 a b) ∧ ((fact_366edf150095_6748 a b) ∨ (fact_366edf150095_6679 a b) ∨ (fact_366edf150095_7224 a b) ∨ (fact_366edf150095_7230 a b) ∨ (fact_366edf150095_6683 a b) ∨ (fact_366edf150095_6881 a b) ∨ (fact_366edf150095_6925 a b) ∨ (fact_366edf150095_6694 a b) ∨ (fact_366edf150095_6932 a b) ∨ (fact_366edf150095_6724 a b) ∨ (((((6 : Int) - b) ≤ (((4 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2259 a b)) ∨ (fact_366edf150095_7272 a b)) ∧ ((fact_366edf150095_5165 a b) ∨ (fact_366edf150095_4459 a b) ∨ (fact_366edf150095_6384 a b) ∨ (fact_366edf150095_6472 a b) ∨ (fact_366edf150095_4543 a b) ∨ (fact_366edf150095_5293 a b) ∨ (fact_366edf150095_5464 a b) ∨ (fact_366edf150095_4727 a b) ∨ (fact_366edf150095_5645 a b) ∨ (fact_366edf150095_4990 a b) ∨ (((((6 : Int) - b) ≤ ((3 : Int) + (1 : Int))) ∧ (((3 : Int) + (1 : Int)) ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ ((3 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (((4 : Int) + b) + a)) ∧ ((((4 : Int) + b) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6905 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((4 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((3 : Int) ≥ run_x))
    (h6 : (a > b))
    (h7 : ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b) + a))))))
    (h8 : ((((3 : Int) + b) - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n361_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≥ run_x))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((0 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ ((((2 : Int) * a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + b) - b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((6 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((-1 : Int) * b)) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((-1 : Int) * b))) ∧ ((((3 : Int) + b) - (0 : Int)) ≤ (((4 : Int) + b) - (1 : Int))) ∧ ((((4 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + b) + a)))))))
    (h2 : (((4 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_point (a b : Int)
    (h0 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_6 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_empty (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_3228 a b) ∨ (fact_366edf150095_3134 a b) ∨ (fact_366edf150095_4224 a b) ∨ (fact_366edf150095_4313 a b) ∨ (fact_366edf150095_3142 a b) ∨ (fact_366edf150095_3359 a b) ∨ (fact_366edf150095_3393 a b) ∨ (fact_366edf150095_3151 a b) ∨ (fact_366edf150095_3414 a b) ∨ (fact_366edf150095_3158 a b) ∨ ((((((6 : Int) + a) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b))))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_366edf150095_1838 a b jx jy))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o1 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1843 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + b) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o2 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (fact_366edf150095_1859 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h9 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h12 : (fact_366edf150095_1874 a b jx jy))
    (h13 : (a ≥ b))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a > b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1875 a b jx jy))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_1858 a b jx jy))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ (5 : Int)))
    (h12 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_366edf150095_1842 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n362_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_366edf150095_1839 a b jx jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_6 a b))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_3228 a b) ∨ (fact_366edf150095_3134 a b) ∨ (fact_366edf150095_4224 a b) ∨ (fact_366edf150095_4313 a b) ∨ (fact_366edf150095_3142 a b) ∨ (fact_366edf150095_3359 a b) ∨ (fact_366edf150095_3393 a b) ∨ (fact_366edf150095_3151 a b) ∨ (fact_366edf150095_3414 a b) ∨ (fact_366edf150095_3158 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1838 a b jx jy))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h12 : (a = (b + (2 : Int))))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_1843 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1859 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_1874 a b jx jy))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jx < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_1875 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_366edf150095_1858 a b jx jy))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_1842 a b jx jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n363_o7 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_366edf150095_1839 a b jx jy))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3514 a b) ∨ (fact_366edf150095_3489 a b) ∨ (fact_366edf150095_5822 a b) ∨ (fact_366edf150095_5825 a b) ∨ (fact_366edf150095_3492 a b) ∨ (fact_366edf150095_4098 a b) ∨ (fact_366edf150095_4104 a b) ∨ (fact_366edf150095_3495 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - b)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4107 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4210 a b) ∨ (fact_366edf150095_4101 a b) ∨ (fact_366edf150095_6123 a b) ∨ (fact_366edf150095_6124 a b) ∨ (fact_366edf150095_4102 a b) ∨ (fact_366edf150095_5107 a b) ∨ (fact_366edf150095_5109 a b) ∨ (fact_366edf150095_4105 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - b)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5110 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_366edf150095_7471 a b) ∨ (fact_366edf150095_7543 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_366edf150095_7471 a b) ∧ (fact_366edf150095_7543 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7471 a b) ∧ (fact_366edf150095_7543 a b) ∧ (((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (fact_366edf150095_4666 a b) ∨ (fact_366edf150095_3956 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4041 a b) ∨ (fact_366edf150095_5046 a b)) ∨ ((fact_366edf150095_5188 a b) ∨ (fact_366edf150095_4482 a b) ∨ (fact_366edf150095_6407 a b) ∨ (fact_366edf150095_6495 a b) ∨ (fact_366edf150095_4566 a b) ∨ (fact_366edf150095_5316 a b) ∨ (fact_366edf150095_5475 a b) ∨ (fact_366edf150095_4762 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5015 a b) ∨ (fact_366edf150095_5728 a b)))) ∨ ((fact_366edf150095_7471 a b) ∧ (fact_366edf150095_7543 a b) ∧ ((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (fact_366edf150095_4666 a b) ∨ (fact_366edf150095_3956 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4041 a b) ∨ (fact_366edf150095_5046 a b)) ∧ ((fact_366edf150095_5188 a b) ∨ (fact_366edf150095_4482 a b) ∨ (fact_366edf150095_6407 a b) ∨ (fact_366edf150095_6495 a b) ∨ (fact_366edf150095_4566 a b) ∨ (fact_366edf150095_5316 a b) ∨ (fact_366edf150095_5475 a b) ∨ (fact_366edf150095_4762 a b) ∨ (((((4 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5015 a b) ∨ (fact_366edf150095_5728 a b))))))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ (fact_366edf150095_3053 a b run_x) ∨ (fact_366edf150095_2355 a b run_x) ∨ ((((7 : Int) ≥ ((4 : Int) - b)) ∧ ((7 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3056 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n364_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (fact_366edf150095_3561 a b run_x) ∨ (fact_366edf150095_3320 a b run_x) ∨ (((((4 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3605 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3511 a b) ∨ (fact_366edf150095_3481 a b) ∨ (fact_366edf150095_5816 a b) ∨ (fact_366edf150095_5818 a b) ∨ (fact_366edf150095_3483 a b) ∨ (fact_366edf150095_4083 a b) ∨ (fact_366edf150095_4093 a b) ∨ (fact_366edf150095_3486 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - b)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4094 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((fact_366edf150095_3236 a b) ∨ (fact_366edf150095_3195 a b) ∨ (fact_366edf150095_5102 a b) ∨ (fact_366edf150095_5104 a b) ∨ (fact_366edf150095_3196 a b) ∨ (fact_366edf150095_3432 a b) ∨ (fact_366edf150095_3433 a b) ∨ (fact_366edf150095_3199 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - b)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3434 a b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_tall (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7388 a b) ∨ (fact_366edf150095_7349 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7388 a b) ∧ (fact_366edf150095_7349 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7388 a b) ∧ (fact_366edf150095_7349 a b) ∧ (((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_3943 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4994 a b)) ∨ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3399 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3688 a b)))) ∨ ((fact_366edf150095_7388 a b) ∧ (fact_366edf150095_7349 a b) ∧ ((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_3943 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4994 a b)) ∧ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3399 a b) ∨ (((((4 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3688 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_3046 a b run_x) ∨ (fact_366edf150095_2350 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - b)) ∧ ((6 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3050 a b run_x)))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n365_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3560 a b run_x) ∨ (fact_366edf150095_3319 a b run_x) ∨ (((((4 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3595 a b run_x))))
    (h1 : (run_x ≤ a))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

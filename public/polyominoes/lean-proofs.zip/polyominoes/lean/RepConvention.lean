import RectangleRep
import RepObstruction

namespace PolyominoFormal

/-- Match the convenient reflected T used in the obstruction to the same
    integer-cell dilation used for all the other polyominoes. -/
def Tiling.reflectScaledT {a k : Int} (ha : 0≤a) (hk : 0<k)
    (T : Tiling a 1 1 0 (CoreBoundaryObstructions.ScaledCross a 1 1 0 k)) :
    Tiling a 1 1 0 (RepObstruction.Target a k) :=
  (T.mirrorX.translate ((a+1)*k-1) 0).congr (by
    intro x y
    have nonneg := Int.mul_nonneg ha (by omega : 0≤k)
    unfold CoreBoundaryObstructions.ScaledCross RepObstruction.Target
    simp only [Int.add_mul,Int.one_mul,Int.zero_mul,Int.neg_mul,Int.sub_zero]
    omega)

theorem no_rep_of_no_target {a : Int} (ha : 0≤a)
    (impossible : ∀ k : Int, 2≤k → ¬Tiles a 1 1 0 (RepObstruction.Target a k)) :
    ¬RepTileable a 1 1 0 := by
  rintro ⟨k,hk,⟨T⟩⟩
  exact impossible k (by omega) ⟨T.reflectScaledT ha (by omega)⟩

theorem no_rep_of_replay {a : Int} (ha : 4≤a) (replay : RepObstruction.Replay a) :
    ¬RepTileable a 1 1 0 :=
  no_rep_of_no_target (by omega) (fun k hk => RepObstruction.no_target_of_replay ha hk replay)

#print axioms no_rep_of_replay
end PolyominoFormal

import LHalfPlaneVleftAssembly
import LHalfPlaneFiveThree
import LQuadrantHpBoundaryallUnequalVleftLongneighborPrunedGeometry
import LQuadrantHpBoundaryallUnequalVleftEastneighborPrunedGeometry

namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits LRegion

theorem west_long_neighbor {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    LongNeighborObstruction a b ⟨-1,0,0,b,a,0⟩ := by
  intro T hO hV hL
  by_cases special : a=5 ∧ b=3
  · rcases special with ⟨rfl,rfl⟩
    exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
  apply HP_boundaryall_unequal_vleft_longneighbor_pruned_anchored_obstruction a b
    (by omega) hb hab ha (by omega) T hO ?_ hL
  simpa only [Int.add_comm] using hV

theorem east_long_neighbor {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    LongNeighborObstruction a b ⟨-a-1,0,a,b,0,0⟩ := by
  intro T hO hV hL
  by_cases special : a=5 ∧ b=3
  · rcases special with ⟨rfl,rfl⟩
    exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
  apply HP_boundaryall_unequal_vleft_eastneighbor_pruned_anchored_obstruction a b
    (by omega) hb hab ha (by omega) T hO ?_ ?_
  · simpa only [Int.add_comm] using hV
  · have eq : (⟨-a-1,0,a,b,0,0⟩ : Cross)=⟨-1+(-1)*a,0,a,b,0,0⟩ := by
      apply same_eq; dsimp [Same]; omega
    simpa only [eq] using hL

#print axioms west_long_neighbor
#print axioms east_long_neighbor
end PolyominoFormal.LHalfPlaneShortbarAssembly

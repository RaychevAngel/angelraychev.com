import LHalfPlaneAlternatingPattern
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits
set_option maxHeartbeats 300000

def reflectPocket {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Tiling a b 0 0 HalfPlane :=
  (T.mirrorX.translate (2*a+1) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])

def reflectCross (a : Int) (t : Cross) : Cross :=
  ⟨2*a+1-t.x,t.y,t.west,t.north,t.east,t.south⟩

theorem reflect_cross_twice (a : Int) (t : Cross) : reflectCross a (reflectCross a t)=t := by
  apply same_eq; dsimp [Same,reflectCross]; omega

theorem reflect_pocket_member {a b : Int} (T : Tiling a b 0 0 HalfPlane)
    {t : Cross} (ht : T.world t) : (reflectPocket T).world (reflectCross a t) := by
  refine ⟨mirrorX t,⟨t,ht,rfl⟩,?_⟩
  apply same_eq; dsimp [Same,shift,mirrorX,reflectCross]; omega

theorem reflect_pocket_unmember {a b : Int} (T : Tiling a b 0 0 HalfPlane)
    {t : Cross} (ht : (reflectPocket T).world t) : T.world (reflectCross a t) := by
  rcases ht with ⟨v,⟨u,hu,rfl⟩,e⟩
  have eq : reflectCross a u=t := by
    rw [←e]
    apply same_eq; dsimp [Same,shift,mirrorX,reflectCross]; omega
  have doubled := congrArg (reflectCross a) eq
  rw [reflect_cross_twice] at doubled
  exact doubled ▸ hu

theorem reflect_eight_bars {a b : Int} (T : Tiling a b 0 0 HalfPlane)
    (bars : EightBars T) : EightBars (reflectPocket T) := by
  rcases bars with ⟨hL0,hL1,h0,h1,h2,h3,hR0,hR1⟩
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_⟩
  · simpa only [reflectCross,show 2*a+1-(4*a+4)=-2*a-3 by omega] using reflect_pocket_member T hR1
  · simpa only [reflectCross,show 2*a+1-(4*a+3)=-2*a-2 by omega] using reflect_pocket_member T hR0
  · simpa only [reflectCross,show 2*a+1-(2*a+2)=-1 by omega] using reflect_pocket_member T h3
  · simpa only [reflectCross,show 2*a+1-(2*a+1)=0 by omega] using reflect_pocket_member T h2
  · simpa only [reflectCross,show 2*a+1-0=2*a+1 by omega] using reflect_pocket_member T h1
  · simpa only [reflectCross,show 2*a+1-(-1)=2*a+2 by omega] using reflect_pocket_member T h0
  · simpa only [reflectCross,show 2*a+1-(-2*a-2)=4*a+3 by omega] using reflect_pocket_member T hL1
  · simpa only [reflectCross,show 2*a+1-(-2*a-3)=4*a+4 by omega] using reflect_pocket_member T hL0

theorem right_pattern_from_reflected_left {a b : Int} (T : Tiling a b 0 0 HalfPlane)
    (pattern : LeftLongPattern (reflectPocket T)) : RightLongPattern T := by
  rcases pattern with h | h | ⟨bound,h⟩
  · left
    simpa only [reflectCross,show 2*a+1-1=2*a by omega] using reflect_pocket_unmember T h
  · right; left
    simpa only [reflectCross,show 2*a+1-(a+1)=a by omega] using reflect_pocket_unmember T h
  · right; right
    refine ⟨by omega,?_⟩
    simpa only [reflectCross,show 2*a+1-(a+b+2)=a-b-1 by omega] using reflect_pocket_unmember T h

/-- This assembly leaves precisely the stated wall-dependent obstruction
as an explicit input; it does not claim that obstruction has been proved. -/
theorem delta_two_of_outer_obstruction {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (outer : ∀U : Tiling a b 0 0 HalfPlane, EightBars U →
      ¬(U.world ⟨1,1,b,a,0,0⟩ ∧ U.world ⟨2*b+2,1,0,a,b,0⟩))
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) : a=b+2 := by
  have left := left_long_pattern_of_no_outer ha hb hab T bars (outer T bars)
  have ubars := reflect_eight_bars T bars
  have uleft := left_long_pattern_of_no_outer ha hb hab (reflectPocket T) ubars
    (outer (reflectPocket T) ubars)
  exact endpoint_patterns_force_delta_two ha hb hab T left
    (right_pattern_from_reflected_left T uleft)

/-- At the forced arm difference, the first row consists of exactly two
bars with their stems at the outer ends of the pocket. -/
theorem mixed_motif_of_delta_two {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (delta : a=b+2)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) :
    (T.world ⟨1,1,a,b,0,0⟩ ∧ T.world ⟨2*a,1,0,a,b,0⟩) ∨
    (T.world ⟨1,1,b,a,0,0⟩ ∧ T.world ⟨2*a,1,0,b,a,0⟩) := by
  obtain ⟨l,r,m,s,hl,hr,hm,hs,bound,first,second,dirs⟩ := first_two_bars_all ha hb hab T bars
  have ubars := reflect_eight_bars T bars
  rcases hl with hl | hl
  · subst l
    have mb : m=b := by omega
    subst m
    have sb : s=b := by
      rcases hs with hs | hs
      · subst s
        apply False.elim
        apply no_first_short_away_all ha hb hab (reflectPocket T)
        · have h2 := bars.2.2.2.2.1
          simpa only [reflectCross,show 2*a+1-(2*a+1)=0 by omega] using reflect_pocket_member T h2
        · have h := reflect_pocket_member T second
          simpa only [reflectCross,Int.add_zero,Int.sub_zero,show a+b-b=a by omega,
            show 2*a+1-(a+2)=b+1 by omega] using h
      · exact hs
    subst s
    rcases hr with hr | hr
    · subst r
      left; constructor
      · simpa only [Int.add_zero,Int.sub_zero,show a+b-a=b by omega] using first
      · simpa only [Int.sub_self,show a+b-b=a by omega,show a+2+b=2*a by omega] using second
    · subst r
      apply False.elim
      apply no_left_junction_after_first_short ha hb hab (Or.inl rfl) (reflectPocket T) ubars
      · simpa only [reflectCross,Int.sub_self,show a+b-b=a by omega,
          show 2*a+1-(a+2+b)=1 by omega] using reflect_pocket_member T second
      · simpa only [reflectCross,Int.sub_self,show a+b-a=b by omega,
          show 2*a+1-(1+a)=b+2 by omega] using reflect_pocket_member T first
  · subst l
    obtain ⟨rzero,sm⟩ := dirs rfl
    subst r; subst s
    rcases hm with hm | hm
    · subst m
      right; constructor
      · simpa only [Int.add_zero,Int.sub_zero,show a+b-b=a by omega] using first
      · simpa only [Int.sub_self,show a+b-a=b by omega,show b+2+a=2*a by omega] using second
    · subst m
      have next : T.world ⟨(b+2)+b,1,b-b,a+b-b,b,0⟩ := second
      obtain ⟨n,t,hn,_,hnBound,_⟩ := successor_horizontal (q:=b+2) ha hb hab (Or.inr rfl)
        (Or.inr rfl) (by omega) (by omega) T bars next
      omega

#print axioms mixed_motif_of_delta_two
#print axioms delta_two_of_outer_obstruction
end PolyominoFormal.LHalfPlaneAlternating

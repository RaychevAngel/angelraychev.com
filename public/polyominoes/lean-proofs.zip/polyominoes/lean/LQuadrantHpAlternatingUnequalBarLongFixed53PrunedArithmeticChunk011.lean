import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o3 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o6 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n275_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o0 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o1 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o3 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (3 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o5 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : (a = (5 : Int)))
    (h6 : (¬ ((((8 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n276_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((8 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : (((8 : Int) > (jx + a)) ∨ ((8 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o2 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o3 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (((8 : Int) > (jx + (0 : Int))) ∨ ((8 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (((8 : Int) > (jx + (0 : Int))) ∨ ((8 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n277_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((8 : Int) - (5 : Int))) ∨ (((8 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o0 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (3 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : (a = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (¬ ((((-7 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o2 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o4 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o5 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : (¬ ((((-5 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (a = (5 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n278_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-7 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-7 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-7 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-7 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o0 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-7 : Int) > (jx + a)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o3 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o4 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o6 (a b jx jy : Int)
    (h0 : (¬ ((((-5 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n279_o7 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-7 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-7 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-7 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-7 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (3 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((-5 : Int) > (jx + a)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o3 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-5 : Int) > (jx + (0 : Int))) ∨ ((-5 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o6 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-5 : Int) > (jx + b)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n280_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (3 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((-5 : Int) > (jx + a)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o1 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o4 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : (((-5 : Int) > (jx + (0 : Int))) ∨ ((-5 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-5 : Int) > (jx + b)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n281_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (3 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((1 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a = (5 : Int)))
    (h3 : (¬ ((((1 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h4 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h5 : (b = (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o2 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (¬ ((((1 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h6 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h7 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (¬ ((((1 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (a = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n282_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (3 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o0 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o4 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n283_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_point (a b : Int)
    (h0 : (¬ (((0 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((0 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_empty (a b : Int)
    (h0 : (((((0 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((0 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ (((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o0 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h6 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h7 : (¬ ((((-5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o2 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h1 : (a = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h7 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o3 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o4 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o5 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o6 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n284_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : (a = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (¬ ((((-5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h9 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (4 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (5 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o0 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h7 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h9 : (¬ ((((-7 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n285_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-7 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-7 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-7 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-7 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((-7 : Int) > (jx + a)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h7 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n286_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (4 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (5 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o0 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (((-5 : Int) > (jx + a)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o4 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o5 (a b jx jy : Int)
    (h0 : (((-5 : Int) > (jx + (0 : Int))) ∨ ((-5 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o6 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (5 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-5 : Int) > (jx + b)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n287_o7 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_empty (a b : Int)
    (h0 : (((((2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((2 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o1 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a = (5 : Int)))
    (h6 : (¬ ((((2 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o2 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : (b = (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o4 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : (((jx + (0 : Int)) < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < (jx - b)) ∨ ((7 : Int) > jy) ∨ ((7 : Int) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o6 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n288_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (b = (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o3 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o4 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : ((jx < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n289_o7 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_point (a b : Int)
    (h0 : (¬ (((0 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((0 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_empty (a b : Int)
    (h0 : (((((0 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((-5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h6 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h7 : (a = (5 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h9 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o1 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o2 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h5 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o4 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o6 (a b jx jy : Int)
    (h0 : (¬ ((((-3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (a = (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n290_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((-5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h7 : (b = (3 : Int)))
    (h8 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h9 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h10 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : (a = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (¬ ((((-7 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (3 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n291_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-7 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-7 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-7 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-7 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((-7 : Int) > (jx + a)) ∨ ((-7 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h7 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (b = (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n292_o7 (a b jx jy : Int)
    (h0 : ((jx < ((-7 : Int) - (0 : Int))) ∨ (((-7 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((0 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((0 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_empty (a b : Int)
    (h0 : (((((0 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-13 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((0 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (23 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (24 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((0 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((0 : Int) ≥ ((-3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-3 : Int) + (3 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o0 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + (3 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h2 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o3 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + (3 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o4 (a b jx jy : Int)
    (h0 : ((((0 : Int) ≥ (jx - b)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + (3 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((0 : Int) ≥ (jx - a)) ∧ ((0 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o6 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + (3 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n293_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (3 : Int))) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : ((((0 : Int) ≥ (jx - (0 : Int))) ∧ ((0 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((0 : Int) ≥ jx) ∧ ((0 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((-3 : Int) - (0 : Int))) ∨ (((-3 : Int) + (3 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((-2 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (3 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-5 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((-5 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((-5 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-5 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o0 (a b jx jy : Int)
    (h0 : (((-5 : Int) > (jx + a)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o5 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - (5 : Int))) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-5 : Int) > (jx + b)) ∨ ((-5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n294_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-5 : Int) - (0 : Int))) ∨ (((-5 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((7 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_empty (a b : Int)
    (h0 : (((((7 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o0 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (¬ ((((7 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a = (5 : Int)))
    (h6 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o2 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o3 (a b jx jy : Int)
    (h0 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h9 : (¬ ((((10 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h3 : (b = (3 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((7 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h6 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o6 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (¬ ((((7 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n295_o7 (a b jx jy : Int)
    (h0 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : (b = (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_point (a b : Int)
    (h0 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((7 : Int) > (jx + a)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o1 (a b jx jy : Int)
    (h0 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o4 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o5 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (((7 : Int) > (jx + b)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n296_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b = (3 : Int)))
    (h2 : (¬ ((((8 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((6 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (6 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((7 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((7 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((8 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((8 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (((8 : Int) > (jx + a)) ∨ ((8 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o1 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o2 (a b jx jy : Int)
    (h0 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o5 (a b jx jy : Int)
    (h0 : (((8 : Int) > (jx + (0 : Int))) ∨ ((8 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((8 : Int) > (jx + b)) ∨ ((8 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n297_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_point (a b : Int)
    (h0 : (¬ (((7 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_empty (a b : Int)
    (h0 : (((((7 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((7 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((7 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h6 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o1 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a = (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : (¬ ((((7 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h2 : (a = (5 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h5 : (b = (3 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (¬ ((((7 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h2 : (a = (5 : Int)))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((10 : Int) > (jx + b)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n298_o7 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (((7 : Int) > (jx + a)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o1 (a b jx jy : Int)
    (h0 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o2 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o3 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o4 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o5 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((7 : Int) > (jx + (0 : Int))) ∨ ((7 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o6 (a b jx jy : Int)
    (h0 : (((7 : Int) > (jx + b)) ∨ ((7 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (5 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n299_o7 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

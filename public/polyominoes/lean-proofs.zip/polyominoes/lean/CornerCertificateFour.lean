import CornerCertificateFourAlpha
import CornerCertificateFourBeta
import CornerCertificateFourGamma
import CornerCertificateFourBetaTranspose
import CornerCertificateFourGammaTranspose

namespace CornerCertificate
open CrossUnits

theorem four_local (world : Cross → Prop) (h : Int) (k : Kind)
    (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean k 0 0 B) :
    Transition world h k B := by
  cases k with
  | alpha => exact four_alpha_local world h B copies separate cover ceiling closed bounded clean
  | beta => exact four_beta_local world h B copies separate cover ceiling closed bounded clean
  | gamma => exact four_gamma_local world h B copies separate cover ceiling closed bounded clean
  | betaTranspose => exact four_betaTranspose_local world h B copies separate cover ceiling closed bounded clean
  | gammaTranspose => exact four_gammaTranspose_local world h B copies separate cover ceiling closed bounded clean

#print axioms four_local

end CornerCertificate
